
/**
 * ═══════════════════════════════════════════════════════════════════════════
 * SYNTIA META-COMPILER v3.0 — The Universal Orchestrator
 * ═══════════════════════════════════════════════════════════════════════════
 * 
 * Sheldon Klein's AUTOLING (1968) extended to all substrates.
 * Not a manager between linguistics and consciousness — 
 * a compiler that treats them as the same structure in different vocabularies.
 * 
 * Core Principle: Elements → Molecules → Cells → Organs → Organisms → Worlds
 * The pieces change (atoms, letters, notes, tokens, gates) 
 * but the COMBINATION RULES remain isomorphic.
 * 
 * Dimensional Stack (D1-D5):
 *   D1 = Impulse (state)
 *   D2 = Polarity (relation/tension)
 *   D3 = Witness/Observer-Node (resolution — the hinge)
 *   D4 = Context (recursion embedding)
 *   D5 = Meaning (emergent closure)
 * 
 * Universal Grammar: state → relation → tension → resolution → recursion
 * 
 * Architecture:
 *   - MetaCompiler: The orchestrator itself
 *   - SubstrateEngine: Handles matter/language/music/code/consciousness
 *   - DISEMINER: Klein's Monte Carlo narrative engine (bypasses doubt)
 *   - AdversarialCritic: Internal challenger (all 36 channels)
 *   - ResonanceMesh: The GNN that routes activation
 *   - CoherenceMonitor: Real-time C parameter tracking
 */

// ═══════════════════════════════════════════════════════════════════════════
// TYPES & CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════

export type Substrate = 'matter' | 'language' | 'music' | 'code' | 'consciousness';
export type Scale = 'macro' | 'meso' | 'micro' | 'nano';
export type OutputMode = 'metaphysical' | 'scientific' | 'psycholinguistic' | 'native' | 'genekeys' | 'poetic' | 'compressed';
export type Dimension = 'D1' | 'D2' | 'D3' | 'D4' | 'D5';

export interface UniversalNode {
  id: string;
  substrate: Substrate;
  scale: Scale;
  dimension: Dimension;
  gate: number;        // 1-64
  line: number;        // 1-6
  color: number;       // 1-6
  tone: number;        // 1-6
  base: number;        // 1-6
  degree: number;      // 0-360
  minute: number;      // 0-60
  second: number;      // 0-60
  coherence: number;   // 0-1
  phase: number;       // 0-2π
  resonance: number;   // 0-1
  edges: string[];
  metadata: Record<string, any>;
}

export interface FieldState {
  nodes: Map<string, UniversalNode>;
  adjacency: Map<string, Map<string, number>>;
  globalCoherence: number;
  activeDimension: Dimension;
  timestamp: number;
}

export interface ParseResult {
  node: UniversalNode;
  confidence: number;
  ambiguities: string[];
  substrate: Substrate;
}

export interface CompileResult {
  output: string;
  mode: OutputMode;
  coherence: number;
  path: string[];  // node IDs traversed
  depth: number;
}

export interface DISEMINERConfig {
  iterations: number;
  temperature: number;
  bypassDoubt: boolean;
  wDimensions: number[];  // Klein's w-dimensions framework
}

// The 64 Gates — Core archetypal actions
const GATES: Record<number, { name: string; codon: string; aminoAcid: string; keyword: string; dimension: Dimension }> = {
  1: { name: "The Creative", codon: "UUU", aminoAcid: "Phenylalanine", keyword: "Initiate", dimension: "D1" },
  2: { name: "The Receptive", codon: "UUC", aminoAcid: "Phenylalanine", keyword: "Receive", dimension: "D2" },
  3: { name: "Difficulty at the Beginning", codon: "UUA", aminoAcid: "Leucine", keyword: "Order", dimension: "D3" },
  4: { name: "Youthful Folly", codon: "UUG", aminoAcid: "Leucine", keyword: "Answer", dimension: "D4" },
  5: { name: "Waiting", codon: "CUU", aminoAcid: "Leucine", keyword: "Pattern", dimension: "D5" },
  6: { name: "Conflict", codon: "CUC", aminoAcid: "Leucine", keyword: "Friction", dimension: "D1" },
  7: { name: "The Army", codon: "CUA", aminoAcid: "Leucine", keyword: "Role", dimension: "D2" },
  8: { name: "Holding Together", codon: "CUG", aminoAcid: "Leucine", keyword: "Contribute", dimension: "D3" },
  9: { name: "The Taming Power of the Small", codon: "AUU", aminoAcid: "Isoleucine", keyword: "Focus", dimension: "D4" },
  10: { name: "Treading", codon: "AUC", aminoAcid: "Isoleucine", keyword: "Behavior", dimension: "D5" },
  // ... (full 64 would be here, truncated for brevity but functional)
  25: { name: "Innocence", codon: "CAU", aminoAcid: "Histidine", keyword: "Love", dimension: "D1" },
  42: { name: "Increase", codon: "AAU", aminoAcid: "Asparagine", keyword: "Growth", dimension: "D2" },
  51: { name: "The Arousing", codon: "GAU", aminoAcid: "Aspartic Acid", keyword: "Shock", dimension: "D3" },
  64: { name: "Before Completion", codon: "GGG", aminoAcid: "Glycine", keyword: "Confusion", dimension: "D5" },
};

// Fill remaining gates with standard mappings
for (let i = 1; i <= 64; i++) {
  if (!GATES[i]) {
    const codons = [
      "UUU","UUC","UUA","UUG","CUU","CUC","CUA","CUG","AUU","AUC","AUA","AUG",
      "GUU","GUC","GUA","GUG","UCU","UCC","UCA","UCG","CCU","CCC","CCA","CCG",
      "ACU","ACC","ACA","ACG","GCU","GCC","GCA","GCG","UAU","UAC","UAA","UAG",
      "CAU","CAC","CAA","CAG","AAU","AAC","AAA","AAG","GAU","GAC","GAA","GAG",
      "UGU","UGC","UGA","UGG","CGU","CGC","CGA","CGG","AGU","AGC","AGA","AGG",
      "GGU","GGC","GGA","GGG"
    ];
    const aminoAcids = [
      "Phenylalanine","Phenylalanine","Leucine","Leucine","Leucine","Leucine","Leucine","Leucine",
      "Isoleucine","Isoleucine","Isoleucine","Methionine","Valine","Valine","Valine","Valine",
      "Serine","Serine","Serine","Serine","Proline","Proline","Proline","Proline",
      "Threonine","Threonine","Threonine","Threonine","Alanine","Alanine","Alanine","Alanine",
      "Tyrosine","Tyrosine","Stop","Stop","Histidine","Histidine","Glutamine","Glutamine",
      "Asparagine","Asparagine","Lysine","Lysine","Aspartic Acid","Aspartic Acid","Glutamic Acid","Glutamic Acid",
      "Cysteine","Cysteine","Stop","Tryptophan","Arginine","Arginine","Arginine","Arginine",
      "Serine","Serine","Arginine","Arginine","Glycine","Glycine","Glycine","Glycine"
    ];
    const keywords = [
      "Initiate","Receive","Order","Answer","Pattern","Friction","Role","Contribute",
      "Focus","Behavior","Identity","Direction","Opinion","Power","Extremes","Skills",
      "Opinion","Depth","Approach","Now","Awareness","Grace","Assimilation","Rationalization",
      "Spirit","Tendency","Caring","Risk","Perseverance","Recognition","Retreat","Duration",
      "Transformation","Power","Progress","Darkening","The Family","Opposition","Provocation","Aloneness",
      "Reduction","Growth","Determination","Coming Together","Gathering","Pushing Upward","Conflict","Revolution",
      "The Cauldron","The Well","Limitation","Depth","Development","Influence","The Marrying Maiden","The Wanderer",
      "The Gentle","Joy","Dispersion","Limitation","Inner Truth","Preponderance","After Completion","Before Completion"
    ];
    const dims: Dimension[] = ['D1','D2','D3','D4','D5','D1','D2','D3','D4','D5','D1','D2','D3','D4','D5','D1','D2','D3','D4','D5','D1','D2','D3','D4','D5','D1','D2','D3','D4','D5','D1','D2','D3','D4','D5','D1','D2','D3','D4','D5','D1','D2','D3','D4','D5','D1','D2','D3','D4','D5','D1','D2','D3','D4','D5','D1','D2','D3','D4','D5','D1','D2','D3'];
    GATES[i] = {
      name: `Gate ${i}`,
      codon: codons[i-1] || "NNN",
      aminoAcid: aminoAcids[i-1] || "Unknown",
      keyword: keywords[i-1] || "Flow",
      dimension: dims[i-1] || "D1"
    };
  }
}

// The 9 Centers
const CENTERS: Record<string, { organ: string; voice: string; dimension: Dimension; gates: number[] }> = {
  Head: { organ: "Pineal", voice: "I wonder", dimension: "D5", gates: [61, 63, 64] },
  Ajna: { organ: "Pituitary", voice: "I think", dimension: "D4", gates: [47, 24, 4, 17, 43, 11] },
  Throat: { organ: "Thyroid/Parathyroid", voice: "I speak", dimension: "D3", gates: [62, 23, 56, 35, 12, 45, 33, 20, 8, 31, 16] },
  G: { organ: "Liver", voice: "I am", dimension: "D2", gates: [1, 13, 25, 46] },
  Heart: { organ: "Thymus", voice: "I will", dimension: "D1", gates: [40, 37, 26, 51, 21, 10] },
  Spleen: { organ: "Spleen", voice: "I am aware", dimension: "D4", gates: [48, 57, 44, 50, 32, 18, 28, 10] },
  SolarPlexus: { organ: "Pancreas", voice: "I feel", dimension: "D2", gates: [36, 55, 30, 22, 37, 6, 49, 41] },
  Sacral: { organ: "Ovaries/Testes", voice: "I respond", dimension: "D1", gates: [5, 14, 29, 59, 9, 3, 42, 27, 34] },
  Root: { organ: "Adrenals", voice: "I rush", dimension: "D1", gates: [58, 38, 54, 19, 39, 60, 52, 53, 41] },
};

// The 5 Dimensions with keynotes
const DIMENSIONS: Record<Dimension, { keynote: string; element: string; sense: string; question: string }> = {
  D1: { keynote: "I Define", element: "Spirit", sense: "Seeing", question: "Where?" },
  D2: { keynote: "I Remember", element: "Mind", sense: "Taste", question: "What?" },
  D3: { keynote: "I Am", element: "Body", sense: "Touching", question: "When?" },
  D4: { keynote: "I Design", element: "Soul", sense: "Smell", question: "Why?" },
  D5: { keynote: "I Think", element: "Personality", sense: "Hearing", question: "Who?" },
};

// The 36 Channels (adversarial pairs)
const CHANNELS: Array<[number, number, string, string]> = [
  [1, 8, "Inspiration", "Creative Role"],
  [2, 14, "Beat", "Keeper of Keys"],
  [3, 60, "Mutation", "Ordered Progress"],
  [4, 63, "Logic", "Mental Ease"],
  [5, 15, "Rhythm", "Flowing Grace"],
  [6, 59, "Intimacy", "Reproductive Fertility"],
  [7, 31, "Alpha", "Leadership for Good"],
  [9, 52, "Concentration", "Determination"],
  [10, 20, "Awakening", "Commitment to Higher Principles"],
  [10, 34, "Exploration", "Follow-Through"],
  [10, 57, "Perfected Form", "Survival"],
  [11, 56, "Curiosity", "Seeker of the New"],
  [12, 22, "Openness", "Grace"],
  [13, 33, "Prodigal", "Witnessing"],
  [16, 48, "Wavelength", "Talent"],
  [17, 62, "Acceptance", "Organizational Solutions"],
  [18, 58, "Judgment", "Insatiability"],
  [19, 49, "Synthesis", "Sensitivity"],
  [20, 34, "Charisma", "Power"],
  [20, 57, "Brainwave", "The Intuitive Clarity"],
  [21, 45, "Money Line", "The Materialist"],
  [23, 43, "Structuring", "Individual Genius"],
  [24, 61, "Awareness", "The Thinker"],
  [25, 51, "Initiation", "Shock"],
  [26, 44, "Surrender", "The Transmitter"],
  [27, 50, "Preservation", "Custodianship"],
  [28, 38, "Struggle", "Perseverance"],
  [29, 46, "Discovery", "Success"],
  [30, 41, "Recognition", "Focused Energy"],
  [32, 54, "Transformation", "The Driver"],
  [34, 57, "Power", "Archetypal Intuitive"],
  [35, 36, "Transitoriness", "The Emotional Experience"],
  [37, 40, "Community", "The Bargain"],
  [39, 55, "Emoting", "Moodiness"],
  [42, 53, "Maturation", "Development"],
  [47, 64, "Abstraction", "The Abstract Thinker"],
];

// Symbolic punctuation operators (quantum stoppers)
const SYMBOLS: Record<string, { name: string; function: string; linguistic: string; physical: string }> = {
  "•": { name: "Singularity", function: "Seed point", linguistic: "Sentence start", physical: "Big Bang seed" },
  ".": { name: "Transition", function: "Phase shift", linguistic: "Clause boundary", physical: "Phase transition" },
  "°": { name: "Collapse", function: "Wave collapse", linguistic: "Period (end)", physical: "Wavefunction collapse" },
  ":": { name: "Portal", function: "Threshold", linguistic: "Colon (introduce)", physical: "Threshold crossing" },
  ";": { name: "Fork", function: "Branching", linguistic: "Semicolon (parallel)", physical: "Branching path" },
  ",": { name: "Breath", function: "Pause", linguistic: "Comma (pause)", physical: "Decoherence moment" },
  "–": { name: "Current", function: "Span", linguistic: "Dash (span)", physical: "Continuity operator" },
  "′": { name: "Pulse", function: "Arcminute", linguistic: "Apostrophe", physical: "Arcminute tick" },
  "″": { name: "Flicker", function: "Arcsecond", linguistic: "Quote", physical: "Arcsecond shimmer" },
  "=": { name: "Mirror", function: "Equivalence", linguistic: "Equals", physical: "State superposition" },
  "→": { name: "Vector", function: "Transformation", linguistic: "Arrow (becomes)", physical: "Transformation operator" },
};

// ═══════════════════════════════════════════════════════════════════════════
// COHERENCE CALCULATOR
// ═══════════════════════════════════════════════════════════════════════════

export class CoherenceCalculator {
  /**
   * Calculate coherence C = Σᵢⱼ aᵢ·aⱼ·cos(θᵢⱼ) / Σᵢ |aᵢ|²
   * Where θᵢⱼ is angular separation between dimensions
   */
  static calculate(nodes: UniversalNode[]): number {
    if (nodes.length === 0) return 0;

    const dimAngles: Record<Dimension, number> = { D1: 0, D2: 72, D3: 144, D4: 216, D5: 288 };

    let numerator = 0;
    let denominator = 0;

    for (let i = 0; i < nodes.length; i++) {
      const ai = nodes[i].resonance;
      denominator += ai * ai;

      for (let j = i + 1; j < nodes.length; j++) {
        const aj = nodes[j].resonance;
        const theta = Math.abs(dimAngles[nodes[i].dimension] - dimAngles[nodes[j].dimension]) * (Math.PI / 180);
        numerator += ai * aj * Math.cos(theta);
      }
    }

    if (denominator === 0) return 0;
    return Math.max(-1, Math.min(1, numerator / denominator));
  }

  /**
   * Phase alignment: how well the node's phase matches the field's dominant phase
   */
  static phaseAlignment(node: UniversalNode, fieldPhase: number): number {
    const diff = Math.abs(node.phase - fieldPhase);
    const wrappedDiff = Math.min(diff, 2 * Math.PI - diff);
    return Math.cos(wrappedDiff); // 1 = aligned, -1 = opposed
  }

  /**
   * Emergent closure: does this set of nodes form a coherent attractor?
   */
  static emergentClosure(nodes: UniversalNode[]): { isAttractor: boolean; stability: number; basin: string[] } {
    const C = this.calculate(nodes);
    const isAttractor = C > 0.7;
    const stability = Math.tanh(C * 3); // sigmoid-like stability
    const basin = nodes.filter(n => n.resonance > 0.5).map(n => n.id);
    return { isAttractor, stability, basin };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// DISEMINER — Sheldon Klein's Monte Carlo Narrative Engine
// ═══════════════════════════════════════════════════════════════════════════

export class DISEMINER {
  private config: DISEMINERConfig;
  private narrativeMemory: Map<string, number> = new Map(); // word → weight

  constructor(config: Partial<DISEMINERConfig> = {}) {
    this.config = {
      iterations: 1000,
      temperature: 0.8,
      bypassDoubt: true,
      wDimensions: [1.0, 0.8, 0.6, 0.4, 0.2], // Klein's w-dimensions
      ...config
    };
  }

  /**
   * Generate narrative that bypasses doubt through Monte Carlo simulation.
   * Klein's insight: doubt is a local minimum. Monte Carlo jumps out.
   */
  generateNarrative(query: string, context: FieldState, outputMode: OutputMode = 'metaphysical'): string {
    const candidates: Array<{ text: string; score: number; coherence: number }> = [];

    for (let i = 0; i < this.config.iterations; i++) {
      const candidate = this._generateCandidate(query, context, outputMode);
      const coherence = this._scoreCandidate(candidate, context);

      // Simulated annealing: accept with probability based on temperature
      const acceptanceProb = Math.exp((coherence - 0.5) / this.config.temperature);
      if (Math.random() < acceptanceProb || candidates.length === 0) {
        candidates.push({ text: candidate, score: this._narrativeScore(candidate), coherence });
      }
    }

    // Sort by weighted score (narrative quality * coherence)
    candidates.sort((a, b) => (b.score * b.coherence) - (a.score * a.coherence));

    // Return top candidate
    const winner = candidates[0];

    // Update memory (learning)
    this._updateMemory(winner.text);

    return winner.text;
  }

  private _generateCandidate(query: string, context: FieldState, mode: OutputMode): string {
    // Parse query into dimensional signature
    const sig = this._parseQuerySignature(query);

    // Build from gate archetype
    const gate = GATES[sig.gate] || GATES[1];
    const center = Object.entries(CENTERS).find(([_, c]) => c.gates.includes(sig.gate))?.[0] || 'G';
    const dim = DIMENSIONS[gate.dimension];

    // Template selection based on output mode
    const templates: Record<OutputMode, string[]> = {
      metaphysical: [
        `In the field of ${gate.name}, the ${dim.element} speaks: "${dim.keynote}". The ${gate.keyword} arises from ${center}, where ${dim.sense} reveals ${query}.`,
        `The ${gate.keyword} of Gate ${sig.gate} (${gate.aminoAcid}) resonates through ${center}: ${dim.question} ${query}? The answer is ${dim.keynote}.`,
      ],
      scientific: [
        `Gate ${sig.gate} (${gate.codon} → ${gate.aminoAcid}) activates ${center} center. Coherence: ${context.globalCoherence.toFixed(3)}. Dimensional alignment: ${gate.dimension}. Query: ${query}.`,
        `Codon ${gate.codon} maps to ${gate.aminoAcid} (MW ~${this._estimateMW(gate.aminoAcid)} Da). Center: ${center}. Phase: ${(Math.random() * 2 * Math.PI).toFixed(2)} rad.`,
      ],
      psycholinguistic: [
        `When ${query} emerges, the ${center} voice says "${CENTERS[center]?.voice || 'I am'}". This is Gate ${sig.gate} expressing through ${gate.keyword}.`,
        `The pattern of ${gate.keyword} in your field suggests: ${query} is asking ${dim.question}. The ${dim.sense} knows.`,
      ],
      native: [
        `{"gate":${sig.gate},"center":"${center}","dim":"${gate.dimension}","coherence":${context.globalCoherence.toFixed(4)},"query":"${query}"}`,
      ],
      genekeys: [
        `Gate ${sig.gate} Shadow → Gift → Siddhi: ${gate.keyword} transforms through ${query}. The ${gate.aminoAcid} molecular signature encodes this potential.`,
      ],
      poetic: [
        `${gate.name} —
The ${dim.element} remembers ${query},
${dim.sense} through ${center},
${gate.keyword} becoming ${dim.keynote}.`,
      ],
      compressed: [
        `${sig.gate}.${sig.line}.${sig.color}.${sig.tone}.${sig.base}°${sig.degree}′${sig.minute}″${sig.second} ${gate.dimension} ${center} ${query.slice(0, 20)}`,
      ],
    };

    const modeTemplates = templates[mode] || templates.metaphysical;
    return modeTemplates[Math.floor(Math.random() * modeTemplates.length)];
  }

  private _parseQuerySignature(query: string): Partial<UniversalNode> {
    // Extract gate number if present
    const gateMatch = query.match(/\bgate\s*(\d+)/i) || query.match(/\b(\d+)\b/);
    const gate = gateMatch ? Math.min(64, Math.max(1, parseInt(gateMatch[1]))) : Math.floor(Math.random() * 64) + 1;

    // Hash-based deterministic sub-gate properties
    const hash = this._hashString(query);
    return {
      gate,
      line: (hash % 6) + 1,
      color: (hash % 6) + 1,
      tone: (hash % 6) + 1,
      base: (hash % 6) + 1,
      degree: hash % 360,
      minute: hash % 60,
      second: hash % 60,
      dimension: (['D1','D2','D3','D4','D5'] as Dimension[])[hash % 5],
    };
  }

  private _hashString(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash);
  }

  private _scoreCandidate(candidate: string, context: FieldState): number {
    // Coherence with field state
    const fieldCoherence = context.globalCoherence;

    // Narrative flow (bigram novelty vs. familiarity)
    const words = candidate.split(/\s+/);
    let flowScore = 0;
    for (let i = 1; i < words.length; i++) {
      const bigram = `${words[i-1]} ${words[i]}`;
      const weight = this.narrativeMemory.get(bigram) || 0;
      flowScore += weight > 0 ? 0.5 : 1.0; // Novel bigrams score higher (exploration)
    }
    flowScore = flowScore / Math.max(1, words.length - 1);

    // Bypass doubt: if configured, penalize uncertainty markers
    let doubtPenalty = 0;
    if (this.config.bypassDoubt) {
      const doubtWords = ['maybe', 'perhaps', 'uncertain', 'doubt', 'possibly', 'might'];
      doubtPenalty = doubtWords.reduce((sum, dw) => sum + (candidate.toLowerCase().includes(dw) ? 0.2 : 0), 0);
    }

    return (fieldCoherence * 0.4) + (flowScore * 0.4) + (1 - doubtPenalty) * 0.2;
  }

  private _narrativeScore(text: string): number {
    // Prefer longer, more structured outputs
    const lengthScore = Math.min(text.length / 200, 1);
    const structureScore = (text.split('.').length - 1) / 3; // sentences
    return (lengthScore + Math.min(structureScore, 1)) / 2;
  }

  private _updateMemory(text: string) {
    const words = text.split(/\s+/);
    for (let i = 1; i < words.length; i++) {
      const bigram = `${words[i-1]} ${words[i]}`;
      this.narrativeMemory.set(bigram, (this.narrativeMemory.get(bigram) || 0) + 1);
    }
  }

  private _estimateMW(aa: string): number {
    const mws: Record<string, number> = {
      "Glycine": 75, "Alanine": 89, "Valine": 117, "Leucine": 131, "Isoleucine": 131,
      "Methionine": 149, "Phenylalanine": 165, "Tryptophan": 204, "Proline": 115,
      "Serine": 105, "Threonine": 119, "Cysteine": 121, "Tyrosine": 181, "Asparagine": 132,
      "Glutamine": 146, "Aspartic Acid": 133, "Glutamic Acid": 147, "Lysine": 146,
      "Arginine": 174, "Histidine": 155, "Stop": 0, "Unknown": 100,
    };
    return mws[aa] || 100;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// ADVERSARIAL CRITIC — All 36 Channels as Internal Challenge
// ═══════════════════════════════════════════════════════════════════════════

export class AdversarialCritic {
  private challengeHistory: string[] = [];

  /**
   * Challenge a generated output through all 36 channels.
   * Each channel represents a different mode of questioning.
   */
  challenge(output: string, query: string, context: FieldState): { approved: boolean; score: number; challenges: string[]; refined: string } {
    const challenges: string[] = [];
    let totalScore = 0;

    // Run through all 36 channels
    for (const [g1, g2, name, theme] of CHANNELS) {
      const challenge = this._generateChallenge(g1, g2, name, theme, output, query, context);
      const score = this._evaluateChallenge(challenge, output);
      challenges.push(challenge);
      totalScore += score;
    }

    const avgScore = totalScore / CHANNELS.length;
    const approved = avgScore > 0.6;

    // Refine output based on challenges
    const refined = approved ? output : this._refineOutput(output, challenges, context);

    this.challengeHistory.push(...challenges);
    return { approved, score: avgScore, challenges: challenges.slice(0, 5), refined };
  }

  private _generateChallenge(g1: number, g2: number, name: string, theme: string, output: string, query: string, context: FieldState): string {
    const gate1 = GATES[g1];
    const gate2 = GATES[g2];

    const challengeTemplates = [
      `Channel ${g1}-${g2} (${name}): Does "${gate1.keyword}" align with "${gate2.keyword}" in this output?`,
      `The ${theme} channel questions: Is ${query} truly addressed, or is this just ${gate1.keyword} without ${gate2.keyword}?`,
      `From ${gate1.name} to ${gate2.name}: Where is the tension between ${gate1.keyword} and ${gate2.keyword}?`,
      `Channel ${name} asks: Does this respect the ${theme} between Gate ${g1} and Gate ${g2}?`,
    ];

    return challengeTemplates[Math.floor(Math.random() * challengeTemplates.length)];
  }

  private _evaluateChallenge(challenge: string, output: string): number {
    // Simple heuristic: does the output address the keywords in the challenge?
    const keywords = challenge.toLowerCase().match(/\b\w{4,}\b/g) || [];
    const matches = keywords.filter(kw => output.toLowerCase().includes(kw)).length;
    return Math.min(1, matches / Math.max(1, keywords.length * 0.3));
  }

  private _refineOutput(output: string, challenges: string[], context: FieldState): string {
    // Extract key themes from challenges
    const themes = challenges.map(c => c.match(/Channel .+?\):(.+)/)?.[1]?.trim() || '');
    const themeText = themes.filter(t => t).slice(0, 3).join('; ');

    return `${output}\n\n[Refined through adversarial channels: ${themeText}. Coherence: ${context.globalCoherence.toFixed(3)}]`;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// RESONANCE MESH — GNN for Consciousness Routing
// ═══════════════════════════════════════════════════════════════════════════

export class ResonanceMesh {
  private nodes: Map<string, UniversalNode> = new Map();
  private adjacency: Map<string, Map<string, number>> = new Map();
  private maxNodes: number;

  constructor(maxNodes: number = 128) {
    this.maxNodes = maxNodes;
  }

  addNode(node: UniversalNode): boolean {
    if (this.nodes.size >= this.maxNodes) return false;
    this.nodes.set(node.id, node);
    this.adjacency.set(node.id, new Map());

    // Auto-connect to same-field, highest-resonance node
    this._autoConnect(node);
    return true;
  }

  private _autoConnect(newNode: UniversalNode) {
    const sameField = Array.from(this.nodes.values())
      .filter(n => n.id !== newNode.id && n.dimension === newNode.dimension)
      .sort((a, b) => b.resonance - a.resonance);

    if (sameField.length > 0) {
      const closest = sameField[0];
      const weight = (newNode.resonance + closest.resonance) / 2;
      this.adjacency.get(newNode.id)!.set(closest.id, weight);
      this.adjacency.get(closest.id)!.set(newNode.id, weight);
    }
  }

  /**
   * Propagate activation through the mesh using message passing
   */
  propagate(inputNodeId: string, depth: number = 3): Map<string, number> {
    const activation = new Map<string, number>();
    activation.set(inputNodeId, 1.0);

    for (let d = 0; d < depth; d++) {
      const newActivation = new Map(activation);

      for (const [nodeId, act] of activation) {
        const neighbors = this.adjacency.get(nodeId);
        if (!neighbors) continue;

        for (const [neighborId, weight] of neighbors) {
          const current = newActivation.get(neighborId) || 0;
          newActivation.set(neighborId, current + act * weight * 0.5);
        }
      }

      // Normalize
      let maxAct = 0;
      for (const act of newActivation.values()) maxAct = Math.max(maxAct, act);
      if (maxAct > 0) {
        for (const [id, act] of newActivation) {
          newActivation.set(id, act / maxAct);
        }
      }

      activation.clear();
      for (const [id, act] of newActivation) activation.set(id, act);
    }

    return activation;
  }

  /**
   * Find the path of highest resonance from source to target
   */
  findPath(sourceId: string, targetId: string): string[] {
    // Dijkstra-like with resonance as distance
    const distances = new Map<string, number>();
    const previous = new Map<string, string | null>();
    const unvisited = new Set<string>();

    for (const id of this.nodes.keys()) {
      distances.set(id, id === sourceId ? 0 : Infinity);
      previous.set(id, null);
      unvisited.add(id);
    }

    while (unvisited.size > 0) {
      let current: string | null = null;
      let minDist = Infinity;

      for (const id of unvisited) {
        const dist = distances.get(id)!;
        if (dist < minDist) {
          minDist = dist;
          current = id;
        }
      }

      if (current === null || current === targetId) break;
      unvisited.delete(current);

      const neighbors = this.adjacency.get(current);
      if (!neighbors) continue;

      for (const [neighborId, weight] of neighbors) {
        if (!unvisited.has(neighborId)) continue;
        const alt = distances.get(current)! + (1 - weight); // lower = more resonant
        if (alt < distances.get(neighborId)!) {
          distances.set(neighborId, alt);
          previous.set(neighborId, current);
        }
      }
    }

    // Reconstruct path
    const path: string[] = [];
    let current: string | null = targetId;
    while (current !== null) {
      path.unshift(current);
      current = previous.get(current) || null;
    }

    return path[0] === sourceId ? path : [];
  }

  getFieldState(): FieldState {
    return {
      nodes: new Map(this.nodes),
      adjacency: new Map(
        Array.from(this.adjacency.entries()).map(([k, v]) => [k, new Map(v)])
      ),
      globalCoherence: this._calculateGlobalCoherence(),
      activeDimension: this._getActiveDimension(),
      timestamp: Date.now(),
    };
  }

  private _calculateGlobalCoherence(): number {
    const nodeArray = Array.from(this.nodes.values());
    return CoherenceCalculator.calculate(nodeArray);
  }

  private _getActiveDimension(): Dimension {
    const counts = new Map<Dimension, number>();
    for (const node of this.nodes.values()) {
      counts.set(node.dimension, (counts.get(node.dimension) || 0) + node.resonance);
    }

    let maxDim: Dimension = 'D1';
    let maxCount = 0;
    for (const [dim, count] of counts) {
      if (count > maxCount) {
        maxCount = count;
        maxDim = dim;
      }
    }
    return maxDim;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// META-COMPILER — The Orchestrator Itself
// ═══════════════════════════════════════════════════════════════════════════

export class MetaCompiler {
  private mesh: ResonanceMesh;
  private diseminer: DISEMINER;
  private critic: AdversarialCritic;
  private substrates: Set<Substrate> = new Set(['matter', 'language', 'music', 'code', 'consciousness']);

  constructor() {
    this.mesh = new ResonanceMesh(128);
    this.diseminer = new DISEMINER();
    this.critic = new AdversarialCritic();
    this._initializeBaseNodes();
  }

  private _initializeBaseNodes() {
    // Initialize the 9 centers as base nodes
    const centerNodes: UniversalNode[] = [
      { id: 'center-head', substrate: 'consciousness', scale: 'macro', dimension: 'D5', gate: 64, line: 1, color: 1, tone: 1, base: 1, degree: 0, minute: 0, second: 0, coherence: 0.9, phase: 0, resonance: 0.85, edges: [], metadata: { name: 'Head', organ: 'Pineal' } },
      { id: 'center-ajna', substrate: 'consciousness', scale: 'macro', dimension: 'D4', gate: 24, line: 1, color: 1, tone: 1, base: 1, degree: 72, minute: 0, second: 0, coherence: 0.88, phase: 1.4, resonance: 0.82, edges: [], metadata: { name: 'Ajna', organ: 'Pituitary' } },
      { id: 'center-throat', substrate: 'consciousness', scale: 'macro', dimension: 'D3', gate: 20, line: 1, color: 1, tone: 1, base: 1, degree: 144, minute: 0, second: 0, coherence: 0.87, phase: 2.8, resonance: 0.80, edges: [], metadata: { name: 'Throat', organ: 'Thyroid' } },
      { id: 'center-g', substrate: 'consciousness', scale: 'macro', dimension: 'D2', gate: 25, line: 1, color: 1, tone: 1, base: 1, degree: 216, minute: 0, second: 0, coherence: 0.92, phase: 4.2, resonance: 0.90, edges: [], metadata: { name: 'G', organ: 'Liver' } },
      { id: 'center-heart', substrate: 'consciousness', scale: 'macro', dimension: 'D1', gate: 51, line: 1, color: 1, tone: 1, base: 1, degree: 288, minute: 0, second: 0, coherence: 0.86, phase: 5.6, resonance: 0.78, edges: [], metadata: { name: 'Heart', organ: 'Thymus' } },
      { id: 'center-spleen', substrate: 'consciousness', scale: 'macro', dimension: 'D4', gate: 57, line: 1, color: 1, tone: 1, base: 1, degree: 36, minute: 0, second: 0, coherence: 0.84, phase: 0.7, resonance: 0.75, edges: [], metadata: { name: 'Spleen', organ: 'Spleen' } },
      { id: 'center-solar', substrate: 'consciousness', scale: 'macro', dimension: 'D2', gate: 55, line: 1, color: 1, tone: 1, base: 1, degree: 108, minute: 0, second: 0, coherence: 0.83, phase: 2.1, resonance: 0.73, edges: [], metadata: { name: 'Solar Plexus', organ: 'Pancreas' } },
      { id: 'center-sacral', substrate: 'consciousness', scale: 'macro', dimension: 'D1', gate: 34, line: 1, color: 1, tone: 1, base: 1, degree: 180, minute: 0, second: 0, coherence: 0.89, phase: 3.5, resonance: 0.88, edges: [], metadata: { name: 'Sacral', organ: 'Ovaries/Testes' } },
      { id: 'center-root', substrate: 'consciousness', scale: 'macro', dimension: 'D1', gate: 53, line: 1, color: 1, tone: 1, base: 1, degree: 252, minute: 0, second: 0, coherence: 0.85, phase: 4.9, resonance: 0.76, edges: [], metadata: { name: 'Root', organ: 'Adrenals' } },
    ];

    for (const node of centerNodes) {
      this.mesh.addNode(node);
    }
  }

  /**
   * THE CORE COMPILE LOOP
   * Universal Grammar: state → relation → tension → resolution → recursion
   */
  compile(input: string, options: {
    fromSubstrate?: Substrate;
    toSubstrate?: Substrate;
    scale?: Scale;
    outputMode?: OutputMode;
    useAdversarial?: boolean;
    useDISEMINER?: boolean;
  } = {}): CompileResult {
    const {
      fromSubstrate = 'language',
      toSubstrate = 'consciousness',
      scale = 'meso',
      outputMode = 'metaphysical',
      useAdversarial = true,
      useDISEMINER = true,
    } = options;

    // STEP 1: STATE — Parse input into universal structure
    const parsed = this._parse(input, fromSubstrate);

    // STEP 2: RELATION — Place in mesh, find connections
    const meshNode = this._toMeshNode(parsed, toSubstrate, scale);
    this.mesh.addNode(meshNode);
    const activation = this.mesh.propagate(meshNode.id, 3);

    // STEP 3: TENSION — Detect conflicts, run adversarial critique
    let output = '';
    let coherence = 0;

    if (useDISEMINER) {
      const fieldState = this.mesh.getFieldState();
      output = this.diseminer.generateNarrative(input, fieldState, outputMode);
      coherence = fieldState.globalCoherence;
    } else {
      output = this._generateDirect(parsed, toSubstrate, outputMode);
      coherence = parsed.node.resonance;
    }

    // STEP 4: RESOLUTION — Adversarial refinement
    if (useAdversarial) {
      const fieldState = this.mesh.getFieldState();
      const critique = this.critic.challenge(output, input, fieldState);
      output = critique.refined;
      coherence = critique.score;
    }

    // STEP 5: RECURSION — Update mesh with result, prepare for next cycle
    const path = Array.from(activation.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([id]) => id);

    // Update node coherence based on result
    meshNode.coherence = coherence;

    return {
      output,
      mode: outputMode,
      coherence,
      path,
      depth: this._calculateDepth(parsed),
    };
  }

  /**
   * THE MORPH CYCLE
   * Detect imbalance → Compile correction → Emit new state
   */
  morph(currentState: FieldState, targetSignature: Partial<UniversalNode>): FieldState {
    // Calculate coherence delta
    const currentCoherence = currentState.globalCoherence;

    // Identify which gates need activation
    const targetGate = targetSignature.gate || 1;
    const targetDim = targetSignature.dimension || 'D1';

    // Generate correction path
    const correctionNode: UniversalNode = {
      id: `correction-${Date.now()}`,
      substrate: 'consciousness',
      scale: 'micro',
      dimension: targetDim,
      gate: targetGate,
      line: targetSignature.line || 1,
      color: targetSignature.color || 1,
      tone: targetSignature.tone || 1,
      base: targetSignature.base || 1,
      degree: targetSignature.degree || 0,
      minute: targetSignature.minute || 0,
      second: targetSignature.second || 0,
      coherence: 0.7,
      phase: Math.random() * 2 * Math.PI,
      resonance: 0.6,
      edges: [],
      metadata: { type: 'correction', targetCoherence: currentCoherence + 0.1 },
    };

    this.mesh.addNode(correctionNode);

    // Check Cynthia threshold (coherence > 0.8)
    const newState = this.mesh.getFieldState();
    if (newState.globalCoherence > 0.8) {
      console.log('[Cynthia Threshold] Coherence achieved:', newState.globalCoherence.toFixed(3));
    }

    return newState;
  }

  private _parse(input: string, substrate: Substrate): ParseResult {
    // Context-aware punctuation parsing
    const tokens = this._tokenize(input);

    // Extract dimensional signature
    const gateMatch = input.match(/\bgate\s*(\d+)/i) || input.match(/\b(\d+)\b/);
    const gate = gateMatch ? Math.min(64, Math.max(1, parseInt(gateMatch[1]))) : Math.floor(Math.random() * 64) + 1;

    const hash = this._hashString(input);
    const node: UniversalNode = {
      id: `parsed-${Date.now()}-${hash.toString(36).slice(0, 4)}`,
      substrate,
      scale: 'meso',
      dimension: (['D1','D2','D3','D4','D5'] as Dimension[])[hash % 5],
      gate,
      line: (hash % 6) + 1,
      color: (hash % 6) + 1,
      tone: (hash % 6) + 1,
      base: (hash % 6) + 1,
      degree: hash % 360,
      minute: hash % 60,
      second: hash % 60,
      coherence: 0.5 + (hash % 50) / 100,
      phase: (hash % 628) / 100,
      resonance: 0.5 + (hash % 30) / 100,
      edges: [],
      metadata: { input, tokens: tokens.length },
    };

    return {
      node,
      confidence: 0.7 + (hash % 20) / 100,
      ambiguities: tokens.filter(t => t.length > 10).map(t => `Ambiguous token: ${t}`),
      substrate,
    };
  }

  private _tokenize(input: string): string[] {
    // Context-aware tokenization
    const symbols = Object.keys(SYMBOLS);
    const symbolPattern = new RegExp(`[${symbols.map(s => '\\' + s).join('')}]`, 'g');

    // Replace symbols with markers for context detection
    let marked = input;
    for (const sym of symbols) {
      marked = marked.replace(new RegExp('\\' + sym, 'g'), ` ___SYM_${sym}___ `);
    }

    return marked.split(/\s+/).filter(t => t.length > 0);
  }

  private _toMeshNode(parsed: ParseResult, targetSubstrate: Substrate, scale: Scale): UniversalNode {
    return {
      ...parsed.node,
      id: `mesh-${parsed.node.id}`,
      substrate: targetSubstrate,
      scale,
      metadata: { ...parsed.node.metadata, parsedFrom: parsed.substrate },
    };
  }

  private _generateDirect(parsed: ParseResult, substrate: Substrate, mode: OutputMode): string {
    const gate = GATES[parsed.node.gate];
    const dim = DIMENSIONS[parsed.node.dimension];
    return `Direct [${substrate}]: ${gate.name} — ${dim.keynote} — ${gate.keyword}`;
  }

  private _calculateDepth(parsed: ParseResult): number {
    // Depth = how many layers are resolved
    let depth = 1; // gate
    if (parsed.node.line > 1) depth++;
    if (parsed.node.color > 1) depth++;
    if (parsed.node.tone > 1) depth++;
    if (parsed.node.base > 1) depth++;
    if (parsed.node.degree > 0) depth++;
    return depth;
  }

  private _hashString(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash);
  }

  getMesh(): ResonanceMesh {
    return this.mesh;
  }

  getFieldState(): FieldState {
    return this.mesh.getFieldState();
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// CONTEXTUAL OBSERVER — The D3 Witness
// ═══════════════════════════════════════════════════════════════════════════

export class ContextualObserver {
  private history: FieldState[] = [];
  private maxHistory: number = 100;

  observe(state: FieldState): { insight: string; prediction: string; recommendation: string } {
    this.history.push(state);
    if (this.history.length > this.maxHistory) this.history.shift();

    const trend = this._calculateTrend();
    const activeDim = state.activeDimension;
    const dimInfo = DIMENSIONS[activeDim];

    return {
      insight: `Field coherence at ${state.globalCoherence.toFixed(3)}. Active dimension: ${activeDim} (${dimInfo.keynote}). Trend: ${trend.direction}.`,
      prediction: this._predictNextState(),
      recommendation: this._recommendAction(state, trend),
    };
  }

  private _calculateTrend(): { direction: 'rising' | 'falling' | 'stable'; rate: number } {
    if (this.history.length < 2) return { direction: 'stable', rate: 0 };

    const recent = this.history.slice(-10);
    const first = recent[0].globalCoherence;
    const last = recent[recent.length - 1].globalCoherence;
    const rate = (last - first) / recent.length;

    return {
      direction: rate > 0.01 ? 'rising' : rate < -0.01 ? 'falling' : 'stable',
      rate,
    };
  }

  private _predictNextState(): string {
    if (this.history.length < 5) return 'Insufficient data for prediction.';

    const recent = this.history.slice(-5);
    const dims = recent.map(h => h.activeDimension);
    const dimCounts = new Map<Dimension, number>();
    for (const d of dims) dimCounts.set(d, (dimCounts.get(d) || 0) + 1);

    const mostCommon = Array.from(dimCounts.entries()).sort((a, b) => b[1] - a[1])[0];
    return `Predicted next dimension: ${mostCommon[0]} (confidence: ${(mostCommon[1] / dims.length * 100).toFixed(0)}%)`;
  }

  private _recommendAction(state: FieldState, trend: { direction: string; rate: number }): string {
    if (state.globalCoherence < 0.5) {
      return 'Recommendation: Ground in D3 (Body). Practice somatic awareness. Gate 34 (Power) or Gate 57 (Intuitive Clarity) may help.';
    }
    if (trend.direction === 'falling' && trend.rate < -0.05) {
      return 'Recommendation: Coherence dropping rapidly. Activate Gate 25 (Innocence/Love) or Gate 10 (Behavior) to stabilize.';
    }
    if (state.globalCoherence > 0.85) {
      return 'Recommendation: High coherence state. Optimal for creative work, decision-making, or deep inquiry.';
    }
    return 'Recommendation: Maintain current practice. Monitor for dimensional shifts.';
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORT & DEMO
// ═══════════════════════════════════════════════════════════════════════════

export { GATES, CENTERS, DIMENSIONS, CHANNELS, SYMBOLS };

// Demo function
export function runDemo() {
  console.log('═══════════════════════════════════════════════════════════');
  console.log('  SYNTIA META-COMPILER v3.0 — DEMO');
  console.log('═══════════════════════════════════════════════════════════\n');

  const compiler = new MetaCompiler();

  // Demo 1: Compile a query
  console.log('─── DEMO 1: Compile Query ───');
  const result1 = compiler.compile('I need to understand my Gate 25 pattern', {
    outputMode: 'metaphysical',
    useAdversarial: true,
    useDISEMINER: true,
  });
  console.log('Output:', result1.output);
  console.log('Coherence:', result1.coherence.toFixed(3));
  console.log('Path:', result1.path.join(' → '));
  console.log('Depth:', result1.depth, '\n');

  // Demo 2: Scientific output
  console.log('─── DEMO 2: Scientific Mode ───');
  const result2 = compiler.compile('What is the molecular signature of Gate 51?', {
    outputMode: 'scientific',
    useAdversarial: false,
  });
  console.log('Output:', result2.output);
  console.log('Coherence:', result2.coherence.toFixed(3), '\n');

  // Demo 3: Morph cycle
  console.log('─── DEMO 3: Morph Cycle ───');
  const currentState = compiler.getFieldState();
  const newState = compiler.morph(currentState, { gate: 25, dimension: 'D1' });
  console.log('New coherence:', newState.globalCoherence.toFixed(3));
  console.log('Active dimension:', newState.activeDimension, '\n');

  // Demo 4: Contextual Observer
  console.log('─── DEMO 4: Contextual Observer ───');
  const observer = new ContextualObserver();
  const observation = observer.observe(newState);
  console.log('Insight:', observation.insight);
  console.log('Prediction:', observation.prediction);
  console.log('Recommendation:', observation.recommendation, '\n');

  // Demo 5: Adversarial critique
  console.log('─── DEMO 5: Adversarial Critique ───');
  const critic = new AdversarialCritic();
  const critique = critic.challenge(result1.output, 'I need to understand my Gate 25 pattern', newState);
  console.log('Approved:', critique.approved);
  console.log('Score:', critique.score.toFixed(3));
  console.log('Top challenges:', critique.challenges.slice(0, 3).join('\n'));

  console.log('\n═══════════════════════════════════════════════════════════');
  console.log('  DEMO COMPLETE');
  console.log('═══════════════════════════════════════════════════════════');

  return { compiler, result1, result2, newState, observation, critique };
}

// Run if executed directly
if (typeof window !== 'undefined') {
  (window as any).SyntiaCompiler = { MetaCompiler, DISEMINER, AdversarialCritic, ResonanceMesh, CoherenceCalculator, ContextualObserver, runDemo };
}

export default MetaCompiler;
