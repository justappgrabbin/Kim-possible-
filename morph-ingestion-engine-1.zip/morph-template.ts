
// ============================================================================
// MORPH TEMPLATE — Self-Expanding Project Scaffolder
// Ingests any file, analyzes it, resolves dependencies, fills gaps, mounts for execution
// Usage: Copy this template into any project. It grows with each file you add.
// ============================================================================

import { MorphDatabase, MorphCLI, IngestedFile, ExecutionContext } from './morph-ingestion-engine';

// ═══════════════════════════════════════════════════════════════════════════════
// MORPH TEMPLATE — The Living Project Scaffold
// ═══════════════════════════════════════════════════════════════════════════════
export class MorphTemplate {
  private db: MorphDatabase;
  private cli: MorphCLI;
  private config: MorphConfig;
  private watchers: Map<string, any> = new Map();
  private growthLog: GrowthEvent[] = [];

  constructor(config: Partial<MorphConfig> = {}) {
    this.db = MorphDatabase.getInstance();
    this.cli = new MorphCLI();
    this.config = {
      autoIngest: true,
      autoResolve: true,
      autoFill: true,
      autoMount: true,
      watchMode: true,
      sandboxExecution: true,
      maxComplexity: 100,
      allowedDimensions: ['HTML', 'JS', 'TS', 'PYTHON', 'JSON', 'CSS'],
      ...config,
    };
  }

  // ─── INITIALIZE ──────────────────────────────────────────────────────────────
  async initialize(projectPath: string = './'): Promise<void> {
    console.log(`\n╔════════════════════════════════════════════════════════════════╗`);
    console.log(`║     MORPH TEMPLATE — Self-Expanding Execution System          ║`);
    console.log(`║     Dimensional Code: HTML→Python→JSON→JS→CSS                ║`);
    console.log(`╚════════════════════════════════════════════════════════════════╝\n`);

    // Scan and ingest existing project files
    await this.scanProject(projectPath);

    // Set up watchers if enabled
    if (this.config.watchMode) {
      this.setupWatchers(projectPath);
    }

    // Generate project manifest
    this.generateManifest();

    console.log(`[MORPH TEMPLATE] Initialized. System is alive and growing.\n`);
  }

  // ─── INGEST FILE — The Core Entry Point ──────────────────────────────────────
  async ingestFile(filePath: string): Promise<IngestedFile> {
    console.log(`[MORPH] Ingesting: ${filePath}`);

    // Phase 1: Ingest
    const file = this.db.ingest(filePath);

    // Phase 2: Analyze (auto-triggered by pipeline, but we can observe)
    console.log(`[MORPH]   → Analyzed: ${file.analyzed.lines} lines, complexity ${file.analyzed.complexity}`);

    // Phase 3: Dependencies
    console.log(`[MORPH]   → Dependencies: ${file.dependencies.internal.length} internal, ${file.dependencies.external.length} external`);
    if (file.dependencies.missing.length > 0) {
      console.log(`[MORPH]   → Missing: ${file.dependencies.missing.join(', ')}`);
    }

    // Phase 4: Gaps
    console.log(`[MORPH]   → Gaps found: ${file.gaps.length}`);
    file.gaps.forEach(gap => {
      console.log(`[MORPH]     [${gap.severity}] ${gap.type}: ${gap.description}`);
    });

    // Phase 5: Mount status
    console.log(`[MORPH]   → Mounted: ${file.mounted}, Execution Ready: ${file.executionReady}`);

    // Log growth event
    this.growthLog.push({
      timestamp: new Date(),
      type: 'ingest',
      fileId: file.id,
      dimension: file.dimension,
      cluster: file.metadata.semanticCluster,
    });

    return file;
  }

  // ─── INGEST MULTIPLE FILES ─────────────────────────────────────────────────
  async ingestDirectory(dirPath: string, pattern: RegExp = /\.(js|ts|py|html|css|json)$/): Promise<IngestedFile[]> {
    const { readdirSync, statSync } = require('fs');
    const { join } = require('path');

    const files: IngestedFile[] = [];

    const scan = (path: string) => {
      const entries = readdirSync(path);
      for (const entry of entries) {
        const fullPath = join(path, entry);
        const stat = statSync(fullPath);

        if (stat.isDirectory() && !entry.startsWith('.') && entry !== 'node_modules') {
          scan(fullPath);
        } else if (stat.isFile() && pattern.test(entry)) {
          const file = this.db.ingest(fullPath);
          files.push(file);
        }
      }
    };

    scan(dirPath);
    return files;
  }

  // ─── EXECUTE MOUNTED FILE ──────────────────────────────────────────────────
  async execute(fileId: string, args?: Record<string, any>): Promise<any> {
    const file = this.db.getFile(fileId);
    if (!file) {
      throw new Error(`File not found: ${fileId}`);
    }

    if (!file.executionReady) {
      console.log(`[MORPH] File not ready. Running auto-pipeline...`);
      await this.forcePipeline(fileId);
    }

    console.log(`[MORPH] Executing: ${file.name}`);
    const result = this.db.execute(fileId, args);

    this.growthLog.push({
      timestamp: new Date(),
      type: 'execute',
      fileId,
      result: result.success ? 'success' : 'error',
    });

    return result;
  }

  // ─── FORCE FULL PIPELINE ───────────────────────────────────────────────────
  async forcePipeline(fileId: string): Promise<void> {
    // Manually trigger all phases
    await this.db.analyze(fileId);
    await this.db.resolveDependencies(fileId);
    await this.db.fillGaps(fileId);
    await this.db.mount(fileId);
  }

  // ─── GET PROJECT STATUS ──────────────────────────────────────────────────
  getStatus(): ProjectStatus {
    const files = this.db.getAllFiles();
    const clusters = new Map<string, number>();
    const dimensions = new Map<string, number>();

    files.forEach(f => {
      clusters.set(f.metadata.semanticCluster, (clusters.get(f.metadata.semanticCluster) || 0) + 1);
      dimensions.set(f.dimension, (dimensions.get(f.dimension) || 0) + 1);
    });

    return {
      totalFiles: files.length,
      mountedFiles: files.filter(f => f.mounted).length,
      readyFiles: files.filter(f => f.executionReady).length,
      clusters: Object.fromEntries(clusters),
      dimensions: Object.fromEntries(dimensions),
      totalGaps: files.reduce((sum, f) => sum + f.gaps.length, 0),
      avgQuality: files.length > 0 
        ? Math.round(files.reduce((sum, f) => sum + f.analyzed.qualityScore, 0) / files.length)
        : 0,
      growthEvents: this.growthLog.length,
    };
  }

  // ─── GROW THE SYSTEM ───────────────────────────────────────────────────────
  async grow(): Promise<GrowthReport> {
    console.log(`[MORPH] Triggering system growth...`);

    const before = this.db.getAllFiles().length;
    const growth = this.db.grow();
    const after = this.db.getAllFiles().length;

    const report: GrowthReport = {
      filesBefore: before,
      filesAfter: after,
      newFilesGenerated: after - before,
      clusters: growth.clusters,
      totalComplexity: growth.totalComplexity,
      integrationsCreated: after - before > 0 ? 1 : 0,
    };

    this.growthLog.push({
      timestamp: new Date(),
      type: 'grow',
      newFiles: report.newFilesGenerated,
    });

    console.log(`[MORPH] Growth complete: ${report.newFilesGenerated} new files generated`);
    return report;
  }

  // ─── PRIVATE HELPERS ───────────────────────────────────────────────────────
  private async scanProject(projectPath: string): Promise<void> {
    try {
      const files = await this.ingestDirectory(projectPath);
      console.log(`[MORPH] Scanned ${files.length} files from ${projectPath}`);
    } catch (error) {
      console.log(`[MORPH] No existing files to scan, starting fresh`);
    }
  }

  private setupWatchers(projectPath: string): void {
    try {
      const chokidar = require('chokidar');
      const watcher = chokidar.watch(projectPath, {
        ignored: /(^|[\/\])\../, // ignore dotfiles
        persistent: true,
      });

      watcher.on('add', (path: string) => {
        if (this.config.autoIngest) {
          console.log(`[MORPH WATCH] New file detected: ${path}`);
          this.ingestFile(path);
        }
      });

      watcher.on('change', (path: string) => {
        console.log(`[MORPH WATCH] File changed: ${path}`);
        // Re-ingest and re-analyze
        const file = this.db.getAllFiles().find(f => f.path === path);
        if (file) {
          this.db.ingest(path); // Re-ingest with updated content
        }
      });

      this.watchers.set('project', watcher);
      console.log(`[MORPH] Watch mode active on ${projectPath}`);
    } catch (error) {
      console.log(`[MORPH] Watch mode requires chokidar: npm install chokidar`);
    }
  }

  private generateManifest(): void {
    const status = this.getStatus();
    const manifest = {
      morphVersion: '1.0',
      generatedAt: new Date().toISOString(),
      status,
      config: this.config,
      growthLog: this.growthLog,
    };

    const { writeFileSync } = require('fs');
    writeFileSync('./morph-manifest.json', JSON.stringify(manifest, null, 2));
    console.log(`[MORPH] Manifest generated: morph-manifest.json`);
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════════════════
interface MorphConfig {
  autoIngest: boolean;
  autoResolve: boolean;
  autoFill: boolean;
  autoMount: boolean;
  watchMode: boolean;
  sandboxExecution: boolean;
  maxComplexity: number;
  allowedDimensions: string[];
}

interface GrowthEvent {
  timestamp: Date;
  type: 'ingest' | 'execute' | 'grow' | 'resolve';
  fileId?: string;
  dimension?: string;
  cluster?: string;
  result?: string;
  newFiles?: number;
}

interface ProjectStatus {
  totalFiles: number;
  mountedFiles: number;
  readyFiles: number;
  clusters: Record<string, number>;
  dimensions: Record<string, number>;
  totalGaps: number;
  avgQuality: number;
  growthEvents: number;
}

interface GrowthReport {
  filesBefore: number;
  filesAfter: number;
  newFilesGenerated: number;
  clusters: string[];
  totalComplexity: number;
  integrationsCreated: number;
}

// ═══════════════════════════════════════════════════════════════════════════════
// QUICK START — Example Usage
// ═══════════════════════════════════════════════════════════════════════════════
export async function quickStart() {
  const morph = new MorphTemplate({
    autoIngest: true,
    autoResolve: true,
    autoFill: true,
    autoMount: true,
    watchMode: true,
  });

  // Initialize the system
  await morph.initialize('./');

  // Ingest a specific file
  // const file = await morph.ingestFile('./my-component.tsx');

  // Execute a mounted file
  // const result = await morph.execute(file.id);

  // Check system status
  console.log('Status:', morph.getStatus());

  // Grow the system
  // await morph.grow();

  return morph;
}

// ═══════════════════════════════════════════════════════════════════════════════
// BOOTSTRAP
// ═══════════════════════════════════════════════════════════════════════════════
if (require.main === module) {
  quickStart().catch(console.error);
}

export default MorphTemplate;
