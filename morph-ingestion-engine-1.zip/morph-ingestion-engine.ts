
// ============================================================================
// MORPH INGESTION ENGINE v1.0
// Self-Expanding File Ingestion, Analysis, Dependency Resolution & Execution Mount
// Dimensional Mapping: HTML=Movement, JSON=Evolution, JS=Being, Python=Design, CSS=Space
// ============================================================================

import { createHash } from 'crypto';
import { readFileSync, existsSync, writeFileSync, mkdirSync } from 'fs';
import { dirname, resolve, extname, basename } from 'path';

// ═══════════════════════════════════════════════════════════════════════════════
// DIMENSIONAL CONSTANTS — The Birth Sequence of Code
// ═══════════════════════════════════════════════════════════════════════════════
export const DIMENSIONS = {
  HTML: { name: 'Movement', phase: 'seed', role: 'structure', priority: 1 },
  PYTHON: { name: 'Design', phase: 'brain', role: 'logic', priority: 2 },
  JSON: { name: 'Evolution', phase: 'memory', role: 'gravity', priority: 3 },
  JS: { name: 'Being', phase: 'body', role: 'touch', priority: 4 },
  CSS: { name: 'Space', phase: 'emergent', role: 'illusion', priority: 5 },
} as const;

// ═══════════════════════════════════════════════════════════════════════════════
// TYPES — The Morphological Grammar
// ═══════════════════════════════════════════════════════════════════════════════
export interface IngestedFile {
  id: string;
  hash: string;
  path: string;
  name: string;
  extension: string;
  dimension: keyof typeof DIMENSIONS;
  rawContent: string;
  analyzed: FileAnalysis;
  dependencies: DependencyGraph;
  gaps: GapReport[];
  filled: boolean;
  mounted: boolean;
  executionReady: boolean;
  mountedAt?: Date;
  metadata: FileMetadata;
}

export interface FileAnalysis {
  lines: number;
  complexity: number;
  functions: string[];
  classes: string[];
  imports: string[];
  exports: string[];
  hasEntryPoint: boolean;
  hasTests: boolean;
  hasDocumentation: boolean;
  securityIssues: SecurityIssue[];
  qualityScore: number; // 0-100
  semanticFingerprint: string; // hash of structure
}

export interface DependencyGraph {
  internal: string[];      // files within the morph system
  external: string[];      // npm/pip packages
  missing: string[];       // unresolved dependencies
  circular: string[][];    // circular dependency chains
  resolved: boolean;
}

export interface GapReport {
  type: 'missing_import' | 'missing_function' | 'missing_type' | 'missing_test' | 'missing_doc' | 'incomplete_implementation' | 'security_vulnerability' | 'performance_issue';
  severity: 'critical' | 'high' | 'medium' | 'low';
  line?: number;
  description: string;
  suggestion: string;
  autoFillable: boolean;
  filledContent?: string;
}

export interface SecurityIssue {
  type: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  line: number;
  description: string;
  fix: string;
}

export interface FileMetadata {
  ingestedAt: Date;
  analyzedAt?: Date;
  gapFilledAt?: Date;
  mountedAt?: Date;
  size: number;
  encoding: string;
  author?: string;
  version?: string;
  tags: string[];
  semanticCluster: string; // which attractor basin this file belongs to
}

export interface ExecutionContext {
  environment: 'node' | 'browser' | 'python' | 'shell' | 'hybrid';
  entryPoint: string;
  args: Record<string, any>;
  preconditions: string[];
  postconditions: string[];
  sandbox: boolean;
}

// ═══════════════════════════════════════════════════════════════════════════════
// MORPH DATABASE — The Living Memory of the System
// ═══════════════════════════════════════════════════════════════════════════════
export class MorphDatabase {
  private files: Map<string, IngestedFile> = new Map();
  private semanticIndex: Map<string, Set<string>> = new Map(); // cluster -> fileIds
  private dependencyTree: Map<string, Set<string>> = new Map(); // fileId -> dependents
  private executionQueue: string[] = [];
  private attractorFields: Map<string, any> = new Map(); // semantic gravity wells

  private static instance: MorphDatabase;
  static getInstance(): MorphDatabase {
    if (!MorphDatabase.instance) {
      MorphDatabase.instance = new MorphDatabase();
    }
    return MorphDatabase.instance;
  }

  // ─── INGESTION ─────────────────────────────────────────────────────────────
  ingest(filePath: string, content?: string): IngestedFile {
    const resolvedPath = resolve(filePath);
    if (!existsSync(resolvedPath) && !content) {
      throw new Error(`File not found: ${filePath}`);
    }

    const rawContent = content || readFileSync(resolvedPath, 'utf-8');
    const hash = createHash('sha256').update(rawContent).digest('hex');
    const ext = extname(resolvedPath).slice(1);
    const name = basename(resolvedPath, extname(resolvedPath));
    const dimension = this.classifyDimension(ext);

    const file: IngestedFile = {
      id: this.generateId(hash, name),
      hash,
      path: resolvedPath,
      name,
      extension: ext,
      dimension,
      rawContent,
      analyzed: null as any,
      dependencies: { internal: [], external: [], missing: [], circular: [], resolved: false },
      gaps: [],
      filled: false,
      mounted: false,
      executionReady: false,
      metadata: {
        ingestedAt: new Date(),
        size: Buffer.byteLength(rawContent, 'utf8'),
        encoding: 'utf-8',
        tags: [],
        semanticCluster: 'unclassified',
      },
    };

    this.files.set(file.id, file);
    console.log(`[MORPH] INGESTED: ${name}.${ext} → ${dimension} dimension`);

    // Trigger auto-pipeline
    this.autoPipeline(file.id);

    return file;
  }

  // ─── AUTO-PIPELINE: Ingest → Analyze → Resolve → Fill → Mount ──────────────
  private async autoPipeline(fileId: string): Promise<void> {
    console.log(`[MORPH] Auto-pipeline triggered for ${fileId}`);

    // Phase 1: Analyze
    await this.analyze(fileId);

    // Phase 2: Resolve Dependencies
    await this.resolveDependencies(fileId);

    // Phase 3: Fill Gaps
    await this.fillGaps(fileId);

    // Phase 4: Mount for Execution
    await this.mount(fileId);

    console.log(`[MORPH] Auto-pipeline complete for ${fileId}. EXECUTION READY.`);
  }

  // ─── PHASE 1: ANALYZE ──────────────────────────────────────────────────────
  async analyze(fileId: string): Promise<FileAnalysis> {
    const file = this.files.get(fileId);
    if (!file) throw new Error(`File not found: ${fileId}`);

    const content = file.rawContent;
    const lines = content.split('\n');

    const analysis: FileAnalysis = {
      lines: lines.length,
      complexity: this.calculateComplexity(content),
      functions: this.extractFunctions(content, file.extension),
      classes: this.extractClasses(content, file.extension),
      imports: this.extractImports(content, file.extension),
      exports: this.extractExports(content, file.extension),
      hasEntryPoint: this.detectEntryPoint(content, file.extension),
      hasTests: this.detectTests(content, file.extension),
      hasDocumentation: this.detectDocumentation(content),
      securityIssues: this.scanSecurity(content),
      qualityScore: 0,
      semanticFingerprint: this.generateFingerprint(content),
    };

    // Calculate quality score
    analysis.qualityScore = this.calculateQualityScore(analysis);

    file.analyzed = analysis;
    file.metadata.analyzedAt = new Date();
    file.metadata.tags = this.generateTags(analysis);
    file.metadata.semanticCluster = this.classifySemanticCluster(analysis);

    // Index in semantic cluster
    this.indexSemanticCluster(file.id, file.metadata.semanticCluster);

    console.log(`[MORPH] ANALYZED: ${file.name} — Quality: ${analysis.qualityScore}/100, Cluster: ${file.metadata.semanticCluster}`);

    return analysis;
  }

  // ─── PHASE 2: RESOLVE DEPENDENCIES ─────────────────────────────────────────
  async resolveDependencies(fileId: string): Promise<DependencyGraph> {
    const file = this.files.get(fileId);
    if (!file) throw new Error(`File not found: ${fileId}`);

    const deps: DependencyGraph = {
      internal: [],
      external: [],
      missing: [],
      circular: [],
      resolved: false,
    };

    // Resolve each import
    for (const imp of file.analyzed.imports) {
      if (imp.startsWith('.') || imp.startsWith('/')) {
        // Internal dependency
        const resolved = this.resolveInternalDependency(imp, file.path);
        if (resolved) {
          deps.internal.push(resolved);
          this.addDependencyEdge(fileId, resolved);
        } else {
          deps.missing.push(imp);
        }
      } else if (imp.startsWith('http')) {
        // External URL dependency
        deps.external.push(imp);
      } else {
        // External package dependency
        deps.external.push(imp);
        // Check if it's installed
        if (!this.isPackageInstalled(imp)) {
          deps.missing.push(imp);
        }
      }
    }

    // Detect circular dependencies
    deps.circular = this.detectCircularDependencies(fileId);

    deps.resolved = deps.missing.length === 0 && deps.circular.length === 0;
    file.dependencies = deps;

    console.log(`[MORPH] DEPENDENCIES: ${file.name} — Internal: ${deps.internal.length}, External: ${deps.external.length}, Missing: ${deps.missing.length}, Circular: ${deps.circular.length}`);

    return deps;
  }

  // ─── PHASE 3: FILL GAPS ────────────────────────────────────────────────────
  async fillGaps(fileId: string): Promise<GapReport[]> {
    const file = this.files.get(fileId);
    if (!file) throw new Error(`File not found: ${fileId}`);

    const gaps: GapReport[] = [];

    // Gap 1: Missing imports
    for (const missing of file.dependencies.missing) {
      gaps.push({
        type: 'missing_import',
        severity: 'critical',
        description: `Missing dependency: ${missing}`,
        suggestion: `Install ${missing} or create stub`,
        autoFillable: true,
        filledContent: this.generateStub(missing, file.extension),
      });
    }

    // Gap 2: Missing tests
    if (!file.analyzed.hasTests) {
      gaps.push({
        type: 'missing_test',
        severity: 'medium',
        description: 'No test coverage detected',
        suggestion: `Generate test suite for ${file.name}`,
        autoFillable: true,
        filledContent: this.generateTests(file),
      });
    }

    // Gap 3: Missing documentation
    if (!file.analyzed.hasDocumentation) {
      gaps.push({
        type: 'missing_doc',
        severity: 'low',
        description: 'No documentation found',
        suggestion: 'Generate JSDoc/docstring comments',
        autoFillable: true,
        filledContent: this.generateDocumentation(file),
      });
    }

    // Gap 4: Security vulnerabilities
    for (const issue of file.analyzed.securityIssues) {
      gaps.push({
        type: 'security_vulnerability',
        severity: issue.severity,
        line: issue.line,
        description: issue.description,
        suggestion: issue.fix,
        autoFillable: true,
        filledContent: this.generateSecurityFix(issue, file),
      });
    }

    // Gap 5: Incomplete implementations (detected by pattern)
    const incompleteGaps = this.detectIncompleteImplementations(file);
    gaps.push(...incompleteGaps);

    // Auto-fill all fillable gaps
    for (const gap of gaps) {
      if (gap.autoFillable && gap.filledContent) {
        gap.filledContent = await this.enhanceFill(gap, file);
      }
    }

    file.gaps = gaps;
    file.filled = true;
    file.metadata.gapFilledAt = new Date();

    console.log(`[MORPH] GAPS FILLED: ${file.name} — ${gaps.length} gaps identified, ${gaps.filter(g => g.autoFillable).length} auto-filled`);

    return gaps;
  }

  // ─── PHASE 4: MOUNT FOR EXECUTION ──────────────────────────────────────────
  async mount(fileId: string): Promise<ExecutionContext> {
    const file = this.files.get(fileId);
    if (!file) throw new Error(`File not found: ${fileId}`);

    // Ensure all dependencies are resolved
    if (!file.dependencies.resolved) {
      // Attempt to auto-resolve missing dependencies
      await this.autoResolveMissing(fileId);
    }

    // Create execution context
    const context: ExecutionContext = {
      environment: this.detectEnvironment(file),
      entryPoint: this.determineEntryPoint(file),
      args: {},
      preconditions: this.generatePreconditions(file),
      postconditions: this.generatePostconditions(file),
      sandbox: true,
    };

    // Mount in execution database
    file.mounted = true;
    file.executionReady = true;
    file.mountedAt = new Date();
    file.metadata.mountedAt = new Date();

    this.executionQueue.push(fileId);

    console.log(`[MORPH] MOUNTED: ${file.name} → Environment: ${context.environment}, Entry: ${context.entryPoint}`);
    console.log(`[MORPH] ✓ EXECUTION READY: ${file.name}`);

    return context;
  }

  // ─── EXECUTION ─────────────────────────────────────────────────────────────
  execute(fileId: string, args?: Record<string, any>): any {
    const file = this.files.get(fileId);
    if (!file) throw new Error(`File not found: ${fileId}`);
    if (!file.executionReady) {
      throw new Error(`File not ready for execution: ${fileId}. Run auto-pipeline first.`);
    }

    console.log(`[MORPH] EXECUTING: ${file.name}`);

    // Apply filled content
    const executableContent = this.applyFilledContent(file);

    // Execute based on dimension
    switch (file.dimension) {
      case 'JS':
        return this.executeJS(executableContent, args);
      case 'PYTHON':
        return this.executePython(executableContent, args);
      case 'HTML':
        return this.executeHTML(executableContent, args);
      case 'CSS':
        return this.executeCSS(executableContent, args);
      case 'JSON':
        return this.executeJSON(executableContent, args);
      default:
        throw new Error(`Execution not supported for dimension: ${file.dimension}`);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // ANALYSIS HELPERS
  // ═══════════════════════════════════════════════════════════════════════════════

  private classifyDimension(ext: string): keyof typeof DIMENSIONS {
    const map: Record<string, keyof typeof DIMENSIONS> = {
      'html': 'HTML', 'htm': 'HTML', 'jsx': 'HTML', 'tsx': 'HTML',
      'py': 'PYTHON', 'pyw': 'PYTHON',
      'json': 'JSON', 'yaml': 'JSON', 'yml': 'JSON', 'toml': 'JSON',
      'js': 'JS', 'ts': 'JS', 'mjs': 'JS', 'cjs': 'JS',
      'css': 'CSS', 'scss': 'CSS', 'sass': 'CSS', 'less': 'CSS',
    };
    return map[ext.toLowerCase()] || 'JS';
  }

  private generateId(hash: string, name: string): string {
    return `morph_${name}_${hash.slice(0, 8)}_${Date.now()}`;
  }

  private calculateComplexity(content: string): number {
    // Cyclomatic complexity approximation
    const branches = (content.match(/if|while|for|switch|catch|\?\./g) || []).length;
    const loops = (content.match(/for|while|do\s*{/g) || []).length;
    const conditions = (content.match(/if|else|switch|case/g) || []).length;
    return Math.min(100, Math.round((branches + loops * 2 + conditions) / Math.max(1, content.split('\n').length) * 100));
  }

  private extractFunctions(content: string, ext: string): string[] {
    const patterns: Record<string, RegExp> = {
      js: /(?:function|const|let|var)\s+(\w+)\s*[=\(]/g,
      ts: /(?:function|const|let|var)\s+(\w+)\s*[=\(]|:\s*\(.*?\)\s*=>/g,
      py: /def\s+(\w+)\s*\(/g,
    };
    const pattern = patterns[ext] || patterns.js;
    const matches = [...content.matchAll(pattern)];
    return matches.map(m => m[1]).filter(Boolean);
  }

  private extractClasses(content: string, ext: string): string[] {
    const pattern = /class\s+(\w+)/g;
    const matches = [...content.matchAll(pattern)];
    return matches.map(m => m[1]);
  }

  private extractImports(content: string, ext: string): string[] {
    const patterns: Record<string, RegExp> = {
      js: /(?:import|require)\s*\(?['"]([^'"]+)['"]/g,
      ts: /(?:import|require)\s*\(?['"]([^'"]+)['"]/g,
      py: /(?:import|from)\s+([\w.]+)/g,
    };
    const pattern = patterns[ext] || patterns.js;
    const matches = [...content.matchAll(pattern)];
    return [...new Set(matches.map(m => m[1]))];
  }

  private extractExports(content: string, ext: string): string[] {
    const pattern = /export\s+(?:default\s+)?(?:class|function|const|let|var)?\s*(\w+)/g;
    const matches = [...content.matchAll(pattern)];
    return matches.map(m => m[1]).filter(Boolean);
  }

  private detectEntryPoint(content: string, ext: string): boolean {
    const patterns = [
      /if\s*\(\s*require\s*\.\s*main\s*===\s*module\s*\)/,
      /export\s+default/,
      /def\s+main\s*\(/,
      /\.listen\s*\(/,
      /createRoot\s*\(/,
      /ReactDOM\.render/,
    ];
    return patterns.some(p => p.test(content));
  }

  private detectTests(content: string, ext: string): boolean {
    return /(?:describe|it|test|expect|assert|jest|mocha|pytest|unittest)/.test(content);
  }

  private detectDocumentation(content: string): boolean {
    return /(?:\/\*\*|\/\/\/|#\s|"""|\'\'\')/.test(content);
  }

  private scanSecurity(content: string): SecurityIssue[] {
    const issues: SecurityIssue[] = [];
    const lines = content.split('\n');

    const patterns = [
      { type: 'eval_usage', regex: /eval\s*\(/, severity: 'critical' as const, fix: 'Use JSON.parse or Function constructor instead' },
      { type: 'innerHTML', regex: /\.innerHTML\s*=/, severity: 'high' as const, fix: 'Use textContent or createElement' },
      { type: 'hardcoded_secret', regex: /(?:password|secret|token|key)\s*[=:]\s*['"][^'"]+['"]/i, severity: 'critical' as const, fix: 'Use environment variables' },
      { type: 'sql_injection', regex: /(?:query|exec)\s*\(.*?\+/, severity: 'critical' as const, fix: 'Use parameterized queries' },
      { type: 'xss_vulnerable', regex: /document\.write\s*\(/, severity: 'high' as const, fix: 'Use safe DOM manipulation' },
    ];

    lines.forEach((line, idx) => {
      for (const pattern of patterns) {
        if (pattern.regex.test(line)) {
          issues.push({
            type: pattern.type,
            severity: pattern.severity,
            line: idx + 1,
            description: `Security issue: ${pattern.type}`,
            fix: pattern.fix,
          });
        }
      }
    });

    return issues;
  }

  private generateFingerprint(content: string): string {
    // Structural fingerprint (ignores whitespace/comments)
    const normalized = content
      .replace(/\s+/g, ' ')
      .replace(/\/\/.*$/gm, '')
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .trim();
    return createHash('sha256').update(normalized).digest('hex').slice(0, 16);
  }

  private calculateQualityScore(analysis: FileAnalysis): number {
    let score = 50; // Base score
    if (analysis.hasEntryPoint) score += 10;
    if (analysis.hasTests) score += 15;
    if (analysis.hasDocumentation) score += 10;
    if (analysis.securityIssues.length === 0) score += 15;
    score -= analysis.complexity * 0.5;
    score -= analysis.securityIssues.length * 10;
    return Math.max(0, Math.min(100, Math.round(score)));
  }

  private generateTags(analysis: FileAnalysis): string[] {
    const tags: string[] = [];
    if (analysis.hasEntryPoint) tags.push('entry-point');
    if (analysis.hasTests) tags.push('tested');
    if (analysis.hasDocumentation) tags.push('documented');
    if (analysis.functions.length > 5) tags.push('complex');
    if (analysis.classes.length > 0) tags.push('oop');
    if (analysis.securityIssues.length > 0) tags.push('security-review-needed');
    return tags;
  }

  private classifySemanticCluster(analysis: FileAnalysis): string {
    // Classify into attractor basins based on content patterns
    const content = analysis.functions.join(' ') + ' ' + analysis.classes.join(' ');

    if (/router|controller|endpoint|api|handler|middleware/.test(content)) return 'routing';
    if (/component|render|jsx|tsx|html|dom/.test(content)) return 'presentation';
    if (/database|model|schema|query|repository/.test(content)) return 'data';
    if (/auth|login|permission|token|session|jwt/.test(content)) return 'security';
    if (/test|spec|mock|assert|expect/.test(content)) return 'testing';
    if /config|setting|env|constant/.test(content)) return 'configuration';
    if (/util|helper|format|parse|validate/.test(content)) return 'utility';
    if (/orchestrat|schedul|dispatch|manage|control/.test(content)) return 'orchestration';
    return 'general';
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // DEPENDENCY RESOLUTION HELPERS
  // ═══════════════════════════════════════════════════════════════════════════════

  private resolveInternalDependency(importPath: string, fromPath: string): string | null {
    const resolved = resolve(dirname(fromPath), importPath);
    // Check if already ingested
    for (const [id, file] of this.files) {
      if (file.path === resolved || file.path === resolved + '.js' || file.path === resolved + '.ts') {
        return id;
      }
    }
    // Check if file exists on disk
    if (existsSync(resolved)) return this.ingest(resolved).id;
    if (existsSync(resolved + '.js')) return this.ingest(resolved + '.js').id;
    if (existsSync(resolved + '.ts')) return this.ingest(resolved + '.ts').id;
    return null;
  }

  private isPackageInstalled(pkg: string): boolean {
    try {
      require.resolve(pkg);
      return true;
    } catch {
      return false;
    }
  }

  private detectCircularDependencies(fileId: string, visited: Set<string> = new Set(), path: string[] = []): string[][] {
    const cycles: string[][] = [];

    if (visited.has(fileId)) {
      const cycleStart = path.indexOf(fileId);
      if (cycleStart !== -1) {
        cycles.push(path.slice(cycleStart));
      }
      return cycles;
    }

    visited.add(fileId);
    path.push(fileId);

    const file = this.files.get(fileId);
    if (file) {
      for (const depId of file.dependencies.internal) {
        cycles.push(...this.detectCircularDependencies(depId, new Set(visited), [...path]));
      }
    }

    return cycles;
  }

  private addDependencyEdge(from: string, to: string): void {
    if (!this.dependencyTree.has(to)) {
      this.dependencyTree.set(to, new Set());
    }
    this.dependencyTree.get(to)!.add(from);
  }

  private async autoResolveMissing(fileId: string): Promise<void> {
    const file = this.files.get(fileId);
    if (!file) return;

    for (const missing of file.dependencies.missing) {
      // Try to generate or find the missing dependency
      const generated = this.generateStub(missing, file.extension);
      const stubPath = resolve('./morph_stubs', `${missing}.${file.extension}`);

      mkdirSync(dirname(stubPath), { recursive: true });
      writeFileSync(stubPath, generated);

      const stubFile = this.ingest(stubPath, generated);
      file.dependencies.internal.push(stubFile.id);
      console.log(`[MORPH] AUTO-RESOLVED: Generated stub for ${missing}`);
    }

    file.dependencies.missing = [];
    file.dependencies.resolved = true;
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // GAP FILLING HELPERS
  // ═══════════════════════════════════════════════════════════════════════════════

  private generateStub(moduleName: string, ext: string): string {
    const stubs: Record<string, string> = {
      js: `// Auto-generated stub for ${moduleName}
export default function ${moduleName.replace(/[^a-zA-Z]/g, '_')}() {
  console.warn('[MORPH] Stub called: ${moduleName}');
  return {};
}`,
      ts: `// Auto-generated stub for ${moduleName}
export default function ${moduleName.replace(/[^a-zA-Z]/g, '_')}(): any {
  console.warn('[MORPH] Stub called: ${moduleName}');
  return {};
}`,
      py: `# Auto-generated stub for ${moduleName}
def ${moduleName.replace(/[^a-zA-Z]/g, '_')}():
    print('[MORPH] Stub called: ${moduleName}')
    return {}`,
    };
    return stubs[ext] || stubs.js;
  }

  private generateTests(file: IngestedFile): string {
    const testName = `${file.name}.test.${file.extension}`;
    const functions = file.analyzed.functions.map(f => 
      `  test('${f} should work correctly', () => {
    expect(${f}()).toBeDefined();
  });`
    ).join('\n');

    return `// Auto-generated tests for ${file.name}
import { ${file.analyzed.exports.join(', ')} } from './${file.name}';

describe('${file.name}', () => {
${functions}
});`;
  }

  private generateDocumentation(file: IngestedFile): string {
    const docs = file.analyzed.functions.map(f => 
      `/**
 * ${f} - Auto-generated documentation
 * @returns {any} - Result of ${f}
 */`
    ).join('\n');
    return docs;
  }

  private generateSecurityFix(issue: SecurityIssue, file: IngestedFile): string {
    const fixes: Record<string, string> = {
      eval_usage: '// SECURITY FIX: Replaced eval with safe alternative\nconst safeParse = (str) => JSON.parse(str);',
      innerHTML: '// SECURITY FIX: Use textContent instead of innerHTML\nelement.textContent = sanitizedContent;',
      hardcoded_secret: '// SECURITY FIX: Use environment variable\nconst secret = process.env.SECRET_KEY;',
      sql_injection: '// SECURITY FIX: Use parameterized query\nconst query = "SELECT * FROM users WHERE id = ?";',
      xss_vulnerable: '// SECURITY FIX: Use safe DOM methods\nconst el = document.createElement("div");',
    };
    return fixes[issue.type] || '// SECURITY FIX: Review required';
  }

  private detectIncompleteImplementations(file: IngestedFile): GapReport[] {
    const gaps: GapReport[] = [];
    const content = file.rawContent;
    const lines = content.split('\n');

    // Detect TODO/FIXME/placeholder patterns
    lines.forEach((line, idx) => {
      if (/TODO|FIXME|HACK|XXX|placeholder|not implemented|coming soon/i.test(line)) {
        gaps.push({
          type: 'incomplete_implementation',
          severity: 'medium',
          line: idx + 1,
          description: `Incomplete implementation: ${line.trim()}`,
          suggestion: 'Complete the implementation',
          autoFillable: true,
          filledContent: `// [MORPH] Auto-completed: ${line.trim()}\n// Implementation needed here`,
        });
      }
    });

    // Detect empty function bodies
    const emptyFunctionPattern = /(?:function|=>)\s*\{\s*\}/g;
    let match;
    while ((match = emptyFunctionPattern.exec(content)) !== null) {
      const lineNum = content.substring(0, match.index).split('\n').length;
      gaps.push({
        type: 'incomplete_implementation',
        severity: 'high',
        line: lineNum,
        description: 'Empty function body detected',
        suggestion: 'Implement function logic',
        autoFillable: true,
        filledContent: '// [MORPH] Auto-filled empty function\nreturn null;',
      });
    }

    return gaps;
  }

  private async enhanceFill(gap: GapReport, file: IngestedFile): Promise<string> {
    // Enhance the fill based on semantic cluster and file context
    const cluster = file.metadata.semanticCluster;

    // Add cluster-specific context to the fill
    const contextHeader = `// [MORPH] Auto-generated for ${cluster} cluster\n`;

    return contextHeader + gap.filledContent;
  }

  private applyFilledContent(file: IngestedFile): string {
    let content = file.rawContent;

    // Apply security fixes first (highest priority)
    const securityGaps = file.gaps.filter(g => g.type === 'security_vulnerability');
    for (const gap of securityGaps) {
      if (gap.line && gap.filledContent) {
        const lines = content.split('\n');
        lines[gap.line - 1] = gap.filledContent + '\n' + lines[gap.line - 1];
        content = lines.join('\n');
      }
    }

    // Apply other fills
    for (const gap of file.gaps) {
      if (gap.type === 'security_vulnerability') continue; // Already applied
      if (gap.filledContent) {
        content += '\n\n' + gap.filledContent;
      }
    }

    return content;
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // EXECUTION HELPERS
  // ═══════════════════════════════════════════════════════════════════════════════

  private detectEnvironment(file: IngestedFile): ExecutionContext['environment'] {
    if (file.dimension === 'HTML' || file.dimension === 'CSS') return 'browser';
    if (file.dimension === 'PYTHON') return 'python';
    if (file.rawContent.includes('document.') || file.rawContent.includes('window.')) return 'browser';
    if (file.rawContent.includes('require(') || file.rawContent.includes('module.exports')) return 'node';
    return 'node';
  }

  private determineEntryPoint(file: IngestedFile): string {
    if (file.analyzed.hasEntryPoint) return file.path;
    // Find entry point in exports
    if (file.analyzed.exports.length > 0) {
      return `${file.path}#${file.analyzed.exports[0]}`;
    }
    return file.path;
  }

  private generatePreconditions(file: IngestedFile): string[] {
    const preconditions: string[] = [];
    for (const dep of file.dependencies.external) {
      preconditions.push(`Package ${dep} is installed`);
    }
    for (const dep of file.dependencies.internal) {
      const depFile = this.files.get(dep);
      if (depFile) {
        preconditions.push(`Dependency ${depFile.name} is mounted`);
      }
    }
    return preconditions;
  }

  private generatePostconditions(file: IngestedFile): string[] {
    return [
      `File ${file.name} executes without errors`,
      `All exports are accessible`,
      `Side effects are contained`,
    ];
  }

  private executeJS(content: string, args?: Record<string, any>): any {
    // Create a safe execution context
    const sandbox = {
      console,
      require,
      module: { exports: {} },
      exports: {},
      __dirname: process.cwd(),
      __filename: 'morph_execution.js',
      process,
      Buffer,
      setTimeout,
      setInterval,
      clearTimeout,
      clearInterval,
      ...args,
    };

    const vm = require('vm');
    const script = new vm.Script(content, { filename: 'morph_execution.js' });
    const context = vm.createContext(sandbox);

    try {
      const result = script.runInContext(context, { timeout: 5000 });
      return { success: true, result, exports: sandbox.module.exports };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  private executePython(content: string, args?: Record<string, any>): any {
    // For Python, we'd spawn a child process
    // This is a simplified version
    return { success: true, result: 'Python execution requires child process spawn', simulated: true };
  }

  private executeHTML(content: string, args?: Record<string, any>): any {
    return { success: true, result: 'HTML rendered in browser context', content };
  }

  private executeCSS(content: string, args?: Record<string, any>): any {
    return { success: true, result: 'CSS styles applied', content };
  }

  private executeJSON(content: string, args?: Record<string, any>): any {
    try {
      const parsed = JSON.parse(content);
      return { success: true, result: parsed };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // SEMANTIC INDEXING
  // ═══════════════════════════════════════════════════════════════════════════════

  private indexSemanticCluster(fileId: string, cluster: string): void {
    if (!this.semanticIndex.has(cluster)) {
      this.semanticIndex.set(cluster, new Set());
    }
    this.semanticIndex.get(cluster)!.add(fileId);
  }

  getCluster(cluster: string): IngestedFile[] {
    const ids = this.semanticIndex.get(cluster);
    if (!ids) return [];
    return Array.from(ids).map(id => this.files.get(id)!).filter(Boolean);
  }

  getAllFiles(): IngestedFile[] {
    return Array.from(this.files.values());
  }

  getFile(id: string): IngestedFile | undefined {
    return this.files.get(id);
  }

  getExecutionQueue(): string[] {
    return [...this.executionQueue];
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // MORPH GROWTH — Self-Expansion
  // ═══════════════════════════════════════════════════════════════════════════════

  grow(): { newFiles: number; totalComplexity: number; clusters: string[] } {
    // The system grows by analyzing patterns and generating new files
    const clusters = Array.from(this.semanticIndex.keys());
    const totalComplexity = this.getAllFiles().reduce((sum, f) => sum + f.analyzed.complexity, 0);

    // Generate integration layer if multiple clusters exist
    if (clusters.length > 1) {
      this.generateIntegrationLayer(clusters);
    }

    return {
      newFiles: this.files.size,
      totalComplexity,
      clusters,
    };
  }

  private generateIntegrationLayer(clusters: string[]): void {
    const integrationContent = `
// ═══════════════════════════════════════════════════════════════════════════════
// MORPH INTEGRATION LAYER — Auto-generated
// Connects clusters: ${clusters.join(', ')}
// ═══════════════════════════════════════════════════════════════════════════════

import { MorphDatabase } from './morph-ingestion-engine';

export class MorphIntegrationLayer {
  private db = MorphDatabase.getInstance();

  ${clusters.map(c => `
  async orchestrate${c.charAt(0).toUpperCase() + c.slice(1)}() {
    const files = this.db.getCluster('${c}');
    console.log(\`Orchestrating ${c} cluster with \${files.length} files\`);
    return files.map(f => f.id);
  }`).join('\n')}

  async crossClusterResonance() {
    // Find resonance between clusters
    const allFiles = this.db.getAllFiles();
    return allFiles.map(f => ({
      id: f.id,
      cluster: f.metadata.semanticCluster,
      fingerprint: f.analyzed.semanticFingerprint,
    }));
  }
}
`;

    const integrationPath = resolve('./morph_generated', 'integration-layer.ts');
    mkdirSync(dirname(integrationPath), { recursive: true });
    writeFileSync(integrationPath, integrationContent);
    this.ingest(integrationPath, integrationContent);

    console.log(`[MORPH] GROWTH: Generated integration layer for ${clusters.length} clusters`);
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MORPH CLI — Direct Interface
// ═══════════════════════════════════════════════════════════════════════════════
export class MorphCLI {
  private db = MorphDatabase.getInstance();

  async ingest(filePath: string): Promise<void> {
    const file = this.db.ingest(filePath);
    console.log(`\n[MORPH CLI] File ingested: ${file.name}`);
    console.log(`  Dimension: ${file.dimension}`);
    console.log(`  Cluster: ${file.metadata.semanticCluster}`);
    console.log(`  Quality: ${file.analyzed.qualityScore}/100`);
    console.log(`  Gaps: ${file.gaps.length}`);
    console.log(`  Ready: ${file.executionReady}`);
  }

  async execute(fileId: string): Promise<any> {
    return this.db.execute(fileId);
  }

  status(): void {
    const files = this.db.getAllFiles();
    console.log(`\n[MORPH STATUS]`);
    console.log(`  Total Files: ${files.length}`);
    console.log(`  Execution Queue: ${this.db.getExecutionQueue().length}`);

    const clusters = new Map<string, number>();
    files.forEach(f => {
      const c = f.metadata.semanticCluster;
      clusters.set(c, (clusters.get(c) || 0) + 1);
    });

    console.log(`  Clusters:`);
    for (const [cluster, count] of clusters) {
      console.log(`    ${cluster}: ${count} files`);
    }
  }

  grow(): void {
    const growth = this.db.grow();
    console.log(`\n[MORPH GROWTH]`);
    console.log(`  New Files: ${growth.newFiles}`);
    console.log(`  Total Complexity: ${growth.totalComplexity}`);
    console.log(`  Clusters: ${growth.clusters.join(', ')}`);
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// EXPORT — The Morph Interface
// ═══════════════════════════════════════════════════════════════════════════════
export { MorphDatabase, MorphCLI };
export default MorphDatabase;

// ═══════════════════════════════════════════════════════════════════════════════
// BOOTSTRAP — If run directly
// ═══════════════════════════════════════════════════════════════════════════════
if (require.main === module) {
  const cli = new MorphCLI();
  const args = process.argv.slice(2);

  if (args[0] === 'ingest' && args[1]) {
    cli.ingest(args[1]);
  } else if (args[0] === 'status') {
    cli.status();
  } else if (args[0] === 'grow') {
    cli.grow();
  } else {
    console.log(`
MORPH INGESTION ENGINE v1.0
Usage:
  node morph-ingestion-engine.js ingest <file_path>
  node morph-ingestion-engine.js status
  node morph-ingestion-engine.js grow
    `);
  }
}
