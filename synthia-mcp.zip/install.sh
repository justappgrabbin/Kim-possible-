#!/data/data/com.termux/files/usr/bin/bash
# ═══════════════════════════════════════════════════════════════
#  Synthia MCP — Self-Installing Bootstrap for Termux
#  One command installs everything. No manual steps.
# ═══════════════════════════════════════════════════════════════

set -e

SYNTHIA_DIR="${HOME}/synthia-mcp"
NODE_MIN="20.0.0"
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

banner() {
    echo ""
    echo "${CYAN}╔══════════════════════════════════════════════════════╗${NC}"
    echo "${CYAN}║${NC}  🧠  ${GREEN}Synthia MCP${NC} — Self-Installing Agent          ${CYAN}║${NC}"
    echo "${CYAN}║${NC}     Termux · Core-Termux · Device Control · MCP     ${CYAN}║${NC}"
    echo "${CYAN}╚══════════════════════════════════════════════════════╝${NC}"
    echo ""
}

step() {
    echo "${BLUE}▶${NC} $1"
}

ok() {
    echo "${GREEN}✓${NC} $1"
}

warn() {
    echo "${YELLOW}⚠${NC} $1"
}

fail() {
    echo "${RED}✗${NC} $1"
    exit 1
}

# ─── Check Termux ───
banner

step "Checking Termux environment..."
if [ -z "$TERMUX_VERSION" ] && [ -z "$PREFIX" ]; then
    fail "This installer only works in Termux on Android."
fi
ok "Termux detected"

# ─── Update packages ───
step "Updating package lists..."
pkg update -y > /dev/null 2>&1 || true
ok "Package lists updated"

# ─── Install Node.js if missing ───
step "Checking Node.js..."
if command -v node &> /dev/null; then
    NODE_VER=$(node --version | sed 's/v//')
    ok "Node.js ${NODE_VER} found"
else
    step "Installing Node.js LTS..."
    pkg install nodejs-lts -y
    ok "Node.js installed"
fi

# ─── Install Git if missing ───
step "Checking Git..."
if ! command -v git &> /dev/null; then
    pkg install git -y
    ok "Git installed"
else
    ok "Git found"
fi

# ─── Install TypeScript compiler globally ───
step "Checking TypeScript..."
if ! command -v tsc &> /dev/null; then
    npm install -g typescript
    ok "TypeScript installed globally"
else
    ok "TypeScript found"
fi

# ─── Install core-termux if missing ───
step "Checking core-termux..."
if ! command -v core &> /dev/null; then
    warn "core-termux not found — installing..."
    curl -fsSL https://raw.githubusercontent.com/DevCoreXOfficial/core-termux/main/install.sh | bash
    ok "core-termux installed"
else
    CORE_VER=$(core --version 2>/dev/null || echo "unknown")
    ok "core-termux ${CORE_VER} found"
fi

# ─── Install Termux:API package if missing ───
step "Checking Termux:API..."
if ! command -v termux-media-scan &> /dev/null; then
    warn "Termux:API package not found — installing..."
    pkg install termux-api -y
    ok "Termux:API package installed"
    warn "⚠️  Please also install the Termux:API app from F-Droid for full device control"
else
    ok "Termux:API found"
fi

# ─── Clone or update Synthia MCP ───
step "Setting up Synthia MCP..."
if [ -d "$SYNTHIA_DIR" ]; then
    step "Existing installation found — updating..."
    cd "$SYNTHIA_DIR"
    git pull origin main 2>/dev/null || git pull 2>/dev/null || warn "Could not update via git"
else
    step "Cloning Synthia MCP..."
    # For now, create locally. In production, this would be:
    # git clone https://github.com/YOUR_REPO/synthia-mcp.git "$SYNTHIA_DIR"
    mkdir -p "$SYNTHIA_DIR"
    cd "$SYNTHIA_DIR"
fi
ok "Synthia MCP directory ready"

# ─── Install npm dependencies ───
step "Installing npm dependencies..."
cd "$SYNTHIA_DIR"
if [ ! -f "package.json" ]; then
    # Create package.json inline if it doesn't exist (for local dev)
    cat > package.json << 'EOF'
{
  "name": "synthia-mcp",
  "version": "1.0.0",
  "description": "Self-installing MCP server for Termux",
  "type": "module",
  "main": "dist/server.js",
  "bin": { "synthia-mcp": "dist/server.js" },
  "scripts": {
    "build": "tsc",
    "start": "node dist/server.js",
    "bootstrap": "bash install.sh"
  },
  "dependencies": {
    "@modelcontextprotocol/sdk": "^1.0.4",
    "zod": "^3.23.8"
  },
  "devDependencies": {
    "@types/node": "^22.0.0",
    "typescript": "^5.7.0"
  }
}
EOF
fi

npm install
ok "Dependencies installed"

# ─── Build TypeScript ───
step "Building TypeScript..."
if [ ! -f "tsconfig.json" ]; then
    cat > tsconfig.json << 'EOF'
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "declaration": true,
    "sourceMap": true
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist"]
}
EOF
fi

# Check if source exists, if not create minimal structure
if [ ! -d "src" ]; then
    warn "Source files not found — creating minimal structure..."
    mkdir -p src/utils src/tools src/engine

    # Create minimal server.ts for bootstrapping
    cat > src/server.ts << 'EOF'
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import { exec } from 'child_process';
import { promisify } from 'util';
const execAsync = promisify(exec);

const server = new Server(
  { name: 'synthia-mcp', version: '1.0.0' },
  { capabilities: { tools: {} } }
);

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    { name: 'synthia_intent', description: 'Execute natural language intent', inputSchema: { type: 'object', properties: { intent: { type: 'string' } }, required: ['intent'] } },
    { name: 'synthia_shell', description: 'Run shell command', inputSchema: { type: 'object', properties: { command: { type: 'string' } }, required: ['command'] } },
    { name: 'synthia_status', description: 'System status', inputSchema: { type: 'object', properties: {} } }
  ]
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;
  try {
    if (name === 'synthia_intent') {
      const { stdout } = await execAsync(`echo "Processing: ${args.intent}"`);
      return { content: [{ type: 'text', text: `🧠 Intent received: ${args.intent}\n\n${stdout}` }] };
    }
    if (name === 'synthia_shell') {
      const { stdout, stderr } = await execAsync(args.command as string, { timeout: 60000, maxBuffer: 10 * 1024 * 1024 });
      return { content: [{ type: 'text', text: `STDOUT:\n${stdout}\n\nSTDERR:\n${stderr}` }] };
    }
    if (name === 'synthia_status') {
      const node = (await execAsync('node --version')).stdout.trim();
      const core = (await execAsync('core --version 2>/dev/null || echo "not installed"')).stdout.trim();
      return { content: [{ type: 'text', text: `Node: ${node}\nCore: ${core}\nSynthia: running` }] };
    }
    return { content: [{ type: 'text', text: 'Unknown tool' }] };
  } catch (e: any) {
    return { content: [{ type: 'text', text: `Error: ${e.message}` }], isError: true };
  }
});

const transport = new StdioServerTransport();
await server.connect(transport);
console.log('🧠 Synthia MCP Server running...');
EOF
fi

npx tsc
ok "TypeScript compiled"

# ─── Create startup script ───
step "Creating startup script..."
cat > "$SYNTHIA_DIR/start.sh" << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
cd "${HOME}/synthia-mcp"
echo "🧠 Starting Synthia MCP Server..."
node dist/server.js
EOF
chmod +x "$SYNTHIA_DIR/start.sh"
ok "Startup script created"

# ─── Register with Claude Code if available ───
step "Checking for MCP clients..."
if command -v claude &> /dev/null; then
    step "Registering with Claude Code..."
    claude mcp add synthia-termux -- node "$SYNTHIA_DIR/dist/server.js" 2>/dev/null || warn "Could not auto-register with Claude Code"
    ok "Registered with Claude Code"
fi

if command -v cursor &> /dev/null; then
    warn "Cursor detected — add this to your MCP config:"
    echo "  { 'mcpServers': { 'synthia-termux': { 'command': 'node', 'args': ['$SYNTHIA_DIR/dist/server.js'] } } }"
fi

# ─── Create convenience alias ───
step "Adding shell alias..."
SHELL_RC=""
if [ -f "$HOME/.zshrc" ]; then
    SHELL_RC="$HOME/.zshrc"
elif [ -f "$HOME/.bashrc" ]; then
    SHELL_RC="$HOME/.bashrc"
fi

if [ -n "$SHELL_RC" ] && ! grep -q "synthia-start" "$SHELL_RC" 2>/dev/null; then
    echo "" >> "$SHELL_RC"
    echo "# Synthia MCP alias" >> "$SHELL_RC"
    echo "alias synthia-start='bash ${HOME}/synthia-mcp/start.sh'" >> "$SHELL_RC"
    echo "alias synthia-status='node ${HOME}/synthia-mcp/dist/server.js --status 2>/dev/null || echo "Run synthia-start first"'" >> "$SHELL_RC"
    ok "Alias added to ${SHELL_RC}"
    warn "Run 'source ${SHELL_RC}' to use the alias now"
else
    warn "Shell alias already exists or no shell rc found"
fi

# ─── Final status ───
echo ""
echo "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
echo "${GREEN}║${NC}  🎉 Synthia MCP is ready!                           ${GREEN}║${NC}"
echo "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo "${CYAN}Quick Start:${NC}"
echo "  ${YELLOW}synthia-start${NC}          — Start the MCP server"
echo "  ${YELLOW}bash ${HOME}/synthia-mcp/start.sh${NC}  — Direct start"
echo ""
echo "${CYAN}MCP Client Config (add to your client):${NC}"
echo '  {'
echo '    "mcpServers": {'
echo '      "synthia-termux": {'
echo "        "command": "node","
echo "        "args": ["${HOME}/synthia-mcp/dist/server.js"]"
echo '      }'
echo '    }'
echo '  }'
echo ""
echo "${CYAN}Available Tools (once connected):${NC}"
echo "  • synthia_intent — Natural language execution"
echo "  • synthia_shell — Raw shell commands"
echo "  • synthia_core_install — Install core-termux modules"
echo "  • synthia_core_init — Initialize projects"
echo "  • synthia_core_pg — PostgreSQL management"
echo "  • synthia_device_* — Device control (screenshot, tap, swipe, apps)"
echo "  • synthia_brain_* — Memory management"
echo "  • synthia_status — Full system status"
echo ""
echo "${GREEN}Done!${NC}"
