/**
 * Synthia MCP Server — Self-installing, self-learning Termux agent
 * Bridges core-termux, local device control, and mobile-mcp
 */
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';

import { MemoryStore } from './utils/memory.js';
import { IntentParser } from './engine/intent-parser.js';
import { Planner } from './engine/planner.js';
import { Executor } from './engine/executor.js';
import { CoreTermuxTools } from './tools/core-termux.js';
import { DeviceControlTools } from './tools/device-control.js';
import { runShell } from './utils/shell.js';

// ─── Initialization ───
const memory = new MemoryStore();
await memory.init();

const parser = new IntentParser();
const planner = new Planner(memory);
const executor = new Executor(memory);
const coreTermux = new CoreTermuxTools();
const deviceControl = new DeviceControlTools();

console.log('🧠 Synthia MCP Server initializing...');
console.log(`   Memory: ${(await memory.getStats()).outcomes} outcomes, ${(await memory.getStats()).memories} memories`);

// ─── MCP Server ───
const server = new Server(
  { name: 'synthia-mcp', version: '1.0.0' },
  { capabilities: { tools: {} } }
);

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: 'synthia_intent',
      description: 'Execute a natural language intent. The agent parses, plans, executes, and learns. Examples: "deploy my Next.js app", "fix the server", "screenshot my phone", "install PostgreSQL", "check server health"',
      inputSchema: {
        type: 'object',
        properties: {
          intent: { type: 'string', description: 'What you want to do in plain English' },
          context: { type: 'object', description: 'Optional additional context (cwd, project info, etc.)' }
        },
        required: ['intent']
      }
    },
    {
      name: 'synthia_shell',
      description: 'Execute a raw shell command in Termux with full output capture and logging',
      inputSchema: {
        type: 'object',
        properties: {
          command: { type: 'string', description: 'Shell command to execute' },
          cwd: { type: 'string', description: 'Working directory' },
          timeout: { type: 'number', description: 'Timeout in milliseconds (default: 60000)' },
          retries: { type: 'number', description: 'Number of retries on failure (default: 0)' }
        },
        required: ['command']
      }
    },
    {
      name: 'synthia_core_install',
      description: 'Install a core-termux module or specific tools within it',
      inputSchema: {
        type: 'object',
        properties: {
          module: { type: 'string', enum: ['lang', 'db', 'ai', 'editor', 'dev', 'npm', 'shell', 'ui', 'auto'], description: 'Module to install' },
          tools: { type: 'array', items: { type: 'string' }, description: 'Specific tools to install (optional)' }
        },
        required: ['module']
      }
    },
    {
      name: 'synthia_core_init',
      description: 'Initialize a project with core-termux templates',
      inputSchema: {
        type: 'object',
        properties: {
          template: { type: 'string', enum: ['next', 'react', 'express', 'nest'], description: 'Project template' },
          cwd: { type: 'string', description: 'Working directory (default: current)' }
        },
        required: ['template']
      }
    },
    {
      name: 'synthia_core_env',
      description: 'Manage environment variables via core-termux',
      inputSchema: {
        type: 'object',
        properties: {
          action: { type: 'string', enum: ['set', 'unset', 'list'], description: 'Action to perform' },
          key: { type: 'string', description: 'Variable name (for set/unset)' },
          value: { type: 'string', description: 'Variable value (for set)' }
        },
        required: ['action']
      }
    },
    {
      name: 'synthia_core_pg',
      description: 'Manage PostgreSQL via core-termux',
      inputSchema: {
        type: 'object',
        properties: {
          command: { type: 'string', enum: ['start', 'stop', 'restart', 'status', 'init', 'create', 'drop', 'list', 'shell'], description: 'PostgreSQL command' },
          arg: { type: 'string', description: 'Optional argument (e.g., database name for create/drop)' }
        },
        required: ['command']
      }
    },
    {
      name: 'synthia_device_state',
      description: 'Get current state of the local Android device (battery, screen, app, orientation)',
      inputSchema: { type: 'object', properties: {} }
    },
    {
      name: 'synthia_device_screenshot',
      description: 'Take a screenshot of the local Android device',
      inputSchema: {
        type: 'object',
        properties: {
          path: { type: 'string', description: 'Optional save path' }
        }
      }
    },
    {
      name: 'synthia_device_tap',
      description: 'Tap at specific coordinates on the local Android device',
      inputSchema: {
        type: 'object',
        properties: {
          x: { type: 'number', description: 'X coordinate' },
          y: { type: 'number', description: 'Y coordinate' }
        },
        required: ['x', 'y']
      }
    },
    {
      name: 'synthia_device_swipe',
      description: 'Swipe on the local Android device screen',
      inputSchema: {
        type: 'object',
        properties: {
          x1: { type: 'number', description: 'Start X' },
          y1: { type: 'number', description: 'Start Y' },
          x2: { type: 'number', description: 'End X' },
          y2: { type: 'number', description: 'End Y' },
          duration: { type: 'number', description: 'Swipe duration in ms (default: 300)' }
        },
        required: ['x1', 'y1', 'x2', 'y2']
      }
    },
    {
      name: 'synthia_device_list_apps',
      description: 'List installed apps on the local Android device',
      inputSchema: { type: 'object', properties: {} }
    },
    {
      name: 'synthia_device_launch_app',
      description: 'Launch an app by package name on the local Android device',
      inputSchema: {
        type: 'object',
        properties: {
          packageName: { type: 'string', description: 'Android package name (e.g., com.termux)' }
        },
        required: ['packageName']
      }
    },
    {
      name: 'synthia_device_press_button',
      description: 'Press a hardware button on the local Android device',
      inputSchema: {
        type: 'object',
        properties: {
          button: { type: 'string', enum: ['home', 'back', 'power', 'volume_up', 'volume_down', 'enter', 'menu', 'recent'], description: 'Button to press' }
        },
        required: ['button']
      }
    },
    {
      name: 'synthia_device_type',
      description: 'Type text on the local Android device',
      inputSchema: {
        type: 'object',
        properties: {
          text: { type: 'string', description: 'Text to type' }
        },
        required: ['text']
      }
    },
    {
      name: 'synthia_device_open_url',
      description: 'Open a URL on the local Android device',
      inputSchema: {
        type: 'object',
        properties: {
          url: { type: 'string', description: 'URL to open' }
        },
        required: ['url']
      }
    },
    {
      name: 'synthia_brain_save',
      description: 'Save a memory to core-termux brain',
      inputSchema: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          category: { type: 'string' },
          tags: { type: 'array', items: { type: 'string' } },
          content: { type: 'string' }
        },
        required: ['title', 'category', 'content']
      }
    },
    {
      name: 'synthia_brain_search',
      description: 'Search core-termux brain memories',
      inputSchema: {
        type: 'object',
        properties: {
          query: { type: 'string', description: 'Search query' }
        },
        required: ['query']
      }
    },
    {
      name: 'synthia_memory_stats',
      description: 'Get Synthia memory statistics (outcomes learned, memories stored)',
      inputSchema: { type: 'object', properties: {} }
    },
    {
      name: 'synthia_status',
      description: 'Get full system status: core-termux version, device state, memory stats, available tools',
      inputSchema: { type: 'object', properties: {} }
    }
  ]
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    switch (name) {
      // ─── Intent Engine ───
      case 'synthia_intent': {
        const intent = parser.parse(args.intent as string);
        const plan = await planner.buildPlan(intent);
        const result = await executor.execute(plan);

        const status = result.success ? '✅ SUCCESS' : '❌ FAILED';
        const learnings = result.learnings.length > 0 
          ? `\n\n📚 Learnings:\n${result.learnings.map(l => `  • ${l}`).join('\n')}` 
          : '';

        return {
          content: [{
            type: 'text',
            text: `${status} — "${args.intent}"\n\nPlan: ${plan.id} (${plan.steps.length} steps)\n\n${result.output}${learnings}`
          }]
        };
      }

      // ─── Raw Shell ───
      case 'synthia_shell': {
        const result = await runShell(args.command as string, {
          cwd: args.cwd as string | undefined,
          timeout: args.timeout as number | undefined,
          retries: args.retries as number | undefined,
        });
        const exitInfo = result.exitCode === 0 ? '✅' : `❌ (exit ${result.exitCode})`;
        return {
          content: [{
            type: 'text',
            text: `${exitInfo} ${args.command}\n\nSTDOUT:\n${result.stdout}\n\nSTDERR:\n${result.stderr}`
          }]
        };
      }

      // ─── Core-Termux Tools ───
      case 'synthia_core_install': {
        const out = await coreTermux.install(args.module as string, args.tools as string[] | undefined);
        return { content: [{ type: 'text', text: `✅ Installed ${args.module}\n\n${out}` }] };
      }

      case 'synthia_core_init': {
        const out = await coreTermux.initProject(args.template as string, args.cwd as string | undefined);
        return { content: [{ type: 'text', text: `✅ Initialized ${args.template} project\n\n${out}` }] };
      }

      case 'synthia_core_env': {
        const action = args.action as string;
        let out = '';
        switch (action) {
          case 'set':
            out = await coreTermux.envSet(args.key as string, args.value as string);
            break;
          case 'list':
            out = await coreTermux.envList();
            break;
          default:
            out = 'Use set, unset, or list';
        }
        return { content: [{ type: 'text', text: out }] };
      }

      case 'synthia_core_pg': {
        const out = await coreTermux.pg(args.command as string, args.arg as string | undefined);
        return { content: [{ type: 'text', text: out }] };
      }

      // ─── Device Control ───
      case 'synthia_device_state': {
        const state = await deviceControl.getDeviceState();
        return { content: [{ type: 'text', text: JSON.stringify(state, null, 2) }] };
      }

      case 'synthia_device_screenshot': {
        const path = await deviceControl.takeScreenshot(args.path as string | undefined);
        return { content: [{ type: 'text', text: `📸 Screenshot saved: ${path}` }] };
      }

      case 'synthia_device_tap': {
        const out = await deviceControl.tap(args.x as number, args.y as number);
        return { content: [{ type: 'text', text: out }] };
      }

      case 'synthia_device_swipe': {
        const out = await deviceControl.swipe(
          args.x1 as number, args.y1 as number,
          args.x2 as number, args.y2 as number,
          args.duration as number | undefined
        );
        return { content: [{ type: 'text', text: out }] };
      }

      case 'synthia_device_list_apps': {
        const apps = await deviceControl.listApps();
        const text = apps.slice(0, 30).map(a => `${a.package} — ${a.name}`).join('\n');
        return { content: [{ type: 'text', text: `Installed apps (first 30):\n\n${text}` }] };
      }

      case 'synthia_device_launch_app': {
        const out = await deviceControl.launchApp(args.packageName as string);
        return { content: [{ type: 'text', text: out }] };
      }

      case 'synthia_device_press_button': {
        const out = await deviceControl.pressButton(args.button as string);
        return { content: [{ type: 'text', text: out }] };
      }

      case 'synthia_device_type': {
        const out = await deviceControl.typeText(args.text as string);
        return { content: [{ type: 'text', text: out }] };
      }

      case 'synthia_device_open_url': {
        const out = await deviceControl.openUrl(args.url as string);
        return { content: [{ type: 'text', text: out }] };
      }

      // ─── Brain / Memory ───
      case 'synthia_brain_save': {
        const out = await coreTermux.brainSave(
          args.title as string,
          args.category as string,
          args.tags as string[] || [],
          args.content as string
        );
        return { content: [{ type: 'text', text: `🧠 Saved: ${out}` }] };
      }

      case 'synthia_brain_search': {
        const out = await coreTermux.brainSearch(args.query as string);
        return { content: [{ type: 'text', text: out }] };
      }

      case 'synthia_memory_stats': {
        const stats = await memory.getStats();
        return { content: [{ type: 'text', text: `🧠 Synthia Memory\n\nOutcomes learned: ${stats.outcomes}\nMemories stored: ${stats.memories}` }] };
      }

      case 'synthia_status': {
        const lines: string[] = ['🧠 Synthia Status Report', '═'.repeat(40)];

        // Core-termux
        try {
          const version = await coreTermux.getVersion();
          lines.push(`✅ core-termux: ${version}`);
        } catch {
          lines.push(`❌ core-termux: not installed`);
        }

        // Device
        try {
          const state = await deviceControl.getDeviceState();
          lines.push(`📱 Device: ${state.orientation}, battery ${state.batteryLevel}%, screen ${state.screenOn ? 'ON' : 'OFF'}`);
        } catch (e: any) {
          lines.push(`📱 Device: ${e.message}`);
        }

        // Memory
        const stats = await memory.getStats();
        lines.push(`🧠 Memory: ${stats.outcomes} outcomes, ${stats.memories} memories`);

        // Node/Termux
        const nodeVersion = (await runShell('node --version', { logOutput: false })).stdout;
        lines.push(`🟢 Node.js: ${nodeVersion}`);

        lines.push('═'.repeat(40));
        return { content: [{ type: 'text', text: lines.join('\n') }] };
      }

      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  } catch (err: any) {
    return {
      content: [{ type: 'text', text: `❌ Error: ${err.message}` }],
      isError: true
    };
  }
});

// ─── Start ───
const transport = new StdioServerTransport();
await server.connect(transport);
console.log('🧠 Synthia MCP Server is running — waiting for commands...');
