/**
 * Core-Termux Tool Wrappers
 * Bridges core-termux bash commands into typed functions
 */
import { runShell, checkCommand } from '../utils/shell.js';

export class CoreTermuxTools {
  private available: boolean | null = null;

  async isAvailable(): Promise<boolean> {
    if (this.available !== null) return this.available;
    this.available = await checkCommand('core');
    return this.available;
  }

  async ensureAvailable(): Promise<void> {
    if (!(await this.isAvailable())) {
      throw new Error('core-termux is not installed. Run: curl -fsSL https://raw.githubusercontent.com/DevCoreXOfficial/core-termux/main/install.sh | bash');
    }
  }

  async install(module: string, tools?: string[]): Promise<string> {
    await this.ensureAvailable();
    const flags = tools?.map(t => `\-${\-t}`).join(' ') || '';
    const result = await runShell(`core install ${module} ${flags}`, { timeout: 300000, retries: 1 });
    if (result.exitCode !== 0) throw new Error(result.stderr);
    return result.stdout;
  }

  async envSet(key: string, value: string): Promise<string> {
    await this.ensureAvailable();
    // Use expect-like input for interactive core env set
    const result = await runShell(
      `printf '${key}\n${value}\n' | core env set`,
      { timeout: 30000 }
    );
    if (result.exitCode !== 0) throw new Error(result.stderr);
    return result.stdout;
  }

  async envList(): Promise<string> {
    await this.ensureAvailable();
    const result = await runShell('core env ls', { timeout: 10000 });
    return result.stdout;
  }

  async pg(command: string, arg?: string): Promise<string> {
    await this.ensureAvailable();
    const result = await runShell(`core pg ${command} ${arg || ''}`, { timeout: 30000 });
    if (result.exitCode !== 0) throw new Error(result.stderr);
    return result.stdout;
  }

  async brainSave(title: string, category: string, tags: string[], content: string): Promise<string> {
    await this.ensureAvailable();
    const tagStr = tags.join(', ');
    // Pipe multi-line content carefully
    const escapedContent = content.replace(/'/g, "'\''");
    const script = `cat << 'SYNTHIA_EOF' | core brain save
${title}
${category}
${tagStr}
${escapedContent}
SYNTHIA_EOF`;
    const result = await runShell(script, { timeout: 30000 });
    if (result.exitCode !== 0) throw new Error(result.stderr);
    return result.stdout;
  }

  async brainSearch(query: string): Promise<string> {
    await this.ensureAvailable();
    const result = await runShell(`core brain search "${query}"`, { timeout: 30000 });
    return result.stdout;
  }

  async initProject(template: string, cwd?: string): Promise<string> {
    await this.ensureAvailable();
    const result = await runShell(`core init ${template}`, { cwd, timeout: 120000 });
    if (result.exitCode !== 0) throw new Error(result.stderr);
    return result.stdout;
  }

  async voice(agent: string): Promise<string> {
    await this.ensureAvailable();
    const result = await runShell(`core voice ${agent}`, { timeout: 120000 });
    return result.stdout;
  }

  async list(module: string): Promise<string> {
    await this.ensureAvailable();
    const result = await runShell(`core list ${module}`, { timeout: 10000 });
    return result.stdout;
  }

  async update(target: string, tools?: string[]): Promise<string> {
    await this.ensureAvailable();
    const flags = tools?.map(t => `\-${\-t}`).join(' ') || '';
    const result = await runShell(`core update ${target} ${flags}`, { timeout: 300000 });
    if (result.exitCode !== 0) throw new Error(result.stderr);
    return result.stdout;
  }

  async getVersion(): Promise<string> {
    await this.ensureAvailable();
    const result = await runShell('core --version', { timeout: 10000 });
    return result.stdout;
  }
}
