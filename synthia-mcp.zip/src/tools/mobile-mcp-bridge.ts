/**
 * Mobile MCP Bridge — Connects to @mobilenext/mobile-mcp as subprocess
 * For external device control when local ADB isn't enough
 */
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { runShell, checkCommand } from '../utils/shell.js';

export class MobileMcpBridge {
  private client: Client | null = null;
  private transport: StdioClientTransport | null = null;
  private connected = false;

  async isAvailable(): Promise<boolean> {
    return await checkCommand('npx');
  }

  async connect(): Promise<void> {
    if (this.connected) return;

    if (!(await this.isAvailable())) {
      throw new Error('npx not available. Install Node.js first: core install lang --nodejs-lts');
    }

    this.transport = new StdioClientTransport({
      command: 'npx',
      args: ['-y', '@mobilenext/mobile-mcp@latest'],
    });

    this.client = new Client({ name: 'synthia-mobile-bridge', version: '1.0.0' });
    await this.client.connect(this.transport);
    this.connected = true;
  }

  async disconnect(): Promise<void> {
    if (this.transport) {
      await this.transport.close();
    }
    this.connected = false;
    this.client = null;
    this.transport = null;
  }

  async listDevices(): Promise<any> {
    await this.connect();
    return this.client!.callTool('mobile_list_available_devices', {});
  }

  async takeScreenshot(): Promise<any> {
    await this.connect();
    return this.client!.callTool('mobile_take_screenshot', {});
  }

  async listElements(): Promise<any> {
    await this.connect();
    return this.client!.callTool('mobile_list_elements_on_screen', {});
  }

  async tap(x: number, y: number): Promise<any> {
    await this.connect();
    return this.client!.callTool('mobile_click_on_screen_at_coordinates', { x, y });
  }

  async swipe(direction: 'up' | 'down' | 'left' | 'right'): Promise<any> {
    await this.connect();
    return this.client!.callTool('mobile_swipe_on_screen', { direction });
  }

  async typeText(text: string, submit?: boolean): Promise<any> {
    await this.connect();
    return this.client!.callTool('mobile_type_keys', { text, submit });
  }

  async launchApp(packageName: string): Promise<any> {
    await this.connect();
    return this.client!.callTool('mobile_launch_app', { packageName });
  }

  async terminateApp(packageName: string): Promise<any> {
    await this.connect();
    return this.client!.callTool('mobile_terminate_app', { packageName });
  }

  async listApps(): Promise<any> {
    await this.connect();
    return this.client!.callTool('mobile_list_apps', {});
  }

  async pressButton(button: string): Promise<any> {
    await this.connect();
    return this.client!.callTool('mobile_press_button', { button });
  }
}
