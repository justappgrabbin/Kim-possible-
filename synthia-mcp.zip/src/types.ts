/**
 * Synthia MCP — Universal Types
 * Dimensional mapping: D1=impulse, D2=polarity, D3=witness, D4=context, D5=meaning
 */

export interface ActionStep {
  tool: string;
  params: Record<string, any>;
  validate?: (output: string) => boolean;
  onFail: 'retry' | 'skip' | 'rollback' | 'ask' | 'abort';
  maxRetries: number;
}

export interface ActionPlan {
  id: string;
  intent: string;
  steps: ActionStep[];
  rollbackSteps: ActionStep[];
  context: PlanContext;
  createdAt: number;
}

export interface PlanContext {
  intent: string;
  parsedType: string;
  confidence: number;
  sourceDevice: string;
  previousOutcomes: OutcomeRecord[];
}

export interface OutcomeRecord {
  planId: string;
  intent: string;
  success: boolean;
  failedStep?: number;
  errorMessage?: string;
  timestamp: number;
  learnings: string[];
}

export interface MemoryEntry {
  id: string;
  title: string;
  category: string;
  tags: string[];
  content: string;
  createdAt: number;
  accessCount: number;
  lastAccessed: number;
}

export interface DeviceState {
  screenOn: boolean;
  orientation: 'portrait' | 'landscape';
  currentApp: string | null;
  batteryLevel: number;
  networkType: string;
  lastScreenshot: string | null;
}

export type IntentType = 
  | 'deploy' 
  | 'fix' 
  | 'setup' 
  | 'install' 
  | 'configure' 
  | 'monitor' 
  | 'automate' 
  | 'device_control' 
  | 'query' 
  | 'unknown';

export interface ParsedIntent {
  type: IntentType;
  raw: string;
  entities: string[];
  confidence: number;
  urgency: 'low' | 'medium' | 'high' | 'critical';
}
