const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Add 3D asset support
config.resolver.assetExts.push(
  'glb',
  'gltf',
  'obj',
  'mtl',
  'dae',
  'fbx',
  'wasm'
);

// Support for Three.js modules
config.resolver.sourceExts = [
  ...config.resolver.sourceExts,
  'cjs',
  'mjs'
];

module.exports = config;
