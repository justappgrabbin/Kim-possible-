import React, { useState, useEffect, useCallback } from 'react';
import { View, StyleSheet, StatusBar } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import codePush from 'react-native-code-push';

import { TerminalStage } from './src/projections/TerminalStage';
import { DimensionGuard } from './src/components/DimensionGuard';
import { FloatingAgent } from './src/components/FloatingAgent';
import { useFoundryBridge } from './src/hooks/useFoundryBridge';
import { useAxiomStore } from './src/hooks/useAxiomStore';
import { AxiomOnboarding } from './src/projections/AxiomOnboarding';

/**
 * Synthia Terminal - The Physical Body
 * A "dumb terminal" that projects whatever the Foundry sends.
 */
function App() {
  const [isReady, setIsReady] = useState(false);
  const [hasAxiom, setHasAxiom] = useState(false);
  const [projection, setProjection] = useState({
    mode: '2D',
    code: null,
    metadata: null
  });

  const { bridge, triggerReforge } = useFoundryBridge();
  const { axiom, fieldType, loadAxiom } = useAxiomStore();

  // Initialize on mount
  useEffect(() => {
    initializeTerminal();
  }, []);

  const initializeTerminal = async () => {
    try {
      // Check for existing Axiom
      const storedAxiom = await AsyncStorage.getItem('currentAxiom');
      if (storedAxiom) {
        setHasAxiom(true);
        await loadAxiom();
      }
      setIsReady(true);
    } catch (error) {
      console.error('Terminal initialization failed:', error);
      setIsReady(true);
    }
  };

  // Handle reforge completion
  const handleReforge = useCallback(async (intent) => {
    const result = await triggerReforge(intent);
    if (result) {
      setProjection(result);
    }
  }, [triggerReforge]);

  // Handle onboarding completion
  const handleOnboardingComplete = async (data) => {
    setHasAxiom(true);
    await loadAxiom();
    // Trigger first evolution
    await handleReforge('Initialize my reality');
  };

  if (!isReady) {
    return <View style={styles.container} />;
  }

  return (
    <DimensionGuard>
      <View style={styles.container}>
        <StatusBar barStyle="light-content" />

        {!hasAxiom ? (
          <AxiomOnboarding onComplete={handleOnboardingComplete} />
        ) : (
          <>
            <TerminalStage 
              projection={projection}
              onReforge={handleReforge}
            />
            <FloatingAgent 
              dna={axiom}
              projection={projection}
            />
          </>
        )}
      </View>
    </DimensionGuard>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000'
  }
});

// CodePush configuration
const codePushOptions = {
  checkFrequency: codePush.CheckFrequency.ON_APP_RESUME,
  installMode: codePush.InstallMode.IMMEDIATE
};

export default codePush(codePushOptions)(App);
