import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  withTiming,
  withSpring,
  interpolate
} from 'react-native-reanimated';

import { PaperCanvas } from '../layers/PaperCanvas';
import { WorldCanvas } from '../layers/WorldCanvas';
import { DimensionGuard } from '../components/DimensionGuard';
import { LiveCodeRenderer } from '../components/LiveCodeRenderer';

/**
 * TerminalStage
 * The "Master Toggle" that folds between 2D Paper UI and 3D World.
 * When the Foundry sends a new projection, the screen physically folds.
 */
export function TerminalStage({ projection, onReforge }) {
  const [currentMode, setCurrentMode] = useState('2D');
  const [displayedCode, setDisplayedCode] = useState(null);
  const transition = useSharedValue(0);
  const foldRotation = useSharedValue(0);

  useEffect(() => {
    if (!projection.code) return;

    const newMode = projection.mode || '2D';

    if (newMode !== currentMode) {
      // Start folding animation
      foldRotation.value = withTiming(90, { duration: 600 });

      setTimeout(() => {
        setCurrentMode(newMode);
        setDisplayedCode(projection.code);
        foldRotation.value = withTiming(0, { duration: 600 });
      }, 600);
    } else {
      setDisplayedCode(projection.code);
    }
  }, [projection]);

  const foldStyle = useAnimatedStyle(() => ({
    transform: [
      { perspective: 1000 },
      { rotateY: `${foldRotation.value}deg` }
    ],
    opacity: interpolate(
      foldRotation.value,
      [0, 45, 90],
      [1, 0.5, 0]
    )
  }));

  const unfoldStyle = useAnimatedStyle(() => ({
    transform: [
      { perspective: 1000 },
      { rotateY: `${90 - foldRotation.value}deg` }
    ],
    opacity: interpolate(
      foldRotation.value,
      [0, 45, 90],
      [0, 0.5, 1]
    )
  }));

  return (
    <View style={styles.container}>
      {/* 2D Paper Layer - folds away */}
      <Animated.View style={[styles.layer, foldStyle]}>
        <PaperCanvas 
          code={currentMode === '2D' ? displayedCode : null}
          metadata={projection.metadata}
          onReforge={onReforge}
        />
      </Animated.View>

      {/* 3D World Layer - unfolds in */}
      <Animated.View style={[styles.layer, { zIndex: currentMode === '3D' ? 2 : 0 }, unfoldStyle]}>
        <WorldCanvas 
          code={currentMode === '3D' ? displayedCode : null}
          metadata={projection.metadata}
          onReforge={onReforge}
        />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000'
  },
  layer: {
    ...StyleSheet.absoluteFillObject
  }
});
