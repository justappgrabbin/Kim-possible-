import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TextInput, 
  TouchableOpacity, 
  ScrollView,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import Animated, { useSharedValue, useAnimatedStyle, withSpring, withTiming } from 'react-native-reanimated';

/**
 * AxiomOnboarding
 * The "Paper" setup screen where the user's birth data becomes DNA.
 */
export function AxiomOnboarding({ onComplete }) {
  const [step, setStep] = useState(0);
  const [birthDate, setBirthDate] = useState('');
  const [birthTime, setBirthTime] = useState('');
  const [lat, setLat] = useState('');
  const [lon, setLon] = useState('');
  const [intentions, setIntentions] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const progress = useSharedValue(0);
  const fadeIn = useSharedValue(0);

  const steps = [
    { title: 'Birth Date', field: 'date', placeholder: 'YYYY-MM-DD', value: birthDate, setter: setBirthDate },
    { title: 'Birth Time', field: 'time', placeholder: 'HH:MM', value: birthTime, setter: setBirthTime },
    { title: 'Latitude', field: 'lat', placeholder: 'e.g. 40.7128', value: lat, setter: setLat },
    { title: 'Longitude', field: 'lon', placeholder: 'e.g. -74.0060', value: lon, setter: setLon },
    { title: 'Intentions', field: 'intent', placeholder: 'What do you seek? (spirit, mind, heart...)', value: intentions, setter: setIntentions }
  ];

  const handleNext = () => {
    if (step < steps.length - 1) {
      fadeIn.value = 0;
      setStep(step + 1);
      fadeIn.value = withTiming(1, { duration: 300 });
      progress.value = withSpring((step + 1) / steps.length);
    } else {
      generateAxiom();
    }
  };

  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1);
      progress.value = withSpring((step - 1) / steps.length);
    }
  };

  const generateAxiom = async () => {
    setIsGenerating(true);

    // Calculate axiom locally (also sent to server)
    const dateObj = new Date(`${birthDate}T${birthTime}`);
    const dayOfYear = Math.floor(
      (dateObj - new Date(dateObj.getFullYear(), 0, 0)) / 86400000
    );

    const gates = [
      ((dayOfYear + Math.floor(parseFloat(lat))) % 64) + 1,
      ((dayOfYear * 2 + Math.floor(parseFloat(lon))) % 64) + 1,
      ((dayOfYear + dateObj.getHours()) % 64) + 1,
      ((Math.floor(parseFloat(lat) * parseFloat(lon)) + dayOfYear) % 64) + 1,
      ((dateObj.getMinutes() + dayOfYear) % 64) + 1,
      ((Math.floor(parseFloat(lat)) + Math.floor(parseFloat(lon))) % 64) + 1,
      ((dateObj.getMonth() * dayOfYear) % 64) + 1
    ];

    // Determine field type
    const text = intentions.toLowerCase();
    let fieldType = 'standard';
    if (text.includes('spirit') || text.includes('transcend')) fieldType = 'spiritual';
    else if (text.includes('heart') || text.includes('love')) fieldType = 'emotional';
    else if (text.includes('mind') || text.includes('clarity')) fieldType = 'mental';
    else if (text.includes('quantum') || text.includes('infinite')) fieldType = 'quantum';
    else if (text.includes('void') || text.includes('still')) fieldType = 'void';
    else if (gates[0] < 20) fieldType = 'spiritual';
    else if (gates[0] < 40) fieldType = 'emotional';
    else fieldType = 'mental';

    setIsGenerating(false);

    onComplete({
      date: birthDate,
      time: birthTime,
      lat: parseFloat(lat),
      lon: parseFloat(lon),
      gates,
      fieldType,
      intentions
    });
  };

  const currentStep = steps[step];
  const animatedStyle = useAnimatedStyle(() => ({
    opacity: fadeIn.value,
    transform: [{ translateY: (1 - fadeIn.value) * 20 }]
  }));

  const progressStyle = useAnimatedStyle(() => ({
    width: `${progress.value * 100}%`
  }));

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Progress bar */}
        <View style={styles.progressBar}>
          <Animated.View style={[styles.progressFill, progressStyle]} />
        </View>

        {/* Step indicator */}
        <Text style={styles.stepIndicator}>
          Step {step + 1} of {steps.length}
        </Text>

        {/* Title */}
        <Text style={styles.title}>Paper Onboarding</Text>
        <Text style={styles.subtitle}>
          Your birth data becomes the DNA of your reality.
        </Text>

        {/* Input area */}
        <Animated.View style={[styles.inputContainer, animatedStyle]}>
          <Text style={styles.inputLabel}>{currentStep.title}</Text>
          <TextInput
            style={styles.input}
            placeholder={currentStep.placeholder}
            placeholderTextColor="#555"
            value={currentStep.value}
            onChangeText={currentStep.setter}
            autoFocus
            keyboardType={currentStep.field === 'lat' || currentStep.field === 'lon' ? 'numeric' : 'default'}
          />

          {currentStep.field === 'intent' && (
            <Text style={styles.hint}>
              Keywords: spirit, mind, heart, quantum, void, transcend, clarity, love, infinite, still
            </Text>
          )}
        </Animated.View>

        {/* Navigation buttons */}
        <View style={styles.buttonRow}>
          {step > 0 && (
            <TouchableOpacity style={styles.backButton} onPress={handleBack}>
              <Text style={styles.backText}>Back</Text>
            </TouchableOpacity>
          )}

          <TouchableOpacity 
            style={[styles.nextButton, !currentStep.value && styles.disabled]}
            onPress={handleNext}
            disabled={!currentStep.value || isGenerating}
          >
            <Text style={styles.nextText}>
              {isGenerating ? 'Generating...' : step === steps.length - 1 ? 'Generate My Paper' : 'Next'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Axiom preview (shown on last step) */}
        {step === steps.length - 1 && (
          <View style={styles.previewCard}>
            <Text style={styles.previewTitle}>Your DNA Preview</Text>
            <Text style={styles.previewText}>
              Based on your input, we will calculate a 7-gate sequence that becomes the foundation of your personal reality engine.
            </Text>
          </View>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  scrollContent: { padding: 30, paddingTop: 80, alignItems: 'center' },
  progressBar: { 
    width: '100%', 
    height: 4, 
    backgroundColor: '#1a1a2e', 
    borderRadius: 2,
    marginBottom: 20
  },
  progressFill: { 
    height: '100%', 
    backgroundColor: '#6366f1', 
    borderRadius: 2 
  },
  stepIndicator: { color: '#666', fontSize: 12, marginBottom: 20 },
  title: { color: '#fff', fontSize: 32, fontWeight: 'bold', marginBottom: 8 },
  subtitle: { color: '#888', fontSize: 14, textAlign: 'center', marginBottom: 40 },
  inputContainer: { width: '100%', maxWidth: 400 },
  inputLabel: { color: '#6366f1', fontSize: 14, fontWeight: '600', marginBottom: 8, textTransform: 'uppercase' },
  input: {
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    padding: 16,
    color: '#fff',
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#333'
  },
  hint: { color: '#555', fontSize: 11, marginTop: 8, fontStyle: 'italic' },
  buttonRow: { flexDirection: 'row', marginTop: 30, width: '100%', maxWidth: 400 },
  backButton: {
    flex: 1,
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    padding: 16,
    marginRight: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#333'
  },
  backText: { color: '#888' },
  nextButton: {
    flex: 2,
    backgroundColor: '#6366f1',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center'
  },
  disabled: { opacity: 0.5 },
  nextText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  previewCard: {
    marginTop: 30,
    backgroundColor: '#16162a',
    borderRadius: 12,
    padding: 20,
    width: '100%',
    maxWidth: 400,
    borderLeftWidth: 3,
    borderLeftColor: '#6366f1'
  },
  previewTitle: { color: '#6366f1', fontSize: 14, fontWeight: '600', marginBottom: 8 },
  previewText: { color: '#888', fontSize: 13, lineHeight: 20 }
});
