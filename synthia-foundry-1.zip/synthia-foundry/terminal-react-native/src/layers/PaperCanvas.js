import React, { useState, useEffect } from 'react';
import { View, StyleSheet, TextInput, TouchableOpacity, Text } from 'react-native';
import { Canvas, Circle, Fill, Rect, LinearGradient, vec, Group, BlurMask, RoundedRect } from '@shopify/react-native-skia';
import Animated, { useSharedValue, useAnimatedStyle, withSpring, withRepeat, withTiming } from 'react-native-reanimated';

import { LiveCodeRenderer } from '../components/LiveCodeRenderer';
import { AxiomVisualizer } from '../components/AxiomVisualizer';

/**
 * PaperCanvas
 * The 2D "Paper" UI layer using React Native Skia.
 * Renders forged code or the default Paper aesthetic.
 */
export function PaperCanvas({ code, metadata, onReforge }) {
  const [intentInput, setIntentInput] = useState('');
  const [isReady, setIsReady] = useState(false);

  const pulse = useSharedValue(1);
  const glow = useSharedValue(0);

  useEffect(() => {
    setIsReady(true);

    // Background pulse animation
    pulse.value = withRepeat(
      withSpring(1.2, { damping: 2 }),
      -1,
      true
    );

    glow.value = withRepeat(
      withTiming(1, { duration: 3000 }),
      -1,
      true
    );
  }, []);

  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulse.value }]
  }));

  const handleReforge = () => {
    if (intentInput.trim()) {
      onReforge(intentInput.trim());
      setIntentInput('');
    }
  };

  if (!isReady) {
    return <View style={styles.container}><Text style={styles.loading}>Initializing Paper...</Text></View>;
  }

  return (
    <View style={styles.container}>
      {/* Skia Background Canvas */}
      <Canvas style={StyleSheet.absoluteFill}>
        <Fill color="#0a0a0f" />

        {/* Animated gradient orbs */}
        <Group>
          <Circle cx={100} cy={200} r={80} color="#6366f120">
            <BlurMask blur={40} style="normal" />
          </Circle>
          <Circle cx={300} cy={400} r={100} color="#8b5cf620">
            <BlurMask blur={50} style="normal" />
          </Circle>
          <Circle cx={200} cy={600} r={60} color="#ec489920">
            <BlurMask blur={30} style="normal" />
          </Circle>
        </Group>

        {/* Paper texture lines */}
        {Array.from({ length: 20 }).map((_, i) => (
          <Rect
            key={i}
            x={0}
            y={i * 60}
            width={400}
            height={1}
            color="#ffffff05"
          />
        ))}
      </Canvas>

      {/* Content Layer */}
      <View style={styles.content}>
        {code ? (
          <LiveCodeRenderer code={code} mode="2D" />
        ) : (
          <View style={styles.defaultUI}>
            <Animated.View style={[styles.axiomOrb, pulseStyle]}>
              <AxiomVisualizer metadata={metadata} />
            </Animated.View>

            <View style={styles.inputContainer}>
              <TextInput
                style={styles.input}
                placeholder="What do you want to forge?"
                placeholderTextColor="#666"
                value={intentInput}
                onChangeText={setIntentInput}
                onSubmitEditing={handleReforge}
                returnKeyType="send"
              />
              <TouchableOpacity style={styles.forgeButton} onPress={handleReforge}>
                <Text style={styles.forgeText}>Forge</Text>
              </TouchableOpacity>
            </View>

            {metadata && (
              <View style={styles.metaCard}>
                <Text style={styles.metaTitle}>Last Forge</Text>
                <Text style={styles.metaText}>Mode: {metadata.mode}</Text>
                <Text style={styles.metaText}>Engine: {metadata.engine}</Text>
                <Text style={styles.metaText}>Score: {metadata.validation?.score}</Text>
              </View>
            )}
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, padding: 20 },
  defaultUI: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  axiomOrb: { width: 200, height: 200, marginBottom: 40 },
  inputContainer: { 
    flexDirection: 'row', 
    width: '100%', 
    maxWidth: 400,
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    padding: 4,
    borderWidth: 1,
    borderColor: '#333'
  },
  input: { 
    flex: 1, 
    color: '#fff', 
    padding: 16,
    fontSize: 16
  },
  forgeButton: {
    backgroundColor: '#6366f1',
    borderRadius: 8,
    paddingHorizontal: 24,
    justifyContent: 'center'
  },
  forgeText: { color: '#fff', fontWeight: 'bold' },
  metaCard: {
    marginTop: 30,
    backgroundColor: '#16162a',
    borderRadius: 12,
    padding: 16,
    width: '100%',
    maxWidth: 400,
    borderLeftWidth: 3,
    borderLeftColor: '#6366f1'
  },
  metaTitle: { color: '#6366f1', fontSize: 12, fontWeight: '600', marginBottom: 8 },
  metaText: { color: '#888', fontSize: 13, marginBottom: 4 },
  loading: { color: '#fff', textAlign: 'center', marginTop: 100 }
});
