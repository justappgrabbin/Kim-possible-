import React, { useRef, useEffect, useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { GLView } from 'expo-gl';
import { Renderer } from 'expo-three';
import * as THREE from 'three';

import { LiveCodeRenderer } from '../components/LiveCodeRenderer';

/**
 * WorldCanvas
 * The 3D "Engine Room" layer using Expo-GL + Three.js.
 * Renders forged 3D code or a default DNA-reactive scene.
 */
export function WorldCanvas({ code, metadata, onReforge }) {
  const [isReady, setIsReady] = useState(false);
  const glRef = useRef(null);

  useEffect(() => {
    setIsReady(true);
  }, []);

  const onContextCreate = async (gl) => {
    glRef.current = gl;

    // Three.js setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75,
      gl.drawingBufferWidth / gl.drawingBufferHeight,
      0.1,
      1000
    );

    const renderer = new Renderer({ gl });
    renderer.setSize(gl.drawingBufferWidth, gl.drawingBufferHeight);

    // DNA-reactive environment
    const stability = metadata?.evolutionVector?.fluidity || 0.5;
    const depth = metadata?.evolutionVector?.depth || 0.5;
    const chaos = metadata?.evolutionVector?.chaos || 0.1;

    // Fog based on DNA
    scene.fog = new THREE.FogExp2(
      0x0a0a0f,
      0.02 + (1 - stability) * 0.05
    );

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.5);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0x6366f1, 1, 100);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);

    // DNA Crystal (the user's identity manifest)
    const geometry = new THREE.IcosahedronGeometry(2, Math.floor(depth * 3));
    const material = new THREE.MeshStandardMaterial({
      color: 0x6366f1,
      metalness: 0.8,
      roughness: 0.2,
      wireframe: chaos > 0.5
    });
    const crystal = new THREE.Mesh(geometry, material);
    scene.add(crystal);

    // Orbiting particles
    const particles = new THREE.Group();
    for (let i = 0; i < 50; i++) {
      const pGeom = new THREE.SphereGeometry(0.05, 8, 8);
      const pMat = new THREE.MeshBasicMaterial({ 
        color: new THREE.Color().setHSL(Math.random(), 0.8, 0.5) 
      });
      const particle = new THREE.Mesh(pGeom, pMat);
      const angle = (i / 50) * Math.PI * 2;
      const radius = 3 + Math.random() * 2;
      particle.position.set(
        Math.cos(angle) * radius,
        Math.sin(angle * 2) * 0.5,
        Math.sin(angle) * radius
      );
      particles.add(particle);
    }
    scene.add(particles);

    camera.position.z = 8;

    // Animation loop
    let frameId;
    const animate = () => {
      frameId = requestAnimationFrame(animate);

      crystal.rotation.x += 0.005 + chaos * 0.02;
      crystal.rotation.y += 0.01 + chaos * 0.01;

      particles.rotation.y += 0.002;

      // DNA breathing effect
      const scale = 1 + Math.sin(Date.now() * 0.001) * 0.1 * stability;
      crystal.scale.setScalar(scale);

      renderer.render(scene, camera);
      gl.endFrameEXP();
    };
    animate();

    // Cleanup
    return () => {
      cancelAnimationFrame(frameId);
      geometry.dispose();
      material.dispose();
      renderer.dispose();
    };
  };

  if (!isReady) {
    return <View style={styles.container} />;
  }

  return (
    <View style={styles.container}>
      {code ? (
        <LiveCodeRenderer code={code} mode="3D" />
      ) : (
        <GLView
          style={StyleSheet.absoluteFill}
          onContextCreate={onContextCreate}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' }
});
