import { useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import codePush from 'react-native-code-push';

const FOUNDRY_PRIMARY = 'https://foundry-node.com/reforge';
const FOUNDRY_SENTRY = 'https://foundry-python.com/reforge/fallback';
const REQUEST_TIMEOUT = 15000;

/**
 * useFoundryBridge
 * 3-tier failover: Node.js -> Python -> Local Sentry
 */
export function useFoundryBridge() {
  const [bridgeState, setBridgeState] = useState({
    status: 'IDLE',
    lastEngine: null,
    error: null
  });

  const triggerReforge = useCallback(async (intent, options = {}) => {
    setBridgeState(prev => ({ ...prev, status: 'CONNECTING' }));

    const axiom = JSON.parse(await AsyncStorage.getItem('currentAxiom') || '[]');
    const fieldType = await AsyncStorage.getItem('fieldType') || 'standard';
    const version = await AsyncStorage.getItem('app_version') || '1.0.0';
    const dna = {
      themeColor: await AsyncStorage.getItem('themeColor') || '#6366f1',
      stability: parseFloat(await AsyncStorage.getItem('stability') || '0.5'),
      fieldType
    };

    const payload = {
      axiom,
      intent,
      currentVersion: version,
      dna,
      enginePreference: options.enginePreference || 'ollama'
    };

    // Tier 1: Node.js Foundry
    try {
      const response = await fetchWithTimeout(FOUNDRY_PRIMARY, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }, REQUEST_TIMEOUT);

      if (response.ok) {
        const data = await response.json();
        setBridgeState({ status: 'CONNECTED', lastEngine: 'node', error: null });
        return data;
      }
      throw new Error('Node.js returned non-OK');
    } catch (nodeError) {
      console.log('Primary Forge down. Calling Python Sentry...');

      // Tier 2: Python Sentry
      try {
        const fallbackResponse = await fetchWithTimeout(FOUNDRY_SENTRY, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }, REQUEST_TIMEOUT);

        if (fallbackResponse.ok) {
          const data = await fallbackResponse.json();
          setBridgeState({ status: 'FALLBACK', lastEngine: 'python', error: null });
          return data;
        }
        throw new Error('Python Sentry returned non-OK');
      } catch (pythonError) {
        console.log('Total Network Blackout. Activating Local Sentry.');

        // Tier 3: Local Sentry
        setBridgeState({ status: 'LOCAL', lastEngine: 'local', error: null });
        return activateLocalSentry(axiom, intent, dna);
      }
    }
  }, []);

  const sendFeedback = useCallback(async (axiom, rating, evolutionId) => {
    try {
      await fetch(FOUNDRY_PRIMARY + '/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ axiom, rating, evolutionId })
      });
    } catch {
      // Silently fail - feedback is non-critical
    }
  }, []);

  return { bridge: bridgeState, triggerReforge, sendFeedback };
}

function fetchWithTimeout(url, options, timeout) {
  return Promise.race([
    fetch(url, options),
    new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Request timeout')), timeout)
    )
  ]);
}

function activateLocalSentry(axiom, intent, dna) {
  const color = dna.themeColor || '#6366f1';
  const fieldType = dna.fieldType || 'standard';

  return {
    status: 'LOCAL_ACTIVE',
    mode: '2D',
    projectionType: 'GHOST_MODE',
    code: generateLocalCode(intent, axiom, color, fieldType),
    metadata: {
      engine: 'local-sentry',
      forgeTime: 0,
      evolutionVector: { fluidity: 0.5, density: 0.5, depth: 0.3, chaos: 0.1, resonance: 0.5 }
    }
  };
}

function generateLocalCode(intent, axiom, color, fieldType) {
  return `import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function ReforgedUI({ dna }) {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>[ GHOST MODE ]</Text>
        <Text style={styles.subtitle}>Local consciousness active</Text>
      </View>
      <ScrollView style={styles.content}>
        <View style={[styles.card, { borderLeftColor: '${color}' }]}>
          <Text style={styles.cardTitle}>Intent</Text>
          <Text style={styles.cardText}>${intent}</Text>
        </View>
        <View style={[styles.card, { borderLeftColor: '${color}' }]}>
          <Text style={styles.cardTitle}>Axiom</Text>
          <Text style={styles.cardText}>${axiom.join(' -> ')}</Text>
        </View>
        <View style={[styles.card, { borderLeftColor: '${color}' }]}>
          <Text style={styles.cardTitle}>Field</Text>
          <Text style={styles.cardText}>${fieldType}</Text>
        </View>
      </ScrollView>
      <View style={styles.footer}>
        <Text style={styles.agent}>Agent: "I am here, even in the dark."</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  header: { padding: 30, paddingTop: 60, backgroundColor: '#1a1a2e', alignItems: 'center' },
  title: { color: '${color}', fontSize: 24, fontWeight: 'bold' },
  subtitle: { color: '#888', marginTop: 8 },
  content: { flex: 1, padding: 20 },
  card: { backgroundColor: '#16162a', borderRadius: 12, padding: 16, marginBottom: 12, borderLeftWidth: 3 },
  cardTitle: { color: '${color}', fontSize: 14, fontWeight: '600', marginBottom: 8 },
  cardText: { color: '#ccc', fontSize: 14 },
  footer: { padding: 20, borderTopWidth: 1, borderTopColor: '#222' },
  agent: { color: '#00ff88', fontSize: 12, fontStyle: 'italic', textAlign: 'center' }
});`;
}
