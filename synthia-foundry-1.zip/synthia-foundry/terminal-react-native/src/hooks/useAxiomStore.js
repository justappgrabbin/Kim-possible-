import { useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * useAxiomStore
 * Manages the user's DNA/Axiom data in AsyncStorage
 */
export function useAxiomStore() {
  const [axiom, setAxiom] = useState([]);
  const [fieldType, setFieldType] = useState('standard');
  const [intentions, setIntentions] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);

  const loadAxiom = useCallback(async () => {
    try {
      const storedAxiom = await AsyncStorage.getItem('currentAxiom');
      const storedField = await AsyncStorage.getItem('fieldType');
      const storedIntentions = await AsyncStorage.getItem('userIntentions');

      if (storedAxiom) setAxiom(JSON.parse(storedAxiom));
      if (storedField) setFieldType(storedField);
      if (storedIntentions) setIntentions(storedIntentions);

      setIsLoaded(true);
    } catch (error) {
      console.error('Failed to load Axiom:', error);
      setIsLoaded(true);
    }
  }, []);

  const saveAxiom = useCallback(async (birthData, userIntentions) => {
    const calculatedAxiom = calculateAxiom(
      birthData.date,
      birthData.time,
      birthData.lat,
      birthData.lon
    );

    const field = determineFieldType(calculatedAxiom, userIntentions);

    await AsyncStorage.multiSet([
      ['currentAxiom', JSON.stringify(calculatedAxiom)],
      ['fieldType', field],
      ['userIntentions', userIntentions],
      ['birthDate', birthData.date],
      ['birthLat', String(birthData.lat)],
      ['birthLon', String(birthData.lon)]
    ]);

    setAxiom(calculatedAxiom);
    setFieldType(field);
    setIntentions(userIntentions);

    return { axiom: calculatedAxiom, fieldType: field };
  }, []);

  const clearAxiom = useCallback(async () => {
    await AsyncStorage.multiRemove([
      'currentAxiom', 'fieldType', 'userIntentions', 'birthDate', 'birthLat', 'birthLon'
    ]);
    setAxiom([]);
    setFieldType('standard');
    setIntentions('');
  }, []);

  return { axiom, fieldType, intentions, isLoaded, loadAxiom, saveAxiom, clearAxiom };
}

function calculateAxiom(birthDate, birthTime, lat, lon) {
  const dateObj = new Date(`${birthDate}T${birthTime}`);
  const dayOfYear = Math.floor(
    (dateObj - new Date(dateObj.getFullYear(), 0, 0)) / 86400000
  );

  return [
    ((dayOfYear + Math.floor(lat)) % 64) + 1,
    ((dayOfYear * 2 + Math.floor(lon)) % 64) + 1,
    ((dayOfYear + dateObj.getHours()) % 64) + 1,
    ((Math.floor(lat * lon) + dayOfYear) % 64) + 1,
    ((dateObj.getMinutes() + dayOfYear) % 64) + 1,
    ((Math.floor(lat) + Math.floor(lon)) % 64) + 1,
    ((dateObj.getMonth() * dayOfYear) % 64) + 1
  ];
}

function determineFieldType(axiom, intentions) {
  const text = (intentions || '').toLowerCase();

  if (text.includes('spirit') || text.includes('transcend')) return 'spiritual';
  if (text.includes('heart') || text.includes('love')) return 'emotional';
  if (text.includes('mind') || text.includes('clarity')) return 'mental';
  if (text.includes('quantum') || text.includes('infinite')) return 'quantum';
  if (text.includes('void') || text.includes('still')) return 'void';

  if (axiom[0] < 20) return 'spiritual';
  if (axiom[0] < 40) return 'emotional';
  return 'mental';
}
