import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Canvas, Circle, Group, LinearGradient, vec, Path, Skia } from '@shopify/react-native-skia';

/**
 * AxiomVisualizer
 * Renders the user's 7-gate DNA as a visual mandala.
 */
export function AxiomVisualizer({ metadata }) {
  const axiom = metadata?.axiom || [];
  const size = 200;
  const center = size / 2;
  const maxRadius = 80;

  const gates = axiom.length > 0 ? axiom : [32, 16, 48, 8, 24, 40, 56];

  return (
    <View style={styles.container}>
      <Canvas style={{ width: size, height: size }}>
        <Group>
          {/* Background ring */}
          <Circle cx={center} cy={center} r={maxRadius} color="#1a1a2e" />

          {/* Gate markers */}
          {gates.map((gate, i) => {
            const angle = (i / 7) * Math.PI * 2 - Math.PI / 2;
            const radius = (gate / 64) * maxRadius;
            const x = center + Math.cos(angle) * radius;
            const y = center + Math.sin(angle) * radius;

            return (
              <Circle key={i} cx={x} cy={y} r={6} color={getGateColor(gate)}>
                <LinearGradient
                  start={vec(x - 6, y - 6)}
                  end={vec(x + 6, y + 6)}
                  colors={[getGateColor(gate), '#fff']}
                />
              </Circle>
            );
          })}

          {/* Connecting lines */}
          {gates.map((gate, i) => {
            const angle = (i / 7) * Math.PI * 2 - Math.PI / 2;
            const radius = (gate / 64) * maxRadius;
            const nextAngle = ((i + 1) % 7 / 7) * Math.PI * 2 - Math.PI / 2;
            const nextRadius = (gates[(i + 1) % 7] / 64) * maxRadius;

            const path = Skia.Path.Make();
            path.moveTo(
              center + Math.cos(angle) * radius,
              center + Math.sin(angle) * radius
            );
            path.lineTo(
              center + Math.cos(nextAngle) * nextRadius,
              center + Math.sin(nextAngle) * nextRadius
            );

            return (
              <Path
                key={`line-${i}`}
                path={path}
                color="#6366f140"
                style="stroke"
                strokeWidth={1}
              />
            );
          })}

          {/* Center core */}
          <Circle cx={center} cy={center} r={12} color="#6366f1">
            <LinearGradient
              start={vec(center - 12, center - 12)}
              end={vec(center + 12, center + 12)}
              colors={['#6366f1', '#8b5cf6']}
            />
          </Circle>
        </Group>
      </Canvas>

      <View style={styles.legend}>
        {gates.map((gate, i) => (
          <View key={i} style={styles.gateLabel}>
            <View style={[styles.gateDot, { backgroundColor: getGateColor(gate) }]} />
            <Text style={styles.gateText}>Gate {i + 1}: {gate}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

function getGateColor(gate) {
  const colors = [
    '#f59e0b', '#ec4899', '#3b82f6', '#8b5cf6',
    '#10b981', '#f97316', '#6366f1'
  ];
  return colors[gate % colors.length];
}

const styles = StyleSheet.create({
  container: { alignItems: 'center' },
  legend: { marginTop: 16, width: '100%' },
  gateLabel: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  gateDot: { width: 8, height: 8, borderRadius: 4, marginRight: 8 },
  gateText: { color: '#888', fontSize: 11 }
});
