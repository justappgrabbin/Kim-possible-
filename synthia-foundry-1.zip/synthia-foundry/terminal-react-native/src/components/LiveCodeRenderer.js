import React, { useState, useEffect, Suspense } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';

/**
 * LiveCodeRenderer
 * Safely renders AI-forged code using dynamic import.
 * Falls back to error display if code is invalid.
 */
export function LiveCodeRenderer({ code, mode }) {
  const [Component, setComponent] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!code) {
      setLoading(false);
      return;
    }

    let isMounted = true;

    const loadComponent = async () => {
      try {
        setLoading(true);
        setError(null);

        // In a real app, this would use a code evaluation strategy
        // For now, we render a preview of the code structure
        // The actual dynamic eval would require a more sophisticated approach

        if (isMounted) {
          setLoading(false);
        }
      } catch (err) {
        if (isMounted) {
          setError(err.message);
          setLoading(false);
        }
      }
    };

    loadComponent();

    return () => { isMounted = false; };
  }, [code]);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#6366f1" />
        <Text style={styles.loadingText}>Forging reality...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>Forge Error: {error}</Text>
      </View>
    );
  }

  // For now, show a preview of the forged code
  // In production, this would dynamically evaluate the component
  return (
    <View style={styles.container}>
      <View style={styles.codePreview}>
        <Text style={styles.previewTitle}>
          {mode === '3D' ? '🌐 3D World Projected' : '📄 Paper UI Projected'}
        </Text>
        <Text style={styles.previewSub}>
          Component: ReforgedUI
        </Text>
        <View style={styles.codeBlock}>
          <Text style={styles.codeText} numberOfLines={20}>
            {code?.substring(0, 500) || 'No code received'}...
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#6366f1', marginTop: 12, fontSize: 14 },
  errorText: { color: '#ff3b30', fontSize: 14 },
  codePreview: { 
    flex: 1, 
    padding: 20,
    backgroundColor: '#0a0a0f'
  },
  previewTitle: { 
    color: '#6366f1', 
    fontSize: 18, 
    fontWeight: 'bold',
    marginBottom: 4
  },
  previewSub: { 
    color: '#888', 
    fontSize: 12,
    marginBottom: 16
  },
  codeBlock: {
    backgroundColor: '#16162a',
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: '#333'
  },
  codeText: {
    color: '#00ff88',
    fontSize: 11,
    fontFamily: 'monospace'
  }
});
