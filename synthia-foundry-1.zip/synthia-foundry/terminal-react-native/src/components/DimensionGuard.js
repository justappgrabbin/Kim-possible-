import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

/**
 * DimensionGuard
 * Error boundary that catches crashes from forged code.
 * Falls back to a safe "Ghost Mode" instead of black screen.
 */
export class DimensionGuard extends Component {
  state = { hasError: false, errorInfo: null };

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ errorInfo });
    console.error('Dimension Glitch:', error);
  }

  handleReset = () => {
    this.setState({ hasError: false, errorInfo: null });
  };

  render() {
    if (this.state.hasError) {
      return (
        <View style={styles.container}>
          <View style={styles.ghost}>
            <Text style={styles.ghostIcon}>👾</Text>
          </View>
          <Text style={styles.title}>Reality Glitch Detected</Text>
          <Text style={styles.subtitle}>
            The forged code caused a dimensional instability.
          </Text>
          <Text style={styles.agent}>
            Agent: "The DNA coordinates are unstable. I cannot forge the geometry yet."
          </Text>
          <TouchableOpacity style={styles.resetButton} onPress={this.handleReset}>
            <Text style={styles.resetText}>Reboot Forge</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return this.props.children;
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0f',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40
  },
  ghost: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#1a1a2e',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
    borderWidth: 2,
    borderColor: '#ff3b30'
  },
  ghostIcon: { fontSize: 50 },
  title: { color: '#ff3b30', fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  subtitle: { color: '#888', fontSize: 14, textAlign: 'center', marginBottom: 20 },
  agent: { color: '#00ff88', fontSize: 12, fontStyle: 'italic', textAlign: 'center', marginBottom: 30 },
  resetButton: {
    backgroundColor: '#6366f1',
    paddingHorizontal: 32,
    paddingVertical: 14,
    borderRadius: 8
  },
  resetText: { color: '#fff', fontWeight: 'bold', fontSize: 16 }
});
