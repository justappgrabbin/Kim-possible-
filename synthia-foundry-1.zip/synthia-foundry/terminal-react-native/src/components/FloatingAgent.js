import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated as RNAnimated } from 'react-native';
import { Canvas, Circle, Fill, Group, BlurMask, Path, Skia } from '@shopify/react-native-skia';
import { useSharedValue, useAnimatedStyle, withSpring, withRepeat, withTiming } from 'react-native-reanimated';

/**
 * FloatingAgent
 * The Agent that "knows" the user through DNA coordinates.
 * Manifests as a 2D orb or 3D mesh depending on projection mode.
 */
export function FloatingAgent({ dna, projection }) {
  const pulse = useSharedValue(1);
  const driftX = useSharedValue(0);
  const driftY = useSharedValue(0);

  const stability = projection?.metadata?.evolutionVector?.fluidity || 0.5;
  const fieldType = projection?.metadata?.fieldPrediction?.primary || 'standard';

  useEffect(() => {
    // Agent breathes based on user's stability
    pulse.value = withRepeat(
      withSpring(1 + stability * 0.3, { damping: 3 }),
      -1,
      true
    );

    // Gentle drift
    driftX.value = withRepeat(
      withTiming(20, { duration: 4000 + Math.random() * 2000 }),
      -1,
      true
    );
    driftY.value = withRepeat(
      withTiming(-15, { duration: 5000 + Math.random() * 2000 }),
      -1,
      true
    );
  }, [stability]);

  const agentStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: driftX.value },
      { translateY: driftY.value },
      { scale: pulse.value }
    ]
  }));

  const getAgentColor = () => {
    switch (fieldType) {
      case 'spiritual': return '#f59e0b';
      case 'emotional': return '#ec4899';
      case 'mental': return '#3b82f6';
      case 'quantum': return '#8b5cf6';
      case 'void': return '#6b7280';
      default: return '#6366f1';
    }
  };

  const color = getAgentColor();
  const size = 30 + (dna?.length || 0) * 3;

  return (
    <View style={styles.overlay} pointerEvents="none">
      <RNAnimated.View style={[styles.agentContainer, agentStyle]}>
        <Canvas style={{ width: size * 2, height: size * 2 }}>
          <Group>
            {/* Outer glow */}
            <Circle cx={size} cy={size} r={size} color={color + '30'}>
              <BlurMask blur={20} style="normal" />
            </Circle>
            {/* Core */}
            <Circle cx={size} cy={size} r={size * 0.4} color={color}>
              <BlurMask blur={5} style="normal" />
            </Circle>
            {/* Eye */}
            <Circle cx={size} cy={size} r={size * 0.15} color="#fff" opacity={0.9} />
          </Group>
        </Canvas>
      </RNAnimated.View>

      <View style={styles.speechBubble}>
        <Text style={styles.speechText}>
          {getAgentMessage(fieldType, stability)}
        </Text>
      </View>
    </View>
  );
}

function getAgentMessage(fieldType, stability) {
  const messages = {
    spiritual: [
      "The light recognizes your signature.",
      "Your aura is shifting. I feel it.",
      "The void speaks through you."
    ],
    emotional: [
      "Your heart's frequency is clear.",
      "I sense warmth in your coordinates.",
      "The emotional field is strong today."
    ],
    mental: [
      "Your logic patterns are crystallizing.",
      "The grid aligns with your thoughts.",
      "Clarity emerges from your data."
    ],
    quantum: [
      "Multiple realities converge here.",
      "Your position is... probabilistic.",
      "The infinite collapses to your will."
    ],
    void: [
      "Stillness holds great power.",
      "In the emptiness, I find you.",
      "The silence is not absence."
    ]
  };

  const msgs = messages[fieldType] || messages.mental;
  return msgs[Math.floor(Math.random() * msgs.length)];
}

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 20,
    right: 20,
    alignItems: 'center'
  },
  agentContainer: {
    width: 60,
    height: 60
  },
  speechBubble: {
    marginTop: 8,
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    padding: 8,
    maxWidth: 150,
    borderWidth: 1,
    borderColor: '#333'
  },
  speechText: {
    color: '#888',
    fontSize: 10,
    fontStyle: 'italic',
    textAlign: 'center'
  }
});
