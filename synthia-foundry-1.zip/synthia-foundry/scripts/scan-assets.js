#!/usr/bin/env node
/**
 * scan-assets.js
 * Scans the public/assets directory and generates a manifest.json
 * that the AI can use to "summon" Blender models into projections.
 */

const fs = require('fs').promises;
const path = require('path');
const { glob } = require('glob');

async function scanAssets() {
  const assetsDir = path.join(__dirname, '../public/assets');
  const manifestPath = path.join(__dirname, '../public/assets/manifest.json');

  console.log('🔍 Scanning assets...');

  try {
    const files = await glob('**/*.{glb,gltf,obj,fbx}', {
      cwd: assetsDir,
      absolute: false
    });

    const assets = [];
    const categories = {};

    for (const filePath of files) {
      const fullPath = path.join(assetsDir, filePath);
      const stats = await fs.stat(fullPath);
      const ext = path.extname(filePath).toLowerCase();
      const filename = path.basename(filePath, ext);

      // Parse metadata from filename
      const metadata = parseAssetMetadata(filename);

      const asset = {
        path: filePath,
        filename,
        extension: ext,
        size: stats.size,
        modified: stats.mtime.toISOString(),
        url: `/assets/${filePath}`,
        ...metadata
      };

      assets.push(asset);

      if (!categories[asset.type]) {
        categories[asset.type] = [];
      }
      categories[asset.type].push(asset);
    }

    const manifest = {
      generated: new Date().toISOString(),
      total: assets.length,
      categories,
      assets
    };

    await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2));

    console.log(`✅ Manifest generated: ${assets.length} assets`);
    console.log('📁 Categories:');
    for (const [type, items] of Object.entries(categories)) {
      console.log(`   ${type}: ${items.length} items`);
    }
    console.log(`
📝 Manifest saved to: ${manifestPath}`);

    return manifest;
  } catch (error) {
    console.error('❌ Scan failed:', error);
    process.exit(1);
  }
}

function parseAssetMetadata(filename) {
  const parts = filename.split('_');
  const typeMap = {
    'agent': 'entity',
    'npc': 'entity',
    'character': 'entity',
    'world': 'environment',
    'area': 'environment',
    'landscape': 'environment',
    'artifact': 'artifact',
    'tool': 'artifact',
    'weapon': 'artifact',
    'item': 'artifact',
    'ui': 'interface',
    'hud': 'interface',
    'fx': 'effect',
    'particle': 'effect'
  };

  const type = typeMap[parts[0]] || 'unknown';
  const name = parts[1] || filename;
  const variant = parts[2] || 'default';

  // Infer DNA affinity from filename
  const dnaAffinity = inferDNAAffinity(filename);

  // Infer complexity (poly count hint from filename)
  const complexity = filename.includes('high') ? 'high' : 
                     filename.includes('low') ? 'low' : 'medium';

  return { type, name, variant, dnaAffinity, complexity };
}

function inferDNAAffinity(filename) {
  const lower = filename.toLowerCase();
  const affinities = [];

  const mappings = {
    spiritual: ['spirit', 'aura', 'light', 'angel', 'holy', 'divine', 'sacred'],
    emotional: ['heart', 'love', 'warm', 'soft', 'gentle', 'rose', 'pink'],
    mental: ['mind', 'crystal', 'grid', 'matrix', 'blue', 'ice', 'tech'],
    quantum: ['quantum', 'void', 'dark', 'nebula', 'cosmic', 'star', 'purple'],
    void: ['calm', 'still', 'empty', 'minimal', 'white', 'gray', 'silent']
  };

  for (const [field, keywords] of Object.entries(mappings)) {
    if (keywords.some(k => lower.includes(k))) {
      affinities.push(field);
    }
  }

  return affinities.length > 0 ? affinities : ['universal'];
}

// Run if called directly
if (require.main === module) {
  scanAssets();
}

module.exports = { scanAssets, parseAssetMetadata };
