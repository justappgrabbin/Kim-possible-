#!/usr/bin/env node
/**
 * train-model.js
 * Trains the Neural Foundry from feedback history.
 */

const { NeuralFoundry } = require('../neural/neural-foundry');

async function trainModel() {
  console.log('🧠 Training Neural Foundry...');

  const foundry = new NeuralFoundry();
  await foundry.initialize();

  // Load existing history
  if (foundry.history.length === 0) {
    console.log('⚠️  No feedback history found. Generate some first!');
    return;
  }

  console.log(`📊 Training from ${foundry.history.length} feedback entries...`);
  await foundry.trainFromHistory();
  await foundry.saveModel();

  console.log('✅ Training complete. Model saved.');
}

if (require.main === module) {
  trainModel().catch(console.error);
}

module.exports = { trainModel };
