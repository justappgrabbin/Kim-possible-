const tf = require('@tensorflow/tfjs-node');
const fs = require('fs').promises;
const path = require('path');

/**
 * NeuralFoundry
 * Maps 7-gate Axiom DNA to UI evolution vectors.
 * The neural net learns which evolutions users accept/reject.
 */
class NeuralFoundry {
  constructor() {
    this.model = null;
    this.isInitialized = false;
    this.modelPath = path.join(__dirname, '../../models/foundry-model');
    this.weightsPath = path.join(__dirname, '../../models/foundry-weights.json');
    this.history = []; // Evolution feedback history

    // 5 Field Types: Spiritual, Emotional, Mental, Quantum, Void
    this.fieldTypes = ['spiritual', 'emotional', 'mental', 'quantum', 'void'];

    // Evolution complexity output dimensions
    this.outputDims = 5; // [fluidity, density, depth, chaos, resonance]
  }

  async initialize() {
    try {
      // Try to load existing model
      await this.loadModel();
    } catch {
      // Create fresh model
      await this.buildModel();
    }
    this.isInitialized = true;
  }

  async buildModel() {
    this.model = tf.sequential();

    // Input: 7-gate Axiom sequence
    this.model.add(tf.layers.dense({
      units: 32,
      inputShape: [7],
      activation: 'relu',
      kernelInitializer: 'heNormal'
    }));

    // Hidden layers with dropout for regularization
    this.model.add(tf.layers.dense({
      units: 64,
      activation: 'relu',
      kernelInitializer: 'heNormal'
    }));
    this.model.add(tf.layers.dropout({ rate: 0.2 }));

    this.model.add(tf.layers.dense({
      units: 32,
      activation: 'relu',
      kernelInitializer: 'heNormal'
    }));
    this.model.add(tf.layers.dropout({ rate: 0.1 }));

    // Output: 5 evolution parameters
    this.model.add(tf.layers.dense({
      units: this.outputDims,
      activation: 'sigmoid',
      name: 'evolution_vector'
    }));

    this.model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'meanSquaredError',
      metrics: ['mse']
    });

    console.log('🧠 Neural Foundry model built');
    this.model.summary();
  }

  async loadModel() {
    try {
      this.model = await tf.loadLayersModel(`file://${this.modelPath}/model.json`);
      this.model.compile({
        optimizer: tf.train.adam(0.001),
        loss: 'meanSquaredError'
      });

      // Load feedback history
      const historyRaw = await fs.readFile(this.weightsPath, 'utf8').catch(() => '[]');
      this.history = JSON.parse(historyRaw);

      console.log('🧠 Neural Foundry model loaded from disk');
    } catch (e) {
      throw new Error('Model load failed: ' + e.message);
    }
  }

  async saveModel() {
    if (!this.model) return;
    await fs.mkdir(path.dirname(this.modelPath), { recursive: true });
    await this.model.save(`file://${this.modelPath}`);
    await fs.writeFile(this.weightsPath, JSON.stringify(this.history));
    console.log('💾 Neural Foundry model saved');
  }

  /**
   * Predict evolution vector from Axiom DNA
   * @param {number[]} axiom - 7-gate sequence (1-64)
   */
  async predictEvolutionVector(axiom) {
    if (!this.isInitialized) await this.initialize();

    // Normalize gates to 0-1 range
    const normalized = axiom.map(g => (g - 1) / 63);
    const inputTensor = tf.tensor2d([normalized], [1, 7]);

    const prediction = this.model.predict(inputTensor);
    const values = await prediction.data();

    tf.dispose([inputTensor, prediction]);

    return {
      fluidity: values[0],      // 0=static, 1=fluid animations
      density: values[1],       // 0=minimal, 1=information-dense
      depth: values[2],         // 0=flat, 1=volumetric/3D
      chaos: values[3],         // 0=ordered, 1=chaotic/glitchy
      resonance: values[4],     // 0=detached, 1=deeply personal
      raw: Array.from(values)
    };
  }

  /**
   * Predict field type from Axiom DNA
   */
  async predictFieldType(axiom) {
    const vector = await this.predictEvolutionVector(axiom);

    // Map vector to field type
    const scores = {
      spiritual: vector.fluidity * 0.4 + vector.resonance * 0.6,
      emotional: vector.resonance * 0.5 + vector.chaos * 0.3 + vector.fluidity * 0.2,
      mental: vector.density * 0.6 + vector.depth * 0.2 + vector.fluidity * 0.2,
      quantum: vector.depth * 0.4 + vector.chaos * 0.4 + vector.resonance * 0.2,
      void: (1 - vector.fluidity) * 0.3 + (1 - vector.density) * 0.4 + (1 - vector.resonance) * 0.3
    };

    const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
    return {
      primary: sorted[0][0],
      confidence: sorted[0][1],
      allScores: scores
    };
  }

  /**
   * Record feedback from user interaction
   * @param {number[]} axiom - The DNA that generated the evolution
   * @param {number} rating - User rating (-1 to 1)
   * @param {Object} evolution - The evolution that was applied
   */
  async recordFeedback(axiom, rating, evolution) {
    this.history.push({
      axiom,
      rating,
      evolution,
      timestamp: Date.now()
    });

    // Keep last 1000 entries
    if (this.history.length > 1000) {
      this.history = this.history.slice(-1000);
    }

    // Periodic training (every 10 feedbacks)
    if (this.history.length % 10 === 0) {
      await this.trainFromHistory();
    }

    await this.saveModel();
  }

  /**
   * Train model from feedback history
   */
  async trainFromHistory() {
    if (this.history.length < 10) return;

    const recent = this.history.slice(-50);
    const inputs = recent.map(h => h.axiom.map(g => (g - 1) / 63));
    const labels = recent.map(h => {
      const rating = h.rating;
      return [
        Math.max(0, Math.min(1, 0.5 + rating * 0.3)),
        Math.max(0, Math.min(1, 0.5 + rating * 0.2)),
        Math.max(0, Math.min(1, 0.5 + rating * 0.1)),
        Math.max(0, Math.min(1, 0.5 - rating * 0.2)),
        Math.max(0, Math.min(1, 0.5 + rating * 0.4))
      ];
    });

    const xs = tf.tensor2d(inputs);
    const ys = tf.tensor2d(labels);

    await this.model.fit(xs, ys, {
      epochs: 5,
      batchSize: 8,
      verbose: 0
    });

    tf.dispose([xs, ys]);
    console.log('🧠 Neural Foundry trained from feedback');
  }

  /**
   * Get model statistics
   */
  getStats() {
    return {
      historyLength: this.history.length,
      isInitialized: this.isInitialized,
      outputDims: this.outputDims,
      fieldTypes: this.fieldTypes
    };
  }
}

module.exports = { NeuralFoundry };
