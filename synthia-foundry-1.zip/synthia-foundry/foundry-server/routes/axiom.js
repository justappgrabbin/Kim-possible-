const express = require('express');
const router = express.Router();

/**
 * POST /axiom/calculate
 * Calculate 7-gate Axiom from birth data
 */
router.post('/calculate', (req, res) => {
  const { birthDate, birthTime, lat, lon, intentions } = req.body;

  try {
    const dateObj = new Date(`${birthDate}T${birthTime}`);
    const dayOfYear = Math.floor(
      (dateObj - new Date(dateObj.getFullYear(), 0, 0)) / 86400000
    );

    const gates = [
      ((dayOfYear + Math.floor(lat)) % 64) + 1,
      ((dayOfYear * 2 + Math.floor(lon)) % 64) + 1,
      ((dayOfYear + dateObj.getHours()) % 64) + 1,
      ((Math.floor(lat * lon) + dayOfYear) % 64) + 1,
      ((dateObj.getMinutes() + dayOfYear) % 64) + 1,
      ((Math.floor(lat) + Math.floor(lon)) % 64) + 1,
      ((dateObj.getMonth() * dayOfYear) % 64) + 1
    ];

    // Determine field type from intentions
    const text = (intentions || '').toLowerCase();
    let fieldType = 'standard';

    if (text.includes('spirit') || text.includes('transcend')) fieldType = 'spiritual';
    else if (text.includes('heart') || text.includes('love')) fieldType = 'emotional';
    else if (text.includes('mind') || text.includes('clarity')) fieldType = 'mental';
    else if (text.includes('quantum') || text.includes('infinite')) fieldType = 'quantum';
    else if (text.includes('void') || text.includes('still')) fieldType = 'void';
    else if (gates[0] < 20) fieldType = 'spiritual';
    else if (gates[0] < 40) fieldType = 'emotional';
    else fieldType = 'mental';

    res.json({
      status: 'SUCCESS',
      axiom: gates,
      fieldType,
      metadata: {
        dayOfYear,
        birthDate,
        lat,
        lon,
        intentions: intentions || ''
      }
    });

  } catch (error) {
    res.status(400).json({ status: 'ERROR', message: error.message });
  }
});

/**
 * POST /axiom/analyze
 * Analyze an existing Axiom
 */
router.post('/analyze', async (req, res) => {
  const { axiom } = req.body;
  const { neuralFoundry } = req.foundry;

  try {
    const vector = await neuralFoundry.predictEvolutionVector(axiom);
    const field = await neuralFoundry.predictFieldType(axiom);

    res.json({
      status: 'SUCCESS',
      axiom,
      evolutionVector: vector,
      fieldPrediction: field,
      interpretation: {
        primaryDrive: field.primary,
        complexity: vector.fluidity + vector.density,
        depth: vector.depth > 0.5 ? 'Volumetric' : 'Flat',
        stability: vector.fluidity > 0.5 ? 'Fluid' : 'Static'
      }
    });
  } catch (error) {
    res.status(500).json({ status: 'ERROR', message: error.message });
  }
});

module.exports = router;
