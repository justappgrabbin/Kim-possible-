const express = require('express');
const router = express.Router();
const { AIEngineSelector } = require('../ai-engines/ai-engine-selector');

const aiSelector = new AIEngineSelector();

/**
 * POST /reforge
 * The main forge endpoint. Takes user intent + DNA, returns forged code.
 */
router.post('/', async (req, res) => {
  const startTime = Date.now();
  const { axiom, intent, currentVersion, enginePreference, dna } = req.body;

  try {
    // Validate input
    if (!axiom || !Array.isArray(axiom) || axiom.length !== 7) {
      return res.status(400).json({
        status: 'ERROR',
        message: 'Invalid axiom. Expected 7-gate array.'
      });
    }

    if (!intent || typeof intent !== 'string') {
      return res.status(400).json({
        status: 'ERROR',
        message: 'Intent required'
      });
    }

    const { neuralFoundry, assetManager, codeValidator } = req.foundry;

    // 1. Neural Inference: Calculate evolution vector
    console.log('🔮 Neural inference for axiom:', axiom.join('→'));
    const evolutionVector = await neuralFoundry.predictEvolutionVector(axiom);
    const fieldPrediction = await neuralFoundry.predictFieldType(axiom);

    // 2. Determine projection mode
    const mode = evolutionVector.depth > 0.6 ? '3D' : '2D';
    const complexity = evolutionVector.fluidity + evolutionVector.density;

    // 3. Find matching assets
    const matchingAssets = assetManager.findByDNA(
      fieldPrediction.primary,
      dna?.stability || 0.5
    );

    // 4. Generate code via AI
    console.log('⚒️  Forging code via', enginePreference || 'default engine...');
    const forgedCode = await aiSelector.generateProjection({
      intent,
      axiom,
      dna: {
        ...dna,
        fieldType: fieldPrediction.primary,
        stability: evolutionVector.fluidity
      },
      mode,
      complexity,
      enginePreference
    });

    // 5. Validate the forged code
    const validation = codeValidator.validate(forgedCode);

    if (!validation.isValid) {
      console.warn('⚠️  Code validation failed:', validation.issues);
      const fixedCode = codeValidator.autoFix(forgedCode);
      const reValidation = codeValidator.validate(fixedCode);

      if (!reValidation.isValid) {
        return res.status(422).json({
          status: 'VALIDATION_FAILED',
          message: 'Generated code failed safety checks',
          issues: validation.issues,
          score: validation.score
        });
      }
    }

    // 6. Build response
    const response = {
      status: 'SUCCESS',
      mode,
      projectionType: mode === '3D' ? 'WORLD_GAME' : 'PAPER_UI',
      code: forgedCode,
      metadata: {
        evolutionVector,
        fieldPrediction,
        matchingAssets: matchingAssets.slice(0, 5),
        validation: {
          score: validation.score,
          riskLevel: validation.riskLevel
        },
        forgeTime: Date.now() - startTime,
        version: currentVersion || '1.0.0'
      }
    };

    console.log(`✅ Reforge complete in ${response.metadata.forgeTime}ms`);
    res.status(200).json(response);

  } catch (error) {
    console.error('❌ Reforge failed:', error);
    res.status(500).json({
      status: 'ERROR',
      message: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

/**
 * POST /reforge/feedback
 * Record user feedback to train the neural net
 */
router.post('/feedback', async (req, res) => {
  const { axiom, rating, evolutionId } = req.body;
  const { neuralFoundry } = req.foundry;

  try {
    await neuralFoundry.recordFeedback(axiom, rating, { id: evolutionId });
    res.json({ status: 'SUCCESS', message: 'Feedback recorded' });
  } catch (error) {
    res.status(500).json({ status: 'ERROR', message: error.message });
  }
});

module.exports = router;
