const express = require('express');
const router = express.Router();
const path = require('path');

/**
 * GET /assets/manifest
 * Returns the full asset manifest for AI consumption
 */
router.get('/manifest', (req, res) => {
  const { assetManager } = req.foundry;
  res.json(assetManager.getManifest());
});

/**
 * GET /assets/match
 * Find assets matching DNA field type
 */
router.get('/match', (req, res) => {
  const { fieldType, stability } = req.query;
  const { assetManager } = req.foundry;

  const matches = assetManager.findByDNA(
    fieldType || 'universal',
    parseFloat(stability) || 0.5
  );

  res.json({
    status: 'SUCCESS',
    matches: matches.slice(0, 10),
    total: matches.length
  });
});

/**
 * GET /assets/:type
 * Get assets by category
 */
router.get('/:type', (req, res) => {
  const { assetManager } = req.foundry;
  const assets = assetManager.getByType(req.params.type);
  res.json({ status: 'SUCCESS', assets });
});

module.exports = router;
