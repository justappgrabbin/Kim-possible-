const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const { neuralFoundry, assetManager } = req.foundry;

  res.json({
    status: 'HEALTHY',
    timestamp: new Date().toISOString(),
    foundry: {
      neuralNet: neuralFoundry.isInitialized ? 'ONLINE' : 'OFFLINE',
      neuralStats: neuralFoundry.getStats(),
      assets: {
        total: assetManager.getAssetCount(),
        lastScan: assetManager.lastScan
      }
    }
  });
});

module.exports = router;
