const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const { NeuralFoundry } = require('./neural/neural-foundry');
const { AssetManager } = require('./middleware/asset-manager');
const { CodeValidator } = require('./middleware/code-validator');
const { AxiomRouter } = require('./routes/axiom');
const { ReforgeRouter } = require('./routes/reforge');
const { HealthRouter } = require('./routes/health');
const { AssetRouter } = require('./routes/assets');

const app = express();
const PORT = process.env.FOUNDRY_PORT || 3000;

// ─── Global State ─────────────────────────────────────────────
const neuralFoundry = new NeuralFoundry();
const assetManager = new AssetManager('./public/assets');
const codeValidator = new CodeValidator();

// ─── Middleware ────────────────────────────────────────────────
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGINS?.split(',') || '*' }));
app.use(express.json({ limit: '10mb' }));
app.use(express.static('public'));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { status: 'RATE_LIMITED', message: 'Too many reforge requests' }
});
app.use('/reforge', limiter);

// ─── Attach globals to requests ────────────────────────────────
app.use((req, res, next) => {
  req.foundry = { neuralFoundry, assetManager, codeValidator };
  next();
});

// ─── Routes ────────────────────────────────────────────────────
app.use('/axiom', AxiomRouter);
app.use('/reforge', ReforgeRouter);
app.use('/health', HealthRouter);
app.use('/assets', AssetRouter);

// ─── Neural Foundry Warmup ─────────────────────────────────────
(async () => {
  console.log('🔥 Foundry Neural Net initializing...');
  await neuralFoundry.initialize();
  await assetManager.scanAssets();
  console.log('✅ Foundry online. Port:', PORT);
  console.log('📦 Assets indexed:', assetManager.getAssetCount());
})();

app.listen(PORT, () => {
  console.log(`🌐 Foundry listening on port ${PORT}`);
});

module.exports = { app, neuralFoundry, assetManager };
