const fs = require('fs').promises;
const path = require('path');
const { glob } = require('glob');

/**
 * AssetManager
 * Scans, catalogs, and serves 3D assets (GLB/GLTF) for the Foundry.
 * The AI uses this manifest to "summon" Blender models into projections.
 */
class AssetManager {
  constructor(assetsDir) {
    this.assetsDir = assetsDir;
    this.assets = new Map(); // path -> metadata
    this.manifest = null;
    this.lastScan = 0;
  }

  /**
   * Scan the assets directory and build a manifest
   */
  async scanAssets() {
    console.log('🔍 Scanning assets directory...');

    try {
      const files = await glob('**/*.{glb,gltf,obj,fbx}', {
        cwd: this.assetsDir,
        absolute: true
      });

      this.assets.clear();

      for (const filePath of files) {
        const relativePath = path.relative(this.assetsDir, filePath);
        const stats = await fs.stat(filePath);
        const ext = path.extname(filePath).toLowerCase();

        // Extract metadata from filename
        const filename = path.basename(filePath, ext);
        const metadata = this.parseFilename(filename);

        this.assets.set(relativePath, {
          path: relativePath,
          absolutePath: filePath,
          filename,
          extension: ext,
          size: stats.size,
          modified: stats.mtime,
          ...metadata
        });
      }

      this.manifest = this.buildManifest();
      this.lastScan = Date.now();

      console.log(`📦 Indexed ${this.assets.size} assets`);
      return this.manifest;
    } catch (error) {
      console.error('Asset scan failed:', error);
      return { assets: [], categories: {} };
    }
  }

  /**
   * Parse filename for metadata
   * Naming convention: [type]_[name]_[variant].glb
   * Examples: agent_core_v1.glb, world_forest_autumn.glb, artifact_sword_rare.glb
   */
  parseFilename(filename) {
    const parts = filename.split('_');
    const typeMap = {
      'agent': 'entity',
      'npc': 'entity',
      'world': 'environment',
      'area': 'environment',
      'artifact': 'artifact',
      'tool': 'artifact',
      'weapon': 'artifact',
      'ui': 'interface',
      'fx': 'effect'
    };

    const type = typeMap[parts[0]] || 'unknown';
    const name = parts[1] || filename;
    const variant = parts[2] || 'default';

    // Extract DNA affinity from filename hints
    const dnaAffinity = this.inferDNAAffinity(filename);

    return { type, name, variant, dnaAffinity };
  }

  inferDNAAffinity(filename) {
    const lower = filename.toLowerCase();
    const affinities = [];

    if (lower.includes('spirit') || lower.includes('aura') || lower.includes('light')) {
      affinities.push('spiritual');
    }
    if (lower.includes('heart') || lower.includes('love') || lower.includes('warm')) {
      affinities.push('emotional');
    }
    if (lower.includes('mind') || lower.includes('crystal') || lower.includes('grid')) {
      affinities.push('mental');
    }
    if (lower.includes('quantum') || lower.includes('void') || lower.includes('dark')) {
      affinities.push('quantum');
    }
    if (lower.includes('calm') || lower.includes('still') || lower.includes('empty')) {
      affinities.push('void');
    }

    return affinities.length > 0 ? affinities : ['universal'];
  }

  /**
   * Build a structured manifest for AI consumption
   */
  buildManifest() {
    const categories = {};
    const assets = [];

    for (const [key, asset] of this.assets) {
      if (!categories[asset.type]) {
        categories[asset.type] = [];
      }
      categories[asset.type].push(asset);
      assets.push(asset);
    }

    return {
      total: assets.length,
      categories,
      assets,
      lastScan: this.lastScan
    };
  }

  /**
   * Find assets matching DNA affinity
   */
  findByDNA(fieldType, stability = 0.5) {
    const matches = [];

    for (const asset of this.assets.values()) {
      const score = this.calculateAffinityScore(asset, fieldType, stability);
      if (score > 0.3) {
        matches.push({ ...asset, affinityScore: score });
      }
    }

    return matches.sort((a, b) => b.affinityScore - a.affinityScore);
  }

  calculateAffinityScore(asset, fieldType, stability) {
    let score = 0;

    // Direct field type match
    if (asset.dnaAffinity.includes(fieldType)) score += 0.5;

    // Universal assets get a base score
    if (asset.dnaAffinity.includes('universal')) score += 0.2;

    // Stability-based filtering
    if (stability > 0.7 && asset.type === 'environment') score += 0.2;
    if (stability < 0.3 && asset.type === 'effect') score += 0.2;

    return Math.min(1, score);
  }

  /**
   * Get asset by path
   */
  getAsset(relativePath) {
    return this.assets.get(relativePath);
  }

  /**
   * Get all assets of a type
   */
  getByType(type) {
    return Array.from(this.assets.values()).filter(a => a.type === type);
  }

  getAssetCount() {
    return this.assets.size;
  }

  getManifest() {
    return this.manifest;
  }
}

module.exports = { AssetManager };
