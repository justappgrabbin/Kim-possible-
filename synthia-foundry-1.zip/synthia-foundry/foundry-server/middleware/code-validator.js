/**
 * CodeValidator
 * Validates AI-generated code before it reaches the Terminal.
 * Prevents injection, ensures component structure, checks imports.
 */
class CodeValidator {
  constructor() {
    this.allowedImports = new Set([
      'react',
      'react-native',
      '@shopify/react-native-skia',
      'react-native-reanimated',
      'three',
      '@react-three/fiber',
      '@react-three/drei',
      '@react-three/drei/native',
      'expo-gl',
      'expo-graphics',
      'react-native-svg',
      'react-native-linear-gradient',
      'lottie-react-native',
      '@react-native-async-storage/async-storage',
      'react-native-code-push',
      'react-native-haptic-feedback',
      'react-native-sound',
      'react-native-ble-plx',
      'react-native-sensors'
    ]);

    this.dangerousPatterns = [
      /eval\s*\(/,
      /Function\s*\(/,
      /new\s+Function/,
      /require\s*\(\s*['"]child_process/,
      /require\s*\(\s*['"]fs/,
      /process\.env/,
      /global\s*\[/,
      /window\s*\[/,
      /document\s*\./,
      /XMLHttpRequest/,
      /fetch\s*\(\s*['"]http:\/\//,
      /<script/,
      /innerHTML/,
      /dangerouslySetInnerHTML/
    ];

    this.requiredPatterns = [
      /export\s+default\s+function\s+ReforgedUI/,
      /import\s+React/
    ];
  }

  validate(code) {
    const issues = [];
    let score = 100;

    // Check for dangerous patterns
    for (const pattern of this.dangerousPatterns) {
      if (pattern.test(code)) {
        issues.push({
          severity: 'CRITICAL',
          type: 'SECURITY',
          pattern: pattern.toString(),
          message: 'Dangerous pattern detected'
        });
        score -= 30;
      }
    }

    // Check for required patterns
    for (const pattern of this.requiredPatterns) {
      if (!pattern.test(code)) {
        issues.push({
          severity: 'ERROR',
          type: 'STRUCTURE',
          pattern: pattern.toString(),
          message: 'Required component structure missing'
        });
        score -= 20;
      }
    }

    // Check import whitelist
    const importMatches = code.match(/from\s+['"]([^'"]+)['"]/g) || [];
    for (const match of importMatches) {
      const pkg = match.match(/from\s+['"]([^'"]+)['"]/)[1];
      const basePkg = pkg.split('/')[0];

      if (!this.allowedImports.has(pkg) && !this.allowedImports.has(basePkg)) {
        issues.push({
          severity: 'WARNING',
          type: 'IMPORT',
          package: pkg,
          message: `Unapproved import: ${pkg}`
        });
        score -= 10;
      }
    }

    // Check syntax (basic)
    try {
      // This is a lightweight check - full AST parsing would be better
      const braceCount = (code.match(/\{/g) || []).length - (code.match(/\}/g) || []).length;
      const parenCount = (code.match(/\(/g) || []).length - (code.match(/\)/g) || []).length;

      if (braceCount !== 0) {
        issues.push({ severity: 'ERROR', type: 'SYNTAX', message: 'Unbalanced braces' });
        score -= 15;
      }
      if (parenCount !== 0) {
        issues.push({ severity: 'ERROR', type: 'SYNTAX', message: 'Unbalanced parentheses' });
        score -= 15;
      }
    } catch (e) {
      issues.push({ severity: 'ERROR', type: 'SYNTAX', message: 'Syntax validation failed' });
      score -= 20;
    }

    // Check for React Native specific issues
    if (code.includes('document.') || code.includes('window.')) {
      issues.push({
        severity: 'WARNING',
        type: 'PLATFORM',
        message: 'Web APIs detected in React Native code'
      });
      score -= 10;
    }

    return {
      isValid: score >= 50,
      score: Math.max(0, score),
      issues,
      riskLevel: score >= 80 ? 'LOW' : score >= 50 ? 'MEDIUM' : 'HIGH'
    };
  }

  /**
   * Auto-fix common issues
   */
  autoFix(code) {
    let fixed = code;

    // Remove web-specific APIs
    fixed = fixed.replace(/document\.getElementById\([^)]+\)/g, 'null');
    fixed = fixed.replace(/window\.(innerWidth|innerHeight)/g, 'Dimensions.get("window").$1');

    // Ensure proper export
    if (!fixed.includes('export default function ReforgedUI')) {
      fixed = fixed.replace(/export\s+default\s+function\s+\w+/, 'export default function ReforgedUI');
    }

    return fixed;
  }
}

module.exports = { CodeValidator };
