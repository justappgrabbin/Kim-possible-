const axios = require('axios');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

/**
 * AIEngineSelector
 * Routes forge requests to the appropriate AI backend.
 * Supports: Ollama (local), OpenAI, xAI, TinyLlama WASM, fallback
 */
class AIEngineSelector {
  constructor() {
    this.engines = {
      ollama: new OllamaEngine(),
      openai: new OpenAIEngine(),
      xai: new xAIEngine(),
      tinyllama: new TinyLlamaEngine(),
      fallback: new FallbackEngine()
    };
    this.defaultEngine = process.env.DEFAULT_AI_ENGINE || 'ollama';
  }

  async generateProjection({ intent, axiom, dna, mode, enginePreference, complexity }) {
    const engineName = enginePreference || this.defaultEngine;
    const engine = this.engines[engineName] || this.engines.ollama;

    try {
      return await engine.generate({ intent, axiom, dna, mode, complexity });
    } catch (error) {
      console.warn(`Engine ${engineName} failed:`, error.message);
      // Cascade to fallback
      return await this.engines.fallback.generate({ intent, axiom, dna, mode, complexity });
    }
  }

  async healthCheck(engineName) {
    const engine = this.engines[engineName];
    if (!engine) return { status: 'UNKNOWN', engine: engineName };
    return await engine.healthCheck();
  }
}

// ─── Ollama Engine (Local) ────────────────────────────────────
class OllamaEngine {
  constructor() {
    this.baseUrl = process.env.OLLAMA_URL || 'http://localhost:11434';
    this.model = process.env.OLLAMA_MODEL || 'codellama:7b-code';
    this.timeout = 30000;
  }

  async generate({ intent, axiom, dna, mode, complexity }) {
    const prompt = this.buildPrompt({ intent, axiom, dna, mode, complexity });

    const response = await axios.post(`${this.baseUrl}/api/generate`, {
      model: this.model,
      prompt: prompt,
      stream: false,
      options: {
        temperature: 0.7,
        top_p: 0.9,
        num_predict: 2048
      }
    }, { timeout: this.timeout });

    return this.extractCode(response.data.response);
  }

  buildPrompt({ intent, axiom, dna, mode, complexity }) {
    return `SYSTEM: You are a React Native forge engine. You write production-ready React Native components.

USER DNA:
- Axiom Gates: ${axiom?.join(' → ') || 'Unknown'}
- Field Type: ${dna?.fieldType || 'Standard'}
- Stability: ${dna?.stability?.toFixed(2) || '0.5'}
- Theme Color: ${dna?.themeColor || '#6366f1'}
- Complexity Score: ${complexity?.toFixed(2) || '0.5'}

TASK: Generate a ${mode} React Native component for: "${intent}"

CONSTRAINTS:
1. Use ONLY these imports: React, react-native, @shopify/react-native-skia, react-native-reanimated, three, @react-three/fiber, @react-three/drei
2. Component name MUST be 'ReforgedUI'
3. Export default function ReforgedUI(props)
4. Include proper TypeScript-style prop types
5. For 3D: use Expo-GL compatible Three.js
6. For 2D: use React Native Skia
7. Return ONLY the code. No markdown, no explanations, no backticks.

CURRENT MODE: ${mode}

CODE:`;
  }

  extractCode(raw) {
    // Strip markdown code blocks if present
    let code = raw.trim();
    if (code.startsWith('```')) {
      code = code.replace(/```[\w]*
?/, '').replace(/```$/, '').trim();
    }
    return code;
  }

  async healthCheck() {
    try {
      await axios.get(`${this.baseUrl}/api/tags`, { timeout: 5000 });
      return { status: 'ONLINE', engine: 'ollama', model: this.model };
    } catch {
      return { status: 'OFFLINE', engine: 'ollama' };
    }
  }
}

// ─── OpenAI Engine ────────────────────────────────────────────
class OpenAIEngine {
  constructor() {
    this.apiKey = process.env.OPENAI_API_KEY;
    this.model = process.env.OPENAI_MODEL || 'gpt-4o-mini';
  }

  async generate({ intent, axiom, dna, mode, complexity }) {
    const ollama = new OllamaEngine();
    const prompt = ollama.buildPrompt({ intent, axiom, dna, mode, complexity });

    const response = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: this.model,
      messages: [
        { role: 'system', content: 'You are a React Native forge engine.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 2048
    }, {
      headers: { 'Authorization': `Bearer ${this.apiKey}` },
      timeout: 30000
    });

    return ollama.extractCode(response.data.choices[0].message.content);
  }

  async healthCheck() {
    return { status: this.apiKey ? 'READY' : 'NO_KEY', engine: 'openai' };
  }
}

// ─── xAI Engine ───────────────────────────────────────────────
class xAIEngine {
  constructor() {
    this.apiKey = process.env.XAI_API_KEY;
    this.model = process.env.XAI_MODEL || 'grok-2';
  }

  async generate({ intent, axiom, dna, mode, complexity }) {
    const ollama = new OllamaEngine();
    const prompt = ollama.buildPrompt({ intent, axiom, dna, mode, complexity });

    const response = await axios.post('https://api.x.ai/v1/chat/completions', {
      model: this.model,
      messages: [
        { role: 'system', content: 'You are a React Native forge engine.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 2048
    }, {
      headers: { 'Authorization': `Bearer ${this.apiKey}` },
      timeout: 30000
    });

    return ollama.extractCode(response.data.choices[0].message.content);
  }

  async healthCheck() {
    return { status: this.apiKey ? 'READY' : 'NO_KEY', engine: 'xai' };
  }
}

// ─── TinyLlama WASM Engine ────────────────────────────────────
class TinyLlamaEngine {
  constructor() {
    this.wasmPath = process.env.TINYLLAMA_WASM_PATH;
  }

  async generate({ intent, axiom, dna, mode, complexity }) {
    // This calls a local WASM instance or a Python bridge
    // For now, returns a template that the terminal can use
    return this.getTemplate({ intent, axiom, dna, mode, complexity });
  }

  getTemplate({ intent, axiom, dna, mode, complexity }) {
    const color = dna?.themeColor || '#6366f1';
    const stability = dna?.stability || 0.5;

    if (mode === '3D') {
      return `import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Canvas, Circle, Fill } from '@shopify/react-native-skia';
import Animated, { useSharedValue, useAnimatedStyle, withSpring } from 'react-native-reanimated';

export default function ReforgedUI({ dna }) {
  const scale = useSharedValue(1);

  React.useEffect(() => {
    scale.value = withSpring(${stability > 0.5 ? 1.5 : 0.8}, { damping: 10 });
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }]
  }));

  return (
    <View style={styles.container}>
      <Canvas style={{ flex: 1 }}>
        <Fill color="${color}20" />
        <Circle cx={200} cy={300} r={50} color="${color}" />
      </Canvas>
      <Animated.View style={[styles.overlay, animatedStyle]}>
        <Text style={styles.title}>${intent}</Text>
        <Text style={styles.subtitle}>TinyLlama Mode</Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  overlay: { position: 'absolute', top: 100, left: 0, right: 0, alignItems: 'center' },
  title: { color: '${color}', fontSize: 24, fontWeight: 'bold' },
  subtitle: { color: '#fff', marginTop: 10 }
});`;
    }

    return `import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function ReforgedUI({ dna }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>${intent}</Text>
      <Text style={styles.subtitle}>TinyLlama Offline Mode</Text>
      <Text style={styles.dna}>Axiom: ${axiom?.join(' → ') || 'Unknown'}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e', justifyContent: 'center', alignItems: 'center' },
  title: { color: '${color}', fontSize: 28, fontWeight: 'bold' },
  subtitle: { color: '#888', marginTop: 10 },
  dna: { color: '#444', marginTop: 20, fontSize: 12 }
});`;
  }

  async healthCheck() {
    return { status: 'LOCAL', engine: 'tinyllama' };
  }
}

// ─── Fallback Engine ───────────────────────────────────────────
class FallbackEngine {
  async generate({ intent, axiom, dna, mode, complexity }) {
    const tiny = new TinyLlamaEngine();
    return tiny.generate({ intent, axiom, dna, mode, complexity });
  }

  async healthCheck() {
    return { status: 'ALWAYS_READY', engine: 'fallback' };
  }
}

module.exports = { AIEngineSelector, OllamaEngine, OpenAIEngine, xAIEngine, TinyLlamaEngine };
