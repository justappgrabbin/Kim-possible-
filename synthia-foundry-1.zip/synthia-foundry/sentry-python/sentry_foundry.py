from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import uvicorn
import numpy as np
from datetime import datetime

app = FastAPI(
    title="Synthia Sentry",
    description="Python Fallback Foundry - The Guardian",
    version="1.0.0"
)

# Data Models
class ReforgeRequest(BaseModel):
    axiom: List[int]
    intent: str
    currentVersion: Optional[str] = "1.0.0"
    dna: Optional[Dict[str, Any]] = None
    enginePreference: Optional[str] = None

class AxiomRequest(BaseModel):
    birthDate: str
    birthTime: str
    lat: float
    lon: float
    intentions: Optional[str] = ""

class FeedbackRequest(BaseModel):
    axiom: List[int]
    rating: float
    evolutionId: str

# In-memory state
feedback_history = []
asset_manifest = {
    "entities": [],
    "environments": [],
    "artifacts": []
}

# Axiom Calculator (Pure Python)
def calculate_axiom(birth_date: str, birth_time: str, lat: float, lon: float) -> List[int]:
    from datetime import datetime
    date_obj = datetime.strptime(f"{birth_date}T{birth_time}", "%Y-%m-%dT%H:%M")
    day_of_year = date_obj.timetuple().tm_yday

    gates = [
        ((day_of_year + int(lat)) % 64) + 1,
        ((day_of_year * 2 + int(lon)) % 64) + 1,
        ((day_of_year + date_obj.hour) % 64) + 1,
        ((int(lat * lon) + day_of_year) % 64) + 1,
        ((date_obj.minute + day_of_year) % 64) + 1,
        ((int(lat) + int(lon)) % 64) + 1,
        ((date_obj.month * day_of_year) % 64) + 1
    ]
    return gates

def determine_field_type(axiom: List[int], intentions: str) -> str:
    text = intentions.lower()
    if "spirit" in text or "transcend" in text: return "spiritual"
    if "heart" in text or "love" in text: return "emotional"
    if "mind" in text or "clarity" in text: return "mental"
    if "quantum" in text or "infinite" in text: return "quantum"
    if "void" in text or "still" in text: return "void"
    if axiom[0] < 20: return "spiritual"
    if axiom[0] < 40: return "emotional"
    return "mental"

def predict_evolution_vector(axiom: List[int]) -> Dict[str, float]:
    """Simplified neural prediction using numpy"""
    normalized = np.array(axiom) / 64.0

    fluidity = np.mean(normalized) + np.std(normalized) * 0.3
    density = 1 - np.mean(normalized) + np.max(normalized) * 0.2
    depth = np.max(normalized) * 0.8 + np.min(normalized) * 0.2
    chaos = np.std(normalized) * 2
    resonance = np.mean(np.sin(normalized * np.pi))

    return {
        "fluidity": float(np.clip(fluidity, 0, 1)),
        "density": float(np.clip(density, 0, 1)),
        "depth": float(np.clip(depth, 0, 1)),
        "chaos": float(np.clip(chaos, 0, 1)),
        "resonance": float(np.clip(resonance, 0, 1))
    }

def generate_emergency_code(intent: str, axiom: List[int], dna: Dict, vector: Dict) -> str:
    """Generate a safe-mode React Native component"""
    color = dna.get("themeColor", "#6366f1") if dna else "#6366f1"
    stability = vector.get("fluidity", 0.5)
    field = determine_field_type(axiom, "")

    return f"""import React from 'react';
import {{ View, Text, StyleSheet, ScrollView }} from 'react-native';

export default function ReforgedUI({{ dna }}) {{
  return (
    <View style={{styles.container}}>
      <View style={{styles.header}}>
        <Text style={{styles.title}}>[ SENTRY MODE ]</Text>
        <Text style={{styles.subtitle}}>The Foundry is resting. I am here.</Text>
      </View>

      <ScrollView style={{styles.content}}>
        <View style={{styles.card}}>
          <Text style={{styles.cardTitle}}>Intent</Text>
          <Text style={{styles.cardText}}>{intent}</Text>
        </View>

        <View style={{styles.card}}>
          <Text style={{styles.cardTitle}}>DNA Axiom</Text>
          <Text style={{styles.cardText}}>{" -> ".join(map(str, axiom))}</Text>
        </View>

        <View style={{styles.card}}>
          <Text style={{styles.cardTitle}}>Field Type</Text>
          <Text style={{styles.cardText}}>{field.title()}</Text>
        </View>

        <View style={{styles.card}}>
          <Text style={{styles.cardTitle}}>Neural Vector</Text>
          <Text style={{styles.cardText}}>
            Fluidity: {vector["fluidity"]:.2f}{"\\n"}
            Density: {vector["density"]:.2f}{"\\n"}
            Depth: {vector["depth"]:.2f}{"\\n"}
            Chaos: {vector["chaos"]:.2f}{"\\n"}
            Resonance: {vector["resonance"]:.2f}
          </Text>
        </View>
      </ScrollView>

      <View style={{styles.footer}}>
        <Text style={{styles.agent}}>Agent: "The Forge is quiet, but I remember your DNA."</Text>
      </View>
    </View>
  );
}}

const styles = StyleSheet.create({{
  container: {{ flex: 1, backgroundColor: '#0a0a0f' }},
  header: {{ padding: 30, paddingTop: 60, backgroundColor: '#1a1a2e', alignItems: 'center' }},
  title: {{ color: '#ff3b30', fontSize: 24, fontWeight: 'bold' }},
  subtitle: {{ color: '#888', marginTop: 8, fontSize: 14 }},
  content: {{ flex: 1, padding: 20 }},
  card: {{ backgroundColor: '#16162a', borderRadius: 12, padding: 16, marginBottom: 12, borderLeftWidth: 3, borderLeftColor: '{color}' }},
  cardTitle: {{ color: '{color}', fontSize: 14, fontWeight: '600', marginBottom: 8, textTransform: 'uppercase' }},
  cardText: {{ color: '#ccc', fontSize: 14, lineHeight: 20 }},
  footer: {{ padding: 20, borderTopWidth: 1, borderTopColor: '#222' }},
  agent: {{ color: '#00ff88', fontSize: 12, fontStyle: 'italic', textAlign: 'center' }}
}});
"""

# Routes
@app.get("/")
async def root():
    return {
        "status": "SENTRY_ACTIVE",
        "message": "Python Sentry Guardian Online",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/health")
async def health():
    return {
        "status": "HEALTHY",
        "engine": "python-sentry",
        "assets": len(asset_manifest["entities"]) + len(asset_manifest["environments"]),
        "feedback_count": len(feedback_history)
    }

@app.post("/reforge/fallback")
async def fallback_reforge(request: ReforgeRequest):
    """The main fallback forge endpoint"""
    try:
        vector = predict_evolution_vector(request.axiom)
        field = determine_field_type(request.axiom, "")
        mode = "3D" if vector["depth"] > 0.6 else "2D"

        code = generate_emergency_code(
            request.intent,
            request.axiom,
            request.dna or {},
            vector
        )

        return {
            "status": "FALLBACK_ACTIVE",
            "mode": mode,
            "projectionType": "SAFE_MODE",
            "code": code,
            "metadata": {
                "evolutionVector": vector,
                "fieldPrediction": {"primary": field, "confidence": 0.5},
                "engine": "python-sentry",
                "forgeTime": 0,
                "version": request.currentVersion
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/axiom/calculate")
async def calculate_axiom_endpoint(request: AxiomRequest):
    """Calculate Axiom from birth data (Python implementation)"""
    try:
        gates = calculate_axiom(
            request.birthDate,
            request.birthTime,
            request.lat,
            request.lon
        )
        field = determine_field_type(gates, request.intentions)

        return {
            "status": "SUCCESS",
            "axiom": gates,
            "fieldType": field,
            "metadata": {
                "birthDate": request.birthDate,
                "lat": request.lat,
                "lon": request.lon
            }
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/axiom/analyze")
async def analyze_axiom(request: dict):
    """Analyze an existing Axiom"""
    try:
        axiom = request.get("axiom", [])
        if len(axiom) != 7:
            raise HTTPException(status_code=400, detail="Expected 7-gate array")

        vector = predict_evolution_vector(axiom)
        field = determine_field_type(axiom, "")

        return {
            "status": "SUCCESS",
            "axiom": axiom,
            "evolutionVector": vector,
            "fieldPrediction": {"primary": field, "confidence": 0.5},
            "interpretation": {
                "primaryDrive": field,
                "complexity": vector["fluidity"] + vector["density"],
                "depth": "Volumetric" if vector["depth"] > 0.5 else "Flat",
                "stability": "Fluid" if vector["fluidity"] > 0.5 else "Static"
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/reforge/feedback")
async def record_feedback(request: FeedbackRequest):
    """Record user feedback"""
    feedback_history.append({
        "axiom": request.axiom,
        "rating": request.rating,
        "evolutionId": request.evolutionId,
        "timestamp": datetime.now().isoformat()
    })
    return {"status": "SUCCESS", "message": "Feedback recorded"}

@app.get("/assets/manifest")
async def get_manifest():
    """Return asset manifest"""
    return {
        "status": "SUCCESS",
        "assets": asset_manifest,
        "total": sum(len(v) for v in asset_manifest.values())
    }

if __name__ == "__main__":
    print("Synthia Sentry starting on port 3001...")
    uvicorn.run(app, host="0.0.0.0", port=3001)
