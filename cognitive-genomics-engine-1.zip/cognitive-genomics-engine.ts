
/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║           COGNITIVE GENOMICS ENGINE v1.0                                    ║
 * ║   MxDNA Adaptive Tokenization × MCE Mind Cloning × 5D Cognitive Stack      ║
 * ║                                                                              ║
 * ║   D1=Impulse | D2=Polarity | D3=Witness | D4=Context | D5=Meaning           ║
 * ║   99% Deterministic + 1% Emergent Surprise                                    ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

// ═══════════════════════════════════════════════════════════════════════════════
// D1: IMPULSE — The Raw Signal Stream
// ═══════════════════════════════════════════════════════════════════════════════

interface SignalToken {
  id: string;
  value: number;        // Nucleotide encoding (0=A,1=C,2=G,3=T) or event intensity
  timestamp: number;     // Position in sequence or chronological index
  metadata: Record<string, any>;
}

class SignalStream {
  private buffer: SignalToken[] = [];
  private attractorHistory: Map<string, number> = new Map();

  constructor(private modality: 'dna' | 'cognitive' | 'unified') {}

  ingest(raw: string | any[]): SignalToken[] {
    if (this.modality === 'dna') {
      return this.parseDNA(raw as string);
    } else if (this.modality === 'cognitive') {
      return this.parseExperience(raw as any[]);
    }
    return this.parseUnified(raw);
  }

  private parseDNA(sequence: string): SignalToken[] {
    const map: Record<string, number> = { A: 0, C: 1, G: 2, T: 3 };
    return sequence.split('').map((base, i) => ({
      id: `dna_${i}`,
      value: map[base] ?? -1,
      timestamp: i,
      metadata: { base, codon: this.getCodonContext(sequence, i) }
    }));
  }

  private getCodonContext(seq: string, pos: number): string {
    const start = Math.max(0, pos - (pos % 3));
    return seq.slice(start, start + 3);
  }

  private parseExperience(events: any[]): SignalToken[] {
    return events.map((evt, i) => ({
      id: `evt_${evt.id || i}`,
      value: evt.intensity || evt.emotional_valence || 0.5,
      timestamp: evt.timestamp || i,
      metadata: {
        type: evt.type,
        domain: evt.domain,
        raw: evt
      }
    }));
  }

  private parseUnified(raw: any): SignalToken[] {
    // Unified parser: any signal becomes a token stream
    if (typeof raw === 'string' && /^[ACGT]+$/i.test(raw)) {
      return this.parseDNA(raw);
    }
    if (Array.isArray(raw)) {
      return this.parseExperience(raw);
    }
    // Fallback: treat as single impulse
    return [{
      id: `impulse_${Date.now()}`,
      value: typeof raw === 'number' ? raw : 0.5,
      timestamp: 0,
      metadata: { raw }
    }];
  }

  getBuffer(): SignalToken[] { return this.buffer; }
  append(tokens: SignalToken[]) { this.buffer.push(...tokens); }
}

// ═══════════════════════════════════════════════════════════════════════════════
// D2: POLARITY — The Attractor Field (Tension Geometry)
// ═══════════════════════════════════════════════════════════════════════════════

interface Attractor {
  id: string;
  position: number;      // Center position in signal space
  strength: number;       // g_i — gravitational pull
  radius: number;         // Influence radius
  type: 'biological' | 'cognitive' | 'emergent';
  metadata: Record<string, any>;
}

class AttractorField {
  private attractors: Attractor[] = [];
  private evolutionLog: Array<{time: number, patch: any}> = [];

  constructor(private dimension: number = 1) {}

  /**
   * The manifold M(x) = Σᵢ gᵢ / (1 + |x - aᵢ|)
   * Distance becomes geodesic on M, clustering becomes basin-finding
   */
  computeManifold(position: number): number {
    return this.attractors.reduce((sum, a) => {
      const dist = Math.abs(position - a.position);
      return sum + a.strength / (1 + dist);
    }, 0);
  }

  /**
   * Router confidence scores — analogous to MxDNA's S ∈ R^{l×n}
   * For cognitive: value_weights create the attractor field
   */
  computeRouterScores(signal: SignalToken[]): number[][] {
    const scores: number[][] = [];
    for (const token of signal) {
      const tokenScores = this.attractors.map(a => {
        const dist = Math.abs(token.timestamp - a.position);
        // Confidence = attractor strength × inverse distance × type affinity
        const affinity = this.computeAffinity(token, a);
        return (a.strength / (1 + dist)) * affinity;
      });
      // Softmax normalization
      const maxScore = Math.max(...tokenScores);
      const expScores = tokenScores.map(s => Math.exp(s - maxScore));
      const sumExp = expScores.reduce((a, b) => a + b, 0);
      scores.push(expScores.map(e => e / sumExp));
    }
    return scores;
  }

  private computeAffinity(token: SignalToken, attractor: Attractor): number {
    // Biological: codon match, GC content, etc.
    // Cognitive: domain match, value alignment, etc.
    if (attractor.type === 'biological' && token.metadata.codon) {
      return this.codonAffinity(token.metadata.codon, attractor.metadata);
    }
    if (attractor.type === 'cognitive' && token.metadata.domain) {
      return token.metadata.domain === attractor.metadata.domain ? 1.0 : 0.3;
    }
    return 0.5; // Default affinity
  }

  private codonAffinity(codon: string, meta: any): number {
    // Simplified: match to known start/stop codons or functional domains
    const startCodons = ['ATG'];
    const stopCodons = ['TAA', 'TAG', 'TGA'];
    if (startCodons.includes(codon) && meta.role === 'start') return 1.0;
    if (stopCodons.includes(codon) && meta.role === 'stop') return 1.0;
    return 0.4;
  }

  addAttractor(a: Attractor) { this.attractors.push(a); }

  /**
   * Evolution: new attractors emerge from validation failures
   * 1% emergent surprise — the system grows
   */
  evolve(patch: { newAttractors?: Attractor[], adjust?: any[] }) {
    if (patch.newAttractors) {
      this.attractors.push(...patch.newAttractors);
    }
    if (patch.adjust) {
      for (const adj of patch.adjust) {
        const a = this.attractors.find(at => at.id === adj.id);
        if (a) {
          a.strength = adj.strength ?? a.strength;
          a.position = adj.position ?? a.position;
        }
      }
    }
    this.evolutionLog.push({ time: Date.now(), patch });
  }

  getAttractors(): Attractor[] { return [...this.attractors]; }
}

// ═══════════════════════════════════════════════════════════════════════════════
// D3: WITNESS — The Observer-Node (Non-Maximum Suppression / SKILL Bootloader)
// ═══════════════════════════════════════════════════════════════════════════════

interface Boundary {
  position: number;
  confidence: number;
  attractorId: string;
  type: 'token_center' | 'decision_gate' | 'memory_boundary';
}

class WitnessNode {
  private nmsThreshold: number = 0.5;
  private bootProtocol: string[] = [];

  constructor(private mode: 'dna' | 'cognitive' | 'unified') {}

  /**
   * Non-Maximum Suppression for DNA:
   * Select token centers where router confidence is locally maximal
   * Analogous to MxDNA's BasicUnitNMS.cpp
   */
  selectBoundariesNMS(
    signal: SignalToken[],
    routerScores: number[][],
    attractors: Attractor[]
  ): Boundary[] {
    const boundaries: Boundary[] = [];
    const suppressed = new Set<number>();

    // Flatten: for each token, find best attractor
    const bestScores: Array<{tokenIdx: number, attractorIdx: number, score: number}> = [];
    for (let i = 0; i < signal.length; i++) {
      let bestIdx = 0, bestScore = routerScores[i][0];
      for (let j = 1; j < routerScores[i].length; j++) {
        if (routerScores[i][j] > bestScore) {
          bestScore = routerScores[i][j];
          bestIdx = j;
        }
      }
      bestScores.push({ tokenIdx: i, attractorIdx: bestIdx, score: bestScore });
    }

    // Sort by score descending
    bestScores.sort((a, b) => b.score - a.score);

    for (const candidate of bestScores) {
      if (suppressed.has(candidate.tokenIdx)) continue;

      const attractor = attractors[candidate.attractorIdx];
      boundaries.push({
        position: signal[candidate.tokenIdx].timestamp,
        confidence: candidate.score,
        attractorId: attractor.id,
        type: 'token_center'
      });

      // Suppress neighbors within attractor radius
      const radius = attractor.radius || 3;
      for (let i = candidate.tokenIdx - radius; i <= candidate.tokenIdx + radius; i++) {
        if (i >= 0 && i < signal.length) suppressed.add(i);
      }
    }

    return boundaries.sort((a, b) => a.position - b.position);
  }

  /**
   * SKILL Bootloader for Cognitive:
   * Execute the 4-step cognitive protocol from MCE
   */
  executeBootloader(
    coreFiles: Record<string, string>,
    memoryFiles: Record<string, string>,
    intent: string
  ): { personality: any, values: any, memories: any, style: any } {
    // Step 1: Context Loading — read axioms
    const personality = this.parseMarkdown(coreFiles['personality.md']);
    const values = this.parseValueWeights(coreFiles['value_weights.md']);

    // Step 2: Associative Recall — load relevant memories
    const memories = this.recallMemories(memoryFiles, intent);

    // Step 3: Weighted Decision Making — validate against values
    const decision = this.applyValueWeights(values, intent, memories);

    // Step 4: Style Rendering — compile into linguistic fingerprint
    const style = this.parseMarkdown(coreFiles['linguistics.md']);

    return { personality, values: decision, memories, style };
  }

  private parseMarkdown(content: string): any {
    // Parse MCE-style markdown into structured data
    const sections: Record<string, string> = {};
    const lines = content.split('\n');
    let currentSection = '';
    for (const line of lines) {
      if (line.startsWith('# ')) {
        currentSection = line.slice(2).trim();
        sections[currentSection] = '';
      } else if (currentSection) {
        sections[currentSection] += line + '\n';
      }
    }
    return sections;
  }

  private parseValueWeights(content: string): Record<string, { weight: number, conflict: string }> {
    const weights: Record<string, any> = {};
    const lines = content.split('\n');
    for (const line of lines) {
      const match = line.match(/(.+?):\s*(\d+(?:\.\d+)?)%\s*(?:->\s*(.+))?/);
      if (match) {
        weights[match[1].trim()] = {
          weight: parseFloat(match[2]) / 100,
          conflict: match[3]?.trim() || 'none'
        };
      }
    }
    return weights;
  }

  private recallMemories(memories: Record<string, string>, intent: string): any[] {
    // Simple keyword matching — in production, use semantic search
    const relevant: any[] = [];
    for (const [file, content] of Object.entries(memories)) {
      const intentWords = intent.toLowerCase().split(/\s+/);
      const contentWords = content.toLowerCase();
      const score = intentWords.filter(w => contentWords.includes(w)).length / intentWords.length;
      if (score > 0.2) {
        relevant.push({ file, content, relevance: score });
      }
    }
    return relevant.sort((a, b) => b.relevance - a.relevance);
  }

  private applyValueWeights(
    values: Record<string, any>,
    intent: string,
    memories: any[]
  ): any {
    // Apply trade-off modeling
    const result: Record<string, any> = {};
    for (const [key, val] of Object.entries(values)) {
      result[key] = {
        ...val,
        activated: intent.toLowerCase().includes(key.toLowerCase()) ||
                   memories.some(m => m.content.toLowerCase().includes(key.toLowerCase()))
      };
    }
    return result;
  }

  /**
   * Unified: The hinge where D1×D2 creates stabilized experience
   * J(D1, D2) → D3
   */
  witness(signal: SignalToken[], field: AttractorField): Boundary[] {
    const scores = field.computeRouterScores(signal);
    return this.selectBoundariesNMS(signal, scores, field.getAttractors());
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// D4: CONTEXT — Deformable Convolution / Associative Recall
// ═══════════════════════════════════════════════════════════════════════════════

interface ContextualizedToken {
  token: SignalToken;
  boundary: Boundary;
  neighbors: SignalToken[];  // Local neighborhood
  offset: number;           // Deformable offset or memory shift
  modulator: number;        // Attention weight / modulation factor
}

class ContextEngine {
  private kernelSize: number = 5;

  constructor(private mode: 'dna' | 'cognitive' | 'unified') {}

  /**
   * Deformable Convolution for DNA:
   * Learned offsets ΔP and modulation factors ΔM
   * shape the local receptive field around each token center
   */
  applyDeformableConv(
    signal: SignalToken[],
    boundaries: Boundary[],
    offsets: number[][] = []
  ): ContextualizedToken[] {
    const result: ContextualizedToken[] = [];

    for (let b = 0; b < boundaries.length; b++) {
      const boundary = boundaries[b];
      const tokenIdx = signal.findIndex(t => t.timestamp === boundary.position);
      if (tokenIdx === -1) continue;

      const token = signal[tokenIdx];
      const defaultOffset = offsets[b] || new Array(this.kernelSize).fill(0);

      // Compute neighbors with deformable offsets
      const neighbors: SignalToken[] = [];
      const modulators: number[] = [];

      for (let k = 0; k < this.kernelSize; k++) {
        const offset = defaultOffset[k] || (k - Math.floor(this.kernelSize / 2));
        const neighborIdx = tokenIdx + offset;
        if (neighborIdx >= 0 && neighborIdx < signal.length) {
          neighbors.push(signal[neighborIdx]);
          // Modulation: closer neighbors have higher weight
          modulators.push(1 / (1 + Math.abs(offset)));
        }
      }

      result.push({
        token,
        boundary,
        neighbors,
        offset: defaultOffset.reduce((a, b) => a + b, 0) / defaultOffset.length,
        modulator: modulators.reduce((a, b) => a + b, 0) / modulators.length
      });
    }

    return result;
  }

  /**
   * Associative Recall for Cognitive:
   * Memory context shapes each decision boundary
   */
  applyAssociativeRecall(
    boundaries: Boundary[],
    memories: any[],
    personality: any
  ): ContextualizedToken[] {
    return boundaries.map((b, i) => {
      // Find most relevant memory for this boundary
      const relevant = memories.filter(m => 
        m.content.toLowerCase().includes(b.type)
      );

      return {
        token: { id: `cog_${i}`, value: b.confidence, timestamp: b.position, metadata: {} },
        boundary: b,
        neighbors: relevant.map(m => ({
          id: m.file,
          value: m.relevance,
          timestamp: 0,
          metadata: m
        })),
        offset: relevant.length > 0 ? relevant[0].relevance : 0,
        modulator: personality['Reaction Mechanisms'] ? 0.8 : 0.5
      };
    });
  }

  /**
   * Unified: Context is geodesic distance on the attractor manifold
   */
  apply(signal: SignalToken[], boundaries: Boundary[], field: AttractorField): ContextualizedToken[] {
    if (this.mode === 'dna') {
      return this.applyDeformableConv(signal, boundaries);
    }
    if (this.mode === 'cognitive') {
      return this.applyAssociativeRecall(boundaries, [], {});
    }
    // Unified: compute geodesic context
    return boundaries.map(b => {
      const token = signal.find(t => t.timestamp === b.position)!;
      const neighbors = signal.filter(t => {
        const dist = Math.abs(t.timestamp - b.position);
        return dist > 0 && dist < 5;
      });
      return {
        token,
        boundary: b,
        neighbors,
        offset: field.computeManifold(b.position) - b.confidence,
        modulator: 1 / (1 + Math.abs(field.computeManifold(b.position) - b.confidence))
      };
    });
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// D5: MEANING — The Compiler (Wave Interference → Coherent Output)
// ═══════════════════════════════════════════════════════════════════════════════

interface CompiledToken {
  id: string;
  embedding: number[];     // Final token representation
  meaning: string;          // Human-readable interpretation
  source: ContextualizedToken;
  coherence: number;        // How well this token integrates with neighbors
}

class MeaningCompiler {
  private hiddenDim: number = 64;

  constructor(private mode: 'dna' | 'cognitive' | 'unified') {}

  /**
   * Compile contextualized tokens into final meaning
   * Wave interference: tokens resonate or cancel based on coherence
   */
  compile(contextualized: ContextualizedToken[]): CompiledToken[] {
    const tokens: CompiledToken[] = [];

    for (let i = 0; i < contextualized.length; i++) {
      const ctx = contextualized[i];
      const embedding = this.computeEmbedding(ctx);

      // Coherence: interference with neighbors
      let coherence = 0;
      if (i > 0) {
        coherence += this.cosineSimilarity(embedding, tokens[i - 1].embedding);
      }
      if (i < contextualized.length - 1) {
        // Forward coherence (estimated from context)
        coherence += ctx.modulator;
      }
      coherence = coherence / (i > 0 && i < contextualized.length - 1 ? 2 : 1);

      tokens.push({
        id: `compiled_${i}`,
        embedding,
        meaning: this.interpret(ctx),
        source: ctx,
        coherence: Math.max(0, coherence)
      });
    }

    return tokens;
  }

  private computeEmbedding(ctx: ContextualizedToken): number[] {
    // Simple embedding: weighted combination of token value + neighbor values + offset
    const emb: number[] = new Array(this.hiddenDim).fill(0);
    emb[0] = ctx.token.value * ctx.modulator;
    emb[1] = ctx.offset;
    emb[2] = ctx.boundary.confidence;

    // Add neighbor contributions (wave interference)
    for (let i = 0; i < Math.min(ctx.neighbors.length, 10); i++) {
      emb[3 + i] = ctx.neighbors[i].value * (1 / (1 + i));
    }

    return emb;
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    let dot = 0, normA = 0, normB = 0;
    for (let i = 0; i < Math.min(a.length, b.length); i++) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    return dot / (Math.sqrt(normA) * Math.sqrt(normB) + 1e-8);
  }

  private interpret(ctx: ContextualizedToken): string {
    if (this.mode === 'dna') {
      const codon = ctx.token.metadata.codon;
      return `Token at ${ctx.token.timestamp}: codon ${codon}, confidence ${ctx.boundary.confidence.toFixed(3)}`;
    }
    if (this.mode === 'cognitive') {
      return `Decision gate at ${ctx.boundary.position}: ${ctx.boundary.type}, confidence ${ctx.boundary.confidence.toFixed(3)}`;
    }
    return `Unified token at ${ctx.token.timestamp}: value ${ctx.token.value.toFixed(3)}, coherence ${ctx.modulator.toFixed(3)}`;
  }

  /**
   * Render final output — DNA embeddings or cognitive response
   */
  render(tokens: CompiledToken[]): any {
    if (this.mode === 'dna') {
      return {
        embeddings: tokens.map(t => t.embedding),
        tokenMap: tokens.map(t => ({
          position: t.source.token.timestamp,
          meaning: t.meaning,
          coherence: t.coherence
        }))
      };
    }
    if (this.mode === 'cognitive') {
      // Compile into human-readable response
      const response = tokens.map(t => t.meaning).join('\n');
      return {
        response,
        decisionChain: tokens.map(t => ({
          gate: t.source.boundary.type,
          confidence: t.source.boundary.confidence,
          activated: t.coherence > 0.5
        }))
      };
    }
    return tokens;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// EVOLUTION LOOP — Fidelity Test → Patch → Update (JSON = Gravity)
// ═══════════════════════════════════════════════════════════════════════════════

class EvolutionLoop {
  private history: Array<{ generation: number, output: any, validation: any }> = [];
  private generation: number = 0;

  constructor(
    private fidelityThreshold: number = 0.7,
    private surpriseRate: number = 0.01  // 1% emergent
  ) {}

  /**
   * Cognitive Fidelity Test — beyond Turing Test
   */
  validate(output: any, groundTruth?: any): { passed: boolean; patch?: any } {
    this.generation++;

    // Test A: Covert Turing (if ground truth available)
    let turingScore = 0;
    if (groundTruth) {
      turingScore = this.compareOutputs(output, groundTruth);
    }

    // Test B: Behavioral Prediction Accuracy
    const coherenceScore = output.coherence || 
      (output.embeddings ? this.avgCoherence(output.embeddings) : 0.5);

    // Test C: Value Consistency
    const valueScore = output.decisionChain ? 
      this.checkValueConsistency(output.decisionChain) : 0.5;

    const overall = (turingScore + coherenceScore + valueScore) / 3;

    this.history.push({
      generation: this.generation,
      output,
      validation: { turingScore, coherenceScore, valueScore, overall }
    });

    if (overall >= this.fidelityThreshold) {
      return { passed: true };
    }

    // Generate patch
    const patch = this.generatePatch(output, { turingScore, coherenceScore, valueScore });
    return { passed: false, patch };
  }

  private compareOutputs(a: any, b: any): number {
    // Simplified: compare embedding similarity or response overlap
    if (a.embeddings && b.embeddings) {
      return this.avgCoherence(a.embeddings.map((e: number[], i: number) => 
        this.cosineSim(e, b.embeddings[i] || new Array(e.length).fill(0))
      ));
    }
    return 0.5;
  }

  private avgCoherence(arr: number[]): number {
    return arr.reduce((a, b) => a + b, 0) / arr.length;
  }

  private cosineSim(a: number[], b: number[]): number {
    let dot = 0, na = 0, nb = 0;
    for (let i = 0; i < Math.min(a.length, b.length); i++) {
      dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i];
    }
    return dot / (Math.sqrt(na) * Math.sqrt(nb) + 1e-8);
  }

  private checkValueConsistency(decisions: any[]): number {
    // Check if decisions align with value weights
    const consistent = decisions.filter((d: any) => d.confidence > 0.5 && d.activated).length;
    return consistent / decisions.length;
  }

  private generatePatch(output: any, scores: any): any {
    // 1% chance of emergent attractor
    if (Math.random() < this.surpriseRate) {
      return {
        newAttractors: [{
          id: `emergent_${Date.now()}`,
          position: Math.random() * 100,
          strength: 0.5 + Math.random() * 0.5,
          radius: 2 + Math.random() * 5,
          type: 'emergent',
          metadata: { origin: 'evolution_loop', generation: this.generation }
        }]
      };
    }

    // Otherwise: adjust existing attractors
    return {
      adjust: [{
        id: 'primary',
        strength: 0.8 + (scores.coherenceScore < 0.5 ? 0.2 : -0.1)
      }]
    };
  }

  getHistory() { return this.history; }
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE UNIFIED ENGINE — Orchestrator
// ═══════════════════════════════════════════════════════════════════════════════

class CognitiveGenomicsEngine {
  private signal: SignalStream;
  private field: AttractorField;
  private witness: WitnessNode;
  private context: ContextEngine;
  private compiler: MeaningCompiler;
  private evolution: EvolutionLoop;

  constructor(private modality: 'dna' | 'cognitive' | 'unified') {
    this.signal = new SignalStream(modality);
    this.field = new AttractorField();
    this.witness = new WitnessNode(modality);
    this.context = new ContextEngine(modality);
    this.compiler = new MeaningCompiler(modality);
    this.evolution = new EvolutionLoop();
  }

  /**
   * The Universal Grammar: state → relation → tension → resolution → recursion
   */
  execute(rawInput: any, groundTruth?: any): any {
    // Step 1: State — D1 Impulse
    const tokens = this.signal.ingest(rawInput);
    this.signal.append(tokens);

    // Step 2: Relation — D2 Polarity (attractor field)
    const scores = this.field.computeRouterScores(tokens);

    // Step 3: Tension → Resolution — D3 Witness
    const boundaries = this.witness.witness(tokens, this.field);

    // Step 4: Context — D4 Context shaping
    const contextualized = this.context.apply(tokens, boundaries, this.field);

    // Step 5: Meaning — D5 Compiler
    const compiled = this.compiler.compile(contextualized);
    const output = this.compiler.render(compiled);

    // Step 6: Recursion — Evolution loop
    const validation = this.evolution.validate(output, groundTruth);
    if (!validation.passed && validation.patch) {
      this.field.evolve(validation.patch);
      // Optional: re-run with evolved field
    }

    return {
      output,
      metadata: {
        tokens: tokens.length,
        boundaries: boundaries.length,
        attractors: this.field.getAttractors().length,
        generation: this.evolution.getHistory().length,
        evolved: !validation.passed
      }
    };
  }

  // MCE-style cognitive execution
  executeCognitive(
    coreFiles: Record<string, string>,
    memoryFiles: Record<string, string>,
    intent: string
  ): any {
    const cognitive = this.witness.executeBootloader(coreFiles, memoryFiles, intent);

    // Convert cognitive state into signal tokens for unified processing
    const cognitiveTokens: SignalToken[] = [
      { id: 'personality', value: 1, timestamp: 0, metadata: cognitive.personality },
      { id: 'values', value: 0.8, timestamp: 1, metadata: cognitive.values },
      { id: 'memories', value: 0.6, timestamp: 2, metadata: cognitive.memories },
      { id: 'style', value: 0.9, timestamp: 3, metadata: cognitive.style }
    ];

    return this.execute(cognitiveTokens);
  }

  // DNA-style sequence tokenization
  executeDNA(sequence: string): any {
    return this.execute(sequence);
  }

  getState() {
    return {
      attractors: this.field.getAttractors(),
      evolutionHistory: this.evolution.getHistory()
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════════════════════════════════════════

export {
  CognitiveGenomicsEngine,
  SignalStream,
  AttractorField,
  WitnessNode,
  ContextEngine,
  MeaningCompiler,
  EvolutionLoop
};

export type {
  SignalToken,
  Attractor,
  Boundary,
  ContextualizedToken,
  CompiledToken
};
