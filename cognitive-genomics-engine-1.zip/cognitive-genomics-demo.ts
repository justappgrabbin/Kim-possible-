
/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║     COGNITIVE GENOMICS ENGINE — DEMO & TEST SUITE                          ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 */

import {
  CognitiveGenomicsEngine,
  SignalStream,
  AttractorField,
  WitnessNode,
  ContextEngine,
  MeaningCompiler,
  EvolutionLoop
} from './cognitive-genomics-engine';

import {
  DNA_ATTRACTORS,
  PERSONALITY_MD,
  VALUE_WEIGHTS_MD,
  LINGUISTICS_MD,
  TIMELINE_MD,
  CAREER_MD
} from './cognitive-genomics-fs';

console.log("╔══════════════════════════════════════════════════════════════════════════════╗");
console.log("║     COGNITIVE GENOMICS ENGINE v1.0 — DEMO                                   ║");
console.log("║     MxDNA × MCE × 5D Cognitive Stack                                       ║");
console.log("╚══════════════════════════════════════════════════════════════════════════════╝\n");

// ═══════════════════════════════════════════════════════════════════════════════
// DEMO 1: DNA Sequence Tokenization (MxDNA Mode)
// ═══════════════════════════════════════════════════════════════════════════════

console.log("═══════════════════════════════════════════════════════════════════════════════");
console.log("DEMO 1: DNA Sequence Tokenization — MxDNA Adaptive Mode");
console.log("═══════════════════════════════════════════════════════════════════════════════\n");

const dnaEngine = new CognitiveGenomicsEngine('dna');

// Load biological attractors
for (const a of DNA_ATTRACTORS.attractors) {
  dnaEngine['field'].addAttractor(a);
}

const dnaSequence = `ATGCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCG
ATCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCG
TAAATCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCG
ATCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCG
TAGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCG
ATCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCG
TGAATCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATCG`;

const dnaResult = dnaEngine.executeDNA(dnaSequence);

console.log("DNA Tokenization Results:");
console.log(JSON.stringify(dnaResult, null, 2));

// ═══════════════════════════════════════════════════════════════════════════════
// DEMO 2: Cognitive Mind Cloning (MCE Mode)
// ═══════════════════════════════════════════════════════════════════════════════

console.log("\n═══════════════════════════════════════════════════════════════════════════════");
console.log("DEMO 2: Cognitive Mind Cloning — MCE Execution Mode");
console.log("═══════════════════════════════════════════════════════════════════════════════\n");

const cogEngine = new CognitiveGenomicsEngine('cognitive');

// Load cognitive attractors from value weights
const valueAttractors = [
  { id: "truth", position: 0, strength: 0.95, radius: 5, type: "cognitive" as const, metadata: { domain: "ethics" } },
  { id: "autonomy", position: 20, strength: 0.90, radius: 5, type: "cognitive" as const, metadata: { domain: "freedom" } },
  { id: "growth", position: 40, strength: 0.85, radius: 5, type: "cognitive" as const, metadata: { domain: "development" } },
  { id: "integrity", position: 60, strength: 0.88, radius: 5, type: "cognitive" as const, metadata: { domain: "ethics" } },
  { id: "efficiency", position: 80, strength: 0.65, radius: 5, type: "cognitive" as const, metadata: { domain: "execution" } },
  { id: "harmony", position: 100, strength: 0.55, radius: 5, type: "cognitive" as const, metadata: { domain: "social" } }
];

for (const a of valueAttractors) {
  cogEngine['field'].addAttractor(a);
}

const coreFiles = {
  'personality.md': PERSONALITY_MD,
  'value_weights.md': VALUE_WEIGHTS_MD,
  'linguistics.md': LINGUISTICS_MD
};

const memoryFiles = {
  'timeline.md': TIMELINE_MD,
  'career.md': CAREER_MD
};

const intent = "I'm facing a difficult decision: take a high-paying job that compromises my values, or stay true to myself with less financial security.";

const cogResult = cogEngine.executeCognitive(coreFiles, memoryFiles, intent);

console.log("Cognitive Simulation Results:");
console.log(JSON.stringify(cogResult, null, 2));

// ═══════════════════════════════════════════════════════════════════════════════
// DEMO 3: Unified Mode — Both Biological & Cognitive Signals
// ═══════════════════════════════════════════════════════════════════════════════

console.log("\n═══════════════════════════════════════════════════════════════════════════════");
console.log("DEMO 3: Unified Mode — Bio-Digital Synthesis");
console.log("═══════════════════════════════════════════════════════════════════════════════\n");

const unifiedEngine = new CognitiveGenomicsEngine('unified');

// Load ALL attractors (biological + cognitive)
for (const a of DNA_ATTRACTORS.attractors) {
  unifiedEngine['field'].addAttractor(a);
}
for (const a of valueAttractors) {
  unifiedEngine['field'].addAttractor(a);
}

// Create a unified signal: DNA + cognitive events interleaved
const unifiedSignal = [
  { id: "dna_start", value: 0, timestamp: 0, metadata: { type: "biological", codon: "ATG" } },
  { id: "cog_truth", value: 0.95, timestamp: 1, metadata: { type: "cognitive", domain: "ethics" } },
  { id: "dna_promoter", value: 0, timestamp: 2, metadata: { type: "biological", pattern: "TATAAA" } },
  { id: "cog_growth", value: 0.85, timestamp: 3, metadata: { type: "cognitive", domain: "development" } },
  { id: "dna_exon", value: 0, timestamp: 4, metadata: { type: "biological", consensus: "GT-AG" } },
  { id: "cog_integrity", value: 0.88, timestamp: 5, metadata: { type: "cognitive", domain: "ethics" } },
  { id: "dna_stop", value: 0, timestamp: 6, metadata: { type: "biological", codon: "TAA" } },
  { id: "cog_autonomy", value: 0.90, timestamp: 7, metadata: { type: "cognitive", domain: "freedom" } }
];

const unifiedResult = unifiedEngine.execute(unifiedSignal);

console.log("Unified Bio-Digital Synthesis Results:");
console.log(JSON.stringify(unifiedResult, null, 2));

// ═══════════════════════════════════════════════════════════════════════════════
// DEMO 4: Evolution Loop — Self-Correction & Growth
// ═══════════════════════════════════════════════════════════════════════════════

console.log("\n═══════════════════════════════════════════════════════════════════════════════");
console.log("DEMO 4: Evolution Loop — Self-Correction & Emergent Growth");
console.log("═══════════════════════════════════════════════════════════════════════════════\n");

const evolveEngine = new CognitiveGenomicsEngine('unified');

// Start with minimal attractors
for (const a of DNA_ATTRACTORS.attractors.slice(0, 2)) {
  evolveEngine['field'].addAttractor(a);
}

console.log("Initial attractors:", evolveEngine.getState().attractors.length);

// Run multiple generations with validation
for (let gen = 0; gen < 10; gen++) {
  const result = evolveEngine.execute(unifiedSignal);
  console.log(`Generation ${gen + 1}: tokens=${result.metadata.tokens}, boundaries=${result.metadata.boundaries}, evolved=${result.metadata.evolved}`);
}

console.log("\nFinal attractors:", evolveEngine.getState().attractors.length);
console.log("Evolution history:", evolveEngine.getState().evolutionHistory.length, "generations");

// ═══════════════════════════════════════════════════════════════════════════════
// SUMMARY
// ═══════════════════════════════════════════════════════════════════════════════

console.log("\n═══════════════════════════════════════════════════════════════════════════════");
console.log("SUMMARY: Cognitive Genomics Engine Architecture");
console.log("═══════════════════════════════════════════════════════════════════════════════\n");

console.log(`
The Cognitive Genomics Engine unifies MxDNA and MCE through the 5D stack:

┌─────────────────────────────────────────────────────────────────────────────┐
│ D5: MEANING          │ Compiled tokens, embeddings, human-readable output    │
│ D4: CONTEXT          │ Deformable offsets, associative recall, geodesic      │
│ D3: WITNESS          │ NMS token centers, SKILL bootloader, decision gates │
│ D2: POLARITY         │ Attractor field M(x)=Σgᵢ/(1+|x-aᵢ|), value weights  │
│ D1: IMPULSE          │ DNA sequence, life events, raw signal stream          │
├─────────────────────────────────────────────────────────────────────────────┤
│ EVOLUTION            │ Fidelity test → patch → attractor update (1% emergent)│
└─────────────────────────────────────────────────────────────────────────────┘

Key Insight:
Both DNA and cognition are continuous signals with no natural boundaries.
The model learns where to place boundaries via attractor geometry.
The attractors CREATE the space, not just occupy it.

The 1% emergent surprise is not noise — it is the system's growth mechanism.
`);

console.log("Demo complete.");
