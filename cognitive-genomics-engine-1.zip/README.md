# Cognitive Genomics Engine v1.0

> **MxDNA × MCE × 5D Cognitive Stack** — Unified Bio-Digital Synthesis

```
╔══════════════════════════════════════════════════════════════════════════════╗
║  D1=Impulse  |  D2=Polarity  |  D3=Witness  |  D4=Context  |  D5=Meaning   ║
║  99% Deterministic + 1% Emergent Surprise                                    ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

## What This Is

The **Cognitive Genomics Engine** fuses two powerful paradigms:

- **MxDNA** (NeurIPS 2024): Adaptive DNA sequence tokenization where the model decides where boundaries form
- **MCE** (Mind Cloning Engineering): Cognitive replication via filesystem-based agent skills

Through the **5-Dimensional Cognitive Stack**, both biological and cognitive signals are processed by the same universal grammar:

```
state → relation → tension → resolution → recursion
```

## The Core Insight

> **Attractor geometry is not just shown by the embedding space; it generates the embedding space.**

Both DNA sequences and human cognition are continuous signals with no natural boundaries. The model learns where to place boundaries via an attractor field:

```
M(x) = Σᵢ gᵢ / (1 + |x - aᵢ|)
```

- **Distance** becomes geodesic on M
- **Clustering** becomes basin-finding
- **Resonance** becomes wave interference
- **The attractor field evolves with each recursion**

## Architecture

### 5D Stack

| Dimension | Component | Function |
|-----------|-----------|----------|
| **D1: Impulse** | `SignalStream` | Raw signal ingestion (DNA or life events) |
| **D2: Polarity** | `AttractorField` | Tension field M(x) — where boundaries form |
| **D3: Witness** | `WitnessNode` | NMS token centers / SKILL bootloader — stabilized experience |
| **D4: Context** | `ContextEngine` | Deformable offsets / associative recall — local neighborhood shaping |
| **D5: Meaning** | `MeaningCompiler` | Wave interference → coherent tokens / human-readable output |
| **Evolution** | `EvolutionLoop` | Fidelity test → patch → attractor update (1% emergent) |

### File Structure

```
cognitive-genomics-engine/
├── cognitive-genomics-engine.ts      # Core engine (all 5D components)
├── cognitive-genomics-fs.ts          # MCE filesystem definitions
├── cognitive-genomics-demo.ts      # Demo & test suite
├── package.json
└── tsconfig.json
```

### MCE Filesystem (Mind Clone Structure)

```
mind-clone-[identity_id]/
├── SKILL.md                        # Cognitive Bootloader (D3 Witness)
├── core/                           # Static Attractor Layer (D2)
│   ├── personality.md              # Personality parameters
│   ├── value_weights.md            # Decision weight table
│   ├── linguistics.md              # Linguistic fingerprint
│   └── dna_attractors.json         # Biological attractor definitions
├── memories/                       # Dynamic Signal Layer (D1)
│   ├── timeline.md                 # Life narrative
│   ├── career.md                   # Career history
│   └── dna_sequences/              # DNA archives
├── contexts/                       # D4 Context Engine Config
│   ├── deformable_offsets.json
│   └── associative_rules.json
├── meaning/                        # D5 Compiled Output
│   └── compiled_tokens.json
└── evolution/                      # JSON = Evolution (Gravity)
    ├── patches/
    └── fidelity_log.json
```

## Quick Start

```bash
# Install dependencies
npm install

# Build
npm run build

# Run demo
npm run demo
```

## Demos

### 1. DNA Sequence Tokenization (MxDNA Mode)

```typescript
import { CognitiveGenomicsEngine } from './cognitive-genomics-engine';
import { DNA_ATTRACTORS } from './cognitive-genomics-fs';

const engine = new CognitiveGenomicsEngine('dna');

// Load biological attractors (start codons, stop codons, promoters, etc.)
for (const a of DNA_ATTRACTORS.attractors) {
  engine['field'].addAttractor(a);
}

const dna = "ATGCGATCG...TAA...TAG...TGA";
const result = engine.executeDNA(dna);

// result.output.embeddings — final token representations
// result.metadata.boundaries — where the model decided to tokenize
```

### 2. Cognitive Mind Cloning (MCE Mode)

```typescript
const engine = new CognitiveGenomicsEngine('cognitive');

// Load value attractors (truth, autonomy, growth, integrity, etc.)
const valueAttractors = [
  { id: "truth", position: 0, strength: 0.95, radius: 5, type: "cognitive", metadata: { domain: "ethics" } },
  { id: "autonomy", position: 20, strength: 0.90, radius: 5, type: "cognitive", metadata: { domain: "freedom" } },
  // ...
];

for (const a of valueAttractors) {
  engine['field'].addAttractor(a);
}

const coreFiles = {
  'personality.md': PERSONALITY_MD,
  'value_weights.md': VALUE_WEIGHTS_MD,
  'linguistics.md': LINGUINTICS_MD
};

const memoryFiles = {
  'timeline.md': TIMELINE_MD,
  'career.md': CAREER_MD
};

const intent = "I'm facing a difficult decision...";
const result = engine.executeCognitive(coreFiles, memoryFiles, intent);

// result.output.response — human-readable simulation
// result.output.decisionChain — boundary-by-boundary logic
```

### 3. Unified Bio-Digital Synthesis

```typescript
const engine = new CognitiveGenomicsEngine('unified');

// Load ALL attractors (biological + cognitive)
// The same engine processes DNA and cognition through the same attractor geometry

const unifiedSignal = [
  { id: "dna_start", value: 0, timestamp: 0, metadata: { type: "biological", codon: "ATG" } },
  { id: "cog_truth", value: 0.95, timestamp: 1, metadata: { type: "cognitive", domain: "ethics" } },
  // ...
];

const result = engine.execute(unifiedSignal);
```

### 4. Evolution Loop — Self-Correction & Growth

```typescript
// Run 10 generations — the engine learns and grows
for (let gen = 0; gen < 10; gen++) {
  const result = engine.execute(signal);
  // 1% chance per generation: emergent attractor appears
  // Otherwise: existing attractors adjust based on fidelity scores
}
```

## The Universal Grammar

```
state → relation → tension → resolution → recursion

D1 (Impulse)     → D2 (Polarity)    → D3 (Witness)     → D4 (Context)     → D5 (Meaning)
     ↓                  ↓                  ↓                  ↓                  ↓
  Raw signal      Attractor field    NMS / Bootloader   Deformable conv    Compiled tokens
  DNA sequence    M(x)=Σgᵢ/(1+|x-aᵢ|) Token centers     Offsets / Recall   Wave interference
  Life events     Value weights      Decision gates     Memory shaping     Human response
```

## Key Concepts

### Attractor Geometry

The manifold is not pre-given flat space with attractors placed in it. The attractors **CREATE** the space through their gravitational field.

```
M(x) = Σᵢ gᵢ / (1 + |x - aᵢ|)
```

- **gᵢ**: Attractor strength (value weight, biological significance)
- **aᵢ**: Attractor position (codon position, life event timestamp)
- **|x - aᵢ|**: Geodesic distance on the manifold

### The 1% Emergent Surprise

Not a bug. The system's growth mechanism. When validation fails, the evolution loop has a 1% chance to spawn a **new attractor** rather than just adjusting existing ones. This is how the system discovers new patterns.

### Cognitive Fidelity Test

Beyond Turing Test:

1. **Covert Turing**: >70% of intimate relations can't distinguish clone from real person
2. **Behavioral Prediction**: Consistency in future event prediction
3. **Value Consistency**: Stress testing against deep dilemmas

## License

MIT

---

> *"The ultimate application of Large Language Models is not just answering questions, but cognitive replication."* — yzfly

> *"Attractors CREATE the space."* — Synthia
