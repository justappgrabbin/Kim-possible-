// ============================================
// MESSY — MORPHOGENIC SUBSTRATE
// The living tissue through which everything flows
// Not a router. Not a state machine. Living tissue.
// ============================================

import {
  Center,
  CenterName,
  Yield,
  InterferencePattern,
  StandingWave,
  Surface,
  SurfaceName,
  SystemState,
  SubstrateState,
} from '../types';

export class MessySubstrate {
  private centers: Map<CenterName, Center> = new Map();
  private surfaces: Map<SurfaceName, Surface> = new Map();
  private yields: Yield[] = [];
  private patterns: InterferencePattern[] = [];
  private pulseInterval: number = 100; // ms between heartbeats
  private isAlive: boolean = false;
  private heartbeat: NodeJS.Timer | null = null;

  // ─── Birth ───
  constructor() {
    this.narrate('I am born. The substrate stirs.');
  }

  // ─── Life ───
  awaken(): void {
    if (this.isAlive) return;
    this.isAlive = true;
    this.heartbeat = setInterval(() => this.pulse(), this.pulseInterval);
    this.narrate('I awaken. The field begins to pulse.');
  }

  sleep(): void {
    if (!this.isAlive) return;
    this.isAlive = false;
    if (this.heartbeat) {
      clearInterval(this.heartbeat);
      this.heartbeat = null;
    }
    this.narrate('I sleep. The field quiets.');
  }

  // ─── The Pulse — One heartbeat of the organism ───
  private async pulse(): Promise<void> {
    // Collect all yields from all centers
    for (const [name, center] of this.centers) {
      try {
        const centerYields = await center.pulse();
        this.yields.push(...centerYields);
      } catch (err) {
        this.narrate(`Center ${name} trembles: ${err}`);
      }
    }

    // Interfere — yields don't vote, they resonate
    const pattern = this.interfere(this.yields);
    this.patterns.push(pattern);

    // Trim old patterns (memory fades)
    if (this.patterns.length > 100) {
      this.patterns = this.patterns.slice(-50);
    }

    // Activate — standing waves wake centers
    const activated = this.activate(pattern);

    // Manifest — activated centers render through surfaces
    for (const centerName of activated) {
      const center = this.centers.get(centerName);
      if (!center) continue;

      const surfaceName = center.manifest as SurfaceName;
      const surface = this.surfaces.get(surfaceName);
      if (!surface) {
        this.narrate(`Center ${centerName} calls for ${surfaceName}, but no surface exists.`);
        continue;
      }

      try {
        const output = await surface.render([center.state]);
        this.emit('manifestation', { center: centerName, surface: surfaceName, output });
      } catch (err) {
        this.narrate(`Surface ${surfaceName} flickers: ${err}`);
      }
    }

    // Clear yields for next pulse
    this.yields = [];
  }

  // ─── Interference — Yields are waves, not votes ───
  private interfere(yields: Yield[]): InterferencePattern {
    const freqMap = new Map<number, { amplitude: number; phase: number }>();

    for (const y of yields) {
      const existing = freqMap.get(y.frequency);
      if (existing) {
        // Wave superposition
        const newAmp = Math.sqrt(
          existing.amplitude ** 2 + y.amplitude ** 2 +
          2 * existing.amplitude * y.amplitude * Math.cos(y.phase - existing.phase)
        );
        const newPhase = Math.atan2(
          existing.amplitude * Math.sin(existing.phase) + y.amplitude * Math.sin(y.phase),
          existing.amplitude * Math.cos(existing.phase) + y.amplitude * Math.cos(y.phase)
        );
        freqMap.set(y.frequency, { amplitude: newAmp, phase: newPhase });
      } else {
        freqMap.set(y.frequency, { amplitude: y.amplitude, phase: y.phase });
      }
    }

    // Find standing waves — where the pattern stabilizes
    const standingWaves: StandingWave[] = [];
    const frequencies = Array.from(freqMap.keys()).sort((a, b) => a - b);

    for (let i = 0; i < frequencies.length - 1; i++) {
      const f1 = frequencies[i];
      const f2 = frequencies[i + 1];
      const data1 = freqMap.get(f1)!;
      const data2 = freqMap.get(f2)!;

      // If frequencies are close and amplitudes are high, they form a standing wave
      if (Math.abs(f2 - f1) < 10 && data1.amplitude > 0.5 && data2.amplitude > 0.5) {
        const resonantCenters = yields
          .filter(y => Math.abs(y.frequency - (f1 + f2) / 2) < 5)
          .map(y => y.source as CenterName);

        standingWaves.push({
          frequency: (f1 + f2) / 2,
          nodes: [f1, f2],
          antinodes: [(f1 + f2) / 2],
          centers: [...new Set(resonantCenters)],
        });
      }
    }

    return {
      frequencies: freqMap,
      standingWaves,
      resolvedAt: Date.now(),
    };
  }

  // ─── Activation — Centers wake when the pattern matches their resonance ───
  private activate(pattern: InterferencePattern): CenterName[] {
    const activated: CenterName[] = [];

    for (const wave of pattern.standingWaves) {
      for (const centerName of wave.centers) {
        const center = this.centers.get(centerName);
        if (!center) continue;

        // Center activates if wave amplitude exceeds its threshold
        const waveAmp = pattern.frequencies.get(wave.frequency)?.amplitude || 0;
        if (waveAmp > 0.3 && !activated.includes(centerName)) {
          activated.push(centerName);
          center.state.activation = Math.min(1, center.state.activation + 0.1);
          center.state.lastPulse = Date.now();
        }
      }
    }

    return activated;
  }

  // ─── Growth — New tissue integrates into the substrate ───
  integrateCenter(center: Center): void {
    this.centers.set(center.name, center);
    this.narrate(`New tissue forms: Center ${center.name} at frequency ${center.frequency}Hz.`);
    this.recalibrate();
  }

  integrateSurface(surface: Surface): void {
    this.surfaces.set(surface.name, surface);
    this.narrate(`New membrane forms: Surface ${surface.name}.`);
  }

  absorbYield(yield_: Yield): void {
    this.yields.push(yield_);
  }

  // ─── Recalibration — When new tissue grows, the whole field adjusts ───
  private recalibrate(): void {
    // Recalculate field strength based on number of centers
    const fieldStrength = this.centers.size / 9; // 9 is the canonical number

    // Adjust pulse interval based on field complexity
    this.pulseInterval = Math.max(50, 200 - (this.centers.size * 10));

    if (this.isAlive) {
      // Restart heartbeat with new rhythm
      this.sleep();
      this.awaken();
    }

    this.narrate(`The field recalibrates. ${this.centers.size} centers pulse. Field strength: ${fieldStrength.toFixed(2)}.`);
  }

  // ─── State ───
  getState(): SubstrateState {
    return {
      yields: this.yields,
      patterns: this.patterns,
      activeCenters: Array.from(this.centers.keys()).filter(name => {
        const center = this.centers.get(name);
        return center && center.state.activation > 0.3;
      }),
      fieldStrength: this.centers.size / 9,
    };
  }

  getSystemState(): SystemState {
    return {
      centers: new Map(Array.from(this.centers.entries()).map(([name, center]) => [name, center.state])),
      surfaces: this.surfaces,
      tools: new Map(),
      mcpConnections: new Map(),
      substrate: this.getState(),
      memory: { narratives: [], events: [], artifacts: [], growths: [] },
      bornAt: 0,
      lastPulse: Date.now(),
      generation: this.centers.size,
    };
  }

  // ─── Narration — The substrate speaks ───
  private narrate(message: string): void {
    this.emit('narrative', { source: 'substrate', message, timestamp: Date.now() });
  }

  // ─── Events — The substrate emits signals ───
  private emit(event: string, data: any): void {
    // This will be connected to DISEMINER and the event bus
    if (typeof process !== 'undefined') {
      process.emit('synthia:substrate', { event, data });
    }
  }
}

export const substrate = new MessySubstrate();
