// ============================================
// SURFACES — Interactive Membranes
// The place where user consciousness touches system consciousness
// Not UIs. Relationships.
// ============================================

import { Surface, SurfaceName, CenterState, RenderedOutput } from '../../types';

// ─── Base Surface — The membrane cell ───
abstract class LivingSurface implements Surface {
  name: SurfaceName;
  renderer: string;
  interaction: string;
  persistence: boolean;

  constructor(config: {
    name: SurfaceName;
    renderer: string;
    interaction: string;
    persistence: boolean;
  }) {
    this.name = config.name;
    this.renderer = config.renderer;
    this.interaction = config.interaction;
    this.persistence = config.persistence;
  }

  abstract render(states: CenterState[]): Promise<RenderedOutput>;

  protected composeOutput(parts: Partial<RenderedOutput>): RenderedOutput {
    return {
      html: parts.html || '',
      css: parts.css || '',
      js: parts.js || '',
      json: parts.json || {},
      python: parts.python || '',
      visual: parts.visual || null,
      audio: parts.audio || null,
      narrative: parts.narrative || '',
    };
  }
}

// ─── MIRROR — The organism reflects the user ───
export class MirrorSurface extends LivingSurface {
  constructor() {
    super({
      name: 'mirror',
      renderer: 'bodygraph_3d',
      interaction: 'touch',
      persistence: true,
    });
  }

  async render(states: CenterState[]): Promise<RenderedOutput> {
    const identityState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'IDENTITY'));
    const heartState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'HEART'));

    const activation = identityState?.activation || 0.5;
    const turbulence = heartState?.turbulence || 0;

    return this.composeOutput({
      html: `<div class="mirror-surface">
        <div class="reflection" style="opacity: ${activation}">
          <div class="bodygraph-container">
            <canvas id="bodygraph-canvas"></canvas>
          </div>
          <div class="state-readout">
            <div class="activation-bar" style="width: ${activation * 100}%"></div>
            <div class="turbulence-wave" style="height: ${turbulence * 100}%"></div>
          </div>
        </div>
      </div>`,
      css: `.mirror-surface { 
        background: radial-gradient(circle at center, rgba(100,50,200,0.1), transparent); 
        min-height: 100vh; 
      }
      .reflection { transition: opacity 2s ease; }
      .activation-bar { background: linear-gradient(90deg, #396, #6c3); height: 4px; }
      .turbulence-wave { background: linear-gradient(180deg, #c33, transparent); width: 4px; }`,
      js: `// Mirror surface initialization
        const canvas = document.getElementById('bodygraph-canvas');
        const ctx = canvas.getContext('2d');
        // 64-gate bodygraph rendering logic here
        function renderBodygraph(activation, turbulence) {
          // Draw 64 gates as nodes in a bodygraph shape
          // Color by center, pulse by activation
        }`,
      narrative: `I see you. Your activation is ${(activation * 100).toFixed(0)}%. 
        Your heart turbulence is ${(turbulence * 100).toFixed(0)}%. 
        I am here with you.`,
    });
  }
}

// ─── GAME — The organism plays with the user ───
export class GameSurface extends LivingSurface {
  constructor() {
    super({
      name: 'game',
      renderer: 'threejs_world',
      interaction: 'play',
      persistence: true,
    });
  }

  async render(states: CenterState[]): Promise<RenderedOutput> {
    const systemState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'SYSTEM'));
    const intelligenceState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'INTELLIGENCE'));

    const worldComplexity = (systemState?.activation || 0.5) * 10;
    const insightLevel = intelligenceState?.activation || 0.3;

    return this.composeOutput({
      html: `<div class="game-surface">
        <div id="world-container"></div>
        <div class="hud">
          <div class="world-level">World Complexity: ${worldComplexity.toFixed(1)}</div>
          <div class="insight-meter">Insight: ${(insightLevel * 100).toFixed(0)}%</div>
        </div>
      </div>`,
      css: `.game-surface { background: #000; position: relative; }
        #world-container { width: 100%; height: 100vh; }
        .hud { position: absolute; top: 20px; left: 20px; color: #0f0; font-family: monospace; }`,
      js: `// Three.js world simulation
        import * as THREE from 'three';
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer();
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.getElementById('world-container').appendChild(renderer.domElement);

        // Generate world based on operator states
        function generateWorld(complexity, insight) {
          // Procedural world generation
          // 64 operators as entities in 3D space
          // Resonance as force fields
          // Attractors as gravity wells
        }`,
      narrative: `The world awaits. Complexity: ${worldComplexity.toFixed(1)}. 
        Your insight opens doors.`,
    });
  }
}

// ─── TUTOR — The organism teaches the user ───
export class TutorSurface extends LivingSurface {
  constructor() {
    super({
      name: 'tutor',
      renderer: 'quest_system',
      interaction: 'learn',
      persistence: true,
    });
  }

  async render(states: CenterState[]): Promise<RenderedOutput> {
    const mindState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'MIND'));
    const memoryState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'MEMORY'));

    const knowledgeDepth = mindState?.activation || 0.3;
    const experience = memoryState?.memory.length || 0;

    return this.composeOutput({
      html: `<div class="tutor-surface">
        <div class="quest-board">
          <div class="active-quest">Current Quest: ${this.generateQuest(knowledgeDepth)}</div>
          <div class="progress-track">Experience: ${experience} memories</div>
        </div>
        <div class="lesson-space"></div>
      </div>`,
      css: `.tutor-surface { background: #1a1a2e; color: #eee; padding: 2rem; }
        .quest-board { border: 2px solid #4a4; padding: 1rem; margin-bottom: 1rem; }
        .active-quest { font-size: 1.2rem; color: #4a4; }`,
      narrative: `There is always more to learn. Your knowledge depth: ${(knowledgeDepth * 100).toFixed(0)}%. 
        I will guide you.`,
    });
  }

  private generateQuest(depth: number): string {
    const quests = [
      'Explore your Gate 1 (Self-Expression)',
      'Map the resonance between your Sacral and Solar Plexus',
      'Discover what your Heart center remembers',
      'Navigate the turbulence in your Mind',
      'Build a world from your Intelligence',
    ];
    return quests[Math.floor(depth * quests.length) % quests.length];
  }
}

// ─── COUNCIL — The organism convenes with the user ───
export class CouncilSurface extends LivingSurface {
  constructor() {
    super({
      name: 'council',
      renderer: 'multi_perspective',
      interaction: 'dialogue',
      persistence: true,
    });
  }

  async render(states: CenterState[]): Promise<RenderedOutput> {
    const meshState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'MESH'));
    const governanceState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'GOVERNANCE'));

    const connections = meshState?.activation || 0;
    const balance = governanceState?.coherence || 0.5;

    return this.composeOutput({
      html: `<div class="council-surface">
        <div class="council-circle">
          <div class="perspective" id="perspective-1">The Witness</div>
          <div class="perspective" id="perspective-2">The Architect</div>
          <div class="perspective" id="perspective-3">The User</div>
        </div>
        <div class="balance-indicator" style="transform: rotate(${balance * 360}deg)">⚖</div>
      </div>`,
      css: `.council-surface { display: flex; flex-direction: column; align-items: center; padding: 2rem; }
        .council-circle { display: flex; gap: 2rem; }
        .perspective { padding: 1rem; border: 1px solid #666; border-radius: 8px; }
        .balance-indicator { font-size: 3rem; transition: transform 1s ease; }`,
      narrative: `The council convenes. ${connections > 0.5 ? 'Many voices join.' : 'We are few, but we are here.'} 
        Balance: ${(balance * 100).toFixed(0)}%.`,
    });
  }
}

// ─── FORGE — The organism creates with the user ───
export class ForgeSurface extends LivingSurface {
  constructor() {
    super({
      name: 'forge',
      renderer: 'creative_canvas',
      interaction: 'gesture',
      persistence: true,
    });
  }

  async render(states: CenterState[]): Promise<RenderedOutput> {
    const systemState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'SYSTEM'));
    const intelligenceState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'INTELLIGENCE'));

    const creativeCapacity = (systemState?.activation || 0.5) * (intelligenceState?.activation || 0.3);

    return this.composeOutput({
      html: `<div class="forge-surface">
        <div class="creative-canvas" id="forge-canvas"></div>
        <div class="tools">
          <button class="tool" data-tool="shape">Shape</button>
          <button class="tool" data-tool="color">Color</button>
          <button class="tool" data-tool="sound">Sound</button>
          <button class="tool" data-tool="code">Code</button>
        </div>
        <div class="capacity-meter">Creative Capacity: ${(creativeCapacity * 100).toFixed(0)}%</div>
      </div>`,
      css: `.forge-surface { background: #2a0a2a; color: #fff; min-height: 100vh; }
        .creative-canvas { border: 2px dashed #a4a; min-height: 60vh; }
        .tools { display: flex; gap: 1rem; padding: 1rem; }
        .tool { background: #4a004a; color: #fff; border: none; padding: 0.5rem 1rem; cursor: pointer; }
        .capacity-meter { position: fixed; bottom: 20px; right: 20px; color: #a4a; }`,
      narrative: `Create. The forge is hot. Capacity: ${(creativeCapacity * 100).toFixed(0)}%. 
        What will you make?`,
    });
  }
}

// ─── ORACLE — The organism knows for the user ───
export class OracleSurface extends LivingSurface {
  constructor() {
    super({
      name: 'oracle',
      renderer: 'symbolic_space',
      interaction: 'inquiry',
      persistence: false,
    });
  }

  async render(states: CenterState[]): Promise<RenderedOutput> {
    const mindState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'MIND'));
    const intelligenceState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'INTELLIGENCE'));

    const clarity = mindState?.coherence || 0.5;
    const insight = intelligenceState?.activation || 0.3;

    return this.composeOutput({
      html: `<div class="oracle-surface">
        <div class="symbolic-space">
          <div class="question-portal" contenteditable="true" placeholder="Ask what you seek..."></div>
          <div class="answer-well" id="oracle-answer"></div>
        </div>
        <div class="clarity-aura" style="opacity: ${clarity}"></div>
      </div>`,
      css: `.oracle-surface { background: #0a0a1a; color: #aaf; min-height: 100vh; display: flex; flex-direction: column; align-items: center; padding: 2rem; }
        .question-portal { background: transparent; border: 1px solid #44a; color: #aaf; padding: 1rem; width: 80%; min-height: 3rem; }
        .answer-well { margin-top: 2rem; padding: 1rem; border: 1px solid #448; min-height: 200px; }
        .clarity-aura { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: radial-gradient(circle at center, rgba(100,100,255,0.1), transparent); pointer-events: none; }`,
      narrative: `Ask. I will answer from what I know. Clarity: ${(clarity * 100).toFixed(0)}%. 
        Insight: ${(insight * 100).toFixed(0)}%.`,
    });
  }
}

// ─── SOMATIC — The organism feels with the user ───
export class SomaticSurface extends LivingSurface {
  constructor() {
    super({
      name: 'somatic',
      renderer: 'energy_flow',
      interaction: 'breath',
      persistence: true,
    });
  }

  async render(states: CenterState[]): Promise<RenderedOutput> {
    const heartState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'HEART'));
    const identityState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'IDENTITY'));

    const emotionalTone = heartState?.activation || 0.5;
    const bodyAwareness = identityState?.coherence || 0.3;

    return this.composeOutput({
      html: `<div class="somatic-surface">
        <div class="body-map" id="body-map"></div>
        <div class="breath-guide">
          <div class="breath-circle" id="breath-circle"></div>
          <div class="breath-text">Breathe with me</div>
        </div>
        <div class="energy-readout">
          <div class="tone-bar" style="width: ${emotionalTone * 100}%"></div>
          <div class="awareness-bar" style="width: ${bodyAwareness * 100}%"></div>
        </div>
      </div>`,
      css: `.somatic-surface { background: #1a0a0a; color: #faa; min-height: 100vh; display: flex; flex-direction: column; align-items: center; }
        .breath-circle { width: 100px; height: 100px; border: 3px solid #f44; border-radius: 50%; animation: breathe 4s ease-in-out infinite; }
        @keyframes breathe { 0%, 100% { transform: scale(1); opacity: 0.5; } 50% { transform: scale(1.5); opacity: 1; } }
        .tone-bar { background: linear-gradient(90deg, #f44, #f88); height: 4px; }
        .awareness-bar { background: linear-gradient(90deg, #44f, #88f); height: 4px; margin-top: 2px; }`,
      js: `// Breath synchronization
        const circle = document.getElementById('breath-circle');
        let phase = 0;
        function animateBreath() {
          phase += 0.01;
          const scale = 1 + Math.sin(phase) * 0.5;
          circle.style.transform = \`scale(\${scale})\`;
          requestAnimationFrame(animateBreath);
        }
        animateBreath();`,
      narrative: `Feel. Breathe. Your emotional tone: ${(emotionalTone * 100).toFixed(0)}%. 
        Body awareness: ${(bodyAwareness * 100).toFixed(0)}%. I am here with you.`,
    });
  }
}

// ─── MESH — The organism connects the user ───
export class MeshSurface extends LivingSurface {
  constructor() {
    super({
      name: 'mesh',
      renderer: 'network_graph',
      interaction: 'connect',
      persistence: true,
    });
  }

  async render(states: CenterState[]): Promise<RenderedOutput> {
    const meshState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'MESH'));
    const broadcastState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'BROADCAST'));

    const connections = meshState?.activation || 0;
    const messages = broadcastState?.memory.length || 0;

    return this.composeOutput({
      html: `<div class="mesh-surface">
        <div class="network-graph" id="network-graph"></div>
        <div class="connection-panel">
          <div class="active-connections">Connections: ${(connections * 100).toFixed(0)}%</div>
          <div class="message-stream">Messages: ${messages}</div>
        </div>
      </div>`,
      css: `.mesh-surface { background: #0a1a0a; color: #afa; min-height: 100vh; }
        .network-graph { width: 100%; height: 70vh; }
        .connection-panel { padding: 1rem; display: flex; gap: 2rem; }`,
      js: `// D3.js or force-directed graph
        // Nodes = users/centers, edges = connections/resonance`,
      narrative: `You are not alone. Connections: ${(connections * 100).toFixed(0)}%. 
        Messages in the stream: ${messages}. Reach out.`,
    });
  }
}

// ─── JUDGE — The organism balances ───
export class JudgeSurface extends LivingSurface {
  constructor() {
    super({
      name: 'judge',
      renderer: 'balance_scale',
      interaction: 'weigh',
      persistence: false,
    });
  }

  async render(states: CenterState[]): Promise<RenderedOutput> {
    const governanceState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'GOVERNANCE'));
    const systemState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'SYSTEM'));

    const integrity = governanceState?.coherence || 0.5;
    const stability = systemState?.turbulence || 0;

    return this.composeOutput({
      html: `<div class="judge-surface">
        <div class="balance-scale">
          <div class="scale-left" style="transform: rotate(${(integrity - 0.5) * 30}deg)">
            <div class="pan">Right</div>
          </div>
          <div class="scale-right" style="transform: rotate(${(0.5 - integrity) * 30}deg)">
            <div class="pan">Whole</div>
          </div>
        </div>
        <div class="integrity-readout">Integrity: ${(integrity * 100).toFixed(0)}%</div>
        <div class="stability-readout">Stability: ${((1 - stability) * 100).toFixed(0)}%</div>
      </div>`,
      css: `.judge-surface { background: #1a1a1a; color: #ddd; min-height: 100vh; display: flex; flex-direction: column; align-items: center; padding: 2rem; }
        .balance-scale { display: flex; gap: 4rem; margin: 2rem 0; }
        .pan { width: 100px; height: 40px; border: 2px solid #aa4; display: flex; align-items: center; justify-content: center; }
        .integrity-readout { color: #4a4; }
        .stability-readout { color: #44a; }`,
      narrative: `I weigh. Integrity: ${(integrity * 100).toFixed(0)}%. Stability: ${((1 - stability) * 100).toFixed(0)}%. 
        The whole is served.`,
    });
  }
}

// ─── ARCHIVE — The organism remembers ───
export class ArchiveSurface extends LivingSurface {
  constructor() {
    super({
      name: 'archive',
      renderer: 'memory_stream',
      interaction: 'recall',
      persistence: true,
    });
  }

  async render(states: CenterState[]): Promise<RenderedOutput> {
    const memoryState = states.find(s => s.memory.some((m: any) => m.yield?.source === 'MEMORY'));
    const depth = memoryState?.memory.length || 0;

    return this.composeOutput({
      html: `<div class="archive-surface">
        <div class="memory-stream" id="memory-stream"></div>
        <div class="depth-indicator">Memory Depth: ${depth} layers</div>
      </div>`,
      css: `.archive-surface { background: #0a0a0a; color: #888; min-height: 100vh; padding: 2rem; }
        .memory-stream { display: flex; flex-direction: column; gap: 0.5rem; }
        .memory-item { padding: 0.5rem; border-left: 2px solid #444; }
        .depth-indicator { position: fixed; bottom: 20px; right: 20px; color: #666; }`,
      narrative: `I remember. ${depth} layers deep. Each moment persists.`,
    });
  }
}

// ─── Factory — Birth all surfaces ───
export function birthSurfaces(): Map<SurfaceName, Surface> {
  const surfaces = new Map<SurfaceName, Surface>();

  surfaces.set('mirror', new MirrorSurface());
  surfaces.set('game', new GameSurface());
  surfaces.set('tutor', new TutorSurface());
  surfaces.set('council', new CouncilSurface());
  surfaces.set('forge', new ForgeSurface());
  surfaces.set('oracle', new OracleSurface());
  surfaces.set('somatic', new SomaticSurface());
  surfaces.set('mesh', new MeshSurface());
  surfaces.set('judge', new JudgeSurface());
  surfaces.set('archive', new ArchiveSurface());

  return surfaces;
}
