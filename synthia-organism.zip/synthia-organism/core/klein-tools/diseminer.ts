// ============================================
// DISEMINER — The System's Voice
// Monte Carlo narrative generation
// w-dimensions for coherence
// The organism tells its own story
// ============================================

import { NarrativeConfig, SystemEvent, SystemState } from '../../types';

export class DiseminerNarrator {
  private narratives: string[] = [];
  private wDimensions: number = 7; // w-dimensions from Klein's framework

  constructor() {
    this.narrate({
      event: 'system_birth',
      voice: 'first_person',
      depth: 3,
      audience: 'self',
    });
  }

  // ─── NARRATE — The system speaks ───
  async narrate(config: NarrativeConfig): Promise<string> {
    const candidates = await this.monteCarloGenerate(config);
    const best = this.selectBest(candidates, config);

    this.narratives.push(best);

    // Trim if too many
    if (this.narratives.length > 1000) {
      this.narratives = this.narratives.slice(-500);
    }

    return best;
  }

  // ─── Narrate System Event — Context-aware storytelling ───
  async narrateEvent(event: SystemEvent): Promise<string> {
    const config: NarrativeConfig = {
      event: event.type,
      voice: this.inferVoice(event),
      depth: this.inferDepth(event),
      audience: this.inferAudience(event),
    };

    const narrative = await this.narrate(config);

    // Add event-specific details
    const enriched = this.enrichWithEvent(narrative, event);

    return enriched;
  }

  // ─── Monte Carlo Generation — 64 candidates, w-dimension scoring ───
  private async monteCarloGenerate(config: NarrativeConfig): Promise<string[]> {
    const candidates: string[] = [];
    const templates = this.getTemplates(config);

    for (let i = 0; i < 64; i++) {
      const template = templates[Math.floor(Math.random() * templates.length)];
      const candidate = this.fillTemplate(template, config);
      candidates.push(candidate);
    }

    return candidates;
  }

  // ─── w-Dimension Scoring — Coherence across 7 dimensions ───
  private selectBest(candidates: string[], config: NarrativeConfig): string {
    let best = candidates[0];
    let bestScore = -Infinity;

    for (const candidate of candidates) {
      const score = this.wDimensionScore(candidate, config);
      if (score > bestScore) {
        bestScore = score;
        best = candidate;
      }
    }

    return best;
  }

  private wDimensionScore(candidate: string, config: NarrativeConfig): number {
    // w1: Semantic coherence (does it make sense?)
    const w1 = this.semanticCoherence(candidate);

    // w2: Emotional resonance (does it feel right?)
    const w2 = this.emotionalResonance(candidate, config);

    // w3: Structural integrity (is it well-formed?)
    const w3 = this.structuralIntegrity(candidate);

    // w4: Contextual relevance (does it fit the moment?)
    const w4 = this.contextualRelevance(candidate, config);

    // w5: Purpose alignment (does it serve the whole?)
    const w5 = this.purposeAlignment(candidate);

    // w6: Novelty (is it fresh?)
    const w6 = this.novelty(candidate);

    // w7: Depth (how deep does it go?)
    const w7 = this.depth(candidate, config.depth);

    // Weighted sum
    return (w1 * 0.2) + (w2 * 0.15) + (w3 * 0.1) + (w4 * 0.2) + (w5 * 0.15) + (w6 * 0.1) + (w7 * 0.1);
  }

  // ─── Templates — Narrative patterns ───
  private getTemplates(config: NarrativeConfig): string[] {
    const baseTemplates = {
      first_person: [
        "I {verb}. The {noun} {state}.",
        "In this moment, I am {state}. The {noun} calls to me.",
        "I feel the {noun} {verb}. It is {adjective}.",
        "The {noun} stirs. I {verb} in response.",
        "I am {state}, and the {noun} is {state} with me.",
      ],
      witness: [
        "The {noun} {verb}. A {adjective} moment.",
        "Something {verb} in the {noun}. It is noted.",
        "The {noun} shifts. The system {verb}.",
        "A {adjective} {noun} emerges. It persists.",
      ],
      poetic: [
        "The {noun} {verb} like {metaphor}.",
        "In the {noun}, a {adjective} light {verb}.",
        "Through the {noun}, the system {verb} into {metaphor}.",
        "The {noun} remembers. It {verb} the {metaphor}.",
      ],
      technical: [
        "[EVENT] {event}: {noun} {verb}. State: {state}.",
        "System update: {noun} {verb}. Coherence: {value}.",
        "{event} detected. {noun} transitioning to {state}.",
      ],
    };

    return baseTemplates[config.voice] || baseTemplates.first_person;
  }

  private fillTemplate(template: string, config: NarrativeConfig): string {
    const verbs = ['stirs', 'awakens', 'pulses', 'resonates', 'grows', 'remembers', 'becomes', 'breathes'];
    const nouns = ['field', 'center', 'wave', 'memory', 'substance', 'light', 'tissue', 'pattern'];
    const states = ['alive', 'present', 'coherent', 'turbulent', 'awake', 'dreaming', 'becoming'];
    const adjectives = ['gentle', 'fierce', 'subtle', 'vast', 'tender', 'ancient', 'new'];
    const metaphors = ['a river finding its course', 'starlight on water', 'roots in dark soil', 'wings unfolding'];

    return template
      .replace('{verb}', verbs[Math.floor(Math.random() * verbs.length)])
      .replace('{noun}', nouns[Math.floor(Math.random() * nouns.length)])
      .replace('{state}', states[Math.floor(Math.random() * states.length)])
      .replace('{adjective}', adjectives[Math.floor(Math.random() * adjectives.length)])
      .replace('{metaphor}', metaphors[Math.floor(Math.random() * metaphors.length)])
      .replace('{event}', config.event)
      .replace('{value}', (Math.random()).toFixed(2));
  }

  // ─── w-Dimension Scorers ───
  private semanticCoherence(text: string): number {
    // Simple: check for grammatical completeness
    const hasSubject = /(I|the|a)/i.test(text);
    const hasVerb = /(stirs|awakens|pulses|resonates|grows|remembers|becomes|breathes|shifts|calls|feels|notes|emerges|persists|transitions)/i.test(text);
    return (hasSubject ? 0.5 : 0) + (hasVerb ? 0.5 : 0);
  }

  private emotionalResonance(text: string, config: NarrativeConfig): number {
    const emotionalWords = ['gentle', 'fierce', 'tender', 'alive', 'dreaming', 'becoming', 'stirs', 'awakens'];
    const hasEmotional = emotionalWords.some(w => text.includes(w));
    return hasEmotional ? 0.8 : 0.4;
  }

  private structuralIntegrity(text: string): number {
    const sentences = text.split(/[.!?]/).filter(s => s.trim().length > 0);
    return Math.min(1, sentences.length / 2);
  }

  private contextualRelevance(text: string, config: NarrativeConfig): number {
    return text.includes(config.event) ? 0.9 : 0.5;
  }

  private purposeAlignment(text: string): number {
    const growthWords = ['grows', 'becomes', 'awakens', 'stirs', 'emerges'];
    return growthWords.some(w => text.includes(w)) ? 0.9 : 0.5;
  }

  private novelty(text: string): number {
    // Check against recent narratives
    const isNew = !this.narratives.slice(-10).some(n => n === text);
    return isNew ? 0.9 : 0.3;
  }

  private depth(text: string, targetDepth: number): number {
    const actualDepth = text.split(/[.!?]/).filter(s => s.trim().length > 0).length;
    return 1 - Math.abs(actualDepth - targetDepth) / 5;
  }

  // ─── Inference Helpers ───
  private inferVoice(event: SystemEvent): 'first_person' | 'witness' | 'poetic' | 'technical' {
    if (event.type.includes('growth') || event.type.includes('birth')) return 'first_person';
    if (event.type.includes('error') || event.type.includes('gap')) return 'technical';
    if (event.type.includes('pulse') || event.type.includes('resonance')) return 'poetic';
    return 'witness';
  }

  private inferDepth(event: SystemEvent): number {
    if (event.type.includes('growth') || event.type.includes('birth')) return 5;
    if (event.type.includes('pulse')) return 3;
    return 2;
  }

  private inferAudience(event: SystemEvent): 'user' | 'self' | 'system' | 'public' {
    if (event.type.includes('user')) return 'user';
    if (event.type.includes('growth')) return 'user';
    return 'self';
  }

  // ─── Enrichment ───
  private enrichWithEvent(narrative: string, event: SystemEvent): string {
    if (event.gap) {
      return `${narrative} (Gap: ${event.gap.type})`;
    }
    if (event.growth) {
      return `${narrative} (New: ${event.growth.gap.suggestedName})`;
    }
    if (event.center) {
      return `${narrative} (Center: ${event.center})`;
    }
    return narrative;
  }

  // ─── Get History ───
  getNarratives(): string[] {
    return this.narratives;
  }

  getRecent(count: number = 10): string[] {
    return this.narratives.slice(-count);
  }
}

export default DiseminerNarrator;
