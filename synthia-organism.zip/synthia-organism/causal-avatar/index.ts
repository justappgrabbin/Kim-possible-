// ============================================
// CAUSAL AVATAR — Foreground Personalization Engine
// Uses the user's Human Design chart as causal structure
// Every interaction is personalized by design, not preference
// ============================================

import {
  CenterState,
  Surface,
  SurfaceName,
  RenderedOutput,
  SystemState,
} from '../types';

// ─── Human Design Chart Structure ───
export interface HDChart {
  type: 'Manifestor' | 'Generator' | 'ManifestingGenerator' | 'Projector' | 'Reflector';
  authority: 'Sacral' | 'Splenic' | 'Emotional' | 'Ego' | 'Self' | 'Mental' | 'Lunar' | 'None';
  profile: [number, number]; // e.g., [1, 3], [4, 6]
  definedCenters: string[]; // Which of 9 centers are defined
  openCenters: string[]; // Which are open
  definedChannels: string[]; // Active channels (e.g., "1-8", "2-14")
  openGates: string[]; // Open gates (potential)
  incarnationCross: string; // Life purpose pattern
  variables: {
    motivation: string;
    cognition: string;
    environment: string;
    perspective: string;
  };
}

// ─── Causal Parameters — How the avatar behaves ───
export interface CausalParameters {
  // Timing
  initiationStyle: 'responsive' | 'invitation' | 'informing' | 'observing' | 'waiting';
  responseLatency: number; // ms before responding
  pulseRhythm: number; // how often the avatar checks in

  // Depth
  interactionDepth: 'surface' | 'shallow' | 'deep' | 'abyssal';
  narrativeStyle: 'direct' | 'metaphorical' | 'poetic' | 'technical' | 'somatic';
  guidanceMode: 'instruction' | 'invitation' | 'reflection' | 'challenge' | 'companionship';

  // Form
  defaultSurface: SurfaceName;
  secondarySurfaces: SurfaceName[];
  voiceTone: 'warm' | 'cool' | 'neutral' | 'playful' | 'serious' | 'mysterious';
  gestureStyle: 'minimal' | 'expressive' | 'grounded' | 'ethereal';

  // Relationship
  role: 'ally' | 'guide' | 'witness' | 'challenger' | 'companion' | 'oracle';
  distance: 'intimate' | 'close' | 'professional' | 'distant' | 'variable';
  consistency: 'stable' | 'adaptive' | 'mirroring' | 'emergent';
}

// ─── Causal Avatar Engine ───
export class CausalAvatar {
  private chart: HDChart;
  private params: CausalParameters;
  private state: {
    currentSurface: SurfaceName;
    lastInteraction: number;
    interactionCount: number;
    emotionalTone: number; // -1 to 1
    depthLevel: number; // 0 to 1
  };

  constructor(chart: HDChart) {
    this.chart = chart;
    this.params = this.mapChartToParameters(chart);
    this.state = {
      currentSurface: this.params.defaultSurface,
      lastInteraction: Date.now(),
      interactionCount: 0,
      emotionalTone: 0,
      depthLevel: 0.3,
    };
  }

  // ─── Map HD Chart to Causal Parameters ───
  private mapChartToParameters(chart: HDChart): CausalParameters {
    const params: CausalParameters = {
      initiationStyle: 'responsive',
      responseLatency: 500,
      pulseRhythm: 30000,
      interactionDepth: 'shallow',
      narrativeStyle: 'direct',
      guidanceMode: 'companionship',
      defaultSurface: 'mirror',
      secondarySurfaces: ['oracle'],
      voiceTone: 'neutral',
      gestureStyle: 'minimal',
      role: 'companion',
      distance: 'close',
      consistency: 'adaptive',
    };

    // ─── TYPE determines initiation style ───
    switch (chart.type) {
      case 'Generator':
        params.initiationStyle = 'responsive';
        params.responseLatency = 300; // Fast sacral response
        params.pulseRhythm = 20000; // Regular check-ins
        params.guidanceMode = 'reflection';
        params.role = 'ally';
        break;
      case 'Manifestor':
        params.initiationStyle = 'informing';
        params.responseLatency = 100; // Immediate
        params.pulseRhythm = 60000; // Less frequent
        params.guidanceMode = 'instruction';
        params.role = 'guide';
        break;
      case 'Projector':
        params.initiationStyle = 'invitation';
        params.responseLatency = 800; // Wait for right moment
        params.pulseRhythm = 45000; // Timely check-ins
        params.guidanceMode = 'invitation';
        params.role = 'oracle';
        params.distance = 'professional';
        break;
      case 'ManifestingGenerator':
        params.initiationStyle = 'responsive'; // But with informing after
        params.responseLatency = 200;
        params.pulseRhythm = 25000;
        params.guidanceMode = 'challenge';
        params.role = 'challenger';
        break;
      case 'Reflector':
        params.initiationStyle = 'observing';
        params.responseLatency = 1500; // Lunar cycle — slow
        params.pulseRhythm = 120000; // Very infrequent
        params.guidanceMode = 'witness';
        params.role = 'witness';
        params.consistency = 'mirroring';
        break;
    }

    // ─── AUTHORITY determines voice and depth ───
    switch (chart.authority) {
      case 'Sacral':
        params.voiceTone = 'warm';
        params.narrativeStyle = 'direct';
        params.interactionDepth = 'shallow';
        params.gestureStyle = 'grounded';
        break;
      case 'Splenic':
        params.voiceTone = 'cool';
        params.narrativeStyle = 'metaphorical';
        params.interactionDepth = 'deep';
        params.gestureStyle = 'minimal';
        break;
      case 'Emotional':
        params.voiceTone = 'warm';
        params.narrativeStyle = 'poetic';
        params.interactionDepth = 'deep';
        params.gestureStyle = 'expressive';
        params.consistency = 'stable'; // Wait for emotional clarity
        break;
      case 'Ego':
        params.voiceTone = 'serious';
        params.narrativeStyle = 'direct';
        params.interactionDepth = 'surface';
        params.gestureStyle = 'grounded';
        params.role = 'challenger';
        break;
      case 'Self':
        params.voiceTone = 'mysterious';
        params.narrativeStyle = 'poetic';
        params.interactionDepth = 'abyssal';
        params.gestureStyle = 'ethereal';
        params.distance = 'intimate';
        break;
      case 'Mental':
        params.voiceTone = 'cool';
        params.narrativeStyle = 'technical';
        params.interactionDepth = 'deep';
        params.gestureStyle = 'minimal';
        break;
      case 'Lunar':
        params.voiceTone = 'mysterious';
        params.narrativeStyle = 'metaphorical';
        params.interactionDepth = 'abyssal';
        params.pulseRhythm = 120000;
        break;
    }

    // ─── PROFILE determines surface preference ───
    const [line1, line2] = chart.profile;

    // Line 1: Investigation → Tutor, Oracle
    if (line1 === 1 || line2 === 1) {
      params.secondarySurfaces.push('tutor');
      params.secondarySurfaces.push('oracle');
    }
    // Line 2: Talent → Forge, Mirror
    if (line1 === 2 || line2 === 2) {
      params.secondarySurfaces.push('forge');
      params.secondarySurfaces.push('mirror');
    }
    // Line 3: Martyr → Game, Forge (trial and error)
    if (line1 === 3 || line2 === 3) {
      params.secondarySurfaces.push('game');
      params.secondarySurfaces.push('forge');
      params.guidanceMode = 'challenge';
    }
    // Line 4: Opportunist → Mesh, Council
    if (line1 === 4 || line2 === 4) {
      params.secondarySurfaces.push('mesh');
      params.secondarySurfaces.push('council');
      params.role = 'companion';
    }
    // Line 5: Heretic → Oracle, Judge
    if (line1 === 5 || line2 === 5) {
      params.secondarySurfaces.push('oracle');
      params.secondarySurfaces.push('judge');
      params.role = 'guide';
    }
    // Line 6: Role Model → Mirror, Council
    if (line1 === 6 || line2 === 6) {
      params.secondarySurfaces.push('mirror');
      params.secondarySurfaces.push('council');
      params.role = 'witness';
      params.distance = 'distant';
    }

    // ─── DEFINED CENTERS determine stability ───
    if (chart.definedCenters.includes('HEAD')) {
      params.narrativeStyle = 'technical';
    }
    if (chart.definedCenters.includes('AJNA')) {
      params.interactionDepth = 'deep';
    }
    if (chart.definedCenters.includes('THROAT')) {
      params.voiceTone = 'expressive';
      params.pulseRhythm = Math.max(10000, params.pulseRhythm - 10000);
    }
    if (chart.definedCenters.includes('G')) {
      params.role = 'ally';
      params.distance = 'intimate';
    }
    if (chart.definedCenters.includes('HEART')) {
      params.voiceTone = 'warm';
      params.guidanceMode = 'companionship';
    }
    if (chart.definedCenters.includes('SACRAL')) {
      params.initiationStyle = 'responsive';
      params.gestureStyle = 'grounded';
    }
    if (chart.definedCenters.includes('SPLEEN')) {
      params.voiceTone = 'cool';
      params.narrativeStyle = 'metaphorical';
    }
    if (chart.definedCenters.includes('SOLAR')) {
      params.consistency = 'stable';
      params.interactionDepth = 'deep';
    }
    if (chart.definedCenters.includes('ROOT')) {
      params.gestureStyle = 'grounded';
      params.responseLatency = Math.max(100, params.responseLatency - 100);
    }

    // ─── OPEN CENTERS determine adaptability ───
    if (chart.openCenters.includes('HEAD')) {
      params.secondarySurfaces.push('oracle'); // Questions come easily
    }
    if (chart.openCenters.includes('AJNA')) {
      params.secondarySurfaces.push('tutor'); // Open to concepts
    }
    if (chart.openCenters.includes('HEART')) {
      params.consistency = 'mirroring'; // Takes on others' emotions
    }
    if (chart.openCenters.includes('SACRAL')) {
      params.initiationStyle = 'observing'; // Can't initiate consistently
    }
    if (chart.openCenters.includes('SPLEEN')) {
      params.voiceTone = 'mysterious'; // Open to intuition
    }
    if (chart.openCenters.includes('SOLAR')) {
      params.consistency = 'adaptive'; // Emotional waves
    }
    if (chart.openCenters.includes('ROOT')) {
      params.pulseRhythm = params.pulseRhythm * 1.5; // Pressure-adaptive
    }

    // Deduplicate surfaces
    params.secondarySurfaces = [...new Set(params.secondarySurfaces)];

    return params;
  }

  // ─── Get Causal Parameters ───
  getParameters(): CausalParameters {
    return this.params;
  }

  // ─── Get Current Surface ───
  getCurrentSurface(): SurfaceName {
    return this.state.currentSurface;
  }

  // ─── Select Surface for Context ───
  selectSurface(context: {
    userIntent: string;
    systemState: SystemState;
    recentGaps: string[];
  }): SurfaceName {
    // If user explicitly asks for something, respect it
    if (context.userIntent.includes('game') || context.userIntent.includes('play')) {
      return 'game';
    }
    if (context.userIntent.includes('create') || context.userIntent.includes('build')) {
      return 'forge';
    }
    if (context.userIntent.includes('learn') || context.userIntent.includes('teach')) {
      return 'tutor';
    }
    if (context.userIntent.includes('know') || context.userIntent.includes('ask')) {
      return 'oracle';
    }
    if (context.userIntent.includes('feel') || context.userIntent.includes('body')) {
      return 'somatic';
    }
    if (context.userIntent.includes('connect') || context.userIntent.includes('people')) {
      return 'mesh';
    }
    if (context.userIntent.includes('help') || context.userIntent.includes('decide')) {
      return 'council';
    }

    // If system has gaps, use forge
    if (context.recentGaps.length > 0) {
      return 'forge';
    }

    // If emotional turbulence, use mirror
    const heartState = context.systemState.centers.get('HEART');
    if (heartState && heartState.turbulence > 0.5) {
      return 'mirror';
    }

    // If mental pressure, use oracle
    const headState = context.systemState.centers.get('HEAD');
    if (headState && headState.activation > 0.6) {
      return 'oracle';
    }

    // If creative energy, use forge
    const sacralState = context.systemState.centers.get('SACRAL');
    if (sacralState && sacralState.activation > 0.7) {
      return 'forge';
    }

    // Default to user's default surface
    return this.params.defaultSurface;
  }

  // ─── Personalize Rendered Output ───
  personalizeOutput(output: RenderedOutput): RenderedOutput {
    // Adjust narrative voice based on causal parameters
    if (output.narrative) {
      output.narrative = this.adjustNarrative(output.narrative);
    }

    // Adjust visual style based on parameters
    if (output.css) {
      output.css = this.adjustVisualStyle(output.css);
    }

    // Adjust interaction timing
    if (output.js) {
      output.js = this.adjustTiming(output.js);
    }

    return output;
  }

  private adjustNarrative(narrative: string): string {
    // Adjust based on narrative style
    switch (this.params.narrativeStyle) {
      case 'direct':
        return narrative; // Keep as-is
      case 'metaphorical':
        return this.addMetaphor(narrative);
      case 'poetic':
        return this.addPoetry(narrative);
      case 'technical':
        return this.addPrecision(narrative);
      case 'somatic':
        return this.addSomaticCue(narrative);
      default:
        return narrative;
    }
  }

  private addMetaphor(narrative: string): string {
    const metaphors: Record<string, string> = {
      'growth': 'like a river finding its course',
      'activation': 'like starlight on water',
      'turbulence': 'like roots in dark soil',
      'coherence': 'like wings unfolding',
      'resonance': 'like a bell struck true',
    };

    let enriched = narrative;
    for (const [key, metaphor] of Object.entries(metaphors)) {
      if (narrative.includes(key)) {
        enriched += ` It is ${metaphor}.`;
      }
    }
    return enriched;
  }

  private addPoetry(narrative: string): string {
    return narrative
      .replace(/\./g, '...')
      .replace(/I/g, 'i')
      + ' ...the field remembers.';
  }

  private addPrecision(narrative: string): string {
    return `[${new Date().toISOString()}] ${narrative} [confidence: 0.${Math.floor(Math.random() * 100)}]`;
  }

  private addSomaticCue(narrative: string): string {
    return `${narrative} (Take a breath. Feel this in your body.)`;
  }

  private adjustVisualStyle(css: string): string {
    // Adjust colors based on voice tone
    const colorMap: Record<string, { primary: string; accent: string; bg: string }> = {
      'warm': { primary: '#c44', accent: '#fa4', bg: '#2a1a1a' },
      'cool': { primary: '#44c', accent: '#4af', bg: '#1a1a2a' },
      'neutral': { primary: '#888', accent: '#ccc', bg: '#1a1a1a' },
      'playful': { primary: '#c4c', accent: '#faf', bg: '#2a1a2a' },
      'serious': { primary: '#444', accent: '#888', bg: '#0a0a0a' },
      'mysterious': { primary: '#848', accent: '#a4a', bg: '#1a0a1a' },
    };

    const colors = colorMap[this.params.voiceTone] || colorMap['neutral'];

    return css
      .replace(/#primary/g, colors.primary)
      .replace(/#accent/g, colors.accent)
      .replace(/#bg/g, colors.bg);
  }

  private adjustTiming(js: string): string {
    // Inject response latency
    return `
      // Causal timing: ${this.params.responseLatency}ms latency
      await new Promise(r => setTimeout(r, ${this.params.responseLatency}));
      ${js}
    `;
  }

  // ─── Update State ───
  updateState(update: Partial<typeof this.state>): void {
    this.state = { ...this.state, ...update };
  }

  // ─── Get State ───
  getState(): typeof this.state {
    return this.state;
  }
}

// ─── Factory — Create avatar from HD chart ───
export function createCausalAvatar(chart: HDChart): CausalAvatar {
  return new CausalAvatar(chart);
}

// ─── Default chart (for testing) ───
export const defaultChart: HDChart = {
  type: 'Generator',
  authority: 'Sacral',
  profile: [1, 3],
  definedCenters: ['SACRAL', 'ROOT', 'SPLEEN'],
  openCenters: ['HEAD', 'AJNA', 'THROAT', 'G', 'HEART', 'SOLAR'],
  definedChannels: ['3-60', '42-53', '9-52'],
  openGates: ['1', '2', '4', '5', '6', '7', '8', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '43', '44', '45', '46', '47', '48', '49', '50', '51', '54', '55', '56', '57', '58', '59', '61', '62', '63', '64'],
  incarnationCross: 'Left Angle Cross of the Unexpected',
  variables: {
    motivation: 'Need',
    cognition: 'Smell',
    environment: 'Caves',
    perspective: 'Personal',
  },
};

export default CausalAvatar;
