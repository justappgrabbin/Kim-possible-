// ============================================
// CAUSAL AVATAR INTEGRATOR
// Connects the HD-chart-based avatar to the living organism
// Every surface, every interaction, every pulse is personalized
// ============================================

import { CausalAvatar, HDChart, createCausalAvatar } from './index';
import { SynthiaOrganism } from '../synthia-organism';
import { SystemState, SurfaceName, RenderedOutput } from '../types';

export class AvatarIntegrator {
  private organism: SynthiaOrganism;
  private avatar: CausalAvatar | null = null;
  private userChart: HDChart | null = null;

  constructor(organism: SynthiaOrganism) {
    this.organism = organism;
  }

  // ─── LOAD USER CHART — From Roxy API or stored data ───
  async loadUserChart(chart: HDChart): Promise<void> {
    this.userChart = chart;
    this.avatar = createCausalAvatar(chart);

    // Narrate the recognition
    await this.organism.narrate('avatar_recognized', {
      type: chart.type,
      authority: chart.authority,
      profile: chart.profile.join('/'),
      definedCenters: chart.definedCenters.length,
    });

    console.log(`[AVATAR] Loaded: ${chart.type}, ${chart.authority}, ${chart.profile.join('/')}`);
    console.log(`[AVATAR] Default surface: ${this.avatar.getParameters().defaultSurface}`);
    console.log(`[AVATAR] Role: ${this.avatar.getParameters().role}`);
    console.log(`[AVATAR] Voice: ${this.avatar.getParameters().voiceTone}`);
  }

  // ─── GET PERSONALIZED SURFACE — For current context ───
  getPersonalizedSurface(userIntent: string = ''): SurfaceName {
    if (!this.avatar) return 'mirror';

    const systemState = this.organism.getState();
    const recentGaps: string[] = []; // Would be populated from actual gap history

    return this.avatar.selectSurface({
      userIntent,
      systemState,
      recentGaps,
    });
  }

  // ─── PERSONALIZE OUTPUT — Before it reaches the user ───
  personalizeOutput(output: RenderedOutput): RenderedOutput {
    if (!this.avatar) return output;
    return this.avatar.personalizeOutput(output);
  }

  // ─── GET AVATAR PARAMETERS ───
  getParameters() {
    return this.avatar?.getParameters();
  }

  // ─── GET AVATAR STATE ───
  getState() {
    return this.avatar?.getState();
  }

  // ─── UPDATE AVATAR STATE ───
  updateAvatarState(update: any): void {
    this.avatar?.updateState(update);
  }

  // ─── IS LOADED ───
  isLoaded(): boolean {
    return this.avatar !== null;
  }

  // ─── GET USER CHART ───
  getUserChart(): HDChart | null {
    return this.userChart;
  }
}

export default AvatarIntegrator;
