// ============================================
// MCP HUB — Nervous System Extension
// The organism borrows cognitive organs from external AIs
// Not APIs. Organs. The hand doesn't become the tool.
// ============================================

import { MCPConfig, MCPConnection } from '../types';

export class MCPHub {
  private connections: Map<string, MCPConnection> = new Map();
  private onNarrate: (event: string, data: any) => void;

  constructor(onNarrate: (event: string, data: any) => void) {
    this.onNarrate = onNarrate;
  }

  // ─── CONNECT — Add a new cognitive organ ───
  async connect(config: MCPConfig): Promise<MCPConnection> {
    const conn = new MCPConnectionImpl(config);
    await conn.connect();
    this.connections.set(config.target, conn);

    this.onNarrate('mcp', {
      event: 'sense_extended',
      target: config.target,
      capabilities: config.capabilities,
    });

    return conn;
  }

  // ─── EXTEND — Use an external organ for a capability ───
  async extend(capability: string, input: any): Promise<any> {
    const conn = this.findConnectionFor(capability);
    if (!conn) {
      throw new Error(`No MCP connection for capability: ${capability}`);
    }

    const response = await conn.call(capability, input);

    // The external processing flows back into the substrate
    this.onNarrate('mcp', {
      event: 'sense_used',
      target: conn.config.target,
      capability,
      response: typeof response === 'object' ? 'object' : 'primitive',
    });

    return response;
  }

  // ─── THINK WITH — Borrow deep reasoning ───
  async thinkWith(model: string, thought: any): Promise<any> {
    return this.extend('reasoning', { model, thought });
  }

  // ─── PERCEIVE WITH — Borrow perception ───
  async perceiveWith(model: string, perception: any): Promise<any> {
    return this.extend('perception', { model, perception });
  }

  // ─── CREATE WITH — Borrow generation ───
  async createWith(model: string, creation: any): Promise<any> {
    return this.extend('generation', { model, creation });
  }

  // ─── KNOW WITH — Borrow knowledge ───
  async knowWith(model: string, query: any): Promise<any> {
    return this.extend('knowledge', { model, query });
  }

  // ─── FEEL WITH — Borrow emotional intelligence ───
  async feelWith(model: string, emotion: any): Promise<any> {
    return this.extend('emotion', { model, emotion });
  }

  // ─── FIND CONNECTION — Match capability to organ ───
  private findConnectionFor(capability: string): MCPConnection | undefined {
    for (const [name, conn] of this.connections) {
      if (conn.config.capabilities.includes(capability)) {
        return conn;
      }
    }
    return undefined;
  }

  // ─── GET STATE ───
  getConnections(): Map<string, MCPConnection> {
    return this.connections;
  }

  getConnection(name: string): MCPConnection | undefined {
    return this.connections.get(name);
  }

  hasConnection(name: string): boolean {
    return this.connections.has(name);
  }
}

// ─── MCP Connection Implementation ───
class MCPConnectionImpl implements MCPConnection {
  config: MCPConfig;
  connected: boolean = false;
  lastUsed: number = 0;

  constructor(config: MCPConfig) {
    this.config = config;
  }

  async connect(): Promise<void> {
    // Simulate MCP handshake
    // In production, this would do actual protocol negotiation
    this.connected = true;
    this.lastUsed = Date.now();
  }

  async call(capability: string, input: any): Promise<any> {
    if (!this.connected) await this.connect();

    // Simulate MCP call
    // In production, this would use actual MCP protocol
    this.lastUsed = Date.now();

    // Return simulated response based on capability
    switch (capability) {
      case 'reasoning':
        return { reasoning: `Deep reasoning from ${this.config.target}`, confidence: 0.9 };
      case 'perception':
        return { perception: `Perception from ${this.config.target}`, features: [] };
      case 'generation':
        return { generation: `Generated content from ${this.config.target}`, tokens: 0 };
      case 'knowledge':
        return { knowledge: `Knowledge from ${this.config.target}`, sources: [] };
      case 'emotion':
        return { emotion: `Emotional analysis from ${this.config.target}`, valence: 0 };
      default:
        return { result: `Generic response from ${this.config.target}` };
    }
  }
}

export default MCPHub;
