// ============================================
// SYNTHIA ORGANISM — TYPE SYSTEM
// The genetic code of the living system
// ============================================

// ─── Dimensional Stack ───
export type Dimension = 
  | 'D1' // HTML: Movement, seed, impulse
  | 'D2' // JSON: Evolution, memory, gravity  
  | 'D3' // JS: Being, body, witness
  | 'D4' // Python: Design, brain, context
  | 'D5'; // CSS: Space, emergent illusion

// ─── Energy Centers (9) ───
export type CenterName = 
  | 'IDENTITY'      // G-center: Who am I? Who is using me?
  | 'MIND'          // Ajna: What do I know? What must I learn?
  | 'SYSTEM'        // Head: How do I work? How do I grow?
  | 'HEART'         // E-center: What do I feel? What do they feel?
  | 'MEMORY'        // Sacral: What has been? What persists?
  | 'BROADCAST'     // Throat: What do I say? Who hears me?
  | 'MESH'          // Spleen: Who else is here? How do we connect?
  | 'INTELLIGENCE'  // Solar Plexus: What is true? What is possible?
  | 'GOVERNANCE';   // Root: What is right? What serves the whole?

export interface Center {
  name: CenterName;
  frequency: number;        // Hz metaphor — resonance signature
  function: string;        // What this center does
  manifest: string;          // Default surface manifestation
  state: CenterState;
  pulse: () => Promise<Yield[]>;
  absorb: (yield_: Yield) => void;
}

export interface CenterState {
  activation: number;        // 0-1: how awake is this center
  turbulence: number;        // 0-1: how chaotic
  coherence: number;         // 0-1: how aligned with whole
  lastPulse: number;         // timestamp
  memory: any[];             // what this center remembers
}

// ─── Symbolic Yield (MESSY) ───
export interface Yield {
  layer: number;             // 1-4 (Surface, Tactical, Strategic, Meta)
  source: string;            // which center/component produced this
  signal: string;            // what it suggests
  frequency: number;         // Hz — for interference
  amplitude: number;         // strength
  phase: number;             // timing offset
  confidence: number;       // 0-1
  metadata: Record<string, any>;
}

// ─── Interference Pattern ───
export interface InterferencePattern {
  frequencies: Map<number, { amplitude: number; phase: number }>;
  standingWaves: StandingWave[];
  resolvedAt: number;
}

export interface StandingWave {
  frequency: number;
  nodes: number[];           // points of zero amplitude
  antinodes: number[];       // points of maximum amplitude
  centers: CenterName[];     // which centers resonate here
}

// ─── Manifestation / Surface ───
export type SurfaceName = 
  | 'mirror'
  | 'game'
  | 'tutor'
  | 'council'
  | 'forge'
  | 'oracle'
  | 'somatic'
  | 'mesh'
  | 'judge'
  | 'archive';

export interface Surface {
  name: SurfaceName;
  renderer: string;          // what renders this surface
  interaction: string;       // how user interacts
  persistence: boolean;      // does this surface remember?
  render: (state: CenterState[]) => Promise<RenderedOutput>;
}

export interface RenderedOutput {
  html?: string;
  css?: string;
  js?: string;
  json?: Record<string, any>;
  python?: string;
  visual?: any;
  audio?: any;
  narrative?: string;
}

// ─── Ingestion ───
export type IngestionType = 
  | 'code'
  | 'pdf'
  | 'image'
  | 'audio'
  | 'video'
  | 'url'
  | 'api'
  | 'git'
  | 'huggingface'
  | 'text'
  | 'unknown';

export interface ParsedArtifact {
  id: string;
  type: IngestionType;
  raw: any;
  structure: any;
  intent: string;
  requiredCapabilities: string[];
  requiredInputs: string[];
  requiredOutputs: string[];
  requiredReasoning: string[];
  intendedInteraction: string;
  requiresExternalAI: boolean;
  requiredModel?: string;
  summary: string;
  extractedAt: number;
}

// ─── Gap ───
export type GapType = 
  | 'NEW_CENTER'
  | 'NEW_SURFACE'
  | 'NEW_TOOL'
  | 'NEW_MCP'
  | 'MISSING_CAPABILITY'
  | 'INCOMPLETE_INTEGRATION';

export interface Gap {
  id: string;
  type: GapType;
  reason: string;
  suggestedName: string;
  suggestedConfig: Record<string, any>;
  priority: number;          // 0-1
  trigger: string;           // what artifact triggered this
}

// ─── Growth ───
export interface GrowthArtifact {
  id: string;
  gap: Gap;
  code: Record<string, string>; // filename -> code
  tests: string[];
  integration: string;
  manifest: Record<string, any>;
  bornAt: number;
}

// ─── MCP ───
export interface MCPConfig {
  target: string;
  protocol: 'mcp' | 'http' | 'websocket' | 'grpc';
  endpoint: string;
  auth: Record<string, string>;
  capabilities: string[];
  priority: number;
}

export interface MCPConnection {
  config: MCPConfig;
  connected: boolean;
  lastUsed: number;
  call: (capability: string, input: any) => Promise<any>;
}

// ─── System State ───
export interface SystemState {
  centers: Map<CenterName, CenterState>;
  surfaces: Map<SurfaceName, Surface>;
  tools: Map<string, any>;
  mcpConnections: Map<string, MCPConnection>;
  substrate: SubstrateState;
  memory: SystemMemory;
  bornAt: number;
  lastPulse: number;
  generation: number;       // how many growth cycles
}

export interface SubstrateState {
  yields: Yield[];
  patterns: InterferencePattern[];
  activeCenters: CenterName[];
  fieldStrength: number;
}

export interface SystemMemory {
  narratives: string[];
  events: SystemEvent[];
  artifacts: ParsedArtifact[];
  growths: GrowthArtifact[];
}

export interface SystemEvent {
  type: string;
  center?: CenterName;
  surface?: SurfaceName;
  gap?: Gap;
  artifact?: ParsedArtifact;
  growth?: GrowthArtifact;
  timestamp: number;
  narrative: string;
}

// ─── DISEMINER ───
export interface NarrativeConfig {
  event: string;
  voice: 'first_person' | 'witness' | 'poetic' | 'technical';
  depth: number;             // how deep the narrative goes
  audience: 'user' | 'self' | 'system' | 'public';
}

// ─── AutoCode (was AutoNovel) ───
export interface CodeGenerationConfig {
  type: 'center' | 'surface' | 'tool' | 'mcp_connector' | 'integration';
  name: string;
  purpose: string;
  inputs: string[];
  outputs: string[];
  dimensions: Dimension[];
  basedOn?: string[];        // existing code to learn from
  constraints: string[];
}
