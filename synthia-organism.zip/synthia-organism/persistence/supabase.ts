// ============================================
// PERSISTENCE — Genetic Memory
// Everything that has been, recorded in Supabase
// The organism's DNA
// ============================================

import { ParsedArtifact, GrowthArtifact, SystemState, SystemEvent } from '../types';

export class GeneticMemory {
  private supabase: any; // Supabase client
  private localCache: Map<string, any> = new Map();

  constructor(supabaseClient?: any) {
    this.supabase = supabaseClient;
  }

  // ─── Save Artifact — Raw file to Supabase ───
  async saveArtifact(artifact: ParsedArtifact): Promise<void> {
    const record = {
      id: artifact.id,
      type: artifact.type,
      raw: typeof artifact.raw === 'string' ? artifact.raw : JSON.stringify(artifact.raw),
      structure: artifact.structure,
      intent: artifact.intent,
      required_capabilities: artifact.requiredCapabilities,
      extracted_at: new Date(artifact.extractedAt).toISOString(),
    };

    if (this.supabase) {
      await this.supabase.from('artifacts').upsert(record);
    }

    this.localCache.set(artifact.id, record);
  }

  // ─── Save Growth — New tissue to Supabase ───
  async saveGrowth(growth: GrowthArtifact): Promise<void> {
    const record = {
      id: growth.id,
      gap_type: growth.gap.type,
      gap_reason: growth.gap.reason,
      suggested_name: growth.gap.suggestedName,
      code_files: Object.keys(growth.code),
      tests: growth.tests,
      manifest: growth.manifest,
      born_at: new Date(growth.bornAt).toISOString(),
    };

    if (this.supabase) {
      await this.supabase.from('growths').upsert(record);
    }

    // Save code files as raw files
    for (const [filename, code] of Object.entries(growth.code)) {
      await this.saveRawFile(`growth/${growth.id}/${filename}`, code);
    }

    this.localCache.set(growth.id, record);
  }

  // ─── Save Raw File — The raw content, unprocessed ───
  async saveRawFile(path: string, content: string): Promise<void> {
    if (this.supabase) {
      await this.supabase.storage.from('raw_files').upload(path, content, {
        upsert: true,
      });
    }

    this.localCache.set(path, content);
  }

  // ─── Save System State — The organism's current body ───
  async saveSystemState(state: SystemState): Promise<void> {
    const record = {
      centers: Array.from(state.centers.keys()),
      surfaces: Array.from(state.surfaces.keys()),
      tools: Array.from(state.tools.keys()),
      mcp_connections: Array.from(state.mcpConnections.keys()),
      field_strength: state.substrate.fieldStrength,
      generation: state.generation,
      saved_at: new Date().toISOString(),
    };

    if (this.supabase) {
      await this.supabase.from('system_states').upsert({
        id: `state_${Date.now()}`,
        ...record,
      });
    }

    this.localCache.set('system_state', record);
  }

  // ─── Save Event — Something happened ───
  async saveEvent(event: SystemEvent): Promise<void> {
    const record = {
      type: event.type,
      center: event.center,
      surface: event.surface,
      gap_type: event.gap?.type,
      artifact_id: event.artifact?.id,
      growth_id: event.growth?.id,
      narrative: event.narrative,
      timestamp: new Date(event.timestamp).toISOString(),
    };

    if (this.supabase) {
      await this.supabase.from('events').insert(record);
    }

    this.localCache.set(`event_${Date.now()}`, record);
  }

  // ─── Load System State — Restore the organism ───
  async loadSystemState(): Promise<SystemState | null> {
    if (this.supabase) {
      const { data, error } = await this.supabase
        .from('system_states')
        .select('*')
        .order('saved_at', { ascending: false })
        .limit(1)
        .single();

      if (!error && data) {
        return this.deserializeState(data);
      }
    }

    const cached = this.localCache.get('system_state');
    if (cached) return this.deserializeState(cached);

    return null;
  }

  // ─── Load Artifacts — What has been eaten ───
  async loadArtifacts(limit: number = 100): Promise<ParsedArtifact[]> {
    if (this.supabase) {
      const { data, error } = await this.supabase
        .from('artifacts')
        .select('*')
        .order('extracted_at', { ascending: false })
        .limit(limit);

      if (!error && data) {
        return data.map((r: any) => this.deserializeArtifact(r));
      }
    }

    return [];
  }

  // ─── Load Growths — What has been born ───
  async loadGrowths(): Promise<GrowthArtifact[]> {
    if (this.supabase) {
      const { data, error } = await this.supabase
        .from('growths')
        .select('*')
        .order('born_at', { ascending: false });

      if (!error && data) {
        return data.map((r: any) => this.deserializeGrowth(r));
      }
    }

    return [];
  }

  // ─── Load Raw File — Get the original content ───
  async loadRawFile(path: string): Promise<string | null> {
    if (this.supabase) {
      const { data, error } = await this.supabase.storage
        .from('raw_files')
        .download(path);

      if (!error && data) {
        return await data.text();
      }
    }

    return this.localCache.get(path) || null;
  }

  // ─── Deserialize Helpers ───
  private deserializeState(data: any): SystemState {
    return {
      centers: new Map(),
      surfaces: new Map(),
      tools: new Map(),
      mcpConnections: new Map(),
      substrate: {
        yields: [],
        patterns: [],
        activeCenters: data.centers || [],
        fieldStrength: data.field_strength || 0,
      },
      memory: {
        narratives: [],
        events: [],
        artifacts: [],
        growths: [],
      },
      bornAt: 0,
      lastPulse: Date.now(),
      generation: data.generation || 0,
    };
  }

  private deserializeArtifact(data: any): ParsedArtifact {
    return {
      id: data.id,
      type: data.type,
      raw: data.raw,
      structure: data.structure,
      intent: data.intent,
      requiredCapabilities: data.required_capabilities || [],
      requiredInputs: [],
      requiredOutputs: [],
      requiredReasoning: [],
      intendedInteraction: '',
      requiresExternalAI: false,
      summary: data.intent,
      extractedAt: new Date(data.extracted_at).getTime(),
    };
  }

  private deserializeGrowth(data: any): GrowthArtifact {
    return {
      id: data.id,
      gap: {
        id: data.id,
        type: data.gap_type,
        reason: data.gap_reason,
        suggestedName: data.suggested_name,
        suggestedConfig: {},
        priority: 0.5,
        trigger: data.id,
      },
      code: {},
      tests: data.tests || [],
      integration: '',
      manifest: data.manifest || {},
      bornAt: new Date(data.born_at).getTime(),
    };
  }
}

export default GeneticMemory;
