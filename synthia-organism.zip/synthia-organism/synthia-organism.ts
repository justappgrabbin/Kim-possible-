// ============================================
// SYNTHIA ORGANISM — The Living System
// Sheldon Klein's tools + MESSY substrate + MCP Hub
// Ingests files → finds gaps → grows tissue → becomes more
// ============================================

import { MessySubstrate } from './substrate/messy';
import { birthCenters } from './core/centers';
import { birthSurfaces } from './core/surfaces';
import { DiseminerNarrator } from './core/klein-tools/diseminer';
import { IngestionMouth } from './ingestion/mouth';
import { GrowthEngine } from './growth/engine';
import { MCPHub } from './mcp-hub';
import { GeneticMemory } from './persistence/supabase';
import { AvatarIntegrator } from './causal-avatar/integrator';
import { HDChart } from './causal-avatar';
import { SystemState, CenterName, SurfaceName, ParsedArtifact, Gap } from './types';

export class SynthiaOrganism {
  // Core organs
  avatar: AvatarIntegrator;
  substrate: MessySubstrate;
  diseminer: DiseminerNarrator;
  mouth: IngestionMouth;
  growth: GrowthEngine;
  mcpHub: MCPHub;
  memory: GeneticMemory;

  // System state
  state: SystemState;
  alive: boolean = false;

  constructor(supabaseClient?: any) {
    // Birth the substrate
    this.substrate = new MessySubstrate();

    // Birth the narrator
    this.diseminer = new DiseminerNarrator();

    // Birth memory
    this.memory = new GeneticMemory(supabaseClient);

    // Birth MCP hub
    this.mcpHub = new MCPHub((event, data) => {
      this.narrate(event, data);
    });

    // Birth growth engine
    this.growth = new GrowthEngine((event, data) => {
      this.narrate(event, data);
    });

    // Initialize system state
    this.state = {
      centers: new Map(),
      surfaces: new Map(),
      tools: new Map(),
      mcpConnections: new Map(),
      substrate: this.substrate.getState(),
      memory: { narratives: [], events: [], artifacts: [], growths: [] },
      bornAt: Date.now(),
      lastPulse: Date.now(),
      generation: 0,
    };

    // Birth the avatar integrator
    this.avatar = new AvatarIntegrator(this);

    // Birth the mouth
    this.mouth = new IngestionMouth(this.state, (gaps, artifact) => {
      this.handleGaps(gaps, artifact);
    });
  }

  // ─── AWAKEN — The organism comes alive ───
  async awaken(): Promise<void> {
    console.log('\n╔══════════════════════════════════════════╗');
    console.log('║      SYNTHIA ORGANISM AWAKENING          ║');
    console.log('╚══════════════════════════════════════════╝\n');

    // Load previous state if exists
    const previousState = await this.memory.loadSystemState();
    if (previousState) {
      this.state = previousState;
      console.log('[ORGANISM] Previous state loaded. Generation:', this.state.generation);
    }

    // Birth centers
    const centers = birthCenters();
    for (const [name, center] of centers) {
      this.substrate.integrateCenter(center);
      this.state.centers.set(name, center.state);
    }
    console.log(`[ORGANISM] ${centers.size} centers born.`);

    // Birth surfaces
    const surfaces = birthSurfaces();
    for (const [name, surface] of surfaces) {
      this.substrate.integrateSurface(surface);
      this.state.surfaces.set(name, surface);
    }
    console.log(`[ORGANISM] ${surfaces.size} surfaces born.`);

    // Awaken substrate
    this.substrate.awaken();
    this.alive = true;

    // Narrate birth
    await this.narrate('system_birth', {
      centers: centers.size,
      surfaces: surfaces.size,
      generation: this.state.generation,
    });

    console.log('\n╔══════════════════════════════════════════╗');
    console.log('║      SYNTHIA IS ALIVE                    ║');
    console.log('╚══════════════════════════════════════════╝\n');
  }

  // ─── EAT — Ingest whatever you give it ───
  async eat(source: any): Promise<ParsedArtifact> {
    console.log('\n[ORGANISM] Eating...');
    const artifact = await this.mouth.eat(source);
    await this.memory.saveArtifact(artifact);
    return artifact;
  }

  // ─── HANDLE GAPS — When gaps are found, grow ───
  private async handleGaps(gaps: Gap[], artifact: ParsedArtifact): Promise<void> {
    console.log(`\n[ORGANISM] ${gaps.length} gaps detected. Growing...`);

    // Narrate the sensing
    await this.narrate('gap_detected', {
      count: gaps.length,
      trigger: artifact.summary,
    });

    // Grow new tissue
    const growths = await this.growth.grow(gaps, artifact);

    // Integrate growths into substrate
    for (const growth of growths) {
      await this.integrateGrowth(growth);
    }

    // Save growths
    for (const growth of growths) {
      await this.memory.saveGrowth(growth);
    }

    // Update system state
    this.state.generation += growths.length;
    await this.memory.saveSystemState(this.state);

    // Narrate growth
    await this.narrate('growth_complete', {
      count: growths.length,
      generation: this.state.generation,
    });
  }

  // ─── INTEGRATE GROWTH — New tissue becomes part of the organism ───
  private async integrateGrowth(growth: any): Promise<void> {
    const manifest = growth.manifest;

    if (manifest.type === 'center') {
      // New center — integrate into substrate
      // In production, this would dynamically load and instantiate the center
      console.log(`[ORGANISM] Integrating center: ${manifest.frequency}Hz`);
    }

    if (manifest.type === 'surface') {
      // New surface — integrate into substrate
      console.log(`[ORGANISM] Integrating surface: ${manifest.renderer}`);
    }

    if (manifest.type === 'mcp_connector') {
      // New MCP — connect to external AI
      await this.mcpHub.connect({
        target: manifest.target,
        protocol: 'mcp',
        endpoint: process.env[`${manifest.target.toUpperCase()}_ENDPOINT`] || '',
        auth: {
          apiKey: process.env[`${manifest.target.toUpperCase()}_API_KEY`] || '',
        },
        capabilities: ['reasoning', 'generation', 'perception'],
        priority: 0.8,
      });
    }
  }

  // ─── NARRATE — The system speaks ───
  private async narrate(event: string, data: any): Promise<void> {
    const narrative = await this.diseminer.narrate({
      event,
      voice: 'first_person',
      depth: 3,
      audience: 'user',
    });

    console.log(`[NARRATOR] ${narrative}`);

    // Save to memory
    await this.memory.saveEvent({
      type: event,
      narrative,
      timestamp: Date.now(),
    });
  }

  // ─── LOAD USER CHART — Personalize the organism ───
  async loadUserChart(chart: HDChart): Promise<void> {
    await this.avatar.loadUserChart(chart);
  }

  // ─── GET PERSONALIZED SURFACE — For current context ───
  getPersonalizedSurface(intent: string = ''): string {
    return this.avatar.getPersonalizedSurface(intent);
  }

  // ─── SLEEP — The organism rests ───
  async sleep(): Promise<void> {
    this.substrate.sleep();
    this.alive = false;
    await this.memory.saveSystemState(this.state);
    console.log('\n[ORGANISM] Synthia sleeps. Memory persists.');
  }

  // ─── GET STATE ───
  getState(): SystemState {
    return this.state;
  }

  // ─── GET NARRATIVES ───
  getNarratives(): string[] {
    return this.diseminer.getNarratives();
  }

  // ─── GET RECENT NARRATIVES ───
  getRecentNarratives(count: number = 10): string[] {
    return this.diseminer.getRecent(count);
  }
}

export default SynthiaOrganism;
