// ============================================
// GROWTH ENGINE — AUTOCODE
// When the organism senses a gap, it grows new tissue
// Not "adds a feature." Grows. Like a living thing.
// ============================================

import {
  Gap,
  GapType,
  GrowthArtifact,
  Center,
  CenterName,
  Surface,
  SurfaceName,
  ParsedArtifact,
  CodeGenerationConfig,
  Dimension,
} from '../types';

export class GrowthEngine {
  private generation: number = 0;
  private onNarrate: (event: string, data: any) => void;

  constructor(onNarrate: (event: string, data: any) => void) {
    this.onNarrate = onNarrate;
  }

  // ─── GROW — The main entry point ───
  async grow(gaps: Gap[], trigger: ParsedArtifact): Promise<GrowthArtifact[]> {
    const growths: GrowthArtifact[] = [];

    for (const gap of gaps) {
      console.log(`[GROWTH] Growing for gap: ${gap.type} — ${gap.reason}`);

      let growth: GrowthArtifact;

      switch (gap.type) {
        case 'NEW_CENTER':
          growth = await this.growCenter(gap, trigger);
          break;
        case 'NEW_SURFACE':
          growth = await this.growSurface(gap, trigger);
          break;
        case 'NEW_TOOL':
          growth = await this.growTool(gap, trigger);
          break;
        case 'NEW_MCP':
          growth = await this.growMCP(gap, trigger);
          break;
        case 'MISSING_CAPABILITY':
          growth = await this.growCapability(gap, trigger);
          break;
        case 'INCOMPLETE_INTEGRATION':
          growth = await this.growIntegration(gap, trigger);
          break;
        default:
          growth = await this.growGeneric(gap, trigger);
      }

      growths.push(growth);
      this.generation++;

      this.onNarrate('growth', {
        event: 'tissue_born',
        gap: gap.type,
        name: gap.suggestedName,
        generation: this.generation,
        trigger: trigger.summary,
      });
    }

    return growths;
  }

  // ─── Grow Center — New organ in the organism ───
  private async growCenter(gap: Gap, trigger: ParsedArtifact): Promise<GrowthArtifact> {
    const config: CodeGenerationConfig = {
      type: 'center',
      name: gap.suggestedName,
      purpose: gap.reason,
      inputs: trigger.requiredInputs,
      outputs: trigger.requiredOutputs,
      dimensions: this.inferDimensions(trigger),
      constraints: ['must_pulse', 'must_absorb', 'must_resonate'],
    };

    const code = this.generateCenterCode(config);

    return {
      id: `growth_${Date.now()}_center`,
      gap,
      code,
      tests: this.generateTests(config),
      integration: this.generateIntegration(config),
      manifest: {
        type: 'center',
        frequency: this.inferFrequency(config.name),
        manifest: this.inferManifest(config.name),
        bornAt: Date.now(),
      },
      bornAt: Date.now(),
    };
  }

  private generateCenterCode(config: CodeGenerationConfig): Record<string, string> {
    const className = this.toClassName(config.name);
    const frequency = this.inferFrequency(config.name);

    return {
      [`${config.name}.ts`]: `import { Center, CenterName, CenterState, Yield } from '../../types';
import { LivingCenter } from './index';

// ─── ${className} — Born from gap: ${config.purpose} ───
export class ${className} extends LivingCenter {
  constructor() {
    super({
      name: '${config.name.toUpperCase()}' as CenterName,
      frequency: ${frequency},
      function: '${config.purpose}',
      manifest: '${this.inferManifest(config.name)}',
    });
  }

  async pulse(): Promise<Yield[]> {
    const yields: Yield[] = [];

    // ${config.purpose}
    ${config.inputs.map(input => `
    // Handle ${input}
    yields.push(this.createYield(
      '${input}_detected',
      0.5,
      0.7,
      { input: '${input}', source: 'user' }
    ));`).join('')}

    ${config.outputs.map(output => `
    // Produce ${output}
    yields.push(this.createYield(
      '${output}_ready',
      0.6,
      0.8,
      { output: '${output}', ready: true }
    ));`).join('')}

    return yields;
  }
}
`,
    };
  }

  // ─── Grow Surface — New membrane ───
  private async growSurface(gap: Gap, trigger: ParsedArtifact): Promise<GrowthArtifact> {
    const config: CodeGenerationConfig = {
      type: 'surface',
      name: gap.suggestedName,
      purpose: gap.reason,
      inputs: trigger.requiredInputs,
      outputs: trigger.requiredOutputs,
      dimensions: ['D1', 'D3', 'D5'], // Surfaces are HTML/JS/CSS
      constraints: ['must_render', 'must_interact', 'must_persist'],
    };

    const code = this.generateSurfaceCode(config);

    return {
      id: `growth_${Date.now()}_surface`,
      gap,
      code,
      tests: this.generateTests(config),
      integration: this.generateIntegration(config),
      manifest: {
        type: 'surface',
        renderer: this.inferRenderer(config.name),
        interaction: gap.suggestedConfig.interaction || 'touch',
        persistence: true,
        bornAt: Date.now(),
      },
      bornAt: Date.now(),
    };
  }

  private generateSurfaceCode(config: CodeGenerationConfig): Record<string, string> {
    const className = this.toClassName(config.name);

    return {
      [`${config.name}.ts`]: `import { Surface, SurfaceName, CenterState, RenderedOutput } from '../../types';
import { LivingSurface } from './index';

// ─── ${className} — Born from gap: ${config.purpose} ───
export class ${className} extends LivingSurface {
  constructor() {
    super({
      name: '${config.name}' as SurfaceName,
      renderer: '${this.inferRenderer(config.name)}',
      interaction: '${config.inputs[0] || 'touch'}',
      persistence: true,
    });
  }

  async render(states: CenterState[]): Promise<RenderedOutput> {
    // ${config.purpose}
    const relevantState = states[0]; // First matching state

    return this.composeOutput({
      html: \`<div class="${config.name}-surface">
        <div class="content">
          ${config.purpose}
        </div>
      </div>\`,
      css: \`.${config.name}-surface { 
        background: #1a1a1a; 
        color: #eee; 
        min-height: 100vh; 
        padding: 2rem; 
      }\`,
      js: \`// ${className} initialization
        console.log('${className} surface active');\`,
      narrative: \`I am ${config.name}. ${config.purpose}.\`,
    });
  }
}
`,
    };
  }

  // ─── Grow Tool — Extend Klein toolkit ───
  private async growTool(gap: Gap, trigger: ParsedArtifact): Promise<GrowthArtifact> {
    const config: CodeGenerationConfig = {
      type: 'tool',
      name: gap.suggestedName,
      purpose: gap.reason,
      inputs: trigger.requiredInputs,
      outputs: trigger.requiredOutputs,
      dimensions: ['D4'], // Tools are Python/Design
      constraints: ['must_reason', 'must_learn', 'must_integrate'],
    };

    const code = this.generateToolCode(config);

    return {
      id: `growth_${Date.now()}_tool`,
      gap,
      code,
      tests: this.generateTests(config),
      integration: this.generateIntegration(config),
      manifest: {
        type: 'klein_tool',
        reasoning: gap.suggestedConfig.reasoning || 'general',
        bornAt: Date.now(),
      },
      bornAt: Date.now(),
    };
  }

  private generateToolCode(config: CodeGenerationConfig): Record<string, string> {
    return {
      [`${config.name}.py`]: `# ─── ${config.name} — Klein Tool
# Born from gap: ${config.purpose}
# Dimension: D4 (Design/Brain)

class ${this.toClassName(config.name)}:
    """${config.purpose}"""

    def __init__(self):
        self.purpose = "${config.purpose}"
        self.inputs = ${JSON.stringify(config.inputs)}
        self.outputs = ${JSON.stringify(config.outputs)}

    def reason(self, context):
        """${config.purpose}"""
        # TODO: Implement reasoning logic
        return {"result": "reasoned", "context": context}

    def learn(self, feedback):
        """Learn from feedback"""
        # TODO: Implement learning
        pass
`,
    };
  }

  // ─── Grow MCP — New nervous system extension ───
  private async growMCP(gap: Gap, trigger: ParsedArtifact): Promise<GrowthArtifact> {
    const config: CodeGenerationConfig = {
      type: 'mcp_connector',
      name: gap.suggestedName,
      purpose: gap.reason,
      inputs: ['api-key', 'endpoint'],
      outputs: ['response', 'error'],
      dimensions: ['D2'], // MCPs are JSON/Evolution
      constraints: ['must_connect', 'must_auth', 'must_call'],
    };

    const code = this.generateMCPCode(config, gap.suggestedConfig.model || 'claude');

    return {
      id: `growth_${Date.now()}_mcp`,
      gap,
      code,
      tests: this.generateTests(config),
      integration: this.generateIntegration(config),
      manifest: {
        type: 'mcp_connector',
        target: gap.suggestedConfig.model || 'claude',
        protocol: 'mcp',
        bornAt: Date.now(),
      },
      bornAt: Date.now(),
    };
  }

  private generateMCPCode(config: CodeGenerationConfig, model: string): Record<string, string> {
    return {
      [`${config.name}.ts`]: `import { MCPConfig, MCPConnection } from '../../types';

// ─── ${config.name} — MCP Connector for ${model}
// Born from gap: ${config.purpose}

export const ${config.name}Config: MCPConfig = {
  target: '${model}',
  protocol: 'mcp',
  endpoint: process.env.${model.toUpperCase()}_ENDPOINT || '',
  auth: {
    apiKey: process.env.${model.toUpperCase()}_API_KEY || '',
  },
  capabilities: ['reasoning', 'generation', 'analysis'],
  priority: 0.8,
};

export class ${this.toClassName(config.name)} implements MCPConnection {
  config = ${config.name}Config;
  connected = false;
  lastUsed = 0;

  async connect(): Promise<void> {
    // Handshake with ${model} MCP server
    this.connected = true;
    this.lastUsed = Date.now();
  }

  async call(capability: string, input: any): Promise<any> {
    if (!this.connected) await this.connect();

    // Call ${model} via MCP protocol
    const response = await fetch(this.config.endpoint, {
      method: 'POST',
      headers: { 'Authorization': \`Bearer \${this.config.auth.apiKey}\` },
      body: JSON.stringify({ capability, input }),
    });

    this.lastUsed = Date.now();
    return response.json();
  }
}
`,
    };
  }

  // ─── Grow Capability — Generic capability growth ───
  private async growCapability(gap: Gap, trigger: ParsedArtifact): Promise<GrowthArtifact> {
    return this.growGeneric(gap, trigger);
  }

  // ─── Grow Integration — Connect existing pieces ───
  private async growIntegration(gap: Gap, trigger: ParsedArtifact): Promise<GrowthArtifact> {
    return this.growGeneric(gap, trigger);
  }

  // ─── Generic Growth — Fallback ───
  private async growGeneric(gap: Gap, trigger: ParsedArtifact): Promise<GrowthArtifact> {
    return {
      id: `growth_${Date.now()}_generic`,
      gap,
      code: {
        [`${gap.suggestedName}.ts`]: `// Generic growth for ${gap.type}
// ${gap.reason}
`,
      },
      tests: [],
      integration: '',
      manifest: { type: 'generic', bornAt: Date.now() },
      bornAt: Date.now(),
    };
  }

  // ─── Helpers ───
  private toClassName(name: string): string {
    return name
      .split('_')
      .map(part => part.charAt(0).toUpperCase() + part.slice(1))
      .join('');
  }

  private inferDimensions(trigger: ParsedArtifact): Dimension[] {
    const dims: Dimension[] = [];
    if (trigger.type === 'code') dims.push('D4', 'D3');
    if (trigger.type === 'image' || trigger.type === 'video') dims.push('D5', 'D1');
    if (trigger.type === 'audio') dims.push('D2', 'D5');
    if (trigger.type === 'text') dims.push('D4', 'D2');
    if (trigger.type === 'api') dims.push('D2', 'D4');
    return dims.length > 0 ? dims : ['D3'];
  }

  private inferFrequency(name: string): number {
    // Map name to frequency based on intent
    if (name.includes('visual') || name.includes('image')) return 528;
    if (name.includes('audio') || name.includes('sound')) return 432;
    if (name.includes('data') || name.includes('storage')) return 396;
    if (name.includes('network') || name.includes('connect')) return 639;
    if (name.includes('security') || name.includes('auth')) return 741;
    return 360; // Default
  }

  private inferManifest(name: string): string {
    if (name.includes('visual') || name.includes('image')) return 'mirror';
    if (name.includes('audio') || name.includes('sound')) return 'somatic';
    if (name.includes('data') || name.includes('storage')) return 'archive';
    if (name.includes('network') || name.includes('connect')) return 'mesh';
    if (name.includes('security') || name.includes('auth')) return 'judge';
    if (name.includes('game') || name.includes('play')) return 'game';
    if (name.includes('create') || name.includes('build')) return 'forge';
    if (name.includes('learn') || name.includes('teach')) return 'tutor';
    if (name.includes('know') || name.includes('oracle')) return 'oracle';
    return 'mirror';
  }

  private inferRenderer(name: string): string {
    if (name.includes('3d') || name.includes('world')) return 'threejs';
    if (name.includes('2d') || name.includes('canvas')) return 'canvas_2d';
    if (name.includes('text') || name.includes('chat')) return 'text_stream';
    if (name.includes('audio') || name.includes('sound')) return 'waveform';
    if (name.includes('video') || name.includes('stream')) return 'video_player';
    return 'generic_renderer';
  }

  private generateTests(config: CodeGenerationConfig): string[] {
    return [
      `// Test: ${config.name} can be instantiated`,
      `// Test: ${config.name} fulfills purpose: ${config.purpose}`,
      `// Test: ${config.name} integrates with substrate`,
      `// Test: ${config.name} persists state correctly`,
    ];
  }

  private generateIntegration(config: CodeGenerationConfig): string {
    return `
// Integration: ${config.name}
// 1. Import into substrate
// 2. Register with appropriate center/surface
// 3. Connect to persistence layer
// 4. Add to app tray if surface
// 5. Update orchestrator config
`;
  }
}

export default GrowthEngine;
