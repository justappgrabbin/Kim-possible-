// ============================================
// INGESTION MOUTH — Eats Whatever You Give It
// Code, PDF, image, audio, video, URL, API, git, huggingface
// Identifies → Parses → Extracts → Compares → Gaps → Growth
// ============================================

import {
  IngestionType,
  ParsedArtifact,
  Gap,
  GapType,
  SystemState,
} from '../types';

export class IngestionMouth {
  private systemState: SystemState;
  private onGapFound: (gaps: Gap[], artifact: ParsedArtifact) => void;

  constructor(
    systemState: SystemState,
    onGapFound: (gaps: Gap[], artifact: ParsedArtifact) => void
  ) {
    this.systemState = systemState;
    this.onGapFound = onGapFound;
  }

  // ─── EAT — The main entry point ───
  async eat(source: any): Promise<ParsedArtifact> {
    // 1. Identify what it is
    const type = await this.identify(source);
    console.log(`[MOUTH] Identified: ${type}`);

    // 2. Parse structure and intent
    const parsed = await this.parse(source, type);
    console.log(`[MOUTH] Parsed: ${parsed.summary}`);

    // 3. Compare against current system — find gaps
    const gaps = await this.findGaps(parsed);
    console.log(`[MOUTH] Gaps found: ${gaps.length}`);

    // 4. If gaps exist, trigger growth
    if (gaps.length > 0) {
      console.log(`[MOUTH] Triggering growth for ${gaps.length} gaps`);
      this.onGapFound(gaps, parsed);
    } else {
      console.log(`[MOUTH] No gaps. Integrating as enrichment.`);
      await this.integrate(parsed);
    }

    return parsed;
  }

  // ─── IDENTIFY — What is this thing? ───
  private async identify(source: any): Promise<IngestionType> {
    if (typeof source === 'string') {
      if (source.startsWith('http://') || source.startsWith('https://')) {
        if (source.includes('github.com')) return 'git';
        if (source.includes('huggingface.co')) return 'huggingface';
        return 'url';
      }
      if (source.includes('function') || source.includes('class') || source.includes('import')) {
        return 'code';
      }
      return 'text';
    }

    if (source instanceof File || source instanceof Blob) {
      const type = source.type || '';
      if (type.startsWith('image/')) return 'image';
      if (type.startsWith('audio/')) return 'audio';
      if (type.startsWith('video/')) return 'video';
      if (type === 'application/pdf') return 'pdf';
      if (type.includes('json')) return 'code';
      return 'unknown';
    }

    if (source && typeof source === 'object') {
      if (source.endpoint || source.apiKey || source.baseUrl) return 'api';
      if (source.repo || source.branch) return 'git';
      if (source.model || source.tokenizer) return 'huggingface';
    }

    return 'unknown';
  }

  // ─── PARSE — Extract structure, intent, requirements ───
  private async parse(source: any, type: IngestionType): Promise<ParsedArtifact> {
    const id = `artifact_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    switch (type) {
      case 'code':
        return this.parseCode(source, id);
      case 'pdf':
        return this.parsePDF(source, id);
      case 'image':
        return this.parseImage(source, id);
      case 'audio':
        return this.parseAudio(source, id);
      case 'video':
        return this.parseVideo(source, id);
      case 'url':
        return this.parseURL(source, id);
      case 'api':
        return this.parseAPI(source, id);
      case 'git':
        return this.parseGit(source, id);
      case 'huggingface':
        return this.parseHuggingFace(source, id);
      case 'text':
        return this.parseText(source, id);
      default:
        return this.parseUnknown(source, id);
    }
  }

  // ─── Code Parser ───
  private parseCode(source: string, id: string): ParsedArtifact {
    const structure = this.extractCodeStructure(source);
    const intent = this.inferCodeIntent(source);
    const capabilities = this.inferCodeCapabilities(source);

    return {
      id,
      type: 'code',
      raw: source,
      structure,
      intent,
      requiredCapabilities: capabilities,
      requiredInputs: this.inferCodeInputs(source),
      requiredOutputs: this.inferCodeOutputs(source),
      requiredReasoning: this.inferCodeReasoning(source),
      intendedInteraction: this.inferCodeInteraction(source),
      requiresExternalAI: this.codeNeedsAI(source),
      requiredModel: this.inferRequiredModel(source),
      summary: `Code: ${intent}. ${capabilities.length} capabilities detected.`,
      extractedAt: Date.now(),
    };
  }

  private extractCodeStructure(source: string): any {
    const imports = (source.match(/import.*?from.*?['"]/g) || []).map(s => s.replace(/import|from|['"]/g, '').trim());
    const classes = (source.match(/class\s+\w+/g) || []).map(s => s.replace('class ', '').trim());
    const functions = (source.match(/function\s+\w+/g) || []).map(s => s.replace('function ', '').trim());
    const exports = (source.match(/export\s+(?:default\s+)?(?:class|function|const|let|var)\s+\w+/g) || []);

    return { imports, classes, functions, exports, lines: source.split('
').length };
  }

  private inferCodeIntent(source: string): string {
    if (source.includes('game') || source.includes('engine') || source.includes('render')) return 'game-engine';
    if (source.includes('model') || source.includes('neural') || source.includes('diffusion')) return 'ai-model';
    if (source.includes('api') || source.includes('endpoint') || source.includes('route')) return 'api-service';
    if (source.includes('ui') || source.includes('component') || source.includes('render')) return 'ui-component';
    if (source.includes('data') || source.includes('database') || source.includes('storage')) return 'data-layer';
    if (source.includes('auth') || source.includes('login') || source.includes('security')) return 'auth-system';
    return 'utility';
  }

  private inferCodeCapabilities(source: string): string[] {
    const caps: string[] = [];
    if (source.includes('3d') || source.includes('three') || source.includes('webgl')) caps.push('3d-rendering');
    if (source.includes('2d') || source.includes('canvas') || source.includes('svg')) caps.push('2d-rendering');
    if (source.includes('physics') || source.includes('collision') || source.includes('body')) caps.push('physics');
    if (source.includes('ai') || source.includes('ml') || source.includes('model')) caps.push('ai-inference');
    if (source.includes('network') || source.includes('socket') || source.includes('ws')) caps.push('networking');
    if (source.includes('audio') || source.includes('sound') || source.includes('music')) caps.push('audio');
    if (source.includes('video') || source.includes('stream')) caps.push('video');
    if (source.includes('file') || source.includes('fs') || source.includes('upload')) caps.push('file-handling');
    return caps;
  }

  private inferCodeInputs(source: string): string[] {
    const inputs: string[] = [];
    if (source.includes('props') || source.includes('input') || source.includes('param')) inputs.push('user-input');
    if (source.includes('file') || source.includes('upload')) inputs.push('file-upload');
    if (source.includes('api') || source.includes('fetch') || source.includes('axios')) inputs.push('api-data');
    if (source.includes('sensor') || source.includes('camera') || source.includes('mic')) inputs.push('sensor-data');
    return inputs;
  }

  private inferCodeOutputs(source: string): string[] {
    const outputs: string[] = [];
    if (source.includes('render') || source.includes('display') || source.includes('show')) outputs.push('visual');
    if (source.includes('audio') || source.includes('play')) outputs.push('audio');
    if (source.includes('save') || source.includes('store') || source.includes('persist')) outputs.push('persistence');
    if (source.includes('emit') || source.includes('broadcast') || source.includes('send')) outputs.push('events');
    return outputs;
  }

  private inferCodeReasoning(source: string): string[] {
    const reasoning: string[] = [];
    if (source.includes('algorithm') || source.includes('sort') || source.includes('search')) reasoning.push('algorithmic');
    if (source.includes('pattern') || source.includes('recognize') || source.includes('detect')) reasoning.push('pattern-matching');
    if (source.includes('logic') || source.includes('rule') || source.includes('condition')) reasoning.push('logical');
    if (source.includes('probabilistic') || source.includes('bayesian') || source.includes('stat')) reasoning.push('statistical');
    return reasoning;
  }

  private inferCodeInteraction(source: string): string[] {
    const interaction: string[] = [];
    if (source.includes('click') || source.includes('touch') || source.includes('mouse')) interaction.push('touch');
    if (source.includes('key') || source.includes('input') || source.includes('text')) interaction.push('text');
    if (source.includes('voice') || source.includes('speech') || source.includes('audio')) interaction.push('voice');
    if (source.includes('gesture') || source.includes('motion') || source.includes('move')) interaction.push('gesture');
    if (source.includes('play') || source.includes('game') || source.includes('interactive')) interaction.push('play');
    return interaction;
  }

  private codeNeedsAI(source: string): boolean {
    return source.includes('ai') || source.includes('gpt') || source.includes('claude') ||
           source.includes('llm') || source.includes('model') || source.includes('embed') ||
           source.includes('generate') || source.includes('predict');
  }

  private inferRequiredModel(source: string): string | undefined {
    if (source.includes('claude')) return 'claude';
    if (source.includes('gpt') || source.includes('openai')) return 'gpt';
    if (source.includes('gemini')) return 'gemini';
    if (source.includes('local') || source.includes('ollama')) return 'local';
    return undefined;
  }

  // ─── PDF Parser ───
  private parsePDF(source: any, id: string): ParsedArtifact {
    return {
      id,
      type: 'pdf',
      raw: source,
      structure: { pages: 'unknown', text: 'extracted' },
      intent: 'document-knowledge',
      requiredCapabilities: ['text-extraction', 'knowledge-embedding'],
      requiredInputs: ['file-upload'],
      requiredOutputs: ['knowledge-base', 'searchable-text'],
      requiredReasoning: ['semantic-analysis', 'summarization'],
      intendedInteraction: 'read',
      requiresExternalAI: true,
      requiredModel: 'claude',
      summary: 'PDF document containing knowledge to be ingested and understood.',
      extractedAt: Date.now(),
    };
  }

  // ─── Image Parser ───
  private parseImage(source: any, id: string): ParsedArtifact {
    return {
      id,
      type: 'image',
      raw: source,
      structure: { width: 'unknown', height: 'unknown', format: 'detected' },
      intent: 'visual-content',
      requiredCapabilities: ['image-analysis', 'visual-rendering', 'pattern-recognition'],
      requiredInputs: ['file-upload', 'camera'],
      requiredOutputs: ['visual', 'description', 'embedding'],
      requiredReasoning: ['computer-vision', 'semantic-understanding'],
      intendedInteraction: 'view',
      requiresExternalAI: true,
      requiredModel: 'gemini',
      summary: 'Visual content requiring perception and understanding.',
      extractedAt: Date.now(),
    };
  }

  // ─── Audio Parser ───
  private parseAudio(source: any, id: string): ParsedArtifact {
    return {
      id,
      type: 'audio',
      raw: source,
      structure: { duration: 'unknown', format: 'detected', channels: 'unknown' },
      intent: 'sonic-content',
      requiredCapabilities: ['audio-processing', 'speech-recognition', 'music-analysis'],
      requiredInputs: ['file-upload', 'microphone'],
      requiredOutputs: ['audio', 'transcription', 'analysis'],
      requiredReasoning: ['signal-processing', 'pattern-recognition'],
      intendedInteraction: 'listen',
      requiresExternalAI: true,
      requiredModel: 'whisper',
      summary: 'Audio content requiring sonic perception and analysis.',
      extractedAt: Date.now(),
    };
  }

  // ─── Video Parser ───
  private parseVideo(source: any, id: string): ParsedArtifact {
    return {
      id,
      type: 'video',
      raw: source,
      structure: { duration: 'unknown', format: 'detected', fps: 'unknown' },
      intent: 'temporal-visual-content',
      requiredCapabilities: ['video-processing', 'frame-analysis', 'temporal-understanding'],
      requiredInputs: ['file-upload', 'camera'],
      requiredOutputs: ['visual', 'frames', 'analysis'],
      requiredReasoning: ['computer-vision', 'temporal-reasoning'],
      intendedInteraction: 'watch',
      requiresExternalAI: true,
      requiredModel: 'gemini',
      summary: 'Video content requiring temporal and visual perception.',
      extractedAt: Date.now(),
    };
  }

  // ─── URL Parser ───
  private parseURL(source: string, id: string): ParsedArtifact {
    return {
      id,
      type: 'url',
      raw: source,
      structure: { url: source, domain: new URL(source).hostname },
      intent: 'web-resource',
      requiredCapabilities: ['web-scraping', 'content-extraction'],
      requiredInputs: ['url'],
      requiredOutputs: ['content', 'links', 'metadata'],
      requiredReasoning: ['semantic-analysis', 'structure-parsing'],
      intendedInteraction: 'browse',
      requiresExternalAI: false,
      summary: `Web resource at ${source}.`,
      extractedAt: Date.now(),
    };
  }

  // ─── API Parser ───
  private parseAPI(source: any, id: string): ParsedArtifact {
    return {
      id,
      type: 'api',
      raw: source,
      structure: { endpoint: source.endpoint, methods: source.methods || ['GET'] },
      intent: 'api-integration',
      requiredCapabilities: ['http-client', 'auth-handling', 'data-transformation'],
      requiredInputs: ['api-key', 'endpoint', 'params'],
      requiredOutputs: ['data', 'status', 'errors'],
      requiredReasoning: ['protocol-handling', 'error-recovery'],
      intendedInteraction: 'connect',
      requiresExternalAI: false,
      summary: `API integration for ${source.endpoint}.`,
      extractedAt: Date.now(),
    };
  }

  // ─── Git Parser ───
  private parseGit(source: string, id: string): ParsedArtifact {
    return {
      id,
      type: 'git',
      raw: source,
      structure: { repo: source, provider: 'github' },
      intent: 'code-repository',
      requiredCapabilities: ['git-clone', 'code-analysis', 'dependency-resolution'],
      requiredInputs: ['repo-url'],
      requiredOutputs: ['code', 'structure', 'dependencies'],
      requiredReasoning: ['code-understanding', 'architecture-analysis'],
      intendedInteraction: 'explore',
      requiresExternalAI: true,
      requiredModel: 'claude',
      summary: `Git repository at ${source}.`,
      extractedAt: Date.now(),
    };
  }

  // ─── HuggingFace Parser ───
  private parseHuggingFace(source: any, id: string): ParsedArtifact {
    return {
      id,
      type: 'huggingface',
      raw: source,
      structure: { model: source.model || source, type: 'ml-model' },
      intent: 'ml-model-integration',
      requiredCapabilities: ['model-loading', 'inference', 'tokenization'],
      requiredInputs: ['model-id', 'input-data'],
      requiredOutputs: ['predictions', 'embeddings', 'generations'],
      requiredReasoning: ['statistical', 'pattern-matching'],
      intendedInteraction: 'infer',
      requiresExternalAI: true,
      requiredModel: 'huggingface',
      summary: `HuggingFace model ${source.model || source}.`,
      extractedAt: Date.now(),
    };
  }

  // ─── Text Parser ───
  private parseText(source: string, id: string): ParsedArtifact {
    return {
      id,
      type: 'text',
      raw: source,
      structure: { length: source.length, words: source.split(/\s+/).length },
      intent: 'textual-content',
      requiredCapabilities: ['text-processing', 'semantic-analysis'],
      requiredInputs: ['text'],
      requiredOutputs: ['analysis', 'summary', 'embedding'],
      requiredReasoning: ['semantic-analysis', 'summarization'],
      intendedInteraction: 'read',
      requiresExternalAI: true,
      requiredModel: 'claude',
      summary: `Text content: ${source.substring(0, 100)}...`,
      extractedAt: Date.now(),
    };
  }

  // ─── Unknown Parser ───
  private parseUnknown(source: any, id: string): ParsedArtifact {
    return {
      id,
      type: 'unknown',
      raw: source,
      structure: { type: typeof source },
      intent: 'unknown-content',
      requiredCapabilities: ['type-detection', 'general-processing'],
      requiredInputs: ['unknown'],
      requiredOutputs: ['analysis', 'classification'],
      requiredReasoning: ['pattern-matching'],
      intendedInteraction: 'examine',
      requiresExternalAI: true,
      requiredModel: 'claude',
      summary: 'Unknown content type. Requires analysis.',
      extractedAt: Date.now(),
    };
  }

  // ─── FIND GAPS — Compare artifact against system ───
  private async findGaps(artifact: ParsedArtifact): Promise<Gap[]> {
    const gaps: Gap[] = [];

    // Check each required capability against existing system
    for (const capability of artifact.requiredCapabilities) {
      if (!this.hasCapability(capability)) {
        gaps.push({
          id: `gap_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          type: 'MISSING_CAPABILITY',
          reason: `System lacks capability: ${capability}`,
          suggestedName: capability,
          suggestedConfig: { source: artifact.id, priority: 0.8 },
          priority: 0.8,
          trigger: artifact.id,
        });
      }
    }

    // Check if new center needed
    for (const input of artifact.requiredInputs) {
      if (!this.hasInputHandler(input)) {
        gaps.push({
          id: `gap_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          type: 'NEW_CENTER',
          reason: `No center handles input: ${input}`,
          suggestedName: `${input}_center`,
          suggestedConfig: { inputType: input, source: artifact.id },
          priority: 0.7,
          trigger: artifact.id,
        });
      }
    }

    // Check if new surface needed
    for (const interaction of artifact.intendedInteraction) {
      if (!this.hasSurfaceFor(interaction)) {
        gaps.push({
          id: `gap_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          type: 'NEW_SURFACE',
          reason: `No surface supports interaction: ${interaction}`,
          suggestedName: `${interaction}_surface`,
          suggestedConfig: { interaction, source: artifact.id },
          priority: 0.6,
          trigger: artifact.id,
        });
      }
    }

    // Check if new tool needed
    for (const reasoning of artifact.requiredReasoning) {
      if (!this.hasToolFor(reasoning)) {
        gaps.push({
          id: `gap_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          type: 'NEW_TOOL',
          reason: `No Klein tool for reasoning: ${reasoning}`,
          suggestedName: `${reasoning}_tool`,
          suggestedConfig: { reasoning, source: artifact.id },
          priority: 0.75,
          trigger: artifact.id,
        });
      }
    }

    // Check if MCP needed
    if (artifact.requiresExternalAI && artifact.requiredModel) {
      if (!this.hasMCP(artifact.requiredModel)) {
        gaps.push({
          id: `gap_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          type: 'NEW_MCP',
          reason: `No MCP connection for model: ${artifact.requiredModel}`,
          suggestedName: `${artifact.requiredModel}_mcp`,
          suggestedConfig: { model: artifact.requiredModel, source: artifact.id },
          priority: 0.9,
          trigger: artifact.id,
        });
      }
    }

    return gaps;
  }

  // ─── System Capability Checks ───
  private hasCapability(capability: string): boolean {
    // Check if any center or tool provides this capability
    for (const [name, center] of this.systemState.centers) {
      if (center.memory.some((m: any) => m.yield?.metadata?.capability === capability)) {
        return true;
      }
    }
    return false;
  }

  private hasInputHandler(input: string): boolean {
    for (const [name, center] of this.systemState.centers) {
      if (name.toLowerCase().includes(input.replace('_', ''))) return true;
    }
    return false;
  }

  private hasSurfaceFor(interaction: string): boolean {
    for (const [name, surface] of this.systemState.surfaces) {
      if (surface.interaction === interaction) return true;
    }
    return false;
  }

  private hasToolFor(reasoning: string): boolean {
    // Check Klein toolkit
    return false; // Will be implemented with actual toolkit
  }

  private hasMCP(model: string): boolean {
    return this.systemState.mcpConnections.has(model);
  }

  // ─── INTEGRATE — When no gaps, enrich the system ───
  private async integrate(artifact: ParsedArtifact): Promise<void> {
    // Add to system memory
    this.systemState.memory.artifacts.push(artifact);

    // Emit enrichment event
    console.log(`[MOUTH] Integrated: ${artifact.summary}`);
  }
}

export default IngestionMouth;
