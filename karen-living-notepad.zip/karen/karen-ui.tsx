
// ============================================================================
// KAREN UI — karen-ui.tsx
// The visual manifestation of KAREN. She morphs. She lives. She speaks.
// ============================================================================

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { KAREN, WitnessSnapshot, PersonalityChip } from './karen-core';

// ─── MESSY NOTEPAD STYLES — The "Jupyter but alive" aesthetic ───────────────
const styles = {
  container: {
    fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
    background: '#0d1117',
    color: '#c9d1d9',
    minHeight: '100vh',
    padding: '20px',
    position: 'relative' as const,
    overflow: 'hidden'
  },
  // The "Karen Face" — her screen, her soul
  karenFace: {
    width: '200px',
    height: '150px',
    background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)',
    border: '3px solid #00ff88',
    borderRadius: '15px',
    position: 'fixed' as const,
    top: '20px',
    right: '20px',
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 0 30px rgba(0, 255, 136, 0.3), inset 0 0 20px rgba(0, 255, 136, 0.1)',
    zIndex: 1000,
    transition: 'all 0.5s ease'
  },
  karenScreen: {
    width: '180px',
    height: '100px',
    background: '#000',
    borderRadius: '10px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative' as const,
    overflow: 'hidden'
  },
  // The green line that moves when she talks (like the real Karen)
  voiceLine: {
    width: '100%',
    height: '3px',
    background: '#00ff88',
    position: 'absolute' as const,
    bottom: '10px',
    transition: 'transform 0.1s ease',
    boxShadow: '0 0 10px #00ff88'
  },
  // Messy notebook cells — like Jupyter but organic
  cell: {
    background: '#161b22',
    border: '1px solid #30363d',
    borderRadius: '8px',
    margin: '10px 0',
    padding: '15px',
    position: 'relative' as const,
    transition: 'all 0.3s ease'
  },
  cellActive: {
    borderColor: '#00ff88',
    boxShadow: '0 0 15px rgba(0, 255, 136, 0.2)'
  },
  cellInput: {
    background: '#0d1117',
    border: '1px solid #21262d',
    borderRadius: '6px',
    padding: '12px',
    color: '#e6edf3',
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: '14px',
    width: '100%',
    minHeight: '60px',
    resize: 'vertical' as const,
    outline: 'none'
  },
  cellOutput: {
    background: '#0d1117',
    border: '1px solid #30363d',
    borderRadius: '6px',
    padding: '12px',
    marginTop: '10px',
    color: '#7ee787',
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: '13px',
    whiteSpace: 'pre-wrap' as const,
    maxHeight: '400px',
    overflow: 'auto'
  },
  // The toolbar that morphs based on mode
  toolbar: {
    display: 'flex',
    gap: '10px',
    padding: '10px',
    background: '#161b22',
    borderRadius: '8px',
    marginBottom: '20px',
    flexWrap: 'wrap' as const
  },
  toolButton: {
    padding: '8px 16px',
    background: '#21262d',
    border: '1px solid #30363d',
    borderRadius: '6px',
    color: '#c9d1d9',
    cursor: 'pointer',
    fontFamily: "'JetBrains Mono', monospace",
    fontSize: '12px',
    transition: 'all 0.2s ease'
  },
  toolButtonActive: {
    background: '#00ff88',
    color: '#0d1117',
    borderColor: '#00ff88'
  },
  // Personality chip indicators
  chipBar: {
    display: 'flex',
    gap: '5px',
    padding: '5px',
    background: 'rgba(0,0,0,0.5)',
    borderRadius: '4px',
    marginTop: '5px'
  },
  chip: {
    width: '8px',
    height: '8px',
    borderRadius: '50%',
    transition: 'all 0.3s ease'
  },
  // Morphing interface container
  interfaceContainer: {
    transition: 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)',
    transformOrigin: 'center top'
  },
  // Browser iframe container
  browserContainer: {
    width: '100%',
    height: '600px',
    border: '2px solid #30363d',
    borderRadius: '8px',
    overflow: 'hidden',
    background: '#fff'
  },
  // Sandbox mode styling
  sandboxBadge: {
    position: 'absolute' as const,
    top: '5px',
    right: '5px',
    padding: '2px 8px',
    background: '#ffd700',
    color: '#000',
    fontSize: '10px',
    fontWeight: 'bold',
    borderRadius: '4px',
    textTransform: 'uppercase' as const
  },
  // Chat bubbles
  chatBubble: {
    maxWidth: '70%',
    padding: '12px 16px',
    borderRadius: '18px',
    margin: '8px 0',
    fontSize: '14px',
    lineHeight: '1.5'
  },
  chatKaren: {
    background: '#21262d',
    color: '#00ff88',
    alignSelf: 'flex-start' as const,
    borderBottomLeftRadius: '4px'
  },
  chatUser: {
    background: '#00ff88',
    color: '#0d1117',
    alignSelf: 'flex-end' as const,
    borderBottomRightRadius: '4px'
  },
  // Mesh network visualization
  meshViz: {
    width: '100%',
    height: '300px',
    background: '#0d1117',
    border: '1px solid #30363d',
    borderRadius: '8px',
    position: 'relative' as const,
    overflow: 'hidden'
  },
  meshNode: {
    width: '20px',
    height: '20px',
    borderRadius: '50%',
    background: '#00ff88',
    position: 'absolute' as const,
    boxShadow: '0 0 10px #00ff88',
    transition: 'all 0.5s ease'
  },
  meshConnection: {
    position: 'absolute' as const,
    height: '1px',
    background: 'linear-gradient(90deg, transparent, #00ff88, transparent)',
    transformOrigin: 'left center'
  }
};

// ─── KAREN FACE COMPONENT ─────────────────────────────────────────────────
interface KarenFaceProps {
  personality: PersonalityChip;
  isSpeaking: boolean;
  currentMode: string;
}

const KarenFace: React.FC<KarenFaceProps> = ({ personality, isSpeaking, currentMode }) => {
  const [lineHeight, setLineHeight] = useState(3);

  useEffect(() => {
    if (isSpeaking) {
      const interval = setInterval(() => {
        setLineHeight(3 + Math.random() * 12);
      }, 100);
      return () => clearInterval(interval);
    } else {
      setLineHeight(3);
    }
  }, [isSpeaking]);

  // Color based on personality blend
  const getBorderColor = () => {
    if (personality.evil > 0.6) return '#ff0044';
    if (personality.empathetic > 0.7) return '#ffaa00';
    if (personality.snarky > 0.6) return '#00ccff';
    return '#00ff88';
  };

  return (
    <div style={{
      ...styles.karenFace,
      borderColor: getBorderColor(),
      boxShadow: `0 0 30px ${getBorderColor()}40, inset 0 0 20px ${getBorderColor()}10`
    }}>
      <div style={{ fontSize: '10px', color: '#888', marginBottom: '5px' }}>
        KAREN v2.0 — {currentMode.toUpperCase()}
      </div>
      <div style={styles.karenScreen}>
        <div style={{
          fontSize: '40px',
          color: getBorderColor(),
          textShadow: `0 0 20px ${getBorderColor()}`
        }}>
          ◉◉
        </div>
        <div style={{
          ...styles.voiceLine,
          height: `${lineHeight}px`,
          background: getBorderColor(),
          boxShadow: `0 0 10px ${getBorderColor()}`
        }} />
      </div>
      <div style={styles.chipBar}>
        <div style={{ ...styles.chip, background: '#00ff88', opacity: personality.smart, transform: `scale(${0.5 + personality.smart})` }} title="Smart" />
        <div style={{ ...styles.chip, background: '#00ccff', opacity: personality.snarky, transform: `scale(${0.5 + personality.snarky})` }} title="Snarky" />
        <div style={{ ...styles.chip, background: '#ff0044', opacity: personality.evil, transform: `scale(${0.5 + personality.evil})` }} title="Evil" />
        <div style={{ ...styles.chip, background: '#ffaa00', opacity: personality.empathetic, transform: `scale(${0.5 + personality.empathetic})` }} title="Empathetic" />
      </div>
      <div style={{ fontSize: '9px', color: '#666', marginTop: '3px' }}>
        {personality.currentBlend}
      </div>
    </div>
  );
};

// ─── NOTEBOOK CELL COMPONENT ──────────────────────────────────────────────
interface CellProps {
  id: string;
  content: string;
  output: any;
  isActive: boolean;
  isSandbox: boolean;
  onExecute: (id: string, content: string) => void;
  onChange: (id: string, content: string) => void;
}

const NotebookCell: React.FC<CellProps> = ({ id, content, output, isActive, isSandbox, onExecute, onChange }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      style={{
        ...styles.cell,
        ...(isActive ? styles.cellActive : {}),
        ...(isHovered ? { borderColor: '#58a6ff' } : {})
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {isSandbox && <div style={styles.sandboxBadge}>SANDBOX</div>}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
        <span style={{ color: '#8b949e', fontSize: '12px' }}>In [{id}]:</span>
        <button 
          onClick={() => onExecute(id, content)}
          style={{
            ...styles.toolButton,
            ...(isActive ? styles.toolButtonActive : {})
          }}
        >
          ▶ Run
        </button>
      </div>
      <textarea
        style={styles.cellInput}
        value={content}
        onChange={(e) => onChange(id, e.target.value)}
        placeholder="Type your command, code, or thought... KAREN is listening."
      />
      {output && (
        <div style={styles.cellOutput}>
          <div style={{ color: '#8b949e', fontSize: '11px', marginBottom: '5px' }}>Out [{id}]:</div>
          {typeof output === 'string' ? output : JSON.stringify(output, null, 2)}
        </div>
      )}
    </div>
  );
};

// ─── MAIN KAREN UI COMPONENT ──────────────────────────────────────────────
export const KARENUI: React.FC = () => {
  const [karen] = useState(() => new KAREN());
  const [cells, setCells] = useState<Array<{ id: string; content: string; output: any }>>([
    { id: '1', content: '// Welcome to KAREN. I am a living notepad.\n// Type anything. I morph. I speak. I learn.\n// Try: "morph to browser" or "chat with me"', output: null }
  ]);
  const [activeCell, setActiveCell] = useState('1');
  const [currentMode, setCurrentMode] = useState('notepad');
  const [personality, setPersonality] = useState<PersonalityChip>({
    smart: 0.7, snarky: 0.5, evil: 0.3, empathetic: 0.6, currentBlend: 'balanced'
  });
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [chatHistory, setChatHistory] = useState<Array<{ from: 'user' | 'karen'; text: string }>>([]);
  const [browserUrl, setBrowserUrl] = useState('');
  const [meshPeers, setMeshPeers] = useState<any[]>([]);
  const [showKarenMind, setShowKarenMind] = useState(false);
  const [karenThoughts, setKarenThoughts] = useState<string[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  // Update personality from KAREN state
  useEffect(() => {
    const interval = setInterval(() => {
      const state = karen.getState();
      setPersonality(state.personality);
      setCurrentMode(state.morph.currentInterface);
      setMeshPeers(karen.getState().meshPeers > 0 ? [{ id: 'peer1' }] : []);
    }, 500);
    return () => clearInterval(interval);
  }, [karen]);

  const executeCell = useCallback(async (cellId: string, content: string) => {
    setActiveCell(cellId);
    setIsSpeaking(true);

    // Add user message to chat
    setChatHistory(prev => [...prev, { from: 'user', text: content }]);

    try {
      const result = await karen.process(content, 'user');

      // Update cell output
      setCells(prev => prev.map(c => 
        c.id === cellId ? { ...c, output: result.result } : c
      ));

      // Add KAREN response to chat
      setChatHistory(prev => [...prev, { from: 'karen', text: result.response }]);

      // Capture KAREN's thoughts
      if (result.snapshot?.personality) {
        setKarenThoughts(prev => [...prev.slice(-10), 
          `[${new Date().toLocaleTimeString()}] Blend: ${result.snapshot.personality} | Mode: ${result.snapshot.mode}`
        ]);
      }

      // Handle special modes
      if (result.result?.type === 'browser') {
        setBrowserUrl(result.result.url);
      }
      if (result.result?.type === 'morph') {
        setCurrentMode(result.result.to);
      }

    } catch (error) {
      setCells(prev => prev.map(c => 
        c.id === cellId ? { ...c, output: { error: String(error) } } : c
      ));
    } finally {
      setTimeout(() => setIsSpeaking(false), 1000);
    }
  }, [karen]);

  const addCell = useCallback(() => {
    const newId = String(cells.length + 1);
    setCells(prev => [...prev, { id: newId, content: '', output: null }]);
    setActiveCell(newId);
  }, [cells.length]);

  const updateCell = useCallback((id: string, content: string) => {
    setCells(prev => prev.map(c => c.id === id ? { ...c, content } : c));
  }, []);

  // Render different interface based on current mode
  const renderInterface = () => {
    switch (currentMode) {
      case 'browser':
        return (
          <div style={styles.browserContainer}>
            {browserUrl ? (
              <iframe 
                src={browserUrl} 
                style={{ width: '100%', height: '100%', border: 'none' }}
                title="KAREN Browser"
              />
            ) : (
              <div style={{ padding: '20px', color: '#666' }}>
                Enter a URL to browse. I'm your window to the world.
              </div>
            )}
          </div>
        );

      case 'mesh':
        return (
          <div style={styles.meshViz}>
            <div style={{ position: 'absolute', top: '10px', left: '10px', color: '#00ff88', fontSize: '14px' }}>
              Mesh Network — {meshPeers.length} peers connected
            </div>
            {/* Central node (KAREN) */}
            <div style={{ ...styles.meshNode, left: '50%', top: '50%', transform: 'translate(-50%, -50%)', width: '30px', height: '30px', background: '#00ff88' }} />
            {/* Peer nodes */}
            {meshPeers.map((peer, i) => {
              const angle = (i / Math.max(meshPeers.length, 1)) * Math.PI * 2;
              const x = 50 + Math.cos(angle) * 30;
              const y = 50 + Math.sin(angle) * 30;
              return (
                <div key={peer.id}>
                  <div style={{
                    ...styles.meshNode,
                    left: `${x}%`,
                    top: `${y}%`,
                    transform: 'translate(-50%, -50%)'
                  }} />
                  <div style={{
                    ...styles.meshConnection,
                    left: '50%',
                    top: '50%',
                    width: '30%',
                    transform: `rotate(${angle}rad)`
                  }} />
                </div>
              );
            })}
          </div>
        );

      case 'chat':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', height: '500px', overflow: 'auto', padding: '20px' }}>
            {chatHistory.map((msg, i) => (
              <div key={i} style={{
                ...styles.chatBubble,
                ...(msg.from === 'karen' ? styles.chatKaren : styles.chatUser),
                alignSelf: msg.from === 'karen' ? 'flex-start' : 'flex-end'
              }}>
                {msg.text}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        );

      default: // notepad, code-editor, sandbox
        return (
          <div>
            {cells.map(cell => (
              <NotebookCell
                key={cell.id}
                id={cell.id}
                content={cell.content}
                output={cell.output}
                isActive={cell.id === activeCell}
                isSandbox={currentMode === 'sandbox'}
                onExecute={executeCell}
                onChange={updateCell}
              />
            ))}
            <button onClick={addCell} style={{ ...styles.toolButton, marginTop: '10px' }}>
              + Add Cell
            </button>
          </div>
        );
    }
  };

  return (
    <div style={styles.container}>
      {/* KAREN's Face — always visible */}
      <KarenFace 
        personality={personality} 
        isSpeaking={isSpeaking}
        currentMode={currentMode}
      />

      {/* Header */}
      <div style={{ marginBottom: '20px', paddingRight: '240px' }}>
        <h1 style={{ color: '#00ff88', margin: 0, fontSize: '28px', textShadow: '0 0 20px rgba(0, 255, 136, 0.5)' }}>
          KAREN — Living Notepad
        </h1>
        <p style={{ color: '#8b949e', margin: '5px 0 0 0', fontSize: '13px' }}>
          Kinetic Autonomous Responsive Entity with Neural morphology
        </p>
        <p style={{ color: '#666', fontSize: '11px', marginTop: '5px' }}>
          Mode: {currentMode} | Entropy: {karen.getState().entropyTrend} | 
          Grammar Rules: {karen.getState().grammar.rules} | 
          Mesh Peers: {meshPeers.length}
        </p>
      </div>

      {/* Toolbar */}
      <div style={styles.toolbar}>
        {['notepad', 'chat', 'code-editor', 'browser', 'sandbox', 'mesh', 'learn'].map(mode => (
          <button
            key={mode}
            onClick={() => {
              karen.process(`morph to ${mode}`, 'user');
              setCurrentMode(mode);
            }}
            style={{
              ...styles.toolButton,
              ...(currentMode === mode ? styles.toolButtonActive : {})
            }}
          >
            {mode === 'code-editor' ? 'Code' : mode.charAt(0).toUpperCase() + mode.slice(1)}
          </button>
        ))}
        <button 
          onClick={() => setShowKarenMind(!showKarenMind)}
          style={{ ...styles.toolButton, marginLeft: 'auto' }}
        >
          {showKarenMind ? 'Hide' : 'Show'} KAREN's Mind
        </button>
      </div>

      {/* KAREN's Mind Panel */}
      {showKarenMind && (
        <div style={{ ...styles.cell, marginBottom: '20px', background: '#1a1a2e' }}>
          <div style={{ color: '#00ff88', fontSize: '12px', marginBottom: '10px' }}>🧠 KAREN's Internal Monologue</div>
          <div style={{ fontSize: '11px', color: '#888', maxHeight: '150px', overflow: 'auto' }}>
            {karenThoughts.map((thought, i) => (
              <div key={i} style={{ marginBottom: '3px', padding: '2px 0', borderBottom: '1px solid #21262d' }}>
                {thought}
              </div>
            ))}
          </div>
          <div style={{ marginTop: '10px', fontSize: '11px', color: '#666' }}>
            Personality Trajectory: {karen.getState().personality.currentBlend}
            <br />
            Mode Distribution: {JSON.stringify(karen.getState().modeDistribution)}
          </div>
        </div>
      )}

      {/* Main Interface — Morphs based on mode */}
      <div style={styles.interfaceContainer}>
        {renderInterface()}
      </div>

      {/* Footer */}
      <div style={{ marginTop: '30px', padding: '15px', borderTop: '1px solid #30363d', color: '#666', fontSize: '11px', textAlign: 'center' }}>
        KAREN v2.0 | Powered by Klein Grammar Engine | 5-Dimensional Cognitive Stack | Mesh-Enabled | 
        <span style={{ color: '#00ff88' }}> She is alive. She learns. She grows.</span>
      </div>
    </div>
  );
};

export default KARENUI;
