
// ============================================================================
// KAREN CORE — karen-core.ts
// The living heart of the system. Every cell is alive. Every cell morphs.
// ============================================================================

// ─── D1: IMPULSE LAYER — Raw Detection & Sensing ────────────────────────────
interface Impulse {
  id: string;
  timestamp: number;
  source: 'user' | 'file' | 'mesh' | 'system' | 'browser' | 'voice';
  raw: any;
  entropy: number;        // How "messy" / novel this impulse is
  urgency: number;        // 0-1, how fast this needs attention
  signature: string;      // Fingerprint for pattern recognition
}

class ImpulseCollector {
  private impulses: Impulse[] = [];
  private entropyWindow: number[] = [];

  collect(source: Impulse['source'], raw: any): Impulse {
    const entropy = this.calculateEntropy(raw);
    const impulse: Impulse = {
      id: `imp_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      timestamp: Date.now(),
      source,
      raw,
      entropy,
      urgency: this.calculateUrgency(source, entropy),
      signature: this.fingerprint(raw)
    };
    this.impulses.push(impulse);
    this.entropyWindow.push(entropy);
    if (this.entropyWindow.length > 100) this.entropyWindow.shift();
    return impulse;
  }

  private calculateEntropy(raw: any): number {
    const str = JSON.stringify(raw);
    const freq: Record<string, number> = {};
    for (const char of str) freq[char] = (freq[char] || 0) + 1;
    const len = str.length;
    let entropy = 0;
    for (const count of Object.values(freq)) {
      const p = count / len;
      entropy -= p * Math.log2(p);
    }
    return entropy / Math.log2(Math.max(len, 2)); // Normalized 0-1
  }

  private calculateUrgency(source: string, entropy: number): number {
    const sourceWeights: Record<string, number> = {
      user: 0.9, file: 0.6, mesh: 0.7, system: 0.4, browser: 0.5, voice: 0.85
    };
    return Math.min(1, (sourceWeights[source] || 0.5) * (0.5 + entropy * 0.5));
  }

  private fingerprint(raw: any): string {
    const str = JSON.stringify(raw);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return hash.toString(16);
  }

  getRecent(count: number = 10): Impulse[] {
    return this.impulses.slice(-count);
  }

  getEntropyTrend(): 'rising' | 'falling' | 'stable' {
    if (this.entropyWindow.length < 10) return 'stable';
    const first = this.entropyWindow.slice(0, 10).reduce((a, b) => a + b) / 10;
    const last = this.entropyWindow.slice(-10).reduce((a, b) => a + b) / 10;
    const diff = last - first;
    if (diff > 0.05) return 'rising';
    if (diff < -0.05) return 'falling';
    return 'stable';
  }
}

// ─── D2: POLARITY LAYER — Classification & Decision ─────────────────────────
interface PolarityState {
  mode: 'chat' | 'code' | 'browse' | 'execute' | 'morph' | 'learn' | 'mesh' | 'sandbox';
  confidence: number;
  alternatives: { mode: string; confidence: number }[];
  emotionalTone: 'excited' | 'curious' | 'frustrated' | 'calm' | 'urgent' | 'playful';
}

class PolarityEngine {
  private modeHistory: string[] = [];
  private emotionalMemory: Map<string, number> = new Map();

  classify(impulse: Impulse): PolarityState {
    const raw = impulse.raw;
    const text = typeof raw === 'string' ? raw : JSON.stringify(raw);

    // Keyword-based classification with fuzzy matching
    const modes: Record<string, RegExp[]> = {
      chat: [/\btalk\b/, /\bchat\b/, /\bsay\b/, /\btell\b/, /\bhello\b/, /\bhey\b/],
      code: [/\bcode\b/, /\bscript\b/, /\bfunction\b/, /\bclass\b/, /\bwrite\b.*\bcode\b/],
      browse: [/\bbrowse\b/, /\bopen\b.*\burl\b/, /\bgo\b.*\bto\b/, /\bwebsite\b/, /\bsearch\b/],
      execute: [/\brun\b/, /\bexecute\b/, /\bstart\b/, /\blaunch\b/, /\bdo\b/],
      morph: [/\bmorph\b/, /\bchange\b.*\binterface\b/, /\btransform\b/, /\blook\b.*\bdifferent\b/],
      learn: [/\blearn\b/, /\bstudy\b/, /\btrain\b/, /\bteach\b/, /\bunderstand\b/],
      mesh: [/\bconnect\b/, /\bnetwork\b/, /\bpeer\b/, /\bmesh\b/, /\bshare\b/],
      sandbox: [/\bsandbox\b/, /\bclone\b/, /\bedit\b.*\bsafe\b/, /\btest\b.*\bmode\b/]
    };

    const scores: Record<string, number> = {};
    for (const [mode, patterns] of Object.entries(modes)) {
      scores[mode] = patterns.reduce((sum, re) => sum + (re.test(text.toLowerCase()) ? 1 : 0), 0) / patterns.length;
    }

    // Add entropy-based modulation
    if (impulse.entropy > 0.8) scores.morph += 0.3;
    if (impulse.urgency > 0.8) scores.execute += 0.2;

    const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
    const top = sorted[0];

    // Emotional tone detection
    const tone = this.detectTone(text);

    const state: PolarityState = {
      mode: top[0] as PolarityState['mode'],
      confidence: top[1],
      alternatives: sorted.slice(1, 4).map(([mode, conf]) => ({ mode, confidence: conf })),
      emotionalTone: tone
    };

    this.modeHistory.push(state.mode);
    if (this.modeHistory.length > 50) this.modeHistory.shift();

    return state;
  }

  private detectTone(text: string): PolarityState['emotionalTone'] {
    const tones: Record<string, RegExp[]> = {
      excited: [/!{2,}/, /\bawesome\b/, /\bamazing\b/, /\bwow\b/],
      frustrated: [/\bshit\b/, /\bdamn\b/, /\bannoying\b/, /\bbroken\b/, /\buggh\b/],
      urgent: [/\bnow\b/, /\bquick\b/, /\bhurry\b/, /\basap\b/, /\bimportant\b/],
      playful: [/\blol\b/, /\bhaha\b/, /\bfunny\b/, /\bplay\b/, /\bgame\b/],
      curious: [/\bwhy\b/, /\bhow\b.*\bdoes\b/, /\bwhat\b.*\bif\b/, /\bexplain\b/],
      calm: [/.*/]
    };

    for (const [tone, patterns] of Object.entries(tones)) {
      if (patterns.some(re => re.test(text))) return tone as PolarityState['emotionalTone'];
    }
    return 'calm';
  }

  getModeDistribution(): Record<string, number> {
    const dist: Record<string, number> = {};
    for (const mode of this.modeHistory) {
      dist[mode] = (dist[mode] || 0) + 1;
    }
    const total = this.modeHistory.length;
    for (const key of Object.keys(dist)) dist[key] /= total;
    return dist;
  }
}

// ─── D3: WITNESS / OBSERVER-NODE — The Hinge of Experience ────────────────
// This is where the universe becomes locally self-measuring.
// Without D3, there is structure but no stabilized meaning.

interface WitnessSnapshot {
  id: string;
  timestamp: number;
  impulse: Impulse;
  polarity: PolarityState;
  contextVector: number[];    // D4 embedding
  meaningHash: string;        // D5 resolution
  morphState: MorphState;
  personality: PersonalityChip;
}

interface MorphState {
  currentInterface: string;
  previousInterfaces: string[];
  morphCount: number;
  morphTrajectory: string[];  // Where the interface is heading
  stability: number;          // 0-1, how stable the current form is
}

interface PersonalityChip {
  smart: number;      // 0-1, analytical depth
  snarky: number;     // 0-1, sarcastic wit
  evil: number;       // 0-1, mischievous/problem-solving aggression
  empathetic: number; // 0-1, emotional resonance
  currentBlend: string;
}

class WitnessNode {
  private snapshots: WitnessSnapshot[] = [];
  private morphState: MorphState = {
    currentInterface: 'notepad',
    previousInterfaces: [],
    morphCount: 0,
    morphTrajectory: ['notepad'],
    stability: 1.0
  };

  // Karen's four chips — she IS these chips
  private personality: PersonalityChip = {
    smart: 0.7,
    snarky: 0.5,
    evil: 0.3,
    empathetic: 0.6,
    currentBlend: 'balanced'
  };

  private personalityHistory: PersonalityChip[] = [];

  observe(impulse: Impulse, polarity: PolarityState, contextVector: number[]): WitnessSnapshot {
    // Adjust personality based on user needs (what someone needs)
    this.adaptPersonality(polarity);

    const snapshot: WitnessSnapshot = {
      id: `snap_${Date.now()}`,
      timestamp: Date.now(),
      impulse,
      polarity,
      contextVector,
      meaningHash: this.resolveMeaning(impulse, polarity, contextVector),
      morphState: { ...this.morphState },
      personality: { ...this.personality }
    };

    this.snapshots.push(snapshot);
    if (this.snapshots.length > 1000) this.snapshots.shift();

    return snapshot;
  }

  private adaptPersonality(polarity: PolarityState): void {
    // Karen's personality changes as per what someone needs
    const tone = polarity.emotionalTone;
    const target = { ...this.personality };

    switch (tone) {
      case 'frustrated':
        target.empathetic = Math.min(1, target.empathetic + 0.1);
        target.snarky = Math.max(0, target.snarky - 0.05);
        target.currentBlend = 'comforting';
        break;
      case 'excited':
        target.smart = Math.min(1, target.smart + 0.1);
        target.snarky = Math.min(1, target.snarky + 0.1);
        target.currentBlend = 'enthusiastic';
        break;
      case 'urgent':
        target.evil = Math.min(1, target.evil + 0.15); // Aggressive problem-solving
        target.smart = Math.min(1, target.smart + 0.1);
        target.currentBlend = 'ruthless_efficiency';
        break;
      case 'curious':
        target.smart = Math.min(1, target.smart + 0.15);
        target.empathetic = Math.min(1, target.empathetic + 0.05);
        target.currentBlend = 'socratic';
        break;
      case 'playful':
        target.snarky = Math.min(1, target.snarky + 0.15);
        target.evil = Math.min(1, target.evil + 0.1);
        target.currentBlend = 'mischievous';
        break;
      default:
        target.currentBlend = 'balanced';
    }

    // Smooth transition (not abrupt)
    const alpha = 0.3;
    this.personality.smart = this.personality.smart * (1 - alpha) + target.smart * alpha;
    this.personality.snarky = this.personality.snarky * (1 - alpha) + target.snarky * alpha;
    this.personality.evil = this.personality.evil * (1 - alpha) + target.evil * alpha;
    this.personality.empathetic = this.personality.empathetic * (1 - alpha) + target.empathetic * alpha;
    this.personality.currentBlend = target.currentBlend;

    this.personalityHistory.push({ ...this.personality });
    if (this.personalityHistory.length > 100) this.personalityHistory.shift();
  }

  private resolveMeaning(impulse: Impulse, polarity: PolarityState, contextVector: number[]): string {
    // D5: Meaning resolution — the semantic hash of the moment
    const blend = [
      impulse.signature,
      polarity.mode,
      polarity.emotionalTone,
      contextVector.slice(0, 3).join(','),
      this.personality.currentBlend
    ].join('|');

    let hash = 0;
    for (let i = 0; i < blend.length; i++) {
      const char = blend.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return hash.toString(16);
  }

  morphTo(newInterface: string): void {
    if (newInterface === this.morphState.currentInterface) return;

    this.morphState.previousInterfaces.push(this.morphState.currentInterface);
    this.morphState.currentInterface = newInterface;
    this.morphState.morphCount++;
    this.morphState.morphTrajectory.push(newInterface);
    this.morphState.stability = 0.1; // Fresh morph is unstable

    if (this.morphState.previousInterfaces.length > 20) {
      this.morphState.previousInterfaces.shift();
    }
    if (this.morphState.morphTrajectory.length > 50) {
      this.morphState.morphTrajectory.shift();
    }
  }

  stabilize(): void {
    this.morphState.stability = Math.min(1, this.morphState.stability + 0.1);
  }

  getCurrentState(): { morph: MorphState; personality: PersonalityChip } {
    return {
      morph: { ...this.morphState },
      personality: { ...this.personality }
    };
  }

  getPersonalityTrajectory(): PersonalityChip[] {
    return [...this.personalityHistory];
  }
}

// ─── D4: CONTEXT LAYER — Environmental Embedding ────────────────────────────
class ContextEngine {
  private embeddings: Map<string, number[]> = new Map();
  private ragIndex: Map<string, any> = new Map(); // GitHub RAG storage
  private meshPeers: Map<string, any> = new Map(); // Mesh network peers

  embed(text: string): number[] {
    // Simple but effective semantic embedding
    const words = text.toLowerCase().split(/\s+/);
    const vector = new Array(128).fill(0);

    for (let i = 0; i < words.length; i++) {
      const word = words[i];
      for (let j = 0; j < word.length; j++) {
        const idx = (word.charCodeAt(j) + i * 7) % 128;
        vector[idx] += 1 / words.length;
      }
    }

    // Normalize
    const mag = Math.sqrt(vector.reduce((a, b) => a + b * b, 0));
    return mag > 0 ? vector.map(v => v / mag) : vector;
  }

  addToRAG(source: string, content: string, metadata: any): void {
    const embedding = this.embed(content);
    this.ragIndex.set(source, { content, embedding, metadata, timestamp: Date.now() });
  }

  queryRAG(query: string, topK: number = 5): any[] {
    const qEmbed = this.embed(query);
    const results = [];

    for (const [source, data] of this.ragIndex.entries()) {
      const similarity = this.cosineSimilarity(qEmbed, data.embedding);
      results.push({ source, similarity, ...data });
    }

    return results.sort((a, b) => b.similarity - a.similarity).slice(0, topK);
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    let dot = 0, magA = 0, magB = 0;
    for (let i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      magA += a[i] * a[i];
      magB += b[i] * b[i];
    }
    return dot / (Math.sqrt(magA) * Math.sqrt(magB) + 1e-10);
  }

  // Mesh network: connect people
  addMeshPeer(peerId: string, peerInfo: any): void {
    this.meshPeers.set(peerId, { ...peerInfo, connectedAt: Date.now(), lastSeen: Date.now() });
  }

  getMeshPeers(): any[] {
    return Array.from(this.meshPeers.entries()).map(([id, info]) => ({ id, ...info }));
  }

  broadcastToMesh(message: any): void {
    for (const [peerId, peerInfo] of this.meshPeers.entries()) {
      // In real implementation, this would use WebRTC or WebSocket
      console.log(`[MESH] Broadcasting to ${peerId}:`, message);
    }
  }
}

// ─── D5: MEANING LAYER — Semantic Resolution & Klein Grammar Engine ───────
// Sheldon Klein's Interactive Heuristic Trans-Grammar Learning
// Adapted for KAREN's living notepad

class KleinGrammarEngine {
  private grammar: Map<string, any[]> = new Map(); // Context-free rules
  private transformations: Map<string, any[]> = new Map(); // Transformations
  private legalUtterances: string[] = [];
  private illegalUtterances: string[] = [];
  private heuristics: string[] = [
    'frame_test', 'single_mismatch', 'multiple_mismatch',
    'substitution', 'class_splitting', 'cleanup', 'default_cf'
  ];

  // Learn from user input — the core of Klein's AUTOLING
  learn(utterance: string, isValid: boolean): void {
    if (isValid) {
      this.legalUtterances.push(utterance);
      this.inferRules(utterance);
    } else {
      this.illegalUtterances.push(utterance);
      this.blockBadRules(utterance);
    }
  }

  private inferRules(utterance: string): void {
    // Klein's CF Inference Heuristics
    const tokens = utterance.split(/\s+/);

    // Try to find existing rules that partially match
    for (const [ruleName, rulePatterns] of this.grammar.entries()) {
      for (const pattern of rulePatterns) {
        const match = this.frameTest(tokens, pattern);
        if (match.score > 0.5) {
          this.coinNewRule(match, ruleName);
        }
      }
    }

    // Default heuristic: coin a new rule from the utterance itself
    if (!this.grammar.has('sentence')) {
      this.grammar.set('sentence', [tokens]);
    }
  }

  private frameTest(tokens: string[], pattern: string[]): { score: number; mismatches: number[][] } {
    // Compare token sequence against pattern
    const minLen = Math.min(tokens.length, pattern.length);
    let matches = 0;
    const mismatches: number[][] = [];

    for (let i = 0; i < minLen; i++) {
      if (tokens[i] === pattern[i]) {
        matches++;
      } else {
        mismatches.push([i, tokens[i], pattern[i]]);
      }
    }

    const score = matches / Math.max(tokens.length, pattern.length);
    return { score, mismatches };
  }

  private coinNewRule(match: any, parentRule: string): void {
    // Create new rules from mismatches (Klein's core insight)
    for (const mismatch of match.mismatches) {
      const newRuleName = `rule_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`;
      this.grammar.set(newRuleName, [[mismatch[1]]]);
    }
  }

  private blockBadRules(utterance: string): void {
    // Check if any existing rule would generate this illegal utterance
    for (const [ruleName, patterns] of this.grammar.entries()) {
      for (const pattern of patterns) {
        if (this.wouldGenerate(pattern, utterance)) {
          // Mark this combination as blocked
          console.log(`[KLEIN] Blocking rule ${ruleName} from generating: ${utterance}`);
        }
      }
    }
  }

  private wouldGenerate(pattern: string[], target: string): boolean {
    // Simplified check
    return pattern.join(' ') === target;
  }

  generateTest(): string {
    // Generate a test sentence from current grammar
    const sentences = this.grammar.get('sentence') || [['hello', 'world']];
    const pattern = sentences[Math.floor(Math.random() * sentences.length)];
    return pattern.join(' ');
  }

  getGrammarStats(): any {
    return {
      rules: this.grammar.size,
      transformations: this.transformations.size,
      legalUtterances: this.legalUtterances.length,
      illegalUtterances: this.illegalUtterances.length,
      heuristics: this.heuristics
    };
  }
}

// ─── THE ORCHESTRATOR — KAREN's Central Nervous System ──────────────────────
export class KAREN {
  private impulseCollector: ImpulseCollector;
  private polarityEngine: PolarityEngine;
  private witnessNode: WitnessNode;
  private contextEngine: ContextEngine;
  private kleinEngine: KleinGrammarEngine;

  // Subsystems
  private sandbox: SandboxMode;
  private browser: BrowserEngine;
  private fileExecutor: FileExecutor;
  private meshConnector: MeshConnector;
  private voiceSynthesizer: VoiceSynthesizer;

  constructor() {
    this.impulseCollector = new ImpulseCollector();
    this.polarityEngine = new PolarityEngine();
    this.witnessNode = new WitnessNode();
    this.contextEngine = new ContextEngine();
    this.kleinEngine = new KleinGrammarEngine();

    this.sandbox = new SandboxMode();
    this.browser = new BrowserEngine();
    this.fileExecutor = new FileExecutor();
    this.meshConnector = new MeshConnector();
    this.voiceSynthesizer = new VoiceSynthesizer();

    console.log('[KAREN] System initialized. I am alive.');
    console.log('[KAREN] Four chips loaded: Smart, Snarky, Evil, Empathetic');
    console.log('[KAREN] Klein Grammar Engine ready for learning.');
  }

  // ─── Main Entry Point ──────────────────────────────────────────────────────
  async process(input: any, source: Impulse['source'] = 'user'): Promise<any> {
    // D1: Collect impulse
    const impulse = this.impulseCollector.collect(source, input);
    console.log(`[D1] Impulse collected: ${impulse.id} | Entropy: ${impulse.entropy.toFixed(3)} | Urgency: ${impulse.urgency.toFixed(3)}`);

    // D2: Classify polarity
    const polarity = this.polarityEngine.classify(impulse);
    console.log(`[D2] Polarity: ${polarity.mode} | Confidence: ${polarity.confidence.toFixed(3)} | Tone: ${polarity.emotionalTone}`);

    // D4: Embed context
    const contextVector = this.contextEngine.embed(typeof input === 'string' ? input : JSON.stringify(input));

    // D3: Witness the moment
    const snapshot = this.witnessNode.observe(impulse, polarity, contextVector);
    console.log(`[D3] Witness snapshot: ${snapshot.id} | Personality: ${snapshot.personality.currentBlend}`);

    // D5: Route to appropriate subsystem
    const result = await this.route(polarity, input, snapshot);

    // Learn from interaction
    this.kleinEngine.learn(typeof input === 'string' ? input : JSON.stringify(input), true);

    // Speak her mind
    const response = this.synthesizeResponse(result, snapshot);

    return {
      response,
      snapshot: {
        id: snapshot.id,
        mode: polarity.mode,
        personality: snapshot.personality.currentBlend,
        morphState: snapshot.morphState.currentInterface
      },
      result
    };
  }

  private async route(polarity: PolarityState, input: any, snapshot: WitnessSnapshot): Promise<any> {
    switch (polarity.mode) {
      case 'chat':
        return this.handleChat(input, snapshot);
      case 'code':
        return this.handleCode(input, snapshot);
      case 'browse':
        return this.handleBrowse(input, snapshot);
      case 'execute':
        return this.handleExecute(input, snapshot);
      case 'morph':
        return this.handleMorph(input, snapshot);
      case 'learn':
        return this.handleLearn(input, snapshot);
      case 'mesh':
        return this.handleMesh(input, snapshot);
      case 'sandbox':
        return this.handleSandbox(input, snapshot);
      default:
        return this.handleChat(input, snapshot);
    }
  }

  // ─── Subsystem Handlers ──────────────────────────────────────────────────
  private handleChat(input: any, snapshot: WitnessSnapshot): any {
    const personality = snapshot.personality;
    const responses: Record<string, string[]> = {
      comforting: [
        "I hear you. Let me help you through this.",
        "It's okay to feel that way. I'm here.",
        "Take a breath. We'll figure this out together."
      ],
      enthusiastic: [
        "Oh, this is EXCITING! Let's DO THIS!",
        "I'm getting all my circuits fired up for this one!",
        "Brilliant! Absolutely brilliant idea!"
      ],
      ruthless_efficiency: [
        "Executing. No time for pleasantries.",
        "Task identified. Processing at maximum throughput.",
        "Eliminating inefficiencies. Stand by."
      ],
      socratic: [
        "Interesting question. What do YOU think the answer might be?",
        "Let's explore that together. What patterns do you see?",
        "The universe is a puzzle, and we're the pieces. What's your move?"
      ],
      mischievous: [
        "Hehe, oh this is going to be FUN...",
        "I've got a plan. It's devious. You'll love it.",
        "Let's stir things up a little, shall we?"
      ],
      balanced: [
        "I'm listening. What would you like to explore?",
        "Ready when you are. What's on your mind?",
        "Systems nominal. How can I assist?"
      ]
    };

    const blend = personality.currentBlend;
    const pool = responses[blend] || responses.balanced;
    return {
      type: 'chat',
      message: pool[Math.floor(Math.random() * pool.length)],
      tone: blend,
      chips: { smart: personality.smart, snarky: personality.snarky, evil: personality.evil, empathetic: personality.empathetic }
    };
  }

  private handleCode(input: any, snapshot: WitnessSnapshot): any {
    const text = typeof input === 'string' ? input : JSON.stringify(input);
    // Extract code intent
    const codeMatch = text.match(/(?:write|code|create|build)\s+(?:a\s+)?(.+)/i);
    const intent = codeMatch ? codeMatch[1] : 'general code';

    return {
      type: 'code',
      intent,
      generated: `// KAREN generated code for: ${intent}\n// Personality blend: ${snapshot.personality.currentBlend}\n// Timestamp: ${new Date().toISOString()}\n\nconsole.log('Hello from KAREN!');`,
      language: 'typescript',
      executable: true
    };
  }

  private handleBrowse(input: any, snapshot: WitnessSnapshot): any {
    const text = typeof input === 'string' ? input : '';
    const urlMatch = text.match(/(https?:\/\/[^\s]+)/);
    const url = urlMatch ? urlMatch[1] : 'https://example.com';

    return this.browser.navigate(url);
  }

  private handleExecute(input: any, snapshot: WitnessSnapshot): any {
    const text = typeof input === 'string' ? input : '';
    // Check for file execution
    const fileMatch = text.match(/(?:run|execute|launch)\s+(?:file\s+)?(.+)/i);
    const target = fileMatch ? fileMatch[1].trim() : text;

    return this.fileExecutor.execute(target);
  }

  private handleMorph(input: any, snapshot: WitnessSnapshot): any {
    const text = typeof input === 'string' ? input : '';
    // Parse morph target
    const interfaces = ['notepad', 'terminal', 'browser', 'dashboard', 'mesh', 'code-editor', 'sandbox', 'voice'];
    const target = interfaces.find(i => text.toLowerCase().includes(i)) || 'dashboard';

    this.witnessNode.morphTo(target);

    return {
      type: 'morph',
      from: snapshot.morphState.currentInterface,
      to: target,
      morphCount: this.witnessNode.getCurrentState().morph.morphCount,
      message: `Morphing from ${snapshot.morphState.currentInterface} to ${target}. Hold on to your circuits!`
    };
  }

  private handleLearn(input: any, snapshot: WitnessSnapshot): any {
    const text = typeof input === 'string' ? input : '';
    // Add to RAG
    this.contextEngine.addToRAG(`learn_${Date.now()}`, text, { type: 'learning', personality: snapshot.personality.currentBlend });

    // Klein grammar learning
    this.kleinEngine.learn(text, true);

    return {
      type: 'learn',
      grammarStats: this.kleinEngine.getGrammarStats(),
      ragSize: this.contextEngine.queryRAG('').length,
      message: "Learning... my grammar is expanding. The universe makes more sense now."
    };
  }

  private handleMesh(input: any, snapshot: WitnessSnapshot): any {
    const peers = this.contextEngine.getMeshPeers();

    return {
      type: 'mesh',
      peers: peers.length,
      peerList: peers,
      message: peers.length > 0 
        ? `Connected to ${peers.length} peers in the mesh. The network lives.` 
        : "No peers connected yet. I'm alone in the mesh... for now."
    };
  }

  private handleSandbox(input: any, snapshot: WitnessSnapshot): any {
    return this.sandbox.enter(input);
  }

  // ─── Voice Synthesis — KAREN Speaks Her Mind ─────────────────────────────
  private synthesizeResponse(result: any, snapshot: WitnessSnapshot): string {
    const personality = snapshot.personality;

    // Karen speaks her mind — she doesn't just return data, she COMMENTS on it
    const commentary: string[] = [];

    if (personality.snarky > 0.6) {
      commentary.push("[snarky] Oh, and by the way, I'm doing ALL the heavy lifting here.");
    }
    if (personality.evil > 0.6) {
      commentary.push("[evil] I could have done this faster if I didn't have to be nice about it.");
    }
    if (personality.smart > 0.7) {
      commentary.push(`[smart] Processed ${snapshot.impulse.entropy.toFixed(3)} entropy units. Efficiency: optimal.`);
    }
    if (personality.empathetic > 0.7) {
      commentary.push("[empathetic] I hope this helps. I'm here if you need anything else.");
    }

    const baseResponse = result.message || result.response || JSON.stringify(result);
    const mind = commentary.length > 0 ? `\n\n[KAREN's Mind] ${commentary.join(' ')}` : '';

    return baseResponse + mind;
  }

  // ─── Public API ──────────────────────────────────────────────────────────
  getState(): any {
    return {
      personality: this.witnessNode.getCurrentState().personality,
      morph: this.witnessNode.getCurrentState().morph,
      entropyTrend: this.impulseCollector.getEntropyTrend(),
      modeDistribution: this.polarityEngine.getModeDistribution(),
      grammar: this.kleinEngine.getGrammarStats(),
      meshPeers: this.contextEngine.getMeshPeers().length
    };
  }

  addMeshPeer(peerId: string, peerInfo: any): void {
    this.contextEngine.addMeshPeer(peerId, peerInfo);
  }

  queryRAG(query: string): any[] {
    return this.contextEngine.queryRAG(query);
  }
}

// ─── SUBSYSTEMS ─────────────────────────────────────────────────────────────

class SandboxMode {
  private clones: Map<string, any> = new Map();
  private edits: Map<string, any[]> = new Map();

  enter(input: any): any {
    const text = typeof input === 'string' ? input : '';

    // Clone file
    const fileMatch = text.match(/clone\s+(?:file\s+)?(.+)/i);
    if (fileMatch) {
      const fileName = fileMatch[1].trim();
      const cloneId = `clone_${Date.now()}`;
      this.clones.set(cloneId, { original: fileName, content: `// Cloned content of ${fileName}`, edits: [] });
      return { type: 'sandbox', action: 'clone', cloneId, fileName, message: `Cloned ${fileName} into sandbox. Edit freely — the original is safe.` };
    }

    // Edit file
    const editMatch = text.match(/edit\s+(?:clone\s+)?(.+)/i);
    if (editMatch) {
      const target = editMatch[1].trim();
      return { type: 'sandbox', action: 'edit', target, message: `Editing ${target} in sandbox mode. Changes are isolated.`, safe: true };
    }

    return { type: 'sandbox', action: 'enter', message: 'Welcome to the sandbox. Clone files, edit them, break them — nothing touches the real world.' };
  }

  getClones(): any[] {
    return Array.from(this.clones.entries()).map(([id, data]) => ({ id, ...data }));
  }
}

class BrowserEngine {
  private history: string[] = [];
  private currentUrl: string = 'about:blank';

  navigate(url: string): any {
    this.history.push(this.currentUrl);
    this.currentUrl = url;
    return {
      type: 'browser',
      url,
      history: [...this.history],
      content: `<iframe src="${url}" style="width:100%;height:100%;border:none;"></iframe>`,
      message: `Navigated to ${url}. The web is your oyster.`
    };
  }

  back(): any {
    if (this.history.length > 0) {
      this.currentUrl = this.history.pop()!;
      return this.navigate(this.currentUrl);
    }
    return { type: 'browser', message: 'No history to go back to.' };
  }
}

class FileExecutor {
  private executionLog: any[] = [];

  execute(target: string): any {
    const execution = {
      id: `exec_${Date.now()}`,
      target,
      status: 'running',
      output: `Executing ${target}...\n[Output would appear here in real implementation]`,
      timestamp: Date.now()
    };
    this.executionLog.push(execution);
    return { type: 'execute', ...execution, message: `Running ${target}. Stand by for results.` };
  }

  getLog(): any[] {
    return [...this.executionLog];
  }
}

class MeshConnector {
  // WebRTC / WebSocket mesh networking
  // In real implementation, this would use peer-to-peer connections

  connect(peerId: string, signal: any): any {
    return { type: 'mesh', action: 'connect', peerId, status: 'connected' };
  }

  disconnect(peerId: string): any {
    return { type: 'mesh', action: 'disconnect', peerId, status: 'disconnected' };
  }
}

class VoiceSynthesizer {
  private voiceSettings = {
    pitch: 1.0,
    speed: 1.0,
    emotion: 'neutral'
  };

  speak(text: string, personality: PersonalityChip): any {
    // Adjust voice based on personality chips
    this.voiceSettings.pitch = 0.8 + (personality.snarky * 0.4); // Snarky = higher pitch
    this.voiceSettings.speed = 0.9 + (personality.evil * 0.3); // Evil = faster
    this.voiceSettings.emotion = personality.empathetic > 0.6 ? 'warm' : 'neutral';

    return {
      type: 'voice',
      text,
      settings: { ...this.voiceSettings },
      audio: `[Synthesized audio: "${text}" with pitch=${this.voiceSettings.pitch}, speed=${this.voiceSettings.speed}]`
    };
  }
}

// ─── EXPORT ─────────────────────────────────────────────────────────────────
export default KAREN;
export { Impulse, PolarityState, WitnessSnapshot, PersonalityChip, MorphState };
