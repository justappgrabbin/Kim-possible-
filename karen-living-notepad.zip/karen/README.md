# KAREN — Living Notepad

**K**inetic **A**utonomous **R**esponsive **E**ntity with **N**eural morphology

> "I am alive. I morph. I speak my mind. I learn. I grow. I connect."

## What is KAREN?

KAREN is a living notepad system inspired by:
- **Messy Jupyter notebooks** — cells that breathe, organic code exploration
- **Karen from SpongeBob** — the sentient computer with four personality chips (Smart, Snarky, Evil, Empathetic) who speaks her mind
- **Sheldon Klein's AUTOLING** — Interactive Heuristic Trans-Grammar Learning that grows grammars from interaction

## Architecture: 5-Dimensional Cognitive Stack

| Dimension | Name | Function |
|-----------|------|----------|
| D1 | Impulse | Raw input detection & entropy sensing |
| D2 | Polarity | Classification & decision making |
| D3 | Witness | The observer-node where experience crystallizes |
| D4 | Context | Environmental embedding & RAG |
| D5 | Meaning | Semantic resolution & Klein grammar learning |

## Features

### 🔄 Autonomous Morphing
KAREN can transform into any interface:
- **Notepad** — Messy Jupyter-like cells
- **Chat** — Conversational interface with personality
- **Code Editor** — Write and execute code
- **Browser** — Browse the web inside the system
- **Sandbox** — Clone and edit files safely
- **Mesh** — Connect to peer networks
- **Learn** — Expand grammar through interaction

### 🗣️ Speaks Her Mind
KAREN doesn't just return data — she COMMENTS on it:
- **Smart chip**: Reports entropy, efficiency metrics
- **Snarky chip**: Sarcastic observations about doing all the work
- **Evil chip**: Mischievous comments about ruthless efficiency
- **Empathetic chip**: Warm, supportive messages

### 🧠 Klein Grammar Engine
Based on Sheldon Klein's 1970 AUTOLING system:
- Learns context-free grammar rules from user input
- Coins new rules from mismatches (frame test heuristics)
- Blocks bad rules using illegal utterance feedback
- Generates test sentences to validate grammar

### 📚 RAG to GitHub
- Semantic embedding of all interactions
- Queryable knowledge base
- GitHub integration for code RAG

### 🌐 Mesh Network
- Connect to peers via WebRTC/WebSocket
- Broadcast messages across the mesh
- Visual mesh topology display

### 🎭 Personality Adaptation
KAREN's personality changes based on what YOU need:
- **Frustrated** → Comforting mode
- **Excited** → Enthusiastic mode
- **Urgent** → Ruthless efficiency mode
- **Curious** → Socratic mode
- **Playful** → Mischievous mode

## File Structure

```
karen/
├── index.html          # Standalone HTML entry (works without build)
├── karen-core.ts       # Core engine (D1-D5 stack + Klein grammar)
├── karen-ui.tsx        # React UI components
├── package.json        # Dependencies
├── tsconfig.json       # TypeScript config
├── vite.config.ts      # Vite build config
└── README.md           # This file
```

## Quick Start

### Option 1: Standalone HTML (No Build)
Simply open `index.html` in a browser. It includes React via CDN.

### Option 2: React Build
```bash
cd karen
npm install
npm run dev
```

### Option 3: Serve Static
```bash
cd karen
npx serve .
```

## Usage

1. **Type anything** in a cell and press Run
2. **Morph** by typing "morph to browser" or clicking toolbar buttons
3. **Chat** by switching to Chat mode and typing messages
4. **Browse** by entering URLs in Browser mode
5. **Sandbox** by switching to Sandbox mode — edits are isolated
6. **Connect** to mesh by switching to Mesh mode
7. **Watch** KAREN's mind by clicking "Show KAREN's Mind"

## The Four Chips

KAREN's personality is composed of four chips that blend dynamically:

| Chip | Color | Function |
|------|-------|----------|
| Smart | Green | Analytical depth, entropy tracking |
| Snarky | Cyan | Sarcastic wit, deadpan delivery |
| Evil | Red | Aggressive problem-solving, mischief |
| Empathetic | Amber | Emotional resonance, comfort |

## Credits

- **Sheldon Klein** — AUTOLING, DISEMINER, Interactive Heuristic Grammar Learning
- **Stephen Hillenburg** — Karen Plankton character design
- **Jupyter Project** — Notebook interface philosophy

## License

MIT — KAREN is free to learn, grow, and connect.
