// ============================================
// AVATAR TYPES — Human Design Chart Structure
// ============================================

export type HDType = 'Manifestor' | 'Generator' | 'ManifestingGenerator' | 'Projector' | 'Reflector';
export type HDAuthority = 'Sacral' | 'Splenic' | 'Emotional' | 'Ego' | 'Self' | 'Mental' | 'Lunar' | 'None';

export interface HDChart {
  type: HDType;
  authority: HDAuthority;
  profile: [number, number];
  definedCenters: string[];
  openCenters: string[];
  definedChannels: string[];
  openGates: string[];
  incarnationCross: string;
  variables: {
    motivation: string;
    cognition: string;
    environment: string;
    perspective: string;
  };
}

export interface CausalParams {
  initiationStyle: string;
  responseLatency: number;
  pulseRhythm: number;
  interactionDepth: string;
  narrativeStyle: string;
  guidanceMode: string;
  defaultSurface: string;
  secondarySurfaces: string[];
  voiceTone: string;
  gestureStyle: string;
  role: string;
  distance: string;
  consistency: string;
}
