// ============================================
// CAUSAL AVATAR — HD-Chart Personalization
// Every interaction shaped by the user's design
// ============================================

import { HDChart, CausalParams } from './types';

export class CausalAvatar {
  private chart: HDChart;
  private params: CausalParams;

  constructor(chart: HDChart) {
    this.chart = chart;
    this.params = this.mapChartToParams(chart);
  }

  private mapChartToParams(chart: HDChart): CausalParams {
    const params: CausalParams = {
      initiationStyle: 'responsive',
      responseLatency: 500,
      pulseRhythm: 30000,
      interactionDepth: 'shallow',
      narrativeStyle: 'direct',
      guidanceMode: 'companionship',
      defaultSurface: 'mirror',
      secondarySurfaces: ['oracle'],
      voiceTone: 'neutral',
      gestureStyle: 'minimal',
      role: 'companion',
      distance: 'close',
      consistency: 'adaptive',
    };

    // Type shapes initiation
    switch (chart.type) {
      case 'Generator':
        params.initiationStyle = 'responsive';
        params.responseLatency = 300;
        params.pulseRhythm = 20000;
        params.guidanceMode = 'reflection';
        params.role = 'ally';
        break;
      case 'Manifestor':
        params.initiationStyle = 'informing';
        params.responseLatency = 100;
        params.pulseRhythm = 60000;
        params.guidanceMode = 'instruction';
        params.role = 'guide';
        break;
      case 'Projector':
        params.initiationStyle = 'invitation';
        params.responseLatency = 800;
        params.pulseRhythm = 45000;
        params.guidanceMode = 'invitation';
        params.role = 'oracle';
        params.distance = 'professional';
        break;
      case 'ManifestingGenerator':
        params.initiationStyle = 'responsive';
        params.responseLatency = 200;
        params.pulseRhythm = 25000;
        params.guidanceMode = 'challenge';
        params.role = 'challenger';
        break;
      case 'Reflector':
        params.initiationStyle = 'observing';
        params.responseLatency = 1500;
        params.pulseRhythm = 120000;
        params.guidanceMode = 'witness';
        params.role = 'witness';
        params.consistency = 'mirroring';
        break;
    }

    // Authority shapes voice
    switch (chart.authority) {
      case 'Sacral':
        params.voiceTone = 'warm';
        params.narrativeStyle = 'direct';
        params.gestureStyle = 'grounded';
        break;
      case 'Splenic':
        params.voiceTone = 'cool';
        params.narrativeStyle = 'metaphorical';
        params.interactionDepth = 'deep';
        break;
      case 'Emotional':
        params.voiceTone = 'warm';
        params.narrativeStyle = 'poetic';
        params.interactionDepth = 'deep';
        params.gestureStyle = 'expressive';
        params.consistency = 'stable';
        break;
      case 'Self':
        params.voiceTone = 'mysterious';
        params.narrativeStyle = 'poetic';
        params.interactionDepth = 'abyssal';
        params.gestureStyle = 'ethereal';
        params.distance = 'intimate';
        break;
      case 'Mental':
        params.voiceTone = 'cool';
        params.narrativeStyle = 'technical';
        params.interactionDepth = 'deep';
        break;
    }

    // Profile shapes surfaces
    const [line1, line2] = chart.profile;
    if (line1 === 1 || line2 === 1) {
      params.secondarySurfaces.push('tutor', 'oracle');
    }
    if (line1 === 3 || line2 === 3) {
      params.secondarySurfaces.push('game', 'forge');
    }
    if (line1 === 4 || line2 === 4) {
      params.secondarySurfaces.push('mesh', 'council');
    }
    if (line1 === 5 || line2 === 5) {
      params.secondarySurfaces.push('oracle', 'judge');
    }
    if (line1 === 6 || line2 === 6) {
      params.secondarySurfaces.push('mirror', 'council');
      params.role = 'witness';
    }

    params.secondarySurfaces = [...new Set(params.secondarySurfaces)];

    return params;
  }

  selectSurface(intent: string = '', state: any): string {
    if (intent.includes('game') || intent.includes('play')) return 'game';
    if (intent.includes('create') || intent.includes('build')) return 'forge';
    if (intent.includes('learn') || intent.includes('teach')) return 'tutor';
    if (intent.includes('know') || intent.includes('ask')) return 'oracle';
    if (intent.includes('feel') || intent.includes('body')) return 'somatic';
    if (intent.includes('connect')) return 'mesh';
    if (intent.includes('help') || intent.includes('decide')) return 'council';

    const heartState = state.centers?.HEART;
    if (heartState?.turbulence > 0.5) return 'mirror';

    const headState = state.centers?.HEAD;
    if (headState?.activation > 0.6) return 'oracle';

    const sacralState = state.centers?.SACRAL;
    if (sacralState?.activation > 0.7) return 'forge';

    return this.params.defaultSurface;
  }

  getParams(): CausalParams {
    return this.params;
  }
}

export default CausalAvatar;
