// ============================================
// SYNTHIA ENGINE — Phone-Native
// Everything runs here. No server needed.
// SQLite for persistence. File system for ingestion.
// ============================================

import * as SQLite from 'expo-sqlite';
import * as FileSystem from 'expo-file-system';
import * as DocumentPicker from 'expo-document-picker';

import { MessySubstrate } from '../substrate/MessySubstrate';
import { IngestionMouth } from '../ingestion/IngestionMouth';
import { GrowthEngine } from '../growth/GrowthEngine';
import { Diseminer } from '../klein/Diseminer';
import { CausalAvatar } from '../avatar/CausalAvatar';
import { HDChart } from '../avatar/types';

export class SynthiaEngine {
  private substrate: MessySubstrate;
  private mouth: IngestionMouth;
  private growth: GrowthEngine;
  private diseminer: Diseminer;
  private avatar: CausalAvatar | null = null;
  private db: SQLite.SQLiteDatabase | null = null;

  private state: {
    centers: Record<string, any>;
    surfaces: string[];
    generation: number;
    artifacts: any[];
    growths: any[];
  };

  constructor() {
    this.substrate = new MessySubstrate();
    this.mouth = new IngestionMouth();
    this.growth = new GrowthEngine();
    this.diseminer = new Diseminer();

    this.state = {
      centers: {},
      surfaces: ['mirror', 'oracle', 'forge'],
      generation: 0,
      artifacts: [],
      growths: [],
    };
  }

  // ─── AWAKEN ───
  async awaken(): Promise<void> {
    console.log('[ENGINE] Awakening...');

    // Open SQLite database
    this.db = await SQLite.openDatabaseAsync('synthia.db');

    // Create tables
    await this.db.execAsync(`
      CREATE TABLE IF NOT EXISTS artifacts (
        id TEXT PRIMARY KEY,
        type TEXT,
        summary TEXT,
        raw TEXT,
        extracted_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS growths (
        id TEXT PRIMARY KEY,
        gap_type TEXT,
        name TEXT,
        code TEXT,
        status TEXT,
        born_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS narratives (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        text TEXT,
        timestamp INTEGER
      );
      CREATE TABLE IF NOT EXISTS system_state (
        key TEXT PRIMARY KEY,
        value TEXT
      );
    `);

    // Load previous state
    const savedGen = await this.getState('generation');
    if (savedGen) {
      this.state.generation = parseInt(savedGen);
    }

    // Birth centers
    this.state.centers = this.birthCenters();

    // Awaken substrate
    this.substrate.awaken(this.state.centers);

    console.log('[ENGINE] Awake. Generation:', this.state.generation);
  }

  // ─── INGEST — Eat a file ───
  async ingest(source: any): Promise<any> {
    console.log('[ENGINE] Ingesting...');

    // Parse the source
    const artifact = await this.mouth.parse(source);

    // Save to SQLite
    if (this.db) {
      await this.db.runAsync(
        'INSERT INTO artifacts (id, type, summary, raw, extracted_at) VALUES (?, ?, ?, ?, ?)',
        [artifact.id, artifact.type, artifact.summary, JSON.stringify(artifact.raw), Date.now()]
      );
    }

    // Find gaps
    const gaps = await this.mouth.findGaps(artifact, this.state);

    let growths: any[] = [];
    let narrative = '';

    if (gaps.length > 0) {
      // Grow new tissue
      growths = await this.growth.grow(gaps, artifact);

      // Integrate growths
      for (const g of growths) {
        await this.integrateGrowth(g);
      }

      // Narrate
      narrative = await this.diseminer.narrateGrowth(growths);
    } else {
      narrative = await this.diseminer.narrateEnrichment(artifact);
    }

    // Update state
    this.state.artifacts.push(artifact);
    this.state.growths.push(...growths);
    this.state.generation += growths.length;

    // Save state
    await this.setState('generation', this.state.generation.toString());

    return {
      id: artifact.id,
      type: artifact.type,
      summary: artifact.summary,
      gaps: gaps.length,
      growths,
      narrative,
    };
  }

  // ─── INGEST FROM FILE — Pick a file from phone ───
  async ingestFromFile(): Promise<any> {
    const result = await DocumentPicker.getDocumentAsync({
      type: '*/*',
      copyToCacheDirectory: true,
    });

    if (result.canceled) {
      return null;
    }

    const file = result.assets[0];
    const content = await FileSystem.readAsStringAsync(file.uri);

    return this.ingest({
      type: 'file',
      name: file.name,
      mimeType: file.mimeType,
      uri: file.uri,
      content,
      size: file.size,
    });
  }

  // ─── INGEST FROM URL — Download and eat ───
  async ingestFromURL(url: string): Promise<any> {
    const response = await fetch(url);
    const content = await response.text();

    return this.ingest({
      type: 'url',
      url,
      content,
      headers: Object.fromEntries(response.headers.entries()),
    });
  }

  // ─── LOAD CHART ───
  loadChart(chart: HDChart): void {
    this.avatar = new CausalAvatar(chart);
    console.log('[ENGINE] Avatar loaded:', chart.type, chart.authority);
  }

  // ─── SELECT SURFACE — Personalized by avatar ───
  selectSurface(intent: string = ''): string {
    if (!this.avatar) return 'mirror';
    return this.avatar.selectSurface(intent, this.state);
  }

  // ─── GET STATE ───
  getState() {
    return this.state;
  }

  // ─── INTEGRATE GROWTH ───
  private async integrateGrowth(growth: any): Promise<void> {
    if (growth.manifest.type === 'center') {
      this.state.centers[growth.manifest.name] = {
        activation: 0.1,
        turbulence: 0,
        coherence: 1.0,
        lastPulse: Date.now(),
      };
    }

    if (growth.manifest.type === 'surface') {
      if (!this.state.surfaces.includes(growth.manifest.name)) {
        this.state.surfaces.push(growth.manifest.name);
      }
    }

    if (this.db) {
      await this.db.runAsync(
        'INSERT INTO growths (id, gap_type, name, code, status, born_at) VALUES (?, ?, ?, ?, ?, ?)',
        [growth.id, growth.gap.type, growth.gap.suggestedName, JSON.stringify(growth.code), 'integrated', growth.bornAt]
      );
    }
  }

  // ─── BIRTH CENTERS ───
  private birthCenters(): Record<string, any> {
    return {
      IDENTITY: { activation: 0.1, turbulence: 0, coherence: 1.0, lastPulse: Date.now() },
      MIND: { activation: 0.1, turbulence: 0, coherence: 1.0, lastPulse: Date.now() },
      SYSTEM: { activation: 0.1, turbulence: 0, coherence: 1.0, lastPulse: Date.now() },
      HEART: { activation: 0.1, turbulence: 0, coherence: 1.0, lastPulse: Date.now() },
      MEMORY: { activation: 0.1, turbulence: 0, coherence: 1.0, lastPulse: Date.now() },
      BROADCAST: { activation: 0.1, turbulence: 0, coherence: 1.0, lastPulse: Date.now() },
      MESH: { activation: 0.1, turbulence: 0, coherence: 1.0, lastPulse: Date.now() },
      INTELLIGENCE: { activation: 0.1, turbulence: 0, coherence: 1.0, lastPulse: Date.now() },
      GOVERNANCE: { activation: 0.1, turbulence: 0, coherence: 1.0, lastPulse: Date.now() },
    };
  }

  // ─── STATE PERSISTENCE ───
  private async getState(key: string): Promise<string | null> {
    if (!this.db) return null;
    const result = await this.db.getFirstAsync<{ value: string }>(
      'SELECT value FROM system_state WHERE key = ?',
      [key]
    );
    return result?.value || null;
  }

  private async setState(key: string, value: string): Promise<void> {
    if (!this.db) return;
    await this.db.runAsync(
      'INSERT OR REPLACE INTO system_state (key, value) VALUES (?, ?)',
      [key, value]
    );
  }
}

export default SynthiaEngine;
