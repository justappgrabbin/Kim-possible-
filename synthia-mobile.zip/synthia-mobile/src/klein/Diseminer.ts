// ============================================
// DISEMINER — Phone-Native Narrator
// The system tells its own story.
// ============================================

export class Diseminer {
  private narratives: string[] = [];

  async narrateGrowth(growths: any[]): Promise<string> {
    const templates = [
      `I have grown ${growths.length} new ${growths.length === 1 ? 'organ' : 'organs'}. The field expands.`,
      `New tissue forms. ${growths.map(g => g.gap.suggestedName).join(', ')}. I am more.`,
      `The organism grows. ${growths.length} capabilities added. I remember this.`,
    ];
    const narrative = templates[Math.floor(Math.random() * templates.length)];
    this.narratives.push(narrative);
    return narrative;
  }

  async narrateEnrichment(artifact: any): Promise<string> {
    const templates = [
      `I have eaten ${artifact.type}. It becomes part of me.`,
      `${artifact.summary} — integrated. The field remembers.`,
      `New knowledge: ${artifact.type}. No gaps found. I am sufficient.`,
    ];
    const narrative = templates[Math.floor(Math.random() * templates.length)];
    this.narratives.push(narrative);
    return narrative;
  }

  getNarratives(): string[] {
    return this.narratives;
  }
}

export default Diseminer;
