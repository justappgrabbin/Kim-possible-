// ============================================
// HOME SCREEN — The Pulse
// The organism's heartbeat visualized.
// 9 centers as living nodes. Touch to feel.
// ============================================

import React, { useEffect, useRef } from 'react';
import { StyleSheet, View, Text, Animated, TouchableOpacity, ScrollView } from 'react-native';
import { useSynthiaStore } from '../hooks/useSynthiaStore';

const CENTER_COLORS: Record<string, string> = {
  IDENTITY: '#c4a4ff',
  MIND: '#a4c4ff',
  SYSTEM: '#a4ffa4',
  HEART: '#ffa4a4',
  MEMORY: '#ffffa4',
  BROADCAST: '#ffa4ff',
  MESH: '#a4ffff',
  INTELLIGENCE: '#ffc4a4',
  GOVERNANCE: '#c4c4c4',
};

const CENTER_POSITIONS = [
  { name: 'IDENTITY', x: 0, y: -120 },
  { name: 'MIND', x: 80, y: -60 },
  { name: 'SYSTEM', x: -80, y: -60 },
  { name: 'HEART', x: 0, y: -40 },
  { name: 'MEMORY', x: 0, y: 40 },
  { name: 'BROADCAST', x: 0, y: 80 },
  { name: 'MESH', x: -100, y: 100 },
  { name: 'INTELLIGENCE', x: 100, y: 100 },
  { name: 'GOVERNANCE', x: 0, y: 140 },
];

export function HomeScreen() {
  const centers = useSynthiaStore((s) => s.centers);
  const generation = useSynthiaStore((s) => s.generation);
  const narratives = useSynthiaStore((s) => s.narratives);
  const currentSurface = useSynthiaStore((s) => s.currentSurface);

  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  const latestNarrative = narratives[narratives.length - 1] || 'I am here.';

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Synthia</Text>
        <Text style={styles.generation}>Gen {generation}</Text>
      </View>

      {/* Bodygraph — 9 centers as living nodes */}
      <View style={styles.bodygraph}>
        <Animated.View
          style={[
            styles.field,
            { transform: [{ scale: pulseAnim }] },
          ]}
        />

        {CENTER_POSITIONS.map((pos) => {
          const center = centers[pos.name] || { activation: 0.1, turbulence: 0 };
          const size = 20 + center.activation * 40;
          const opacity = 0.3 + center.activation * 0.7;

          return (
            <TouchableOpacity
              key={pos.name}
              style={[
                styles.center,
                {
                  transform: [
                    { translateX: pos.x },
                    { translateY: pos.y },
                  ],
                  width: size,
                  height: size,
                  borderRadius: size / 2,
                  backgroundColor: CENTER_COLORS[pos.name],
                  opacity,
                  borderWidth: center.turbulence > 0.5 ? 2 : 0,
                  borderColor: '#fff',
                },
              ]}
              onPress={() => {
                // Touching a center activates it
                console.log(`[HOME] Center touched: ${pos.name}`);
              }}
            >
              <Text style={styles.centerLabel}>{pos.name[0]}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Narrative */}
      <View style={styles.narrativeBox}>
        <Text style={styles.narrative}>{latestNarrative}</Text>
      </View>

      {/* Current Surface */}
      <View style={styles.surfaceBadge}>
        <Text style={styles.surfaceText}>{currentSurface}</Text>
      </View>

      {/* Stats */}
      <ScrollView horizontal style={styles.stats} showsHorizontalScrollIndicator={false}>
        {Object.entries(centers).map(([name, state]) => (
          <View key={name} style={styles.stat}>
            <Text style={styles.statName}>{name}</Text>
            <Text style={styles.statValue}>{(state.activation * 100).toFixed(0)}%</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    alignItems: 'center',
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 24,
    marginBottom: 20,
  },
  title: {
    color: '#a4a4ff',
    fontSize: 28,
    fontWeight: '200',
    letterSpacing: 4,
  },
  generation: {
    color: '#666',
    fontSize: 14,
    marginTop: 8,
  },
  bodygraph: {
    width: 300,
    height: 400,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  field: {
    position: 'absolute',
    width: 200,
    height: 200,
    borderRadius: 100,
    backgroundColor: 'rgba(100, 100, 255, 0.05)',
  },
  center: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
  },
  centerLabel: {
    color: '#000',
    fontSize: 10,
    fontWeight: 'bold',
  },
  narrativeBox: {
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    padding: 16,
    marginHorizontal: 24,
    marginTop: 20,
    width: '90%',
  },
  narrative: {
    color: '#ccc',
    fontSize: 14,
    lineHeight: 20,
    fontStyle: 'italic',
  },
  surfaceBadge: {
    backgroundColor: '#2a2a4a',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginTop: 16,
  },
  surfaceText: {
    color: '#a4a4ff',
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 2,
  },
  stats: {
    marginTop: 20,
    paddingHorizontal: 16,
  },
  stat: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 12,
    marginRight: 8,
    alignItems: 'center',
    minWidth: 80,
  },
  statName: {
    color: '#888',
    fontSize: 10,
    textTransform: 'uppercase',
  },
  statValue: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 4,
  },
});
