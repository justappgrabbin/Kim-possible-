// ============================================
// BODY SCREEN — Full Bodygraph
// 64 gates, 9 centers, channels.
// The user's design as a living map.
// ============================================

import React from 'react';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import { useSynthiaStore } from '../hooks/useSynthiaStore';

export function BodyScreen() {
  const centers = useSynthiaStore((s) => s.centers);
  const userChart = useSynthiaStore((s) => s.userChart);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Body</Text>

      {userChart && (
        <View style={styles.chartInfo}>
          <Text style={styles.chartType}>{userChart.type}</Text>
          <Text style={styles.chartAuthority}>{userChart.authority}</Text>
          <Text style={styles.chartProfile}>{userChart.profile.join('/')}</Text>
        </View>
      )}

      <ScrollView style={styles.centers}>
        {Object.entries(centers).map(([name, state]) => (
          <View key={name} style={styles.centerRow}>
            <View style={styles.centerBar}>
              <View 
                style={[
                  styles.centerFill, 
                  { 
                    width: `${state.activation * 100}%`,
                    backgroundColor: state.turbulence > 0.5 ? '#c44' : '#4a4',
                  }
                ]} 
              />
            </View>
            <Text style={styles.centerName}>{name}</Text>
            <Text style={styles.centerValue}>{(state.activation * 100).toFixed(0)}%</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    paddingTop: 60,
    paddingHorizontal: 24,
  },
  title: {
    color: '#a4a4ff',
    fontSize: 32,
    fontWeight: '200',
    letterSpacing: 4,
  },
  chartInfo: {
    marginTop: 20,
    marginBottom: 24,
  },
  chartType: {
    color: '#fff',
    fontSize: 24,
  },
  chartAuthority: {
    color: '#a4a4ff',
    fontSize: 16,
    marginTop: 4,
  },
  chartProfile: {
    color: '#666',
    fontSize: 14,
    marginTop: 4,
  },
  centers: {
    flex: 1,
  },
  centerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  centerBar: {
    flex: 1,
    height: 8,
    backgroundColor: '#1a1a1a',
    borderRadius: 4,
    overflow: 'hidden',
  },
  centerFill: {
    height: '100%',
    borderRadius: 4,
  },
  centerName: {
    color: '#888',
    fontSize: 12,
    width: 100,
    marginLeft: 12,
    textTransform: 'uppercase',
  },
  centerValue: {
    color: '#fff',
    fontSize: 12,
    width: 40,
    textAlign: 'right',
  },
});
