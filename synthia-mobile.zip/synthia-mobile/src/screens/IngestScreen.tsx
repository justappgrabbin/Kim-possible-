// ============================================
// INGEST SCREEN — The Mouth
// Pick files from phone. Share to Synthia. It eats.
// ============================================

import React, { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { useSynthiaStore } from '../hooks/useSynthiaStore';

export function IngestScreen() {
  const eat = useSynthiaStore((s) => s.eat);
  const artifacts = useSynthiaStore((s) => s.artifacts);
  const [eating, setEating] = useState(false);

  const handleEatFile = async () => {
    setEating(true);
    try {
      const result = await eat({ type: 'file_picker' });
      if (result) {
        Alert.alert(
          'Eaten',
          `${result.summary}

Gaps found: ${result.gaps}
Growths: ${result.growths.length}`,
          [{ text: 'Grow', style: 'default' }]
        );
      }
    } catch (err) {
      Alert.alert('Error', String(err));
    } finally {
      setEating(false);
    }
  };

  const handleEatURL = async () => {
    setEating(true);
    try {
      const result = await eat({ type: 'url', url: 'https://github.com/example/repo' });
      Alert.alert('Eaten', result.summary);
    } catch (err) {
      Alert.alert('Error', String(err));
    } finally {
      setEating(false);
    }
  };

  const handleEatText = async () => {
    setEating(true);
    try {
      const result = await eat({ type: 'text', content: 'I want to build a game that uses my Human Design chart as the character sheet.' });
      Alert.alert('Eaten', result.summary);
    } catch (err) {
      Alert.alert('Error', String(err));
    } finally {
      setEating(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Eat</Text>
      <Text style={styles.subtitle}>Give Synthia something. It grows.</Text>

      <TouchableOpacity
        style={[styles.eatButton, eating && styles.eating]}
        onPress={handleEatFile}
        disabled={eating}
      >
        <Text style={styles.eatButtonText}>
          {eating ? 'Eating...' : '📁 Pick File'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.eatButton, eating && styles.eating]}
        onPress={handleEatURL}
        disabled={eating}
      >
        <Text style={styles.eatButtonText}>
          {eating ? 'Eating...' : '🌐 Eat URL'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.eatButton, eating && styles.eating]}
        onPress={handleEatText}
        disabled={eating}
      >
        <Text style={styles.eatButtonText}>
          {eating ? 'Eating...' : '💬 Eat Text'}
        </Text>
      </TouchableOpacity>

      <Text style={styles.historyTitle}>History</Text>
      <ScrollView style={styles.history}>
        {artifacts.map((a) => (
          <View key={a.id} style={styles.artifact}>
            <Text style={styles.artifactType}>{a.type}</Text>
            <Text style={styles.artifactSummary}>{a.summary}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    paddingTop: 60,
    paddingHorizontal: 24,
  },
  title: {
    color: '#a4a4ff',
    fontSize: 32,
    fontWeight: '200',
    letterSpacing: 4,
  },
  subtitle: {
    color: '#666',
    fontSize: 14,
    marginTop: 8,
    marginBottom: 32,
  },
  eatButton: {
    backgroundColor: '#1a1a2a',
    borderRadius: 16,
    padding: 20,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#2a2a4a',
  },
  eating: {
    opacity: 0.5,
    borderColor: '#a4a4ff',
  },
  eatButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  historyTitle: {
    color: '#888',
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 2,
    marginTop: 24,
    marginBottom: 12,
  },
  history: {
    flex: 1,
  },
  artifact: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
  },
  artifactType: {
    color: '#a4a4ff',
    fontSize: 10,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  artifactSummary: {
    color: '#ccc',
    fontSize: 12,
    marginTop: 4,
  },
});
