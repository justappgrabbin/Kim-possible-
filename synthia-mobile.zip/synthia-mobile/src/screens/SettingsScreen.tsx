// ============================================
// SETTINGS SCREEN — Self
// Load your HD chart. Configure the organism.
// ============================================

import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import { useSynthiaStore } from '../hooks/useSynthiaStore';

export function SettingsScreen() {
  const loadChart = useSynthiaStore((s) => s.loadChart);
  const userChart = useSynthiaStore((s) => s.userChart);
  const [type, setType] = useState('Generator');
  const [authority, setAuthority] = useState('Sacral');
  const [profile, setProfile] = useState('1/3');

  const handleLoadChart = () => {
    const [p1, p2] = profile.split('/').map(Number);
    loadChart({
      type: type as any,
      authority: authority as any,
      profile: [p1, p2],
      definedCenters: ['SACRAL', 'ROOT', 'SPLEEN'],
      openCenters: ['HEAD', 'AJNA', 'THROAT', 'G', 'HEART', 'SOLAR'],
      definedChannels: ['3-60', '42-53', '9-52'],
      openGates: ['1', '2', '4', '5', '6', '7', '8', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '43', '44', '45', '46', '47', '48', '49', '50', '51', '54', '55', '56', '57', '58', '59', '61', '62', '63', '64'],
      incarnationCross: 'Left Angle Cross of the Unexpected',
      variables: {
        motivation: 'Need',
        cognition: 'Smell',
        environment: 'Caves',
        perspective: 'Personal',
      },
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Self</Text>

      <ScrollView style={styles.form}>
        <Text style={styles.label}>Type</Text>
        <TextInput
          style={styles.input}
          value={type}
          onChangeText={setType}
          placeholder="Generator"
          placeholderTextColor="#444"
        />

        <Text style={styles.label}>Authority</Text>
        <TextInput
          style={styles.input}
          value={authority}
          onChangeText={setAuthority}
          placeholder="Sacral"
          placeholderTextColor="#444"
        />

        <Text style={styles.label}>Profile</Text>
        <TextInput
          style={styles.input}
          value={profile}
          onChangeText={setProfile}
          placeholder="1/3"
          placeholderTextColor="#444"
        />

        <TouchableOpacity style={styles.button} onPress={handleLoadChart}>
          <Text style={styles.buttonText}>Load Chart</Text>
        </TouchableOpacity>

        {userChart && (
          <View style={styles.chartDisplay}>
            <Text style={styles.chartTitle}>Loaded Chart</Text>
            <Text style={styles.chartText}>{userChart.type}</Text>
            <Text style={styles.chartText}>{userChart.authority}</Text>
            <Text style={styles.chartText}>{userChart.profile.join('/')}</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    paddingTop: 60,
    paddingHorizontal: 24,
  },
  title: {
    color: '#a4a4ff',
    fontSize: 32,
    fontWeight: '200',
    letterSpacing: 4,
  },
  form: {
    marginTop: 24,
  },
  label: {
    color: '#888',
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 2,
    marginTop: 16,
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    color: '#fff',
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#2a2a2a',
  },
  button: {
    backgroundColor: '#2a2a4a',
    borderRadius: 12,
    padding: 16,
    marginTop: 24,
    alignItems: 'center',
  },
  buttonText: {
    color: '#a4a4ff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  chartDisplay: {
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    padding: 16,
    marginTop: 24,
  },
  chartTitle: {
    color: '#888',
    fontSize: 12,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  chartText: {
    color: '#fff',
    fontSize: 16,
    marginTop: 4,
  },
});
