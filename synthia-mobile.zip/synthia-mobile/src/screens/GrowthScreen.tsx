// ============================================
// GROWTH SCREEN — See What Has Grown
// New organs, new surfaces, new capabilities.
// The organism's growth history.
// ============================================

import React from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { useSynthiaStore } from '../hooks/useSynthiaStore';

export function GrowthScreen() {
  const growths = useSynthiaStore((s) => s.growths);
  const generation = useSynthiaStore((s) => s.generation);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'growing': return '#a4a4ff';
      case 'ready': return '#a4ffa4';
      case 'integrated': return '#ffa4a4';
      default: return '#888';
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Growth</Text>
      <Text style={styles.subtitle}>Generation {generation} — {growths.length} organs grown</Text>

      <ScrollView style={styles.list}>
        {growths.length === 0 && (
          <View style={styles.empty}>
            <Text style={styles.emptyText}>No growth yet.</Text>
            <Text style={styles.emptySub}>Go to Eat and feed the organism.</Text>
          </View>
        )}

        {growths.map((g) => (
          <View key={g.id} style={styles.growth}>
            <View style={styles.growthHeader}>
              <Text style={styles.growthType}>{g.type}</Text>
              <View style={[styles.status, { backgroundColor: getStatusColor(g.status) }]}>
                <Text style={styles.statusText}>{g.status}</Text>
              </View>
            </View>
            <Text style={styles.growthName}>{g.name}</Text>
            <Text style={styles.growthTime}>
              {new Date(g.bornAt).toLocaleDateString()}
            </Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    paddingTop: 60,
    paddingHorizontal: 24,
  },
  title: {
    color: '#a4a4ff',
    fontSize: 32,
    fontWeight: '200',
    letterSpacing: 4,
  },
  subtitle: {
    color: '#666',
    fontSize: 14,
    marginTop: 8,
    marginBottom: 24,
  },
  list: {
    flex: 1,
  },
  empty: {
    alignItems: 'center',
    marginTop: 100,
  },
  emptyText: {
    color: '#666',
    fontSize: 18,
  },
  emptySub: {
    color: '#444',
    fontSize: 14,
    marginTop: 8,
  },
  growth: {
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderLeftWidth: 3,
    borderLeftColor: '#a4a4ff',
  },
  growthHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  growthType: {
    color: '#888',
    fontSize: 10,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  status: {
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  statusText: {
    color: '#000',
    fontSize: 10,
    fontWeight: 'bold',
  },
  growthName: {
    color: '#fff',
    fontSize: 16,
    marginTop: 8,
  },
  growthTime: {
    color: '#666',
    fontSize: 12,
    marginTop: 4,
  },
});
