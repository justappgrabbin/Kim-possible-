// ============================================
// MESSY SUBSTRATE — Phone-Native Living Tissue
// Symbolic yields interfere. Standing waves activate centers.
// Not a router. Living tissue.
// ============================================

export interface Yield {
  layer: number;
  source: string;
  signal: string;
  frequency: number;
  amplitude: number;
  phase: number;
  confidence: number;
  metadata: Record<string, any>;
}

export interface StandingWave {
  frequency: number;
  centers: string[];
  amplitude: number;
}

export class MessySubstrate {
  private yields: Yield[] = [];
  private waves: StandingWave[] = [];
  private centers: Record<string, any> = {};
  private isAlive: boolean = false;
  private heartbeat: any = null;

  awaken(initialCenters: Record<string, any>): void {
    this.centers = initialCenters;
    this.isAlive = true;

    // Start heartbeat
    this.heartbeat = setInterval(() => this.pulse(), 1000);
    console.log('[MESSY] Substrate awakened. Field pulsing.');
  }

  sleep(): void {
    this.isAlive = false;
    if (this.heartbeat) {
      clearInterval(this.heartbeat);
      this.heartbeat = null;
    }
  }

  private pulse(): void {
    if (!this.isAlive) return;

    // Collect yields from all centers
    for (const [name, center] of Object.entries(this.centers)) {
      const yield_: Yield = {
        layer: this.inferLayer(name),
        source: name,
        signal: `${name.toLowerCase()}_pulse`,
        frequency: this.inferFrequency(name),
        amplitude: center.activation || 0.1,
        phase: Date.now() % 1000,
        confidence: center.coherence || 0.5,
        metadata: { activation: center.activation, turbulence: center.turbulence },
      };
      this.yields.push(yield_);
    }

    // Interfere
    this.waves = this.interfere(this.yields);

    // Activate centers from standing waves
    for (const wave of this.waves) {
      for (const centerName of wave.centers) {
        if (this.centers[centerName]) {
          this.centers[centerName].activation = Math.min(1, this.centers[centerName].activation + 0.02);
          this.centers[centerName].lastPulse = Date.now();
        }
      }
    }

    // Decay old yields
    this.yields = [];
  }

  private interfere(yields: Yield[]): StandingWave[] {
    const freqMap: Record<number, { amplitude: number; centers: string[] }> = {};

    for (const y of yields) {
      if (!freqMap[y.frequency]) {
        freqMap[y.frequency] = { amplitude: 0, centers: [] };
      }
      freqMap[y.frequency].amplitude += y.amplitude * y.confidence;
      freqMap[y.frequency].centers.push(y.source);
    }

    const waves: StandingWave[] = [];
    for (const [freq, data] of Object.entries(freqMap)) {
      if (data.amplitude > 0.3) {
        waves.push({
          frequency: Number(freq),
          centers: [...new Set(data.centers)],
          amplitude: data.amplitude,
        });
      }
    }

    return waves.sort((a, b) => b.amplitude - a.amplitude);
  }

  private inferLayer(name: string): number {
    const surface = ['IDENTITY', 'HEART', 'MESH'];
    const tactical = ['MIND', 'INTELLIGENCE'];
    const strategic = ['MEMORY', 'BROADCAST'];
    const meta = ['SYSTEM', 'GOVERNANCE'];

    if (surface.includes(name)) return 1;
    if (tactical.includes(name)) return 2;
    if (strategic.includes(name)) return 3;
    return 4;
  }

  private inferFrequency(name: string): number {
    const freqs: Record<string, number> = {
      IDENTITY: 396, MIND: 528, SYSTEM: 639, HEART: 741,
      MEMORY: 852, BROADCAST: 963, MESH: 417, INTELLIGENCE: 432, GOVERNANCE: 144,
    };
    return freqs[name] || 360;
  }

  getCenters(): Record<string, any> {
    return this.centers;
  }

  getWaves(): StandingWave[] {
    return this.waves;
  }
}

export default MessySubstrate;
