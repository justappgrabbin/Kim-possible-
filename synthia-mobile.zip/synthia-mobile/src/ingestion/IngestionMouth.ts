// ============================================
// INGESTION MOUTH — Phone-Native
// Picks files from phone. Parses. Finds gaps.
// ============================================

import * as DocumentPicker from 'expo-document-picker';

export interface ParsedArtifact {
  id: string;
  type: string;
  raw: any;
  summary: string;
  requiredCapabilities: string[];
  requiredInputs: string[];
  requiredOutputs: string[];
  requiredReasoning: string[];
  intendedInteraction: string;
  requiresExternalAI: boolean;
  requiredModel?: string;
}

export interface Gap {
  id: string;
  type: string;
  reason: string;
  suggestedName: string;
  suggestedConfig: Record<string, any>;
  priority: number;
  trigger: string;
}

export class IngestionMouth {
  async parse(source: any): Promise<ParsedArtifact> {
    if (source.type === 'file_picker') {
      const result = await DocumentPicker.getDocumentAsync({ type: '*/*' });
      if (result.canceled) throw new Error('User cancelled');
      const file = result.assets[0];
      return this.parseFile(file);
    }

    if (source.type === 'url') {
      return this.parseURL(source.url);
    }

    if (source.type === 'text') {
      return this.parseText(source.content);
    }

    return this.parseUnknown(source);
  }

  private parseFile(file: any): ParsedArtifact {
    const id = `file_${Date.now()}`;
    const type = this.inferType(file.name);

    return {
      id,
      type,
      raw: file,
      summary: `File: ${file.name} (${(file.size / 1024).toFixed(1)}KB)`,
      requiredCapabilities: this.inferCapabilities(type),
      requiredInputs: ['file'],
      requiredOutputs: ['analysis', 'integration'],
      requiredReasoning: ['pattern-matching'],
      intendedInteraction: 'view',
      requiresExternalAI: type === 'image' || type === 'audio',
      requiredModel: type === 'image' ? 'gemini' : type === 'audio' ? 'whisper' : undefined,
    };
  }

  private parseURL(url: string): ParsedArtifact {
    const id = `url_${Date.now()}`;
    return {
      id,
      type: 'url',
      raw: url,
      summary: `URL: ${url.substring(0, 50)}...`,
      requiredCapabilities: ['web-scraping', 'content-extraction'],
      requiredInputs: ['url'],
      requiredOutputs: ['content'],
      requiredReasoning: ['semantic-analysis'],
      intendedInteraction: 'browse',
      requiresExternalAI: false,
    };
  }

  private parseText(content: string): ParsedArtifact {
    const id = `text_${Date.now()}`;
    return {
      id,
      type: 'text',
      raw: content,
      summary: `Text: ${content.substring(0, 100)}...`,
      requiredCapabilities: ['text-processing'],
      requiredInputs: ['text'],
      requiredOutputs: ['analysis'],
      requiredReasoning: ['semantic-analysis'],
      intendedInteraction: 'read',
      requiresExternalAI: true,
      requiredModel: 'claude',
    };
  }

  private parseUnknown(source: any): ParsedArtifact {
    return {
      id: `unknown_${Date.now()}`,
      type: 'unknown',
      raw: source,
      summary: 'Unknown content',
      requiredCapabilities: ['type-detection'],
      requiredInputs: [],
      requiredOutputs: ['analysis'],
      requiredReasoning: ['pattern-matching'],
      intendedInteraction: 'examine',
      requiresExternalAI: true,
      requiredModel: 'claude',
    };
  }

  private inferType(filename: string): string {
    if (filename.match(/\.(jpg|jpeg|png|gif|webp)$/i)) return 'image';
    if (filename.match(/\.(mp3|wav|aac|ogg)$/i)) return 'audio';
    if (filename.match(/\.(mp4|mov|avi|webm)$/i)) return 'video';
    if (filename.match(/\.(pdf|epub)$/i)) return 'pdf';
    if (filename.match(/\.(js|ts|jsx|tsx|py|java|cpp|go|rs)$/i)) return 'code';
    if (filename.match(/\.(json|xml|yaml|yml)$/i)) return 'data';
    return 'file';
  }

  private inferCapabilities(type: string): string[] {
    const caps: Record<string, string[]> = {
      image: ['image-analysis', 'visual-rendering'],
      audio: ['audio-processing', 'speech-recognition'],
      video: ['video-processing', 'frame-analysis'],
      pdf: ['text-extraction', 'document-analysis'],
      code: ['code-analysis', 'syntax-parsing'],
      data: ['data-parsing', 'schema-extraction'],
      file: ['file-handling', 'content-analysis'],
    };
    return caps[type] || ['content-analysis'];
  }

  async findGaps(artifact: ParsedArtifact, systemState: any): Promise<Gap[]> {
    const gaps: Gap[] = [];

    for (const cap of artifact.requiredCapabilities) {
      if (!systemState.surfaces.includes(cap)) {
        gaps.push({
          id: `gap_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          type: 'MISSING_CAPABILITY',
          reason: `System lacks: ${cap}`,
          suggestedName: cap,
          suggestedConfig: { source: artifact.id },
          priority: 0.8,
          trigger: artifact.id,
        });
      }
    }

    if (artifact.requiresExternalAI && artifact.requiredModel) {
      gaps.push({
        id: `gap_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        type: 'NEW_MCP',
        reason: `Needs AI: ${artifact.requiredModel}`,
        suggestedName: `${artifact.requiredModel}_connector`,
        suggestedConfig: { model: artifact.requiredModel },
        priority: 0.9,
        trigger: artifact.id,
      });
    }

    return gaps;
  }
}

export default IngestionMouth;
