// ============================================
// SYNTHIA CONTEXT — React Provider
// Makes the organism available to all components
// ============================================

import React, { createContext, useContext, ReactNode } from 'react';
import { useSynthiaStore } from './useSynthiaStore';

const SynthiaContext = createContext<any>(null);

export function SynthiaProvider({ children }: { children: ReactNode }) {
  const store = useSynthiaStore();

  return (
    <SynthiaContext.Provider value={store}>
      {children}
    </SynthiaContext.Provider>
  );
}

export function useSynthia() {
  return useContext(SynthiaContext);
}
