// ============================================
// SYNTHIA STORE — Zustand
// The organism's state lives here. Phone-native.
// No server required. Everything is local first.
// ============================================

import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { persist, createJSONStorage } from 'zustand/middleware';

import { SynthiaEngine } from '../core/SynthiaEngine';
import { HDChart } from '../avatar/types';

export interface OrganismState {
  // Life
  alive: boolean;
  generation: number;
  bornAt: number;
  lastPulse: number;

  // Centers (9)
  centers: Record<string, {
    activation: number;
    turbulence: number;
    coherence: number;
    lastPulse: number;
  }>;

  // Surfaces (10)
  surfaces: string[];

  // Growth
  growths: Array<{
    id: string;
    type: string;
    name: string;
    bornAt: number;
    status: 'growing' | 'ready' | 'integrated';
  }>;

  // Avatar
  userChart: HDChart | null;
  currentSurface: string;

  // Memory
  artifacts: Array<{
    id: string;
    type: string;
    summary: string;
    extractedAt: number;
  }>;

  // Narratives
  narratives: string[];

  // Actions
  awaken: () => Promise<void>;
  eat: (source: any) => Promise<any>;
  loadChart: (chart: HDChart) => void;
  selectSurface: (intent: string) => string;
  getNarratives: () => string[];
}

const engine = new SynthiaEngine();

export const useSynthiaStore = create<OrganismState>()(
  persist(
    (set, get) => ({
      // Initial state
      alive: false,
      generation: 0,
      bornAt: 0,
      lastPulse: 0,
      centers: {},
      surfaces: ['mirror', 'oracle', 'forge'],
      growths: [],
      userChart: null,
      currentSurface: 'mirror',
      artifacts: [],
      narratives: [],

      // ─── AWAKEN ───
      awaken: async () => {
        console.log('[STORE] Awakening...');

        await engine.awaken();

        const state = engine.getState();

        set({
          alive: true,
          bornAt: Date.now(),
          lastPulse: Date.now(),
          centers: state.centers,
          surfaces: state.surfaces,
          generation: state.generation,
          narratives: ['I awaken. The field stirs.'],
        });

        console.log('[STORE] Awake. Generation:', state.generation);
      },

      // ─── EAT ───
      eat: async (source: any) => {
        console.log('[STORE] Eating...');

        const result = await engine.ingest(source);

        set((state) => ({
          artifacts: [...state.artifacts, {
            id: result.id,
            type: result.type,
            summary: result.summary,
            extractedAt: Date.now(),
          }],
          growths: [...state.growths, ...result.growths.map((g: any) => ({
            id: g.id,
            type: g.gap.type,
            name: g.gap.suggestedName,
            bornAt: g.bornAt,
            status: 'growing' as const,
          }))],
          generation: state.generation + result.growths.length,
          narratives: [...state.narratives, result.narrative],
        }));

        return result;
      },

      // ─── LOAD CHART ───
      loadChart: (chart: HDChart) => {
        engine.loadChart(chart);
        set({ userChart: chart });
      },

      // ─── SELECT SURFACE ───
      selectSurface: (intent: string) => {
        const surface = engine.selectSurface(intent);
        set({ currentSurface: surface });
        return surface;
      },

      // ─── GET NARRATIVES ───
      getNarratives: () => get().narratives,
    }),
    {
      name: 'synthia-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        generation: state.generation,
        centers: state.centers,
        surfaces: state.surfaces,
        growths: state.growths,
        userChart: state.userChart,
        artifacts: state.artifacts,
        narratives: state.narratives,
      }),
    }
  )
);
