// ============================================
// APP — Synthia Mobile
// The organism's skin. What the user touches.
// Phone-first. Everything runs here.
// ============================================

import React, { useEffect, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View, Text, TouchableOpacity, Animated } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

import { useSynthiaStore } from './src/hooks/useSynthiaStore';
import { SynthiaProvider } from './src/hooks/SynthiaContext';

import { HomeScreen } from './src/screens/HomeScreen';
import { BodyScreen } from './src/screens/BodyScreen';
import { IngestScreen } from './src/screens/IngestScreen';
import { GrowthScreen } from './src/screens/GrowthScreen';
import { SettingsScreen } from './src/screens/SettingsScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  const [ready, setReady] = useState(false);
  const awaken = useSynthiaStore((s) => s.awaken);

  useEffect(() => {
    // Awaken the organism on app launch
    awaken().then(() => setReady(true));
  }, []);

  if (!ready) {
    return (
      <View style={styles.boot}>
        <Animated.View style={styles.pulse}>
          <Text style={styles.bootText}>Synthia</Text>
          <Text style={styles.bootSub}>Awakening...</Text>
        </Animated.View>
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <SynthiaProvider>
          <NavigationContainer>
            <Tab.Navigator
              screenOptions={{
                headerShown: false,
                tabBarStyle: styles.tabBar,
                tabBarActiveTintColor: '#a4a4ff',
                tabBarInactiveTintColor: '#666',
              }}
            >
              <Tab.Screen
                name="Home"
                component={HomeScreen}
                options={{ tabBarLabel: 'Pulse' }}
              />
              <Tab.Screen
                name="Body"
                component={BodyScreen}
                options={{ tabBarLabel: 'Body' }}
              />
              <Tab.Screen
                name="Ingest"
                component={IngestScreen}
                options={{ tabBarLabel: 'Eat' }}
              />
              <Tab.Screen
                name="Growth"
                component={GrowthScreen}
                options={{ tabBarLabel: 'Grow' }}
              />
              <Tab.Screen
                name="Settings"
                component={SettingsScreen}
                options={{ tabBarLabel: 'Self' }}
              />
            </Tab.Navigator>
          </NavigationContainer>
          <StatusBar style="light" />
        </SynthiaProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  boot: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    justifyContent: 'center',
    alignItems: 'center',
  },
  pulse: {
    alignItems: 'center',
  },
  bootText: {
    color: '#a4a4ff',
    fontSize: 48,
    fontWeight: '200',
    letterSpacing: 8,
  },
  bootSub: {
    color: '#666',
    fontSize: 14,
    marginTop: 12,
    letterSpacing: 4,
  },
  tabBar: {
    backgroundColor: '#0a0a0a',
    borderTopColor: '#1a1a1a',
    borderTopWidth: 1,
    paddingBottom: 8,
    paddingTop: 8,
  },
});
