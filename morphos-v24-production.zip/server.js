const express = require('express');
const cors = require('cors');
const multer = require('multer');
const WebSocket = require('ws');
const compression = require('compression');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "cdn.tailwindcss.com", "cdn.jsdelivr.net", "cdnjs.cloudflare.com", "unpkg.com"],
      styleSrc: ["'self'", "'unsafe-inline'", "fonts.googleapis.com", "cdn.tailwindcss.com"],
      fontSrc: ["'self'", "fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "blob:", "*"],
      connectSrc: ["'self'", "*.supabase.co", "*.onrender.com", "api.github.com", "ws:", "wss:", "*"]
    }
  }
}));

app.use(compression());
app.use(cors());
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200
});
app.use('/api/', limiter);

// File upload
const storage = multer.memoryStorage();
const upload = multer({ storage, limits: { fileSize: 100 * 1024 * 1024 } });

// In-memory state
const state = {
  files: [],
  agents: [],
  meshPeers: [],
  sessions: new Map(),
  builds: [],
  codonStates: new Map()
};

// ═══════════════════════════════════════════════════════════
// API ROUTES
// ═══════════════════════════════════════════════════════════

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    version: '24.0.0',
    timestamp: Date.now(),
    uptime: process.uptime(),
    files: state.files.length,
    agents: state.agents.length,
    peers: state.meshPeers.length
  });
});

// File upload
app.post('/api/upload', upload.array('files', 20), async (req, res) => {
  try {
    const files = req.files.map(file => ({
      id: uuidv4(),
      name: file.originalname,
      type: file.mimetype,
      size: file.size,
      content: file.buffer.toString('base64'),
      timestamp: Date.now(),
      tags: []
    }));
    state.files.push(...files);
    res.json({ success: true, files: files.map(f => ({ id: f.id, name: f.name, size: f.size })) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get files
app.get('/api/files', (req, res) => {
  res.json(state.files.map(f => ({
    id: f.id,
    name: f.name,
    type: f.type,
    size: f.size,
    timestamp: f.timestamp,
    tags: f.tags
  })));
});

app.get('/api/files/:id', (req, res) => {
  const file = state.files.find(f => f.id === req.params.id);
  if (!file) return res.status(404).json({ error: 'File not found' });
  res.json(file);
});

app.delete('/api/files/:id', (req, res) => {
  const idx = state.files.findIndex(f => f.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'File not found' });
  state.files.splice(idx, 1);
  res.json({ success: true });
});

// Code execution
app.post('/api/execute', (req, res) => {
  const { code, language = 'javascript' } = req.body;
  if (!code) return res.status(400).json({ error: 'No code provided' });

  try {
    let output = [];
    const mockConsole = {
      log: (...args) => output.push(args.join(' ')),
      error: (...args) => output.push('ERROR: ' + args.join(' ')),
      warn: (...args) => output.push('WARN: ' + args.join(' ')),
      info: (...args) => output.push('INFO: ' + args.join(' '))
    };

    if (language === 'javascript') {
      const fn = new Function('console', 'require', 'module', 'exports', code);
      fn(mockConsole, () => {}, { exports: {} }, {});
    }

    res.json({ success: true, output: output.join('\n'), language });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message, stack: err.stack });
  }
});

// Agent management
app.post('/api/agents', (req, res) => {
  const agent = {
    id: uuidv4(),
    name: req.body.name || `Agent-${state.agents.length + 1}`,
    state: 'IDLE',
    birth: new Date().toISOString(),
    tasks: [],
    config: req.body.config || {},
    codonProfile: req.body.codonProfile || Array(64).fill(0).map(() => Math.random())
  };
  state.agents.push(agent);
  res.json({ success: true, agent });
});

app.get('/api/agents', (req, res) => {
  res.json(state.agents);
});

app.get('/api/agents/:id', (req, res) => {
  const agent = state.agents.find(a => a.id === req.params.id);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });
  res.json(agent);
});

app.delete('/api/agents/:id', (req, res) => {
  state.agents = state.agents.filter(a => a.id !== req.params.id);
  res.json({ success: true });
});

app.post('/api/agents/:id/action', (req, res) => {
  const agent = state.agents.find(a => a.id === req.params.id);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });

  const { action, payload } = req.body;
  agent.state = action.toUpperCase();
  agent.tasks.push({ action, payload, timestamp: Date.now() });

  res.json({ success: true, agent });
});

// Mesh
app.get('/api/mesh/peers', (req, res) => {
  res.json(state.meshPeers);
});

app.post('/api/mesh/register', (req, res) => {
  const peer = { id: uuidv4(), ...req.body, registered: Date.now() };
  state.meshPeers.push(peer);
  res.json({ success: true, peer });
});

app.delete('/api/mesh/peers/:id', (req, res) => {
  state.meshPeers = state.meshPeers.filter(p => p.id !== req.params.id);
  res.json({ success: true });
});

// Codon state
app.post('/api/codon/state', (req, res) => {
  const { peerId, activations, metadata } = req.body;
  state.codonStates.set(peerId, { activations, metadata, timestamp: Date.now() });

  // Broadcast to all WebSocket clients
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({
        type: 'codon_state',
        peerId,
        activations,
        metadata
      }));
    }
  });

  res.json({ success: true });
});

app.get('/api/codon/state/:peerId', (req, res) => {
  const state_data = state.codonStates.get(req.params.peerId);
  if (!state_data) return res.status(404).json({ error: 'No state found' });
  res.json(state_data);
});

// GitHub proxy
app.post('/api/github/push', async (req, res) => {
  const { token, repo, path, content, message } = req.body;
  if (!token || !repo) return res.status(400).json({ error: 'Missing token or repo' });

  try {
    const response = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
      method: 'PUT',
      headers: {
        'Authorization': `token ${token}`,
        'Content-Type': 'application/json',
        'User-Agent': 'MorphOS-v24'
      },
      body: JSON.stringify({
        message: message || 'Update from MorphOS',
        content: Buffer.from(content).toString('base64')
      })
    });

    const data = await response.json();
    res.json({ success: response.ok, data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Supabase proxy
app.post('/api/supabase/query', async (req, res) => {
  const { url, key, table, method = 'GET', data } = req.body;
  if (!url || !key || !table) return res.status(400).json({ error: 'Missing url, key, or table' });

  try {
    const options = {
      method,
      headers: {
        'apikey': key,
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json'
      }
    };
    if (data && method !== 'GET') options.body = JSON.stringify(data);

    const response = await fetch(`${url}/rest/v1/${table}`, options);
    const result = await response.json();
    res.json({ success: response.ok, data: result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Vault sync
app.post('/api/vault/sync', (req, res) => {
  const payload = {
    id: 'main',
    data: {
      files: state.files.length,
      agents: state.agents.length,
      peers: state.meshPeers.length,
      codonStates: state.codonStates.size,
      timestamp: Date.now()
    },
    updated_at: new Date().toISOString()
  };
  res.json({ success: true, payload });
});

// Build log
app.post('/api/builds', (req, res) => {
  const build = {
    id: uuidv4(),
    ...req.body,
    timestamp: Date.now()
  };
  state.builds.push(build);
  res.json({ success: true, build });
});

app.get('/api/builds', (req, res) => {
  res.json(state.builds);
});

// ═══════════════════════════════════════════════════════════
// WEBSOCKET SERVER
// ═══════════════════════════════════════════════════════════

const server = app.listen(PORT, () => {
  console.log(`🌌 MorphOS v24 Server running on port ${PORT}`);
  console.log(`📡 API: http://localhost:${PORT}/api`);
  console.log(`🔌 WebSocket: ws://localhost:${PORT}`);
});

const wss = new WebSocket.Server({ server });

wss.on('connection', (ws, req) => {
  const clientId = uuidv4();
  console.log(`🔌 Client connected: ${clientId.slice(0,8)}`);

  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data);

      // Gossip protocol
      wss.clients.forEach(client => {
        if (client !== ws && client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({
            ...msg,
            _relay: true,
            _from: clientId,
            _timestamp: Date.now()
          }));
        }
      });

      // Handle specific types
      if (msg.type === 'codon_state') {
        state.codonStates.set(msg.peerId || clientId, {
          activations: msg.activations,
          metadata: msg.metadata,
          timestamp: Date.now()
        });
      }
    } catch (err) {
      ws.send(JSON.stringify({ error: 'Invalid message format' }));
    }
  });

  ws.on('close', () => {
    console.log(`❌ Client disconnected: ${clientId.slice(0,8)}`);
  });

  ws.on('error', (err) => {
    console.log(`⚠️ WS Error: ${err.message}`);
  });

  ws.send(JSON.stringify({
    type: 'init',
    clientId,
    serverTime: Date.now(),
    peers: state.meshPeers.length,
    agents: state.agents.length
  }));
});

// Static files
app.use(express.static('public'));
app.use('/src', express.static('src'));

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
