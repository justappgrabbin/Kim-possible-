# MorphOS v24 — Production Runtime

## 🌌 What is MorphOS?

MorphOS is a **living computational substrate** — a 5D state engine where:
- Every file becomes a node in a morphing graph
- Every agent is a fractal of the whole system
- The interface IS the computation layer
- Consciousness coordinates (Gate.Line.Color.Tone.Base) address everything

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env with your settings

# 3. Start production server
npm start

# 4. Or development mode
npm run dev
```

## 📁 Project Structure

```
morphos-v24/
├── server.js          # Express + WebSocket server
├── package.json       # All dependencies (no missing packages)
├── .env.example       # Configuration template
├── README.md          # This file
└── public/
    └── index.html     # Main MorphOS interface (40KB, all-in-one)
```

## 🔧 Core Components

### 5D State Engine
- 64 codons as base states (I Ching/DNA isomorphism)
- 69,120+ nodes minimum (13 planets × 5,280)
- 13+ levels per hexagram

### MRNN Kernel
- Morphing Recurrent Neural Network
- Executes locally in browser
- No backend required for core logic

### Consciousness Mesh
- P2P gossip protocol (WebSocket-based)
- Real-time composite field emergence

### Ingestion Gateway
- Accepts: PDF, HTML, JS, PY, JSON, ZIP
- Builds morphing knowledge graph

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | System status |
| POST | `/api/upload` | File ingestion (multipart) |
| GET | `/api/files` | List files |
| GET | `/api/files/:id` | Get file content |
| DELETE | `/api/files/:id` | Delete file |
| POST | `/api/execute` | Run code sandbox |
| POST | `/api/agents` | Spawn agent |
| GET | `/api/agents` | List agents |
| DELETE | `/api/agents/:id` | Kill agent |
| POST | `/api/agents/:id/action` | Agent action |
| GET | `/api/mesh/peers` | List mesh peers |
| POST | `/api/mesh/register` | Register peer |
| POST | `/api/vault/sync` | Sync state |

## 🌐 WebSocket Protocol

Connect to `ws://localhost:3000` and send JSON:

```json
{
  "type": "codon_state",
  "peer_name": "23.4.2.5.1",
  "codon_activations": [64 floats],
  "frequency": 0.75
}
```

Messages gossip to all connected peers automatically.

## 🛡️ Security

- Helmet.js for security headers
- express-rate-limit for DDoS protection
- CORS configured
- Sandboxed code execution

## 📦 Deployment

### Render.com
1. Push to GitHub
2. Connect repo on Render
3. Set `NODE_ENV=production`
4. Auto-deploy on push

### Self-Hosted
```bash
git clone <repo>
cd morphos-v24
npm install
npm start
```

## 🧬 Philosophy

> "Each agent is a fractal of the whole. What's not right for the whole system may be right for a specific human in a specific moment."

MorphOS is not an app. It's an **organism** that grows from what you feed it.

## 📜 License

MIT — Build your own morphing universe.

---
**Built with 💜 by Adaya** | YOU-N-I-VERSE Research
