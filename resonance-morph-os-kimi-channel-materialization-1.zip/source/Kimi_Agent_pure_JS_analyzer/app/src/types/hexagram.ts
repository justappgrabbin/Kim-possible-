export type Circuit = 'understanding' | 'sensing' | 'knowing' | 'centering';

export type LineState = {
  state: 'yang' | 'yin';
  tension: number;
  stable: boolean;
};

export interface Hexagram {
  gate: number;
  name: string;
  chineseName: string;
  circuit: Circuit;
  channel: string;
  trigram: string;
  unicode: string;
  description: string;
}

export interface Channel {
  name: string;
  gates: string;
  architecture: string;
  circuit: Circuit;
  description: string;
}

export interface FileType {
  circuit: Circuit;
  family: string;
  ext: string;
}

export interface ParsedFile {
  name: string;
  size: number;
  type: FileType;
  content: string;
  checksum: number;
}

export interface FileHexagram {
  primary: Hexagram;
  secondary: Hexagram;
  lines: LineState[];
  changingLines: (LineState & { index: number })[];
  channels: Channel[];
  circuit: Circuit;
}

export interface MorphResult {
  original: string;
  morphed: string;
  diff: {
    added: number;
    removed: number;
  };
  stages: string[];
}
