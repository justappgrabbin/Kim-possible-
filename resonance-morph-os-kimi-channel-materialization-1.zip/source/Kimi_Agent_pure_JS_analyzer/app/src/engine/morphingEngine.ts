import type { ParsedFile, FileHexagram, MorphResult } from '../types/hexagram';

export class MorphingEngine {
  morph(parsedFile: ParsedFile, analysis: FileHexagram): MorphResult {
    const stages: string[] = [];
    let content = parsedFile.content;
    const type = parsedFile.type;

    stages.push('DECODING FILE STRUCTURE');

    // Apply transformations based on changing lines
    for (const changingLine of analysis.changingLines) {
      switch (changingLine.index) {
        case 0: // Line 1: Foundation — fix syntax, add strict mode
          stages.push('STAGE 1/6: ENHANCING FOUNDATION');
          content = this.enhanceFoundation(content, type);
          break;
        case 1: // Line 2: Connections — organize imports
          stages.push('STAGE 2/6: ORGANIZING CONNECTIONS');
          content = this.organizeImports(content, type);
          break;
        case 2: // Line 3: Transformation — add error handling
          stages.push('STAGE 3/6: ADDING ERROR HANDLING');
          content = this.addErrorHandling(content, type);
          break;
        case 3: // Line 4: Logic flow — refactor
          stages.push('STAGE 4/6: REFACTORING LOGIC FLOW');
          content = this.refactorLogic(content, type);
          break;
        case 4: // Line 5: Architecture — modularize
          stages.push('STAGE 5/6: MODULARIZING ARCHITECTURE');
          content = this.modularize(content, type);
          break;
        case 5: // Line 6: Purpose — add docs
          stages.push('STAGE 6/6: ADDING DOCUMENTATION');
          content = this.addDocumentation(content, type);
          break;
      }
    }

    // If no changing lines, apply general improvements
    if (analysis.changingLines.length === 0) {
      stages.push('APPLYING GENERAL OPTIMIZATIONS');
      content = this.applyGeneralOptimizations(content, type);
    }

    stages.push('RESOLVING CHANNELS');

    // Apply circuit-specific transformations
    switch (analysis.circuit) {
      case 'understanding':
        content = this.applyUnderstandingTransform(content, type);
        stages.push('UNDERSTANDING CIRCUIT: LOGICAL OPTIMIZATION');
        break;
      case 'sensing':
        content = this.applySensingTransform(content, type);
        stages.push('SENSING CIRCUIT: EXPERIENTIAL ENHANCEMENT');
        break;
      case 'knowing':
        content = this.applyKnowingTransform(content, type);
        stages.push('KNOWING CIRCUIT: AWARENESS INTEGRATION');
        break;
      case 'centering':
        content = this.applyCenteringTransform(content, type);
        stages.push('CENTERING CIRCUIT: IDENTITY PERSISTENCE');
        break;
    }

    stages.push('TRANSMUTATION COMPLETE');

    // Calculate diff
    const originalLines = parsedFile.content.split('\n');
    const morphedLines = content.split('\n');
    const added = Math.max(0, morphedLines.length - originalLines.length);
    const removed = Math.max(0, originalLines.length - morphedLines.length);

    return {
      original: parsedFile.content,
      morphed: content,
      diff: { added, removed },
      stages,
    };
  }

  private enhanceFoundation(content: string, type: { ext: string; family: string }): string {
    if (type.family === 'code' || type.family === 'web') {
      // Add 'use strict' if missing for JS files
      if ((type.ext === 'js' || type.ext === 'ts') && !content.includes('"use strict"') && !content.includes("'use strict'")) {
        content = '"use strict";\n' + content;
      }
      // Fix common bracket mismatches
      content = this.fixBracketMismatches(content);
    }
    return content;
  }

  private organizeImports(content: string, type: { ext: string; family: string }): string {
    if (type.ext === 'js' || type.ext === 'ts' || type.ext === 'jsx' || type.ext === 'tsx') {
      const importRegex = /^(import|const .* = require|from|export)\b.*$/gm;
      const imports = content.match(importRegex) || [];
      if (imports.length > 1) {
        const body = content.replace(importRegex, '').trim();
        const sorted = [...new Set(imports)].sort().join('\n');
        content = sorted + '\n\n' + body;
      }
    }
    return content;
  }

  private addErrorHandling(content: string, type: { ext: string; family: string }): string {
    if (type.family === 'code' || type.family === 'web') {
      const lines = content.split('\n');
      const processed = lines.map(line => {
        // Wrap await calls without try-catch
        if (line.match(/=\s*await\b/) && !line.includes('try')) {
          const indent = line.match(/^(\s*)/)?.[1] || '';
          return `${indent}try {\n${line}\n${indent}} catch (error) {\n${indent}  console.error('Operation failed:', error);\n${indent}}`;
        }
        return line;
      });
      content = processed.join('\n');
    }
    return content;
  }

  private refactorLogic(content: string, type: { ext: string; family: string }): string {
    if (type.ext === 'js' || type.ext === 'ts' || type.ext === 'jsx' || type.ext === 'tsx') {
      // Convert var to const
      content = content.replace(/\bvar\b/g, 'const');
      // Add function annotations
      content = content.replace(
        /function\s+(\w+)\s*\(([^)]*)\)\s*\{/g,
        '/**\n * $1 - auto-generated\n * @param {$2}\n */\nconst $1 = ($2) => {'
      );
    }
    return content;
  }

  private modularize(content: string, type: { ext: string; family: string }): string {
    if (type.ext === 'js' || type.ext === 'ts') {
      if (!content.includes('module.exports') && !content.includes('export default') && !content.includes('export {')) {
        const mainFunc = content.match(/const\s+(\w+)\s*=/)?.[1];
        if (mainFunc) {
          content += `\n\n// Auto-generated export\nmodule.exports = { ${mainFunc} };\n`;
        }
      }
    }
    return content;
  }

  private addDocumentation(content: string, type: { ext: string; family: string }): string {
    if (type.family === 'code' || type.family === 'web') {
      const lines = content.split('\n');
      const processed: string[] = [];
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        // Add doc comments before function declarations
        if (line.match(/^(const|function|class|def|async\s+function)\b/) &&
            (i === 0 || !lines[i - 1].includes('*'))) {
          const name = line.match(/(?:const|function|class|def|async\s+function)\s+(\w+)/)?.[1] || '';
          const indent = line.match(/^(\s*)/)?.[1] || '';
          processed.push(`${indent}/** ${name} - auto-generated documentation */`);
        }
        processed.push(line);
      }
      content = processed.join('\n');
    }
    // Add file header
    const header = `/**
 * ============================================================================
 * MORPHED FILE - Resonance Engine
 * Circuit: ${type.family}
 * Generated: ${new Date().toISOString()}
 * ============================================================================
 */\n\n`;
    if (!content.startsWith('/**')) {
      content = header + content;
    }
    return content;
  }

  private applyGeneralOptimizations(content: string, type: { ext: string; family: string }): string {
    // Remove trailing whitespace
    content = content.replace(/[ \t]+$/gm, '');
    // Ensure newline at end of file
    if (!content.endsWith('\n')) content += '\n';
    // Add header
    if (type.ext === 'js' || type.ext === 'ts') {
      content = this.enhanceFoundation(content, type);
      content = this.refactorLogic(content, type);
    }
    return content;
  }

  private applyUnderstandingTransform(content: string, type: { ext: string; family: string }): string {
    if (type.ext === 'js' || type.ext === 'ts') {
      // Add type annotations where possible
      if (!content.includes('@ts-check') && type.ext === 'js') {
        content = '// @ts-check\n' + content;
      }
    }
    return content;
  }

  private applySensingTransform(content: string, _type: { ext: string; family: string }): string {
    // For media/sensing files, add metadata processing helpers
    return content;
  }

  private applyKnowingTransform(content: string, type: { ext: string; family: string }): string {
    if (type.ext === 'json') {
      // Validate and format JSON
      try {
        const parsed = JSON.parse(content);
        content = JSON.stringify(parsed, null, 2);
      } catch {
        // Invalid JSON, leave as is
      }
    }
    return content;
  }

  private applyCenteringTransform(content: string, _type: { ext: string; family: string }): string {
    // Add configuration schema validation helpers
    return content;
  }

  private fixBracketMismatches(content: string): string {
    const brackets: Record<string, string> = { '(': ')', '[': ']', '{': '}' };
    for (const [open, close] of Object.entries(brackets)) {
      const openCount = (content.match(new RegExp(`\\${open}`, 'g')) || []).length;
      const closeCount = (content.match(new RegExp(`\\${close}`, 'g')) || []).length;
      if (openCount > closeCount) {
        content += '\n' + close.repeat(openCount - closeCount) + ' // Auto-fixed bracket mismatch';
      }
    }
    return content;
  }
}
