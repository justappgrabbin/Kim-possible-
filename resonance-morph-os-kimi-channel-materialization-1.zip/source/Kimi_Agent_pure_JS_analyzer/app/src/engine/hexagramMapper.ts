import type { ParsedFile, FileHexagram, LineState, Channel, Hexagram, Circuit } from '../types/hexagram';
import { HEXAGRAMS, CHANNELS } from './hexagramData';

export class HexagramMapper {
  private hexagrams: Hexagram[] = HEXAGRAMS;
  private channels: Channel[] = CHANNELS;

  mapFile(parsedFile: ParsedFile): FileHexagram {
    const checksum = parsedFile.checksum;
    const primaryIndex = checksum % 64;
    const primary = this.hexagrams[primaryIndex];

    // Analyze each of the 6 lines
    const lines: LineState[] = [];
    const content = parsedFile.content;
    const type = parsedFile.type;

    // Line 1 (bottom): Foundation — syntax complexity
    lines.push(this.analyzeFoundation(content));
    // Line 2: Connections — imports/references
    lines.push(this.analyzeConnections(content, type));
    // Line 3: Transformation — mutations/changes
    lines.push(this.analyzeTransformation(content));
    // Line 4: Logic flow — functions/classes
    lines.push(this.analyzeLogicFlow(content));
    // Line 5: Architecture — module depth
    lines.push(this.analyzeArchitecture(content));
    // Line 6 (top): Purpose — documentation
    lines.push(this.analyzePurpose(content));

    // Changing lines: where tension exceeds threshold
    const changingLines = lines
      .map((line, i) => ({ ...line, index: i }))
      .filter(line => line.tension > 0.7);

    // Secondary hexagram: flip changing lines
    const secondary = this.resolveChangingHexagram(primary, changingLines);

    // Active channels based on file type + content patterns
    const channels = this.identifyChannels(parsedFile, lines);

    // Override circuit from file type classification
    const circuit = type.circuit;

    return {
      primary,
      secondary,
      lines,
      changingLines,
      channels,
      circuit,
    };
  }

  private analyzeFoundation(content: string): LineState {
    const tokens = content.split(/[;{}(),\[\]\s]+/).filter(t => t.length > 0);
    const complexity = tokens.length / Math.max(content.length / 100, 1);
    const hasIssues = this.detectSyntaxIssues(content);
    const tension = Math.min((complexity / 10) + (hasIssues ? 0.3 : 0), 1);
    return {
      state: tension > 0.5 ? 'yang' : 'yin',
      tension,
      stable: tension < 0.7,
    };
  }

  private analyzeConnections(content: string, type: { ext: string }): LineState {
    let imports: string[] = [];
    if (type.ext === 'js' || type.ext === 'ts' || type.ext === 'jsx' || type.ext === 'tsx') {
      imports = content.match(/^(import|from|require)\b.*$/gm) || [];
    } else if (type.ext === 'py') {
      imports = content.match(/^(import|from)\b.*$/gm) || [];
    } else if (type.ext === 'java' || type.ext === 'cpp' || type.ext === 'c') {
      imports = content.match(/^#include\b.*$/gm) || [];
    } else {
      imports = content.match(/^(import|include|using|require|from)\b.*$/gm) || [];
    }
    const tension = Math.min(imports.length / 15, 1);
    return {
      state: imports.length > 5 ? 'yang' : 'yin',
      tension,
      stable: tension < 0.7,
    };
  }

  private analyzeTransformation(content: string): LineState {
    const mutations = (content.match(/(=|:=|\+=|-=|\*=|\/=|%=|&&|\|\||\+\+|--)/g) || []).length;
    const reassignments = (content.match(/\w+\s*=\s*[^=]/g) || []).length;
    const tension = Math.min((mutations + reassignments) / 80, 1);
    return {
      state: mutations > 20 ? 'yang' : 'yin',
      tension,
      stable: tension < 0.7,
    };
  }

  private analyzeLogicFlow(content: string): LineState {
    const functions = (content.match(/\b(function|def|class|const|let|var|=>|\bif\b|\bfor\b|\bwhile\b|\bswitch\b)\b/g) || []).length;
    const depth = this.getNestingDepth(content);
    const tension = Math.min((functions / 20) + (depth / 20), 1);
    return {
      state: functions > 5 ? 'yang' : 'yin',
      tension,
      stable: tension < 0.7,
    };
  }

  private analyzeArchitecture(content: string): LineState {
    const lines = content.split('\n');
    let maxIndent = 0;
    for (const line of lines) {
      const indent = line.match(/^(\s*)/)?.[1].length || 0;
      maxIndent = Math.max(maxIndent, indent);
    }
    const modules = (content.match(/\b(module|export|import|namespace|package)\b/g) || []).length;
    const tension = Math.min((maxIndent / 40) + (modules / 10), 1);
    return {
      state: maxIndent > 12 ? 'yang' : 'yin',
      tension,
      stable: tension < 0.7,
    };
  }

  private analyzePurpose(content: string): LineState {
    const docs = (content.match(/(\/\/|\/\*|\*|#|"""|'''|\/\*\*|@)/g) || []).length;
    const hasDescription = content.match(/\b(description|purpose|@param|@return|README|TODO|FIXME)\b/gi);
    const tension = Math.min((docs / 30) + (hasDescription ? 0.1 : 0.2), 1);
    return {
      state: docs > 5 ? 'yang' : 'yin',
      tension,
      stable: tension < 0.7,
    };
  }

  private detectSyntaxIssues(content: string): number {
    let issues = 0;
    // Unmatched brackets
    const brackets = { '(': ')', '[': ']', '{': '}' };
    for (const [open, close] of Object.entries(brackets)) {
      const openCount = (content.match(new RegExp(`\\${open}`, 'g')) || []).length;
      const closeCount = (content.match(new RegExp(`\\${close}`, 'g')) || []).length;
      if (openCount !== closeCount) issues++;
    }
    // Missing semicolons in JS-like
    const lines = content.split('\n');
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed && !trimmed.endsWith(';') && !trimmed.endsWith('{') && !trimmed.endsWith('}') &&
          !trimmed.endsWith('(') && !trimmed.endsWith(')') && !trimmed.startsWith('//') &&
          !trimmed.startsWith('/*') && !trimmed.startsWith('*') && !trimmed.startsWith('import') &&
          !trimmed.startsWith('export') && trimmed.length > 5) {
        // Potential missing semicolon
      }
    }
    return issues;
  }

  private getNestingDepth(content: string): number {
    const lines = content.split('\n');
    let maxDepth = 0;
    for (const line of lines) {
      const indent = line.match(/^(\s*)/)?.[1].length || 0;
      maxDepth = Math.max(maxDepth, Math.floor(indent / 2));
    }
    return maxDepth;
  }

  private identifyChannels(parsedFile: ParsedFile, lines: LineState[]): Channel[] {
    const channels: Channel[] = [];
    const type = parsedFile.type;

    // Understanding Circuit channels (for code/web files)
    if (type.circuit === 'understanding') {
      if (lines[3].tension > 0.3) channels.push(this.findChannel('Logic'));
      if (lines[1].tension > 0.3) channels.push(this.findChannel('Acceptance'));
      if (lines[2].tension > 0.4) channels.push(this.findChannel('Judgment'));
      if (lines[4].tension > 0.3) channels.push(this.findChannel('Wavelength'));
      if (lines[0].tension > 0.3) channels.push(this.findChannel('Concentration'));
      if (lines[5].tension > 0.3) channels.push(this.findChannel('Rhythm'));
    }
    // Sensing Circuit channels (for media files)
    else if (type.circuit === 'sensing') {
      channels.push(this.findChannel('Maturation'));
      if (lines[3].tension > 0.4) channels.push(this.findChannel('Penetration'));
      if (lines[2].tension > 0.5) channels.push(this.findChannel('Struggle'));
    }
    // Knowing Circuit channels (for data files)
    else if (type.circuit === 'knowing') {
      channels.push(this.findChannel('Mutation'));
      if (lines[1].tension > 0.3) channels.push(this.findChannel('Awareness'));
      if (lines[4].tension > 0.4) channels.push(this.findChannel('Structuring'));
      if (lines[0].tension > 0.3) channels.push(this.findChannel('Openness'));
    }
    // Centering Circuit channels (for config files)
    else if (type.circuit === 'centering') {
      channels.push(this.findChannel('Action'));
      channels.push(this.findChannel('Initiation'));
    }

    return channels.filter(Boolean);
  }

  private findChannel(name: string): Channel {
    return this.channels.find(c => c.name === name) || this.channels[0];
  }

  private resolveChangingHexagram(primary: Hexagram, changingLines: (LineState & { index: number })[]): Hexagram {
    if (changingLines.length === 0) return primary;

    // Build a 6-bit representation where each bit is a line (0=yin, 1=yang)
    let bits = primary.gate - 1; // 0-indexed

    // Flip the bits corresponding to changing lines
    for (const line of changingLines) {
      bits ^= (1 << line.index);
    }

    // Ensure valid range
    bits = ((bits % 64) + 64) % 64;
    return this.hexagrams[bits];
  }

  getHexagramsByCircuit(circuit: Circuit): Hexagram[] {
    return this.hexagrams.filter(h => h.circuit === circuit);
  }

  getActiveHexagrams(analysis: FileHexagram): Hexagram[] {
    // Return hexagrams that relate to the file's changing lines
    const active: Hexagram[] = [analysis.primary];
    if (analysis.secondary.gate !== analysis.primary.gate) {
      active.push(analysis.secondary);
    }
    // Add hexagrams from active channels
    for (const channel of analysis.channels) {
      const gateNums = channel.gates.split('-').map(Number);
      for (const gn of gateNums) {
        const hex = this.hexagrams.find(h => h.gate === gn);
        if (hex && !active.find(a => a.gate === hex.gate)) {
          active.push(hex);
        }
      }
    }
    return active;
  }
}
