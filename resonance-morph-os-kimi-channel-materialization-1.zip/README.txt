Resonance Morph OS — Kimi Channel Materialization Patch

Added:
- Kimi Pure JS Analyzer integrated as a local channel engine.
- Circuit mapping: understanding / sensing / knowing / centering.
- 64 hexagram gate assignment from uploaded analyzer.
- Channel-edge routing from uploaded analyzer.
- Executable capsule materialization still produces SVG identity + app tray registration.
- Backend remains optional/teaching-only for unknown flows.

Run by opening resonance-os-MORPH-KIMI-CHANNELS.html in a browser.
