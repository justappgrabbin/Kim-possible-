import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { apiService, Pod, MissionBrief } from '../services/apiService';
import BottomNavigation from '../components/BottomNavigation';
import { FIELD_COLOR } from '../lib/fieldVisuals';

const HomeDashboard: React.FC = () => {
  const [pods, setPods] = useState<Pod[]>([]);
  const [hasLoggedToday, setHasLoggedToday] = useState(false);
  const [loading, setLoading] = useState(true);
  const [mission, setMission] = useState<MissionBrief | null>(null);
  const [showWhy, setShowWhy] = useState(false);

  const navigate = useNavigate();
  const { userId, displayName, profile, logout } = useAuth();

  useEffect(() => {
    loadData();
  }, [userId]);

  const loadData = async () => {
    if (!userId) return;
    setLoading(true);
    try {
      const [podList, logs, missionBrief] = await Promise.all([
        apiService.listPods(),
        apiService.getDailyLogs(userId),
        apiService.getTodaysMission(userId).catch(() => null),
      ]);
      setPods(podList);
      const today = new Date().toISOString().split('T')[0];
      setHasLoggedToday(logs.some((l: any) => l.log_date === today));
      setMission(missionBrief);
    } catch (e) {
      console.error('Error loading dashboard data:', e);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !profile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pixel-dark via-gray-900 to-retro-purple flex items-center justify-center safe-area-top safe-area-bottom">
        <div className="text-center">
          <i className="fa fa-spinner animate-pixel-spin text-4xl text-retro-cyan mb-4"></i>
          <p className="font-pixel text-white">Loading your field...</p>
        </div>
      </div>
    );
  }

  const { bodygraph } = profile.natal_report;
  const fields = Object.values(profile.field_state);
  const coherence = profile.network_coherence;
  const definedCenters = Object.entries(bodygraph.centers).filter(([, s]) => s === 'Defined');

  return (
    <div className="min-h-screen bg-gradient-to-br from-pixel-dark via-gray-900 to-retro-purple safe-area-top safe-area-bottom pb-20">
      <div className="container mx-auto px-4 py-6 max-w-md">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-pixel text-white text-shadow-pixel">
              RESONANCE HUB
            </h1>
            <p className="text-retro-cyan font-pixel text-sm">
              {displayName ? `Welcome back, ${displayName}` : ''}
            </p>
          </div>
          <button onClick={logout} className="p-2 text-white/60 hover:text-white transition-colors">
            <i className="fa fa-sign-out-alt text-xl"></i>
          </button>
        </div>

        {mission && (
          <div className="pixel-card mb-6 animate-slide-up">
            <div className="flex items-center justify-between mb-3">
              <span className={`font-pixel text-[10px] px-2 py-1 border-2 ${
                mission.go ? 'border-retro-green text-retro-green' : 'border-retro-yellow text-retro-yellow'
              }`}>
                <i className={`fa ${mission.go ? 'fa-circle-check' : 'fa-hourglass-half'} mr-1`}></i>
                {mission.go ? 'GO' : 'RECALIBRATE FIRST'}
              </span>
              <span className="font-pixel text-[10px] text-white/40">TODAY'S MISSION</span>
            </div>
            <p className="font-pixel text-white text-sm leading-relaxed mb-3">{mission.mission_text}</p>
            <button
              onClick={() => setShowWhy((s) => !s)}
              className="font-pixel text-[10px] text-retro-cyan active:opacity-70 min-h-[44px]"
            >
              <i className={`fa ${showWhy ? 'fa-chevron-up' : 'fa-chevron-down'} mr-1`}></i>
              {showWhy ? 'HIDE WHY' : 'WHY THIS MISSION?'}
            </button>
            {showWhy && (
              <div className="mt-2 pt-3 border-t border-white/10 space-y-2 animate-slide-up">
                <p className="font-pixel text-[10px] text-white/60">
                  <span className="text-retro-green">STRONGEST TODAY:</span> {mission.strongest_field}
                </p>
                <p className="font-pixel text-[10px] text-white/60">
                  <span className="text-retro-red">{mission.weakest_field.toUpperCase()} FRICTION:</span> {mission.friction_signature}
                </p>
              </div>
            )}
          </div>
        )}

        <div className="pixel-card mb-6 animate-slide-up">
          <div className="flex items-center mb-3">
            <i className="fa fa-diagram-project text-retro-cyan text-xl mr-3"></i>
            <h2 className="font-pixel text-white text-lg">YOUR BODYGRAPH</h2>
          </div>
          <div className="flex items-center justify-between mb-3">
            <span className="font-pixel text-white/70 text-xs">DEFINITION</span>
            <span className="font-pixel text-retro-cyan text-sm">{bodygraph.definition}</span>
          </div>
          <div className="flex items-center justify-between mb-3">
            <span className="font-pixel text-white/70 text-xs">ACTIVE GATES</span>
            <span className="font-pixel text-retro-cyan text-sm">{bodygraph.active_gates.length}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {definedCenters.map(([center]) => (
              <span key={center} className="px-2 py-1 bg-retro-cyan/20 border border-retro-cyan text-retro-cyan font-pixel text-xs">
                {center.toUpperCase()}
              </span>
            ))}
          </div>
        </div>

        <button
          onClick={() => navigate('/field')}
          className="pixel-card mb-6 animate-slide-up w-full text-left active:opacity-70 transition-opacity"
        >
          <div className="flex items-center mb-3">
            <i className="fa fa-wave-square text-retro-pink text-xl mr-3"></i>
            <h2 className="font-pixel text-white text-lg">FIELD COHERENCE</h2>
            <span className="ml-auto font-pixel text-retro-pink text-lg">
              {(coherence * 100).toFixed(0)}%
            </span>
          </div>
          <div className="space-y-2">
            {fields.map((f) => (
              <div key={f.field_type} className="flex items-center">
                <span className="w-20 font-pixel text-xs text-white/70">{f.field_type}</span>
                <div className="flex-1 h-2 bg-gray-800 mx-2">
                  <div
                    className={`h-2 bg-${FIELD_COLOR[f.field_type] || 'retro-cyan'}`}
                    style={{ width: `${Math.round(f.coherence * 100)}%` }}
                  />
                </div>
                <span className="font-pixel text-xs text-white/50 w-8 text-right">
                  {Math.round(f.coherence * 100)}
                </span>
              </div>
            ))}
          </div>
          <p className="font-pixel text-white/40 text-[10px] mt-3 text-center">
            <i className="fa fa-hand-pointer mr-1"></i>tap to see the live interference pattern
          </p>
        </button>

        <div className="pixel-card mb-6 animate-slide-up">
          <button
            onClick={() => navigate('/check-in')}
            className="w-full flex items-center justify-between p-4 hover:bg-white/5 transition-colors"
          >
            <div className="flex items-center">
              <i className={`fa fa-square-check text-2xl mr-4 ${hasLoggedToday ? 'text-retro-green' : 'text-white/40'}`}></i>
              <div className="text-left">
                <h3 className="font-pixel text-white text-lg">DAILY CHECK-IN</h3>
                <p className="font-pixel text-sm text-white/60">
                  {hasLoggedToday ? 'Completed today' : 'Log your resonance'}
                </p>
              </div>
            </div>
            <i className="fa fa-chevron-right text-white/40"></i>
          </button>
        </div>

        <div className="pixel-card animate-slide-up">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <i className="fa fa-users text-retro-green text-xl mr-3"></i>
              <h2 className="font-pixel text-white text-lg">PODS</h2>
            </div>
          </div>

          {pods.length === 0 ? (
            <p className="font-pixel text-white/50 text-sm">
              No pods yet -- be the first to start one.
            </p>
          ) : (
            <div className="space-y-3">
              {pods.slice(0, 3).map((pod) => (
                <button
                  key={pod.id}
                  onClick={() => navigate(`/pod/${pod.id}`)}
                  className="w-full p-3 bg-gray-900/50 border border-retro-green/30 hover:border-retro-green transition-colors text-left"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-pixel text-retro-green text-sm">{pod.name}</h4>
                      <p className="font-pixel text-white/60 text-xs">{pod.resonance_theme}</p>
                    </div>
                    <i className="fa fa-chevron-right text-white/40"></i>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default HomeDashboard;
