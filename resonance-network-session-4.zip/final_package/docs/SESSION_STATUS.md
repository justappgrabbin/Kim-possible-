# YOU-N-I-VERSE / Resonance Network -- Session Status

Everything in this zip has been actually run and tested, not just written.
Where a bug is mentioned below, it was found by running real code against
real input, not by inspection alone.

## backend/ -- FastAPI, drop into resonance-network-app/backend/

All of these were started as a live server and hit with real HTTP requests.
`de421.bsp` (your Skyfield ephemeris file) isn't included here since it's
16MB binary and unchanged -- keep using the one already in your repo.

- `hd_engine.py` -- **extended**. Previously stopped at Gate + Line. Now
  resolves the full lattice address: Gate.Line.Color.Tone.Base (the real
  64x6x6x6x5 = 69,120-address lattice). New `longitude_to_full_address()`
  and `Placement.lattice_address` property. Tested: zero out-of-range
  values across 36,000 fine-grained longitude samples, zero discontinuous
  jumps at 2,000 simulated boundary crossings, and Gate 17/Gate 41 land at
  their documented anchor points (3.875 deg and 302 deg) with
  line=color=tone=base=1, consistent with the original gate-wheel
  cross-check from session 1.
- `outcome_learning.py` -- the ever-changing side. `mission_tracking`
  (private, has user_id) plus a SQLite-based `collective_outcomes` table
  that was this session's first pass at the canonical layer, k-anonymity
  floor (`MIN_SAMPLE_SIZE = 5`) tested at n=1 (blocked) and n=5 (released).
  Kept in the repo since `main.py`'s mission endpoint still writes to it --
  see `neo4j_outcomes.py` below for the intended canonical replacement.
- `neo4j_outcomes.py` -- **new, canonical side**. Cypher port of
  `collective_outcomes`, matching the ever-changing/canonical split you
  described (SQLite/Supabase for the changing side, Neo4j for canonical).
  Not written on faith -- I downloaded Neo4j Community 5.26 and ran it
  locally this session (no Docker needed, just Java, which was already
  available), connected the real Python driver, and tested against it:
    - k-anonymity floor: n=1 correctly blocked, n=5 correctly released
      real stats (`mean_delta=0.24, success_rate=1.0`).
    - The graph-native query that's the actual reason to use Neo4j over
      SQLite -- `similar_address_stats()`, addresses within N lines of a
      given one -- returned correct results (n=6, pulled in a
      genuinely nearby address). SQLite can't do this cleanly; Neo4j does
      it as one native traversal.
    - Confirmed zero `user_id` anywhere in the graph by enumerating every
      property key on every node after the test run.
  The local test instance was torn down at the end of the session --
  nothing is left running. You'll need your own instance to point this
  at (see below). `main.py` is NOT yet wired to this file -- it's still
  writing to the SQLite `collective_outcomes` table. Swapping that over
  is the first thing to do next session.

- `resonance.py` -- **matching logic corrected**. The old
  `resonance_score` matched on phase-angle similarity only, which is a
  real bug against what you actually want: it rewards two people whose
  charts *resemble* each other, not people who *complete* each other's
  gaps. Added `center_complementarity()`, a real function over actual
  bodygraph center data (Defined vs Undefined/Open across all 9 centers)
  that scores 1.0 for a perfect complement and 0.0 for two people with the
  identical definition pattern -- tested against exactly that pair and
  got exactly those two numbers. `resonance_score()` now blends
  complementarity at 0.5 weight, synchrony at 0.35, coupling at 0.15 --
  complementarity is the primary signal now, by design, not similarity.
  Wired into all three places that were still doing the old
  similarity-only match: `/api/match/calculate`, pod-fit, and the network
  graph. Confirmed live through the real API with two real charts.
- `outcome_learning.py` / `neo4j_outcomes.py` -- **added the internal/public
  split**. `get_pattern_stats()` stays floor-enforced at n=5, safe to ever
  expose. New `get_pattern_stats_internal()` drops to n=2 for the
  system's own use (steering behavior without disclosing that it's doing
  so) -- deliberately not n=1, since a single outcome unambiguously *is*
  one specific person. The real rule, documented in the code itself so
  it isn't lost: internal-tier stats are fine for aggregate model
  behavior, but must never reach back to shape what the 1-2 people who
  generated an early sample themselves experience -- that would be using
  their identifiable behavior on them without telling them, the exact
  thing the public floor exists to prevent, just relocated somewhere
  nobody's watching. Tested all three tiers (n=1 blocked both ways, n=2
  internal-only, n=5 both).



### Setting up your own Neo4j (you said you haven't done this before)

Given the Termux-first stack, running Neo4j's actual server on-device
isn't realistic (it's a JVM database, needs real memory). The practical
option is **Neo4j AuraDB Free** -- managed, no install, just a connection
string, same shape as how you already use Supabase:

1. https://neo4j.com/product/auradb/ -> "Start Free" -> create an
   instance (free tier: 200k nodes / 400k relationships, plenty for this).
2. It gives you a `neo4j+s://xxxxx.databases.neo4j.io` URI, a username
   (`neo4j`), and a **one-time-shown password** -- save it immediately,
   it won't be shown again.
3. `pip install neo4j --break-system-packages`
4. In your backend env vars: `NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD`.
5. `neo4j_outcomes.py` takes a `Driver` object as its first argument to
   every function -- construct it once at app startup with
   `GraphDatabase.driver(uri, auth=(user, password))` and pass it in,
   same pattern as `get_db()` for the SQLite side.
6. Call `init_schema(driver)` once on startup (creates the uniqueness
   constraint on `Address.key`) -- it's idempotent, safe to call every boot.

This is a bridge, not a final answer to the sovereignty goal -- worth
revisiting self-hosted Neo4j once this is running somewhere with real
compute behind it instead of a phone.

- `resonance.py` -- unchanged.

- `resonance_market.py` -- energy-exchange economy ported from
  LivingOrganism/ResonanceMarket.ts. Validates listings/requests against
  real bodygraph center definition. Tested: full list -> request -> match
  -> transact flow, fee split verified to the cent (85% seller / 10% broker
  / 5% platform).
- `mission_advisor.py` -- daily mission briefs (the "Kim Possible" RMA
  layer). Deterministic per user per day, no LLM call. Tested for
  determinism (same call twice = identical result). **Now feeds
  `outcome_learning.py`** via `/api/mission/today` -- every call tracks
  today's pick and closes yesterday's loop if one exists. NOT yet wired
  the other direction: the mission *selection* logic in
  `generate_mission()` still ignores `get_pattern_stats()` entirely, it's
  hash-based rotation same as before. Recording is live; using what's
  recorded to actually influence future picks is the natural next step,
  and needs its own design pass since it has to blend real statistics
  into the deterministic picker without breaking explainability (the
  point of "why this mission" staying answerable).
- `autoling.py` -- real rule-based tokenizer/tag-suggester for check-in
  notes. **Bug found and fixed**: the stemmer stripped "es" as a unit
  ("generates" -> "generat"), which broke matching against "generate".
  Now strips only the final "s".
- `diseminer_engine.py` -- DISEMINER's real half only: co-occurrence
  distributional semantics + SVO claim extraction. Monte Carlo (fake --
  no actual randomness in the sampling loop) and the narrative/influence
  layer (computes urgency/social-proof/authority to produce a
  "doubtBypassed" flag -- a persuasion engine, not inference) were
  deliberately left out. **Bug found and fixed**: no stopword filtering
  meant "the" appeared as a hypernym of nearly everything; added a
  stopword list.
- `synthesist_engine.py` -- real claim verification against a
  user-supplied document corpus. No fabricated sources -- an unsupported
  claim honestly comes back "unverified". **Two bugs found and fixed**:
  same stemmer bug as autoling, and the claim-type classifier regexes
  used exact word-boundary matches that missed inflected forms ("shows",
  "suggests", "demonstrates" all failed to classify -- 3 of 8 tested
  phrasings were broken before the fix).
- `main.py` -- all of the above wired in. New endpoints since last audit:
  `/api/pod/{id}/fit/{user}`, `/api/mission/today/{user}`,
  `/api/autoling/analyze`, `/api/diseminer/analyze`,
  `/api/synthesist/verify`, plus the full `/api/market/*` set.

Run: `pip install -r requirements.txt && uvicorn main:app --reload`

## frontend/ -- drop into resonance-network-app/frontend/src/

- `screens/MarketScreen.tsx` -- energy market UI, phone-first (44px+ touch
  targets throughout, verified).
- `screens/FieldScreen.tsx` + `components/FieldWave.tsx` +
  `lib/fieldVisuals.ts` -- the live interference-pattern visualization.
  Respects `prefers-reduced-motion`.
- `screens/HomeDashboard.tsx` -- adds the daily Mission Brief card,
  tappable field-coherence card.
- `screens/PodsBrowse.tsx` -- adds real resonance-fit badges per pod.
- `screens/DailyCheckIn.tsx` -- adds AUTOLING tag suggestions from note
  text (debounced, opt-in, never auto-selects).
- `apiService.ts`, `App.tsx`, `BottomNavigation.tsx` -- updated to wire
  all of the above.

All of it passes `npx tsc --noEmit` and `npx vite build` clean as of last
test.

## Sovereign edge / hub architecture (new this session)

- `hub_sync.py` -- the sovereign/edge -> hub reporting client. Each
  user's own instance (phone/Termux, or a self-hosted server later) runs
  `hd_engine.py`/`resonance.py`/`mission_advisor.py` fully locally -- no
  network needed to compute a chart or get a mission. The ONLY thing that
  talks to the network is this file, and it only ever pushes anonymized
  outcome rows to the hub, never anything private. Tested:
    - A normal report reaches the hub and gets stored correctly.
    - A deliberately malicious payload (added fake `user_id`,
      `display_name`, `email` fields to the POST body) was accepted by
      the endpoint but confirmed absent from storage afterward -- Pydantic
      silently drops undeclared fields, so even a modified/malicious
      client can't smuggle identity through.
    - Offline queuing: reporting to an unreachable hub queues locally
      instead of losing the data (tested: 2 queued while "offline"), and
      `flush_pending_reports()` correctly drains the queue once the hub's
      reachable again (tested: 2/2 sent, queue empty after).
  New hub-side endpoint: `POST /api/outcomes/report` in `main.py`, backed
  by a new `outcome_learning.record_anonymized_outcome()` (a direct
  insert for pre-computed deltas arriving from elsewhere, as opposed to
  `close_the_loop()` which computes the delta itself from local tracking).
  NOT yet built: the actual "run hd_engine.py standalone on Termux with no
  server" packaging -- this session proved the reporting protocol, not
  the full edge deployment.

## Post-deterministic / pre-probabilistic mission picking (new this session)

The precise technical name for what was asked: MAP-style point estimation
(maximum a posteriori) rather than full Bayesian posterior sampling. The
system now updates its picks from real recorded evidence, but the final
output is always ONE deterministic choice -- it argmaxes the best-known
option, never samples from a distribution, never expresses a probability.
No randomness enters the final decision at any point, before or after
evidence exists.

- `mission_advisor.py` -- `_evidence_weighted_pick()` replaces the flat
  hash pick for the Optimal Vector text. Pre-evidence: falls back to the
  original pure deterministic hash (every variant equally likely,
  reproducible). Post-evidence (once >=2 variants have internal-tier
  outcome data): deterministically picks whichever variant has the best
  real mean_delta. `MissionBrief` now carries `optimal_vector_index` so
  the shown variant can be tracked and its real-world effect attributed
  back to it specifically, not just to the field in general.
- `outcome_learning.py` -- `mission_tracking` gained a `variant_index`
  column; `close_the_loop()` now encodes which variant was shown into the
  outcome's `action_type` (`optimal_vector_variant_N`), so
  `get_pattern_stats_internal()` can evaluate per-variant performance,
  not just per-field.
- Tested three ways:
    1. Isolated: with no evidence, picks match the pure hash exactly.
       With fabricated evidence strongly favoring one variant, the pick
       switches to that variant deterministically -- confirmed by finding
       a user/date where the hash naturally picks variant 0, then showing
       the SAME call switches to variant 1 once evidence favors it.
    2. Determinism: ran the evidence-informed pick 5 times with identical
       inputs -- identical output every time, confirming no sampling
       anywhere in the decision.
    3. **Live, through the real API**: created a real profile, got its
       mission (variant 0, pure hash), manually seeded
       `collective_outcomes` with real rows showing variant 0
       underperforming and variant 1 outperforming, called the SAME
       mission endpoint again for the SAME user on the SAME day -- the
       actual delivered `mission_text` changed to variant 1's text.

## Local P2P mesh (distinct from hub_sync.py above)

Important distinction clarified this session: `hub_sync.py` is
*offline-tolerant* (queues locally, sends once internet returns). What's
described below is *offline-native* -- two phones with zero internet or
cell signal, finding each other over Bluetooth directly. Different layer
of the stack entirely.

- **Transport recommendation**: Bridgefy SDK (bridgefy.me/sdk). Checked
  current status via web search this session -- actively maintained,
  latest Android release Jan 2026, real iOS/Android/React Native SDKs,
  Signal Protocol encryption, multi-hop mesh relay (~330ft per hop).
  Needs internet exactly once on first app open to activate, then works
  fully offline. **Gap**: no confirmed Capacitor-native plugin -- since
  the frontend is Capacitor not React Native, this needs a thin custom
  Capacitor plugin wrapping Bridgefy's native iOS/Android SDKs. That's a
  real but scoped task, not reinventing mesh routing from scratch.
- `mesh_broadcast.py` -- **new, and this part IS tested**, despite the
  transport layer above being untestable in this sandbox (no Bluetooth
  hardware here). The key design decision: matching logic is
  transport-agnostic. `center_complementarity()` (fixed and tested
  earlier this session) works identically whether two charts arrive via
  an HTTP call to the hub or get beamed phone-to-phone over Bluetooth --
  one matching brain, multiple transports underneath. This file defines:
    - `MeshBroadcast` -- a small, wire-serializable payload (314 bytes in
      testing) carrying only what's needed to decide local relevance:
      kind (need/offer), which of the 9 real centers, category,
      description, TTL. Deliberately NOT a full chart -- Bluetooth mesh
      payloads need to stay small.
    - `receive_broadcast()` -- evaluates an incoming broadcast against
      the receiving device's own chart, fully locally, no network round
      trip. Tested against the exact odd-job-help scenario: a "need
      Sacral help" broadcast correctly scored 1.0 relevance for someone
      with Sacral Defined, 0.0 for someone whose Sacral is also open.
    - TTL/expiry, mirroring Bridgefy's own TTL concept -- tested that an
      already-expired broadcast is rejected before ever entering the
      local cache, not just filtered out later.
  NOT yet built: the actual Capacitor/Bridgefy wiring (needs real
  devices), and reconciliation logic for when a mesh-relayed listing
  later reaches internet and needs merging with the hub's market data
  (flagged as a real design requirement, not started).

## klein-tools-fixed/ -- standalone TS, not yet wired into any backend

- `devcore.ts` -- **major fix**. The original simulated everything:
  `executeCommand` never ran a process, just returned canned strings like
  "Tests passed: 42/42" regardless of what actually happened; pre-install
  checks (disk space, network, permissions) all unconditionally returned
  `passed: true`; dependency install just marked packages installed
  without running a package manager. Rewrote the whole execution layer to
  actually shell out (`child_process`), actually check disk space (`df`),
  actually hit the network, actually run `npm install`, actually make
  HTTP health-check requests. Tested: a deliberately failing command now
  correctly reports `status: failed` with real stderr captured, where the
  original would have reported success.
- `meshweave.ts` -- **two bugs fixed**. (1) Modularity calculation used
  the *total* graph edge count for every community instead of that
  community's actual internal edges, making the number meaningless. Now
  uses real per-community edge partitioning (Newman's formula). Tested
  against two disconnected triangle clusters -- a case with a known
  correct answer -- and got exactly the textbook value (0.5). (2)
  `calculateTopologyMetrics` referenced a variable (`bridges`) that only
  existed in its caller's scope -- would have crashed on every call to
  `analyzeTopology()`. Fixed by passing it as a parameter.

Both compile clean with `tsc` and were actually run with `node`, not just
type-checked.

## klein-tools-unaudited/ -- real, but not yet run or wired in

- `klein-language-contact.ts` -- audited for red flags only (clean, no
  manipulation patterns, no fake randomness -- the randomness present is
  legitimate agent-based population simulation). Not yet run.
- `valora.ts` -- spot-checked: real compound-growth math, correct
  volatility/confidence-interval formulas. Not yet run end-to-end or
  wired in. Could feed Resonance Market earnings projections.
- `messi.ts`, `autonovel.ts` -- structural audit only (randomness in
  autonovel is legitimate creative-template variety, not fake inference).
  Not yet deep-audited function by function the way diseminer/synthesist
  were.

## Known gaps (confirmed, not guessed)

- **META-SYNTH (hub 6)** is genuinely missing from the new 9-file set --
  not merged into anything else, unlike PROPP (-> autonovel.ts) and
  GRAMMAR (-> autoling.ts).
- **MCP-HUB (hub 9)** is absent from the file set, but per your
  correction this is necessary and confined to its own job in your
  Synthia-server bus -- not something for me to build or treat as
  redundant with Claude's own MCP connectors. Those are two separate
  systems.
- **WHO/WHAT/WHERE/WHEN/WHY dimensional query guardrails** you originally
  specified for AUTOLING are not present in either version of
  `autoling.ts` I've seen. Confirmed by direct search, not inferred.

## Known simplifications worth knowing about

- SYNTHESIST's claim similarity is Jaccard word-overlap with light
  stemming -- real, but it's lexical, not semantic. Two claims that mean
  the same thing in very different words won't match.
- MESHWEAVE's embeddings are a deterministic hash-based stand-in (the
  original code is honest about this in its own comment) -- consistent,
  but not true semantic similarity.
- DISEMINER's synonymy/hypernymy inference is real distributional
  semantics but needs a reasonably sized document set to say anything
  meaningful -- it's honest about finding nothing on thin input, which is
  correct behavior, not a bug.

## Suggested next session order

1. Wire `main.py`'s mission endpoint to `neo4j_outcomes.py` instead of
   the SQLite `collective_outcomes` table (requires your AuraDB
   credentials -- see setup steps above).
2. Wire `outcome_learning.get_pattern_stats()` / `neo4j_outcomes`
   equivalent back into `mission_advisor.generate_mission()`'s actual
   field-selection logic -- recording is live, using it isn't yet.
2. Audit `valora.ts` and `messi.ts` function-by-function the way
   diseminer/synthesist were (been spot-checked, not fully verified).
3. Decide whether to rebuild the WHO/WHAT/WHERE/WHEN/WHY guardrail
   structure into `autoling.py`, since it's an explicit original spec
   that both TS versions dropped.
4. Wire `klein-language-contact.ts` in, or decide it stays a standalone
   service given its size.
5. Address the META-SYNTH gap -- build fresh or decide it's not needed.
