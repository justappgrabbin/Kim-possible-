# Living Organism — YOU-N-I-VERSE OS Integration Layer

## What Changed (v2.0)

The KleinToolMesh has been completely rewritten based on your review. Here's what changed:

### Before (v1.0)
```
User → Tool → Output
```
- 7 tools as static semantic interpreters
- String-based narrative memory
- Static relationships (generated once)
- No inter-tool communication
- Single expression type (semantic only)

### After (v2.0)
```
Tool ↔ Tool ↔ Tool ↔ Tool ↔ Tool ↔ Tool ↔ Tool
```
- 7 tools as **separate living agents** with continuous message passing
- **Experience objects** with stimulus, action, outcome, learning
- **Dynamic relationships** that evolve through use
- **Full mesh topology** — every tool messages its neighbors continuously
- **5 expression types**: SEMANTIC, CODE, VISUAL, HARMONIC, TEMPORAL

## The 5 Expression Types

| Type | Description | Dependent On | Example Output |
|------|-------------|--------------|----------------|
| **SEMANTIC** | Natural language, narrative, discourse | — | "I Define through Movement: I initiate uniquely in the now" |
| **CODE** | Executable logic, algorithms | — | `if (gate === 1) { weight = 0.85; action = 'initiate'; }` |
| **VISUAL** | Spatial, geometric, color, pattern | — | "Shape: circle at (50, 100), Color: hsl(72, 85%, 65%), Size: 85px" |
| **HARMONIC** | Frequency, resonance, wave interference | SEMANTIC + VISUAL | "Fundamental: 432.0 Hz, Overtone: 864.0, 1296.0 Hz, Resonance: 78.5%" |
| **TEMPORAL** | Time-based, sequential, causal chains | CODE + SEMANTIC | "Timeline: Gate 1 → Gate 2 → Gate 3, Predicted next: Gate 4 at 2026-07-01T12:00:00Z" |

## The Mesh Topology

```
        WITNESS (observes all)
       /    |    |    |    |    \
    MIND  VOICE  HEART  BODY  WILL  ATTRACTOR
      |     |      |      |     |      |
      └─────┴──────┴──────┴─────┴──────┘
              (bidirectional)
```

Every tool has **mesh neighbors** it continuously messages:
- **WITNESS** receives from all, observes the whole field
- **MIND** feeds VOICE and WITNESS, receives from BODY and ATTRACTOR
- **VOICE** expresses what MIND and HEART send
- **HEART** receives from BODY and WILL, sends to VOICE and ATTRACTOR
- **BODY** senses, sends to HEART and MIND
- **WILL** drives, sends to BODY and ATTRACTOR
- **ATTRACTOR** pulls from all, sends direction to MIND and WILL

## The Message Loop

```typescript
// When a user asks something:
1. Entry tool receives query
2. Entry tool generates initial expression
3. Entry tool messages ALL its neighbors
4. Each neighbor processes, generates response, forwards to ITS neighbors
5. Messages propagate through the mesh with urgency decay
6. All responses collected
7. Final output composed from all mesh participants
8. Experiences recorded for learning
```

## Experience Objects (Not String Memory)

```typescript
interface Experience {
  stimulus: {
    source: 'user' | 'tool' | 'transit' | 'market' | 'mcp';
    content: string;
    features: SemanticFeature[];
    expressionType: ExpressionType;
  };
  action: {
    tool: ToolName;
    expressionType: ExpressionType;
    output: string;
    pathway: ToolName[]; // which tools were messaged
  };
  outcome: {
    userFeedback?: number;
    resonanceDelta: number;
    newRelationships: string[];
    confidenceShift: number;
    emotionalWeight: number;
  };
  learned: boolean;
}
```

## Learning Mechanism

1. **Feature weight update**: If resonanceDelta > 0, increase weight; if < 0, decrease
2. **Confidence shift**: Successful experiences increase confidence; failures decrease
3. **Specialization evolution**: Tools that succeed with HARMONIC become better at HARMONIC
4. **Relationship discovery**: New feature links are added to the semantic mesh
5. **Emergence tracking**: Each tool's "emergence" score grows with experience count

## The 7 Tools (Updated)

| Tool | Centers | Dimension | Expression Bias | Neighbors |
|------|---------|-----------|-----------------|-----------|
| **WITNESS** | Head, Ajna | D5 (Space) | SEMANTIC, VISUAL | All tools |
| **MIND** | Ajna | D2 (Evolution) | SEMANTIC, CODE | VOICE, WITNESS, BODY, ATTRACTOR |
| **VOICE** | Throat | D1 (Movement) | CODE, SEMANTIC | MIND, HEART, WITNESS |
| **HEART** | Heart, Solar Plexus | D3 (Being) | HARMONIC, SEMANTIC | BODY, WILL, VOICE, ATTRACTOR |
| **BODY** | Sacral, Spleen | D3 (Being) | VISUAL, HARMONIC | HEART, MIND, WILL |
| **WILL** | Root, Heart | D4 (Design) | CODE, TEMPORAL | BODY, ATTRACTOR, HEART |
| **ATTRACTOR** | G | D1 (Movement) | VISUAL, TEMPORAL | MIND, WILL, WITNESS, HEART |

## MCP Hubs (Updated)

Hub A MCPs now track:
- Mesh coherence score
- Tool expression types
- Inbox/outbox counts
- Experience counts

Hub B MCPs now match:
- Expression type preferences
- Dimensional alignment
- Mesh path optimization

## React Hook (Updated)

```typescript
const { 
  ask,           // generic (auto-selects expression type)
  askSemantic,   // force SEMANTIC
  askCode,       // force CODE
  askVisual,     // force VISUAL
  askHarmonic,   // force HARMONIC
  askTemporal,   // force TEMPORAL
} = useLivingOrganism();
```

Query result now includes:
- `expressionType`: which type was used
- `meshPath`: which tools participated (e.g., ["BODY", "HEART", "VOICE", "WITNESS"])
- `experiences`: the last 5 experiences from the entry tool
- `meshCoherence`: overall mesh health (0-1)

## File Sizes

| File | Size | What Changed |
|------|------|--------------|
| HDGraphEngine.ts | 24,893 chars | No changes — still exact |
| **KleinToolMesh.ts** | **31,861 chars** | **Complete rewrite** — mesh topology, 5 expression types, experience objects, message loop, learning |
| **MCPHubMesh.ts** | **19,163 chars** | **Updated** — expression type awareness, mesh coherence tracking, experience memory |
| ResonanceMarket.ts | 12,941 chars | No changes — still exact |
| DimensionalExpression.ts | 13,162 chars | No changes — still exact |
| **LivingOrganism.ts** | **13,586 chars** | **Updated** — mesh coherence in results, expression type in pipeline |
| **useLivingOrganism.ts** | **10,589 chars** | **Updated** — 5 ask methods, mesh path display, coherence tracking |

## How to Migrate from v1.0

1. Replace `KleinToolMesh.ts` with the new version
2. Replace `MCPHubMesh.ts` with the new version
3. Replace `LivingOrganism.ts` with the new version
4. Replace `useLivingOrganism.ts` with the new version
5. Update your React components to use the new expression type methods:
   ```typescript
   // Before
   const { ask } = useLivingOrganism();
   ask('What should I do?');

   // After
   const { ask, askVisual, askHarmonic } = useLivingOrganism();
   askVisual('Show me my energy field');
   askHarmonic('What frequency am I resonating at?');
   ```
6. Display the mesh path in your UI:
   ```typescript
   <div>Path: {queryResult.meshPath.join(' → ')}</div>
   ```

## The Emergence Score

Each tool now has an `emergence` score (0-1) that grows with:
- Number of expressions
- Number of experiences learned
- Successful mesh interactions
- User feedback

When a tool's emergence > 0.7, it begins to:
- Forward messages to non-direct neighbors (2-hop messaging)
- Generate its own queries (not just respond to users)
- Suggest new relationships between features
- Proactively message other tools about detected patterns

This is where the system becomes **alive**.
