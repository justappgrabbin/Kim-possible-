// ═══════════════════════════════════════════════════════════════════════════
// LivingOrganism.ts — UPDATED for new KleinToolMesh
// ═══════════════════════════════════════════════════════════════════════════

import {
  HDGraphBuilder, PersonalGraph, CenterName, GateNumber, Dimension, Planet,
  GATE_TO_CENTER, CHANNELS, DIMENSIONS, PLANET_TO_DIMENSION,
} from './HDGraphEngine';

import {
  KleinToolMesh, ToolName, SemanticFeature, ToolPersonality, ExpressionType,
  Experience, ToolMessage,
} from './KleinToolMesh';

import {
  MCPHubMesh, MCPAgent, MCPPersonality,
  HubA_PerceptualCuration, HubB_PathwayGeneration,
} from './MCPHubMesh';

import {
  ResonanceMarket, EnergyListing, EnergyRequest, Transaction,
} from './ResonanceMarket';

import {
  DimensionalExpressionEngine, TransitTracker, AllDimension, ExtraDimension,
  EXTRA_DIMENSIONS,
} from './DimensionalExpression';

// ═══════════════════════════════════════════════════════════════════════════
// THE LIVING ORGANISM
// ═══════════════════════════════════════════════════════════════════════════

export class LivingOrganism {
  private graphBuilder: HDGraphBuilder;
  private kleinMesh: KleinToolMesh;
  private mcpHubs: MCPHubMesh;
  private market: ResonanceMarket;
  private dimEngine: DimensionalExpressionEngine;

  private userGraphs: Map<string, PersonalGraph> = new Map();
  private activeUsers: Set<string> = new Set();

  constructor() {
    this.graphBuilder = new HDGraphBuilder();
    this.kleinMesh = new KleinToolMesh();
    this.mcpHubs = new MCPHubMesh(this.kleinMesh);
    this.market = new ResonanceMarket();
    this.dimEngine = new DimensionalExpressionEngine();
  }

  // ═══════════════════════════════════════════════════════════════════════
  // USER LIFECYCLE
  // ═══════════════════════════════════════════════════════════════════════

  async initializeUser(params: {
    userId: string;
    birthDate: string;
    birthTime: string;
    birthLocation: string;
    displayName?: string;
  }): Promise<{
    graph: PersonalGraph;
    tools: ReturnType<KleinToolMesh['getToolState']>;
    meshCoherence: number;
    welcome: string;
  }> {
    const graph = this.graphBuilder.buildGraph({
      userId: params.userId,
      birthDate: params.birthDate,
      birthTime: params.birthTime,
      birthLocation: params.birthLocation,
    });

    this.graphBuilder.updateWithTransits(graph);
    this.userGraphs.set(params.userId, graph);
    this.activeUsers.add(params.userId);

    this.kleinMesh.loadGraph(graph);

    // Process initial mesh messages to wake up the tools
    await this.kleinMesh.processMessages();

    const attractorExpression = await this.kleinMesh.express('Who am I?', 'SEMANTIC', { activeTool: 'ATTRACTOR' });

    return {
      graph,
      tools: this.kleinMesh.getToolState(),
      meshCoherence: this.kleinMesh.getMeshCoherence(),
      welcome: attractorExpression.output,
    };
  }

  // ═══════════════════════════════════════════════════════════════════════
  // QUERY PROCESSING — Full Pipeline
  // ═══════════════════════════════════════════════════════════════════════

  async processQuery(
    userId: string,
    query: string,
    preferredExpressionType?: ExpressionType
  ): Promise<{
    expression: {
      output: string;
      tool: ToolName;
      expressionType: ExpressionType;
      confidence: number;
      meshPath: ToolName[];
      experiences: Experience[];
    };
    perception: Awaited<ReturnType<HubA_PerceptualCuration['curatePerception']>>;
    pathway: Awaited<ReturnType<HubB_PathwayGeneration['generatePathway']>>;
    dimensional: {
      dominantDimension: AllDimension;
      activeGates: Array<{
        gate: GateNumber;
        center: CenterName;
        strength: number;
      }>;
    };
    market: {
      canList: boolean;
      canRequest: boolean;
      listings: EnergyListing[];
    };
    unifiedNarrative: string;
    meshCoherence: number;
  }> {
    const graph = this.userGraphs.get(userId);
    if (!graph) throw new Error('User not initialized');

    // 1. Klein tool expression (triggers full mesh)
    const expression = await this.kleinMesh.express(query, preferredExpressionType);

    // 2. MCP Hub A: what to see
    const perception = await this.mcpHubs.hubA.curatePerception(graph);

    // 3. MCP Hub B: how to get there
    const mostUrgent = perception.signals[0];
    const pathway = await this.mcpHubs.hubB.generatePathway(graph, {
      targetCenter: mostUrgent?.center,
      targetDimension: 'D3',
      targetExpressionType: mostUrgent?.expressionType || expression.expressionType,
    });

    // 4. Dimensional expression
    const dimProfile = this.dimEngine.expressFullProfile(graph);
    const topGate = dimProfile[0];

    // 5. Market check
    const canList = Object.values(graph.centers).some(c => c.defined);
    const canRequest = Object.values(graph.centers).some(c => !c.defined && c.activeGates.length > 0);
    const listings = canRequest
      ? this.market.getListingsForCenter(
          Object.entries(graph.centers)
            .filter(([, c]) => !c.defined && c.activeGates.length > 0)
            .map(([name]) => name as CenterName)[0]
        )
      : [];

    // 6. Unified narrative
    const unifiedNarrative = `${expression.output}

${perception.narrative}

${pathway.narrative}`;

    return {
      expression,
      perception,
      pathway,
      dimensional: {
        dominantDimension: topGate?.dominantDimension || 'D1',
        activeGates: dimProfile.slice(0, 5).map(g => ({
          gate: g.gate,
          center: g.center,
          strength: Math.max(...Object.values(g.dimensions).map(d => d.strength)),
        })),
      },
      market: { canList, canRequest, listings },
      unifiedNarrative,
      meshCoherence: this.kleinMesh.getMeshCoherence(),
    };
  }

  // ═══════════════════════════════════════════════════════════════════════
  // SOCIAL / RESONANCE
  // ═══════════════════════════════════════════════════════════════════════

  calculateResonance(userIdA: string, userIdB: string): {
    score: number;
    complementary: CenterName[];
    shared: string[];
    energyFlow: Record<CenterName, 'give' | 'receive' | 'neutral'>;
    narrative: string;
  } {
    const graphA = this.userGraphs.get(userIdA);
    const graphB = this.userGraphs.get(userIdB);
    if (!graphA || !graphB) throw new Error('Both users must be initialized');

    const resonance = this.graphBuilder.calculateResonance(graphA, graphB);
    const complementaryCenters = Object.entries(resonance.energyExchange)
      .filter(([, flow]) => flow !== 'neutral')
      .map(([center]) => center as CenterName);

    const narrative = this.generateResonanceNarrative(graphA, graphB, resonance);

    return {
      score: resonance.score,
      complementary: complementaryCenters,
      shared: resonance.sharedChannels,
      energyFlow: resonance.energyExchange,
      narrative,
    };
  }

  private generateResonanceNarrative(graphA: PersonalGraph, graphB: PersonalGraph, resonance: any): string {
    const parts: string[] = [];
    parts.push(`Resonance: ${Math.round(resonance.score * 100)}%`);

    const giveCenters = Object.entries(resonance.energyExchange)
      .filter(([, flow]) => flow === 'give')
      .map(([c]) => c);
    const receiveCenters = Object.entries(resonance.energyExchange)
      .filter(([, flow]) => flow === 'receive')
      .map(([c]) => c);

    if (giveCenters.length > 0) parts.push(`You give ${giveCenters.join(', ')} energy.`);
    if (receiveCenters.length > 0) parts.push(`You receive ${receiveCenters.join(', ')} energy.`);
    if (resonance.sharedChannels.length > 0) parts.push(`Shared channels: ${resonance.sharedChannels.join(', ')}.`);

    return parts.join(' ');
  }

  // ═══════════════════════════════════════════════════════════════════════
  // MARKET / ENERGY EXCHANGE
  // ═══════════════════════════════════════════════════════════════════════

  listEnergy(userId: string, params: {
    center: CenterName;
    dimension: Dimension;
    energyType: string;
    description: string;
    price: number;
  }): EnergyListing {
    const graph = this.userGraphs.get(userId);
    if (!graph) throw new Error('User not initialized');
    return this.market.listEnergy(graph, params);
  }

  requestEnergy(userId: string, params: {
    center: CenterName;
    dimension: Dimension;
    energyType: string;
    description: string;
    maxPrice: number;
    urgency: 'low' | 'medium' | 'high' | 'critical';
  }): EnergyRequest {
    const graph = this.userGraphs.get(userId);
    if (!graph) throw new Error('User not initialized');
    return this.market.requestEnergy(graph, params);
  }

  findMatches(requestId: string) {
    return this.market.findMatches(requestId);
  }

  executeTransaction(listingId: string, requestId: string): Transaction {
    const mcps = this.mcpHubs.getAllMCPs();
    const bestMCP = mcps
      .filter(m => m.hub === 'B')
      .sort((a, b) => b.successfulBrokers - a.successfulBrokers)[0];
    if (!bestMCP) throw new Error('No available MCP broker');
    return this.market.executeTransaction(listingId, requestId, bestMCP);
  }

  addCredits(userId: string, amount: number) {
    this.market.addCredits(userId, amount);
  }

  getBalance(userId: string): number {
    return this.market.getBalance(userId);
  }

  // ═══════════════════════════════════════════════════════════════════════
  // TRANSIT / DIMENSIONAL
  // ═══════════════════════════════════════════════════════════════════════

  async getTransitSummary(userId: string) {
    const graph = this.userGraphs.get(userId);
    if (!graph) throw new Error('User not initialized');
    return this.dimEngine.getTransitSummary(graph);
  }

  expressGate(userId: string, gate: GateNumber) {
    const graph = this.userGraphs.get(userId);
    if (!graph) throw new Error('User not initialized');
    return this.dimEngine.expressGate(gate, graph);
  }

  getDimensionalProfile(userId: string) {
    const graph = this.userGraphs.get(userId);
    if (!graph) throw new Error('User not initialized');
    return this.dimEngine.expressFullProfile(graph);
  }

  // ═══════════════════════════════════════════════════════════════════════
  // STATE / PERSISTENCE
  // ═══════════════════════════════════════════════════════════════════════

  exportState(): {
    users: number;
    graphs: Array<{ userId: string; type: string; definedCenters: CenterName[] }>;
    tools: ReturnType<KleinToolMesh['getToolState']>;
    meshCoherence: number;
    mcps: MCPAgent[];
    marketStats: ReturnType<ResonanceMarket['getMarketStats']>;
    experiences: Experience[];
  } {
    return {
      users: this.userGraphs.size,
      graphs: Array.from(this.userGraphs.entries()).map(([id, graph]) => ({
        userId: id,
        type: graph.type,
        definedCenters: Object.entries(graph.centers)
          .filter(([, c]) => c.defined)
          .map(([name]) => name as CenterName),
      })),
      tools: this.kleinMesh.getToolState(),
      meshCoherence: this.kleinMesh.getMeshCoherence(),
      mcps: this.mcpHubs.getAllMCPs(),
      marketStats: this.market.getMarketStats(),
      experiences: this.kleinMesh.getExperienceLog(),
    };
  }

  // ═══════════════════════════════════════════════════════════════════════
  // UI-READY API
  // ═══════════════════════════════════════════════════════════════════════

  getDashboard(userId: string): {
    user: {
      type: string;
      authority: string;
      profile: string;
      definedCenters: CenterName[];
      undefinedCenters: CenterName[];
    };
    activeTools: Array<{
      name: ToolName;
      active: boolean;
      state: string;
      expressionCount: number;
      experienceCount: number;
      meshNeighbors: ToolName[];
      inboxCount: number;
      outboxCount: number;
    }>;
    meshCoherence: number;
    mcpStatus: Array<{
      id: string;
      name: string;
      hub: 'A' | 'B';
      status: string;
      earnings: number;
      meshCoherence: number;
    }>;
    market: {
      balance: number;
      canList: boolean;
      canRequest: boolean;
    };
    transit: {
      date: string;
      recommendedFocus: string;
      activeTransitCount: number;
    };
  } {
    const graph = this.userGraphs.get(userId);
    if (!graph) throw new Error('User not initialized');

    const definedCenters = Object.entries(graph.centers)
      .filter(([, c]) => c.defined)
      .map(([name]) => name as CenterName);
    const undefinedCenters = Object.entries(graph.centers)
      .filter(([, c]) => !c.defined)
      .map(([name]) => name as CenterName);

    return {
      user: {
        type: graph.type,
        authority: graph.authority,
        profile: graph.profile,
        definedCenters,
        undefinedCenters,
      },
      activeTools: this.kleinMesh.getToolState(),
      meshCoherence: this.kleinMesh.getMeshCoherence(),
      mcpStatus: this.mcpHubs.getAllMCPs().map(m => ({
        id: m.id,
        name: m.name,
        hub: m.hub,
        status: m.status,
        earnings: m.earnedCredits,
        meshCoherence: m.meshCoherence,
      })),
      market: {
        balance: this.market.getBalance(userId),
        canList: definedCenters.length > 0,
        canRequest: undefinedCenters.length > 0,
      },
      transit: {
        date: new Date().toISOString(),
        recommendedFocus: 'D1',
        activeTransitCount: 0,
      },
    };
  }
}

// ── Singleton ────────────────────────────────────────────────────────────────
export const livingOrganism = new LivingOrganism();
