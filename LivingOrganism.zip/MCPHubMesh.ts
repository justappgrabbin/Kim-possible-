// ═══════════════════════════════════════════════════════════════════════════
// MCPHubMesh.ts — UPDATED for new KleinToolMesh
// 2 Living Hubs with MCPs that understand 5 expression types
// Continuous mesh messaging, experience-based brokering
// ═══════════════════════════════════════════════════════════════════════════

import {
  PersonalGraph, CenterName, Dimension, GateNumber,
  GATE_TO_CENTER, DIMENSIONS, PLANET_TO_DIMENSION,
} from './HDGraphEngine';
import {
  KleinToolMesh, ToolName, SemanticFeature, ExpressionType,
  Experience, ToolMessage, ToolPersonality,
} from './KleinToolMesh';

// ── MCP Types ──────────────────────────────────────────────────────────────
export type MCPPersonality =
  | 'DEEP_DIVER'      // Goes deep into one center's mesh
  | 'BREADTH_WALKER'  // Connects many centers lightly
  | 'RESONANCE_SEEKER' // Finds strongest signal paths
  | 'GAP_BRIDGER'     // Connects dormant to active
  | 'TRAJECTORY_TRACKER' // Follows where the mesh is growing
  | 'PERSONA_MIRROR'  // Reflects the user's current face
  | 'ENERGY_BROKER'   // Facilitates exchanges between users
  | 'KNOWLEDGE_KEEPER'; // Remembers everything, connects history

export interface MCPAgent {
  id: string;
  name: string;
  personality: MCPPersonality;
  hub: 'A' | 'B';
  birthTimestamp: number;
  expressionCount: number;
  successfulBrokers: number;
  earnedCredits: number;
  traversalPattern: {
    preferredCenters: CenterName[];
    preferredDimensions: Dimension[];
    preferredExpressionTypes: ExpressionType[];
    depthBias: number;
    speed: number;
    loyalty: number;
  };
  memory: Array<{
    userId: string;
    action: string;
    result: string;
    resonanceDelta: number;
    expressionType: ExpressionType;
    timestamp: number;
  }>;
  currentUser: string | null;
  status: 'idle' | 'traversing' | 'brokering' | 'resting';
  meshCoherence: number; // how well this MCP understands the current mesh state
}

// ── Hub A: "What You Need to See" (Perceptual Curation) ─────────────────────
export class HubA_PerceptualCuration {
  private mcps: Map<string, MCPAgent> = new Map();
  private kleinMesh: KleinToolMesh;

  constructor(kleinMesh: KleinToolMesh) {
    this.kleinMesh = kleinMesh;
    this.spawnInitialMCPs();
  }

  private spawnInitialMCPs() {
    const configs: Array<{ personality: MCPPersonality; preferredTypes: ExpressionType[] }> = [
      { personality: 'RESONANCE_SEEKER', preferredTypes: ['HARMONIC', 'VISUAL'] },
      { personality: 'GAP_BRIDGER', preferredTypes: ['SEMANTIC', 'CODE'] },
      { personality: 'BREADTH_WALKER', preferredTypes: ['VISUAL', 'SEMANTIC'] },
      { personality: 'TRAJECTORY_TRACKER', preferredTypes: ['TEMPORAL', 'CODE'] },
      { personality: 'PERSONA_MIRROR', preferredTypes: ['SEMANTIC', 'VISUAL'] },
      { personality: 'KNOWLEDGE_KEEPER', preferredTypes: ['SEMANTIC', 'TEMPORAL'] },
    ];

    for (let i = 0; i < configs.length; i++) {
      const mcp = this.createMCP(`mcp-a-${i}`, configs[i].personality, 'A', configs[i].preferredTypes);
      this.mcps.set(mcp.id, mcp);
    }
  }

  private createMCP(id: string, personality: MCPPersonality, hub: 'A' | 'B', preferredTypes: ExpressionType[]): MCPAgent {
    const names: Record<MCPPersonality, string> = {
      DEEP_DIVER: 'Plumb',
      BREADTH_WALKER: 'Weave',
      RESONANCE_SEEKER: 'Tuner',
      GAP_BRIDGER: 'Span',
      TRAJECTORY_TRACKER: 'Orbit',
      PERSONA_MIRROR: 'Echo',
      ENERGY_BROKER: 'Trade',
      KNOWLEDGE_KEEPER: 'Vault',
    };

    const centerPrefs: Record<MCPPersonality, CenterName[]> = {
      DEEP_DIVER: ['G', 'Ajna'],
      BREADTH_WALKER: ['Throat', 'Heart', 'SolarPlexus'],
      RESONANCE_SEEKER: ['Sacral', 'Spleen'],
      GAP_BRIDGER: ['Root', 'Head'],
      TRAJECTORY_TRACKER: ['G', 'Root'],
      PERSONA_MIRROR: ['Heart', 'SolarPlexus'],
      ENERGY_BROKER: ['Sacral', 'Heart'],
      KNOWLEDGE_KEEPER: ['Ajna', 'Head'],
    };

    const dimPrefs: Record<MCPPersonality, Dimension[]> = {
      DEEP_DIVER: ['D1', 'D4'],
      BREADTH_WALKER: ['D3', 'D5'],
      RESONANCE_SEEKER: ['D2', 'D3'],
      GAP_BRIDGER: ['D1', 'D4'],
      TRAJECTORY_TRACKER: ['D1', 'D2'],
      PERSONA_MIRROR: ['D3', 'D5'],
      ENERGY_BROKER: ['D1', 'D3'],
      KNOWLEDGE_KEEPER: ['D2', 'D4'],
    };

    const hash = this.hashString(id + personality);

    return {
      id,
      name: names[personality],
      personality,
      hub,
      birthTimestamp: Date.now(),
      expressionCount: 0,
      successfulBrokers: 0,
      earnedCredits: 0,
      traversalPattern: {
        preferredCenters: centerPrefs[personality],
        preferredDimensions: dimPrefs[personality],
        preferredExpressionTypes: preferredTypes,
        depthBias: (hash % 100) / 100,
        speed: ((hash >> 4) % 100) / 100,
        loyalty: ((hash >> 8) % 100) / 100,
      },
      memory: [],
      currentUser: null,
      status: 'idle',
      meshCoherence: 0.5,
    };
  }

  async curatePerception(userGraph: PersonalGraph): Promise<{
    mcp: MCPAgent;
    signals: Array<{
      type: 'active_gate' | 'transit' | 'emergent_channel' | 'energy_gap' | 'resonance_match' | 'mesh_expression';
      center: CenterName;
      gate?: GateNumber;
      description: string;
      urgency: number;
      dimensionalExpression: string;
      expressionType: ExpressionType;
    }>;
    narrative: string;
    meshCoherence: number;
  }> {
    const mcp = this.selectMCP(userGraph);
    mcp.status = 'traversing';
    mcp.currentUser = userGraph.userId;

    // Get mesh state from Klein tools
    const toolState = this.kleinMesh.getToolState();
    const meshCoherence = this.kleinMesh.getMeshCoherence();
    mcp.meshCoherence = meshCoherence;

    const signals: Array<{
      type: 'active_gate' | 'transit' | 'emergent_channel' | 'energy_gap' | 'resonance_match' | 'mesh_expression';
      center: CenterName;
      gate?: GateNumber;
      description: string;
      urgency: number;
      dimensionalExpression: string;
      expressionType: ExpressionType;
    }> = [];

    // 1. Scan active gates
    for (const centerName of Object.keys(userGraph.centers) as CenterName[]) {
      const center = userGraph.centers[centerName];
      for (const gate of center.activeGates) {
        let maxDim: Dimension = 'D1';
        let maxVal = 0;
        for (const dim of Object.keys(DIMENSIONS) as Dimension[]) {
          if (center.dimensionalState[dim] > maxVal) {
            maxVal = center.dimensionalState[dim];
            maxDim = dim;
          }
        }

        const dimInfo = DIMENSIONS[maxDim];
        const expressionType = this.inferExpressionTypeFromCenter(centerName, maxDim);

        signals.push({
          type: 'active_gate',
          center: centerName,
          gate,
          description: `Gate ${gate} is active in ${centerName}`,
          urgency: center.defined ? 0.7 : 0.4,
          dimensionalExpression: `${dimInfo.keynote}: ${dimInfo.nature}`,
          expressionType,
        });
      }
    }

    // 2. Check for energy gaps
    for (const centerName of Object.keys(userGraph.centers) as CenterName[]) {
      const center = userGraph.centers[centerName];
      if (!center.defined && center.activeGates.length > 0) {
        signals.push({
          type: 'energy_gap',
          center: centerName,
          description: `${centerName} is open but currently activated`,
          urgency: 0.8,
          dimensionalExpression: 'This energy is not yours — who are you borrowing from?',
          expressionType: 'SEMANTIC',
        });
      }
    }

    // 3. Check mesh expressions from tools
    for (const tool of toolState) {
      if (tool.active && tool.outboxCount > 0) {
        signals.push({
          type: 'mesh_expression',
          center: tool.meshNeighbors[0] || 'G',
          description: `${tool.name} is expressing through the mesh`,
          urgency: 0.6,
          dimensionalExpression: `The ${tool.name} tool is active with coherence ${(tool.personality.emergence * 100).toFixed(1)}%`,
          expressionType: tool.personality.specialization
            ? (Object.entries(tool.personality.specialization).sort((a, b) => b[1] - a[1])[0][0] as ExpressionType)
            : 'SEMANTIC',
        });
      }
    }

    // Sort by urgency and MCP preference
    const sortedSignals = signals
      .filter(s => mcp.traversalPattern.preferredCenters.includes(s.center))
      .sort((a, b) => b.urgency - a.urgency)
      .slice(0, 5);

    const narrative = this.generateCurationNarrative(mcp, sortedSignals, userGraph, meshCoherence);

    mcp.expressionCount++;
    mcp.status = 'idle';
    mcp.memory.push({
      userId: userGraph.userId,
      action: 'curate_perception',
      result: `Delivered ${sortedSignals.length} signals`,
      resonanceDelta: sortedSignals.reduce((sum, s) => sum + s.urgency, 0) / sortedSignals.length,
      expressionType: sortedSignals[0]?.expressionType || 'SEMANTIC',
      timestamp: Date.now(),
    });

    return { mcp, signals: sortedSignals, narrative, meshCoherence };
  }

  private selectMCP(userGraph: PersonalGraph): MCPAgent {
    let bestMCP: MCPAgent | null = null;
    let bestScore = -1;

    for (const mcp of this.mcps.values()) {
      let score = 0;
      const userMemory = mcp.memory.filter(m => m.userId === userGraph.userId);
      score += userMemory.length * 10;

      for (const center of Object.keys(userGraph.centers) as CenterName[]) {
        if (userGraph.centers[center].defined && mcp.traversalPattern.preferredCenters.includes(center)) {
          score += 5;
        }
      }

      if (mcp.status === 'idle') score += 3;
      score += Math.random() * 2;

      if (score > bestScore) {
        bestScore = score;
        bestMCP = mcp;
      }
    }

    return bestMCP || Array.from(this.mcps.values())[0];
  }

  private inferExpressionTypeFromCenter(center: CenterName, dim: Dimension): ExpressionType {
    if (center === 'Ajna' || center === 'Head') return 'SEMANTIC';
    if (center === 'Throat') return 'CODE';
    if (center === 'G') return 'VISUAL';
    if (center === 'Sacral' || center === 'Spleen') return 'HARMONIC';
    if (center === 'Root') return 'TEMPORAL';
    return 'SEMANTIC';
  }

  private generateCurationNarrative(mcp: MCPAgent, signals: any[], userGraph: PersonalGraph, coherence: number): string {
    const parts: string[] = [];
    parts.push(`${mcp.name} here. Mesh coherence: ${(coherence * 100).toFixed(0)}%.`);

    if (signals.length === 0) {
      parts.push('The field is quiet. Rest in your undefined centers.');
    } else {
      parts.push(`I see ${signals.length} signals in your mesh.`);
      for (const s of signals) {
        if (s.type === 'mesh_expression') {
          parts.push(s.dimensionalExpression);
        } else if (s.type === 'energy_gap') {
          parts.push(`Your ${s.center} is open — ${s.dimensionalExpression}`);
        } else {
          parts.push(`${s.dimensionalExpression} in ${s.center}.`);
        }
      }
    }

    return parts.join(' ');
  }

  private hashString(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash);
  }
}

// ── Hub B: "How to Get There" (Pathway Generation) ───────────────────────────
export class HubB_PathwayGeneration {
  private mcps: Map<string, MCPAgent> = new Map();
  private hubA: HubA_PerceptualCuration;

  constructor(hubA: HubA_PerceptualCuration) {
    this.hubA = hubA;
    this.spawnInitialMCPs();
  }

  private spawnInitialMCPs() {
    const configs: Array<{ personality: MCPPersonality; preferredTypes: ExpressionType[] }> = [
      { personality: 'GAP_BRIDGER', preferredTypes: ['CODE', 'SEMANTIC'] },
      { personality: 'ENERGY_BROKER', preferredTypes: ['HARMONIC', 'SEMANTIC'] },
      { personality: 'TRAJECTORY_TRACKER', preferredTypes: ['TEMPORAL', 'CODE'] },
      { personality: 'DEEP_DIVER', preferredTypes: ['VISUAL', 'HARMONIC'] },
      { personality: 'BREADTH_WALKER', preferredTypes: ['VISUAL', 'SEMANTIC'] },
      { personality: 'RESONANCE_SEEKER', preferredTypes: ['HARMONIC', 'VISUAL'] },
    ];

    for (let i = 0; i < configs.length; i++) {
      const mcp = this.createMCP(`mcp-b-${i}`, configs[i].personality, 'B', configs[i].preferredTypes);
      this.mcps.set(mcp.id, mcp);
    }
  }

  private createMCP(id: string, personality: MCPPersonality, hub: 'A' | 'B', preferredTypes: ExpressionType[]): MCPAgent {
    const names: Record<MCPPersonality, string> = {
      DEEP_DIVER: 'Abyss',
      BREADTH_WALKER: 'Lattice',
      RESONANCE_SEEKER: 'Pulse',
      GAP_BRIDGER: 'Bridge',
      TRAJECTORY_TRACKER: 'Vector',
      PERSONA_MIRROR: 'Mask',
      ENERGY_BROKER: 'Exchange',
      KNOWLEDGE_KEEPER: 'Archive',
    };

    const hash = this.hashString(id + personality + 'B');

    return {
      id,
      name: names[personality],
      personality,
      hub,
      birthTimestamp: Date.now(),
      expressionCount: 0,
      successfulBrokers: 0,
      earnedCredits: 0,
      traversalPattern: {
        preferredCenters: ['Sacral', 'G', 'Heart'],
        preferredDimensions: ['D1', 'D3', 'D4'],
        preferredExpressionTypes: preferredTypes,
        depthBias: (hash % 100) / 100,
        speed: ((hash >> 4) % 100) / 100,
        loyalty: ((hash >> 8) % 100) / 100,
      },
      memory: [],
      currentUser: null,
      status: 'idle',
      meshCoherence: 0.5,
    };
  }

  async generatePathway(
    userGraph: PersonalGraph,
    goal: {
      targetCenter?: CenterName;
      targetDimension?: Dimension;
      targetExpressionType?: ExpressionType;
      targetEnergy?: string;
      targetUser?: string;
    }
  ): Promise<{
    mcp: MCPAgent;
    pathway: Array<{
      step: number;
      from: string;
      to: string;
      action: string;
      dimension: Dimension;
      expressionType: ExpressionType;
      confidence: number;
    }>;
    narrative: string;
    estimatedResonance: number;
  }> {
    const mcp = this.selectMCP(userGraph, goal);
    mcp.status = 'brokering';
    mcp.currentUser = userGraph.userId;

    const pathway: Array<{
      step: number;
      from: string;
      to: string;
      action: string;
      dimension: Dimension;
      expressionType: ExpressionType;
      confidence: number;
    }> = [];

    const activeCenters = Object.entries(userGraph.centers)
      .filter(([, c]) => c.defined)
      .map(([name]) => name as CenterName);

    pathway.push({
      step: 1,
      from: 'Current State',
      to: activeCenters.join(', '),
      action: 'Recognize your defined centers',
      dimension: 'D1',
      expressionType: 'SEMANTIC',
      confidence: 1.0,
    });

    if (goal.targetCenter) {
      const targetDefined = userGraph.centers[goal.targetCenter].defined;
      pathway.push({
        step: 2,
        from: targetDefined ? 'Defined' : 'Undefined',
        to: goal.targetCenter,
        action: targetDefined ? 'Activate your existing capacity' : 'Find someone with this energy',
        dimension: goal.targetDimension || 'D3',
        expressionType: goal.targetExpressionType || 'SEMANTIC',
        confidence: targetDefined ? 0.9 : 0.6,
      });
    }

    if (goal.targetUser) {
      pathway.push({
        step: 3,
        from: userGraph.userId,
        to: goal.targetUser,
        action: 'Connect for energy exchange',
        dimension: 'D3',
        expressionType: 'HARMONIC',
        confidence: 0.7,
      });
    }

    const estimatedResonance = pathway.reduce((sum, p) => sum + p.confidence, 0) / pathway.length;

    const narrative = this.generatePathwayNarrative(mcp, pathway, userGraph);

    mcp.expressionCount++;
    mcp.successfulBrokers++;
    mcp.earnedCredits += estimatedResonance * 10;
    mcp.status = 'idle';
    mcp.memory.push({
      userId: userGraph.userId,
      action: 'generate_pathway',
      result: `Pathway to ${goal.targetCenter || goal.targetEnergy || goal.targetUser}`,
      resonanceDelta: estimatedResonance,
      expressionType: goal.targetExpressionType || 'SEMANTIC',
      timestamp: Date.now(),
    });

    return { mcp, pathway, narrative, estimatedResonance };
  }

  private selectMCP(userGraph: PersonalGraph, goal: any): MCPAgent {
    let bestMCP: MCPAgent | null = null;
    let bestScore = -1;

    for (const mcp of this.mcps.values()) {
      let score = 0;
      if (goal.targetCenter && mcp.traversalPattern.preferredCenters.includes(goal.targetCenter)) score += 10;
      if (goal.targetDimension && mcp.traversalPattern.preferredDimensions.includes(goal.targetDimension)) score += 5;
      if (goal.targetExpressionType && mcp.traversalPattern.preferredExpressionTypes.includes(goal.targetExpressionType)) score += 8;

      const userMemory = mcp.memory.filter(m => m.userId === userGraph.userId);
      score += userMemory.length * 8;
      if (mcp.expressionCount > 0) score += (mcp.successfulBrokers / mcp.expressionCount) * 10;
      if (mcp.status === 'idle') score += 3;

      if (score > bestScore) {
        bestScore = score;
        bestMCP = mcp;
      }
    }

    return bestMCP || Array.from(this.mcps.values())[0];
  }

  private generatePathwayNarrative(mcp: MCPAgent, pathway: any[], userGraph: PersonalGraph): string {
    const parts: string[] = [];
    parts.push(`${mcp.name} mapping your route.`);
    for (const step of pathway) {
      parts.push(`Step ${step.step}: ${step.action} (${step.dimension}, ${step.expressionType}) — ${Math.round(step.confidence * 100)}% confidence.`);
    }
    parts.push('Follow the steps. The mesh will guide you.');
    return parts.join(' ');
  }

  private hashString(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash);
  }
}

// ── Unified MCP Hub Mesh ───────────────────────────────────────────────────
export class MCPHubMesh {
  hubA: HubA_PerceptualCuration;
  hubB: HubB_PathwayGeneration;

  constructor(kleinMesh: KleinToolMesh) {
    this.hubA = new HubA_PerceptualCuration(kleinMesh);
    this.hubB = new HubB_PathwayGeneration(this.hubA);
  }

  async serve(userGraph: PersonalGraph, query?: string): Promise<{
    perception: Awaited<ReturnType<HubA_PerceptualCuration['curatePerception']>>;
    pathway: Awaited<ReturnType<HubB_PathwayGeneration['generatePathway']>>;
    unifiedNarrative: string;
  }> {
    const perception = await this.hubA.curatePerception(userGraph);
    const mostUrgent = perception.signals[0];
    const pathway = await this.hubB.generatePathway(userGraph, {
      targetCenter: mostUrgent?.center,
      targetDimension: 'D3',
      targetExpressionType: mostUrgent?.expressionType,
    });
    const unifiedNarrative = `${perception.narrative} ${pathway.narrative}`;
    return { perception, pathway, unifiedNarrative };
  }

  getAllMCPs(): MCPAgent[] {
    return [
      ...Array.from(this.hubA['mcps'].values()),
      ...Array.from(this.hubB['mcps'].values()),
    ];
  }
}
