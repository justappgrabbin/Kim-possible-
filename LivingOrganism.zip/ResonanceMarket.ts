// ═══════════════════════════════════════════════════════════════════════════
// ResonanceMarket.ts — Energy Exchange Profit Membrane
// ═══════════════════════════════════════════════════════════════════════════

import { PersonalGraph, CenterName, Dimension } from './HDGraphEngine';
import { MCPAgent } from './MCPHubMesh';

// ── Transaction Types ──────────────────────────────────────────────────────
export type TransactionType =
  | 'ENERGY_LENDING'      // Defined center lends to undefined center
  | 'INSIGHT_BROKERAGE'   // Defined Ajna provides clarity
  | 'DIRECTIONAL_GUIDANCE' // Defined G provides direction
  | 'EMOTIONAL_SUPPORT'   // Defined SP provides emotional truth
  | 'INTUITIVE_READING'   // Defined Spleen provides gut-check
  | 'LIFE_FORCE_BOOST'    // Defined Sacral provides energy
  | 'WILL_POWER_TRANSFER' // Defined Heart provides drive
  | 'IDENTITY_MIRRORING'  // Defined G reflects identity
  | 'KLEIN_TUNING'        // Tool tuning subscription
  | 'MCP_BROKERAGE';      // MCP facilitation fee

export interface EnergyListing {
  id: string;
  sellerId: string;          // user who has the defined energy
  sellerName: string;
  center: CenterName;
  dimension: Dimension;
  energyType: string;        // e.g., "Sacral Response", "Ajna Clarity"
  description: string;
  price: number;             // in credits
  availability: 'immediate' | 'scheduled' | 'queued';
  resonanceDepth: number;   // 0-1, how deep the tuning goes
  kleinToolTuned: boolean;  // has the Klein tool been personalized?
  rating: number;           // 0-5
  transactionCount: number;
  createdAt: number;
}

export interface EnergyRequest {
  id: string;
  buyerId: string;
  buyerName: string;
  center: CenterName;
  dimension: Dimension;
  energyType: string;
  description: string;
  maxPrice: number;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  preferredSellers: string[];
  createdAt: number;
}

export interface Transaction {
  id: string;
  type: TransactionType;
  listingId: string;
  requestId: string;
  sellerId: string;
  buyerId: string;
  mcpId: string;            // which MCP brokered this
  amount: number;           // total credits
  mcpFee: number;           // MCP's cut (10%)
  platformFee: number;      // platform cut (5%)
  sellerReceives: number;   // what seller gets
  resonanceScore: number;   // 0-1, quality of match
  status: 'pending' | 'active' | 'completed' | 'disputed';
  startedAt: number;
  completedAt?: number;
  review?: {
    rating: number;
    comment: string;
    resonanceDelta: number;
  };
}

// ── The Resonance Market ─────────────────────────────────────────────────────
export class ResonanceMarket {
  private listings: Map<string, EnergyListing> = new Map();
  private requests: Map<string, EnergyRequest> = new Map();
  private transactions: Map<string, Transaction> = new Map();
  private userBalances: Map<string, number> = new Map(); // credit balances
  private mcpEarnings: Map<string, number> = new Map();
  private platformRevenue: number = 0;

  private readonly MCP_FEE_RATE = 0.10;     // 10% to MCP
  private readonly PLATFORM_FEE_RATE = 0.05; // 5% to platform

  // ── Listing Management ─────────────────────────────────────────────────────

  listEnergy(userGraph: PersonalGraph, listing: Omit<EnergyListing, 'id' | 'sellerId' | 'sellerName' | 'resonanceDepth' | 'rating' | 'transactionCount' | 'createdAt'>): EnergyListing {
    // Verify user actually has this energy defined
    const center = userGraph.centers[listing.center];
    if (!center.defined) {
      throw new Error(`Cannot list energy from undefined center: ${listing.center}`);
    }

    const fullListing: EnergyListing = {
      ...listing,
      id: `list-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      sellerId: userGraph.userId,
      sellerName: userGraph.userId, // would be user's display name
      resonanceDepth: this.calculateResonanceDepth(userGraph, listing.center, listing.dimension),
      rating: 0,
      transactionCount: 0,
      createdAt: Date.now(),
    };

    this.listings.set(fullListing.id, fullListing);
    return fullListing;
  }

  private calculateResonanceDepth(graph: PersonalGraph, center: CenterName, dimension: Dimension): number {
    const c = graph.centers[center];
    const dimActivation = c.dimensionalState[dimension];
    const gateCount = c.activeGates.length;
    const channelCount = c.channels.length;
    return Math.min(1, (dimActivation + gateCount * 0.05 + channelCount * 0.1) / 3);
  }

  // ── Request Management ───────────────────────────────────────────────────

  requestEnergy(userGraph: PersonalGraph, request: Omit<EnergyRequest, 'id' | 'buyerId' | 'buyerName' | 'createdAt'>): EnergyRequest {
    // Verify user actually needs this energy (undefined center)
    const center = userGraph.centers[request.center];
    if (center.defined) {
      throw new Error(`You already have ${request.center} defined — no need to request`);
    }

    const fullRequest: EnergyRequest = {
      ...request,
      id: `req-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      buyerId: userGraph.userId,
      buyerName: userGraph.userId,
      createdAt: Date.now(),
    };

    this.requests.set(fullRequest.id, fullRequest);
    return fullRequest;
  }

  // ── Matching Engine ────────────────────────────────────────────────────────

  findMatches(requestId: string): Array<{
    listing: EnergyListing;
    matchScore: number;
    estimatedResonance: number;
    price: number;
  }> {
    const request = this.requests.get(requestId);
    if (!request) throw new Error('Request not found');

    const matches: Array<{
      listing: EnergyListing;
      matchScore: number;
      estimatedResonance: number;
      price: number;
    }> = [];

    for (const listing of this.listings.values()) {
      // Basic filter: same center, within price
      if (listing.center !== request.center) continue;
      if (listing.price > request.maxPrice) continue;
      if (listing.availability === 'queued' && request.urgency === 'critical') continue;

      // Calculate match score
      let score = 0;

      // Dimension alignment
      if (listing.dimension === request.dimension) score += 0.3;
      else if (listing.dimension === 'D3' || request.dimension === 'D3') score += 0.1;

      // Resonance depth
      score += listing.resonanceDepth * 0.3;

      // Rating
      if (listing.rating > 0) score += (listing.rating / 5) * 0.2;

      // Urgency match
      if (listing.availability === 'immediate' && request.urgency === 'critical') score += 0.2;

      // Price efficiency
      const priceRatio = listing.price / request.maxPrice;
      score += (1 - priceRatio) * 0.1;

      // Preferred seller boost
      if (request.preferredSellers.includes(listing.sellerId)) score += 0.1;

      matches.push({
        listing,
        matchScore: Math.min(1, score),
        estimatedResonance: listing.resonanceDepth * (0.7 + Math.random() * 0.3),
        price: listing.price,
      });
    }

    return matches.sort((a, b) => b.matchScore - a.matchScore);
  }

  // ── Transaction Execution ──────────────────────────────────────────────────

  executeTransaction(
    listingId: string,
    requestId: string,
    mcp: MCPAgent
  ): Transaction {
    const listing = this.listings.get(listingId);
    const request = this.requests.get(requestId);
    if (!listing || !request) throw new Error('Listing or request not found');

    const buyerBalance = this.userBalances.get(request.buyerId) || 0;
    if (buyerBalance < listing.price) {
      throw new Error('Insufficient credits');
    }

    // Calculate fees
    const totalAmount = listing.price;
    const mcpFee = totalAmount * this.MCP_FEE_RATE;
    const platformFee = totalAmount * this.PLATFORM_FEE_RATE;
    const sellerReceives = totalAmount - mcpFee - platformFee;

    // Deduct from buyer
    this.userBalances.set(request.buyerId, buyerBalance - totalAmount);

    // Add to seller
    const sellerBalance = this.userBalances.get(listing.sellerId) || 0;
    this.userBalances.set(listing.sellerId, sellerBalance + sellerReceives);

    // Add to MCP
    const mcpEarnings = this.mcpEarnings.get(mcp.id) || 0;
    this.mcpEarnings.set(mcp.id, mcpEarnings + mcpFee);

    // Add to platform
    this.platformRevenue += platformFee;

    // Create transaction
    const transaction: Transaction = {
      id: `tx-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      type: this.determineTransactionType(listing.center),
      listingId,
      requestId,
      sellerId: listing.sellerId,
      buyerId: request.buyerId,
      mcpId: mcp.id,
      amount: totalAmount,
      mcpFee,
      platformFee,
      sellerReceives,
      resonanceScore: listing.resonanceDepth,
      status: 'active',
      startedAt: Date.now(),
    };

    this.transactions.set(transaction.id, transaction);

    // Update listing stats
    listing.transactionCount++;

    // Remove fulfilled request
    this.requests.delete(requestId);

    return transaction;
  }

  private determineTransactionType(center: CenterName): TransactionType {
    const mapping: Record<CenterName, TransactionType> = {
      Head: 'INSIGHT_BROKERAGE',
      Ajna: 'INSIGHT_BROKERAGE',
      Throat: 'DIRECTIONAL_GUIDANCE',
      G: 'IDENTITY_MIRRORING',
      Heart: 'WILL_POWER_TRANSFER',
      SolarPlexus: 'EMOTIONAL_SUPPORT',
      Sacral: 'LIFE_FORCE_BOOST',
      Spleen: 'INTUITIVE_READING',
      Root: 'ENERGY_LENDING',
    };
    return mapping[center] || 'ENERGY_LENDING';
  }

  // ── Subscription: Klein Tool Tuning ────────────────────────────────────────

  subscribeToTuning(userId: string, toolName: string, tier: 'basic' | 'deep' | 'mastery'): {
    subscriptionId: string;
    monthlyCost: number;
    features: string[];
  } {
    const pricing = {
      basic: { cost: 10, features: ['Weekly tuning reports', 'Basic resonance analysis'] },
      deep: { cost: 25, features: ['Daily tuning updates', 'Dimensional depth analysis', 'Transit alerts'] },
      mastery: { cost: 50, features: ['Real-time tuning', 'Full 5D expression map', 'MCP priority access', 'Emergent channel detection'] },
    };

    const plan = pricing[tier];

    // Deduct first month
    const balance = this.userBalances.get(userId) || 0;
    if (balance < plan.cost) {
      throw new Error('Insufficient credits for subscription');
    }
    this.userBalances.set(userId, balance - plan.cost);
    this.platformRevenue += plan.cost * 0.5; // 50% to platform for subscriptions

    return {
      subscriptionId: `sub-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      monthlyCost: plan.cost,
      features: plan.features,
    };
  }

  // ── Credit Management ──────────────────────────────────────────────────────

  addCredits(userId: string, amount: number) {
    const current = this.userBalances.get(userId) || 0;
    this.userBalances.set(userId, current + amount);
  }

  getBalance(userId: string): number {
    return this.userBalances.get(userId) || 0;
  }

  // ── Analytics ────────────────────────────────────────────────────────────────

  getMarketStats() {
    const totalTransactions = this.transactions.size;
    const totalVolume = Array.from(this.transactions.values()).reduce((sum, tx) => sum + tx.amount, 0);
    const avgResonance = totalTransactions > 0
      ? Array.from(this.transactions.values()).reduce((sum, tx) => sum + tx.resonanceScore, 0) / totalTransactions
      : 0;

    const centerVolumes: Record<CenterName, number> = {} as any;
    for (const tx of this.transactions.values()) {
      const listing = this.listings.get(tx.listingId);
      if (listing) {
        centerVolumes[listing.center] = (centerVolumes[listing.center] || 0) + tx.amount;
      }
    }

    return {
      totalListings: this.listings.size,
      totalRequests: this.requests.size,
      totalTransactions,
      totalVolume,
      platformRevenue: this.platformRevenue,
      avgResonance,
      centerVolumes,
      topMCPs: Array.from(this.mcpEarnings.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([id, earnings]) => ({ id, earnings })),
    };
  }

  // ── Get listings for a specific center ─────────────────────────────────────
  getListingsForCenter(center: CenterName): EnergyListing[] {
    return Array.from(this.listings.values())
      .filter(l => l.center === center)
      .sort((a, b) => b.resonanceDepth - a.resonanceDepth);
  }

  // ── Get user's transaction history ───────────────────────────────────────────
  getUserHistory(userId: string): Transaction[] {
    return Array.from(this.transactions.values())
      .filter(tx => tx.sellerId === userId || tx.buyerId === userId)
      .sort((a, b) => b.startedAt - a.startedAt);
  }
}

// ── Singleton ────────────────────────────────────────────────────────────────
export const resonanceMarket = new ResonanceMarket();
