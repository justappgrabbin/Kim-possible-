// ═══════════════════════════════════════════════════════════════════════════
// useLivingOrganism.ts — UPDATED for 5 Expression Types + Mesh Messaging
// ═══════════════════════════════════════════════════════════════════════════

import { useState, useCallback, useEffect, useRef } from 'react';
import { livingOrganism, LivingOrganism } from './LivingOrganism';
import {
  PersonalGraph, CenterName, GateNumber, Dimension, Planet,
} from './HDGraphEngine';
import { ToolName, ExpressionType, Experience } from './KleinToolMesh';
import { MCPAgent } from './MCPHubMesh';
import { EnergyListing, EnergyRequest, Transaction } from './ResonanceMarket';

// ── Types for React consumption ──────────────────────────────────────────────
export interface UserSession {
  userId: string;
  graph: PersonalGraph | null;
  initialized: boolean;
  loading: boolean;
  error: string | null;
}

export interface OrganismState {
  tools: Array<{
    name: ToolName;
    active: boolean;
    state: string;
    expressionCount: number;
    experienceCount: number;
    meshNeighbors: ToolName[];
    inboxCount: number;
    outboxCount: number;
  }>;
  meshCoherence: number;
  mcps: MCPAgent[];
  experiences: Experience[];
  marketStats: {
    totalListings: number;
    totalRequests: number;
    totalTransactions: number;
    totalVolume: number;
    platformRevenue: number;
    avgResonance: number;
  };
}

export interface QueryResult {
  expression: string;
  tool: ToolName;
  expressionType: ExpressionType;
  confidence: number;
  meshPath: ToolName[];
  experiences: Experience[];
  signals: Array<{
    type: string;
    center: CenterName;
    description: string;
    urgency: number;
    expressionType: ExpressionType;
  }>;
  pathway: Array<{
    step: number;
    action: string;
    dimension: string;
    expressionType: ExpressionType;
    confidence: number;
  }>;
  narrative: string;
  meshCoherence: number;
}

// ── The Hook ─────────────────────────────────────────────────────────────────
export function useLivingOrganism() {
  const organismRef = useRef<LivingOrganism>(livingOrganism);
  const [session, setSession] = useState<UserSession>({
    userId: '',
    graph: null,
    initialized: false,
    loading: false,
    error: null,
  });
  const [organismState, setOrganismState] = useState<OrganismState>({
    tools: [],
    meshCoherence: 0.5,
    mcps: [],
    experiences: [],
    marketStats: {
      totalListings: 0,
      totalRequests: 0,
      totalTransactions: 0,
      totalVolume: 0,
      platformRevenue: 0,
      avgResonance: 0,
    },
  });
  const [queryResult, setQueryResult] = useState<QueryResult | null>(null);
  const [queryLoading, setQueryLoading] = useState(false);

  // Initialize a user
  const initializeUser = useCallback(async (params: {
    userId: string;
    birthDate: string;
    birthTime: string;
    birthLocation: string;
    displayName?: string;
  }) => {
    setSession(prev => ({ ...prev, loading: true, error: null }));
    try {
      const result = await organismRef.current.initializeUser(params);
      setSession({
        userId: params.userId,
        graph: result.graph,
        initialized: true,
        loading: false,
        error: null,
      });
      return result;
    } catch (err: any) {
      setSession(prev => ({ ...prev, loading: false, error: err.message }));
      throw err;
    }
  }, []);

  // Process a query with optional expression type preference
  const ask = useCallback(async (query: string, preferredExpressionType?: ExpressionType) => {
    if (!session.initialized) throw new Error('User not initialized');
    setQueryLoading(true);
    try {
      const result = await organismRef.current.processQuery(session.userId, query, preferredExpressionType);
      setQueryResult({
        expression: result.expression.output,
        tool: result.expression.tool,
        expressionType: result.expression.expressionType,
        confidence: result.expression.confidence,
        meshPath: result.expression.meshPath,
        experiences: result.expression.experiences,
        signals: result.perception.signals.map(s => ({
          type: s.type,
          center: s.center,
          description: s.description,
          urgency: s.urgency,
          expressionType: s.expressionType,
        })),
        pathway: result.pathway.pathway.map(p => ({
          step: p.step,
          action: p.action,
          dimension: p.dimension,
          expressionType: p.expressionType,
          confidence: p.confidence,
        })),
        narrative: result.unifiedNarrative,
        meshCoherence: result.meshCoherence,
      });
      setQueryLoading(false);
      return result;
    } catch (err: any) {
      setQueryLoading(false);
      throw err;
    }
  }, [session.userId, session.initialized]);

  // Ask with specific expression type
  const askSemantic = useCallback((query: string) => ask(query, 'SEMANTIC'), [ask]);
  const askCode = useCallback((query: string) => ask(query, 'CODE'), [ask]);
  const askVisual = useCallback((query: string) => ask(query, 'VISUAL'), [ask]);
  const askHarmonic = useCallback((query: string) => ask(query, 'HARMONIC'), [ask]);
  const askTemporal = useCallback((query: string) => ask(query, 'TEMPORAL'), [ask]);

  // Calculate resonance with another user
  const checkResonance = useCallback((otherUserId: string) => {
    if (!session.initialized) return null;
    return organismRef.current.calculateResonance(session.userId, otherUserId);
  }, [session.userId, session.initialized]);

  // List energy
  const listEnergy = useCallback((params: {
    center: CenterName;
    dimension: Dimension;
    energyType: string;
    description: string;
    price: number;
  }) => {
    if (!session.initialized) throw new Error('User not initialized');
    return organismRef.current.listEnergy(session.userId, params);
  }, [session.userId, session.initialized]);

  // Request energy
  const requestEnergy = useCallback((params: {
    center: CenterName;
    dimension: Dimension;
    energyType: string;
    description: string;
    maxPrice: number;
    urgency: 'low' | 'medium' | 'high' | 'critical';
  }) => {
    if (!session.initialized) throw new Error('User not initialized');
    return organismRef.current.requestEnergy(session.userId, params);
  }, [session.userId, session.initialized]);

  // Find matches
  const findMatches = useCallback((requestId: string) => {
    return organismRef.current.findMatches(requestId);
  }, []);

  // Execute transaction
  const executeTransaction = useCallback((listingId: string, requestId: string) => {
    return organismRef.current.executeTransaction(listingId, requestId);
  }, []);

  // Add credits
  const addCredits = useCallback((amount: number) => {
    if (!session.initialized) return;
    organismRef.current.addCredits(session.userId, amount);
  }, [session.userId, session.initialized]);

  // Get balance
  const getBalance = useCallback(() => {
    if (!session.initialized) return 0;
    return organismRef.current.getBalance(session.userId);
  }, [session.userId, session.initialized]);

  // Get dashboard data
  const getDashboard = useCallback(() => {
    if (!session.initialized) return null;
    return organismRef.current.getDashboard(session.userId);
  }, [session.userId, session.initialized]);

  // Get transit summary
  const getTransitSummary = useCallback(async () => {
    if (!session.initialized) return null;
    return organismRef.current.getTransitSummary(session.userId);
  }, [session.userId, session.initialized]);

  // Get dimensional profile
  const getDimensionalProfile = useCallback(() => {
    if (!session.initialized) return null;
    return organismRef.current.getDimensionalProfile(session.userId);
  }, [session.userId, session.initialized]);

  // Refresh organism state
  const refreshState = useCallback(() => {
    const state = organismRef.current.exportState();
    setOrganismState({
      tools: state.tools,
      meshCoherence: state.meshCoherence,
      mcps: state.mcps,
      experiences: state.experiences,
      marketStats: state.marketStats,
    });
  }, []);

  // Auto-refresh on mount
  useEffect(() => {
    refreshState();
    const interval = setInterval(refreshState, 30000);
    return () => clearInterval(interval);
  }, [refreshState]);

  return {
    // Session
    session,
    initializeUser,

    // Query (all 5 expression types)
    ask,
    askSemantic,
    askCode,
    askVisual,
    askHarmonic,
    askTemporal,
    queryResult,
    queryLoading,

    // Social
    checkResonance,

    // Market
    listEnergy,
    requestEnergy,
    findMatches,
    executeTransaction,
    addCredits,
    getBalance,

    // Dashboard
    getDashboard,
    getTransitSummary,
    getDimensionalProfile,

    // State
    organismState,
    refreshState,
  };
}

// ── Example usage ────────────────────────────────────────────────────────────
/*
import { useLivingOrganism } from './hooks/useLivingOrganism';

function Dashboard() {
  const {
    session,
    initializeUser,
    askSemantic,
    askVisual,
    askHarmonic,
    queryResult,
    queryLoading,
    getDashboard,
    organismState,
  } = useLivingOrganism();

  useEffect(() => {
    initializeUser({
      userId: 'user-123',
      birthDate: '1990-01-01',
      birthTime: '12:00',
      birthLocation: 'New York, USA',
    });
  }, []);

  return (
    <div>
      <div>Mesh Coherence: {(organismState.meshCoherence * 100).toFixed(1)}%</div>

      {organismState.tools.map(tool => (
        <div key={tool.name}>
          {tool.name}: {tool.state} | 
          Inbox: {tool.inboxCount} | Outbox: {tool.outboxCount} |
          Experiences: {tool.experienceCount}
        </div>
      ))}

      <button onClick={() => askSemantic('What should I focus on?')}>
        Ask (Semantic)
      </button>
      <button onClick={() => askVisual('Show me my energy field')}>
        Ask (Visual)
      </button>
      <button onClick={() => askHarmonic('What is my resonance frequency?')}>
        Ask (Harmonic)
      </button>

      {queryLoading && <div>Mesh processing...</div>}
      {queryResult && (
        <div>
          <div>Type: {queryResult.expressionType}</div>
          <div>Tool: {queryResult.tool}</div>
          <div>Mesh Path: {queryResult.meshPath.join(' → ')}</div>
          <pre>{queryResult.expression}</pre>
          <div>Confidence: {Math.round(queryResult.confidence * 100)}%</div>
          <div>Coherence: {Math.round(queryResult.meshCoherence * 100)}%</div>
        </div>
      )}
    </div>
  );
}
*/
