/**
 * ============================================================
 * KLEIN FULL TOOLKIT — All 8 Tools on MESSY Morphing Substrate
 *
 * Sheldon Klein's complete research apparatus:
 *
 * 1. DISEMINER (1968) — Distributional-Semantics Inference Maker
 *    "You shall know a word by the company it keeps"
 *    Co-occurrence matrices → semantic fields → meaning inference
 *
 * 2. AUTOLING (1968) — Meta-linguistic Natural Language System
 *    Configurable to model ANY theoretical linguistic model
 *    Semantic structures = relational calculus = implicit semantic networks
 *    Same rules for generation AND recognition
 *    Bi-directional Boolean feature inheritance
 *    Relations as logical operators
 *
 * 3. Auto Novel Writing (1973) — Computer-Generated Fiction
 *    "AUTOMATIC NOVEL WRITING" (UWCS Tech Report 186, 109 pages)
 *    Abridged in Text Processing/Textverarbeitung (1979)
 *    Meta-symbolic simulation of narrative generation
 *    Can be CURATED to write code instead of fiction
 *
 * 4. MESSY (1976) — Meta-Symbolic Simulation System
 *    "The Meta-symbolic Simulation System User Manual" (Tech Report 272, 169 pages)
 *    The MORPHING SUBSTRATE — everything connects through here
 *    Simulates Propp & Lévi-Strauss structures
 *    Boolean groups + analogy in complex behavioral systems
 *    Connectionist implementation of categorial grammars
 *
 * 5. Propp/Lévi-Strauss Simulation (1976-1977)
 *    "Modelling Propp and Lévi-Strauss in a Meta-symbolic Simulation System"
 *    French translation in Informatique et Sciences Humaines (1976)
 *    Computer-generated folktales with revised models
 *
 * 6. Analogy & Mysticism (1983) — Cultural Structure via Analogy
 *    "Analogy and Mysticism and the Structure of Culture" (Current Anthropology)
 *    Boolean feature vectors link language structure to neural net theory
 *    Archaeological materials analysis (Middle-to-Upper Paleolithic)
 *
 * 7. Historical Language Change (1966, 1974)
 *    Monte Carlo simulation of language contact and change
 *    "Historical Change in Language using Monte Carlo Techniques"
 *    "Computer Simulation of Language Contact Models"
 *
 * 8. Analogical Foundations of Creativity (1999-2002)
 *    "The Analogical Foundations of Creativity in Language, Culture & the Arts"
 *    Upper Paleolithic to 2100CE — the full arc
 *
 * ============================================================
 * MESSY AS THE MORPHING SUBSTRATE:
 * All 8 tools connect through MESSY's meta-symbolic layer.
 * MESSY is not just a tool — it is the CONNECTIVE TISSUE.
 * It morphs between representations: linguistic → semantic →
 * narrative → behavioral → connectionist → archaeological.
 *
 * Dimensional Mapping:
 *   D1 (Impulse)    → DISEMINER: raw text → distributional vectors
 *   D2 (Polarity)   → AUTOLING: classify linguistic structures
 *   D3 (Witness)    → MESSY: meta-symbolic observation node
 *   D4 (Context)    → Auto Novel: narrative context building
 *   D5 (Meaning)    → Analogy Engine: creative synthesis
 * ============================================================
 */

import { SemanticNode, AnalogyMapping } from './core-engine';

// ═══════════════════════════════════════════════════════════
// MESSY: META-SYMBOLIC SIMULATION SYSTEM (1976)
 * The morphing substrate — everything passes through here
 * MESSY is the "coordinate system" that lets all 8 tools
 * speak to each other in a common language.
// ═══════════════════════════════════════════════════════════

interface MessySymbol {
  id: string;
  // A symbol in MESSY can be ANYTHING: word, concept, rule, image, sound
  // It carries its own "type" but MESSY doesn't care — it morphs
  type: 'linguistic' | 'semantic' | 'narrative' | 'behavioral' | 'connectionist' | 'archaeological';
  // The actual content (polymorphic by type)
  content: any;
  // Boolean feature vector (Klein's universal encoding)
  features: boolean[];
  // Morphological state: what form is this symbol currently in?
  morphState: 'raw' | 'parsed' | 'inferred' | 'generated' | 'simulated' | 'evolved';
  // Temporal depth (for historical simulation)
  epoch: number; // 0 = present, negative = past, positive = future
  // Connections to other symbols in MESSY space
  connections: Map<string, number>; // symbolId -> connection strength
}

interface MessyMorphRule {
  // A rule for morphing between symbol types
  fromType: MessySymbol['type'];
  toType: MessySymbol['type'];
  // The transformation function (analogy-based)
  transform: (symbol: MessySymbol, context: MessyContext) => MessySymbol;
  // Confidence in this morph
  confidence: number;
  // Which tool originated this rule
  originTool: 'DISEMINER' | 'AUTOLING' | 'AutoNovel' | 'MESSY' | 'Propp' | 'Analogy' | 'Historical' | 'Creativity';
}

interface MessyContext {
  // The surrounding symbols that condition morphing
  neighbors: MessySymbol[];
  // The current "epoch" (for historical simulation)
  currentEpoch: number;
  // The active analogy mapping
  activeAnalogy?: AnalogyMapping;
  // The query being processed (who/what/where/when/why)
  query?: WhoWhatWhereWhenWhy;
}

interface WhoWhatWhereWhenWhy {
  who?: string;    // Agent identification
  what?: string;   // Action/event identification
  where?: string;  // Spatial context
  when?: string;   // Temporal context
  why?: string;    // Causal/motivational context
  // Confidence in each dimension
  confidence: { who: number; what: number; where: number; when: number; why: number };
}

class MessySubstrate {
  private symbols: Map<string, MessySymbol> = new Map();
  private morphRules: MessyMorphRule[] = [];
  private featureDimension: number = 256;
  private epochCounter: number = 0;

  // The 8 tools as modules within MESSY
  private modules: Map<string, MessyModule> = new Map();

  constructor() {
    this.seedMorphRules();
  }

  private seedMorphRules() {
    // Rule 1: DISEMINER → AUTOLING (raw text → parsed structure)
    this.morphRules.push({
      fromType: 'linguistic',
      toType: 'semantic',
      transform: (sym, ctx) => this.morphToSemantic(sym, ctx),
      confidence: 0.85,
      originTool: 'DISEMINER'
    });

    // Rule 2: AUTOLING → MESSY (parsed structure → meta-symbolic)
    this.morphRules.push({
      fromType: 'semantic',
      toType: 'behavioral',
      transform: (sym, ctx) => this.morphToBehavioral(sym, ctx),
      confidence: 0.78,
      originTool: 'AUTOLING'
    });

    // Rule 3: MESSY → Auto Novel (meta-symbolic → narrative)
    this.morphRules.push({
      fromType: 'behavioral',
      toType: 'narrative',
      transform: (sym, ctx) => this.morphToNarrative(sym, ctx),
      confidence: 0.82,
      originTool: 'AutoNovel'
    });

    // Rule 4: Narrative → Connectionist (stories → neural patterns)
    this.morphRules.push({
      fromType: 'narrative',
      toType: 'connectionist',
      transform: (sym, ctx) => this.morphToConnectionist(sym, ctx),
      confidence: 0.71,
      originTool: 'MESSY'
    });

    // Rule 5: Connectionist → Archaeological (patterns → historical depth)
    this.morphRules.push({
      fromType: 'connectionist',
      toType: 'archaeological',
      transform: (sym, ctx) => this.morphToArchaeological(sym, ctx),
      confidence: 0.65,
      originTool: 'Historical'
    });

    // Reverse rules (MESSY morphs bidirectionally)
    this.morphRules.push({
      fromType: 'semantic',
      toType: 'linguistic',
      transform: (sym, ctx) => this.morphToLinguistic(sym, ctx),
      confidence: 0.80,
      originTool: 'AUTOLING'
    });

    this.morphRules.push({
      fromType: 'narrative',
      toType: 'semantic',
      transform: (sym, ctx) => this.morphNarrativeToSemantic(sym, ctx),
      confidence: 0.75,
      originTool: 'AutoNovel'
    });
  }

  // Morph transformations
  private morphToSemantic(sym: MessySymbol, ctx: MessyContext): MessySymbol {
    // DISEMINER: distributional analysis of text
    const text = sym.content as string;
    const tokens = this.tokenize(text);
    const cooccurrence = this.buildCooccurrence(tokens);
    return {
      ...sym,
      type: 'semantic',
      content: { tokens, cooccurrence, field: this.inferField(tokens) },
      morphState: 'inferred',
      features: this.computeSemanticFeatures(tokens, cooccurrence)
    };
  }

  private morphToBehavioral(sym: MessySymbol, ctx: MessyContext): MessySymbol {
    // AUTOLING: parse semantic structure into behavioral rules
    const semantic = sym.content as { tokens: string[]; cooccurrence: Map<string, number>; field: string };
    const behavioralRules = this.extractBehavioralRules(semantic);
    return {
      ...sym,
      type: 'behavioral',
      content: behavioralRules,
      morphState: 'parsed',
      features: this.computeBehavioralFeatures(behavioralRules)
    };
  }

  private morphToNarrative(sym: MessySymbol, ctx: MessyContext): MessySymbol {
    // Auto Novel: generate narrative from behavioral rules
    const rules = sym.content as any[];
    const narrative = this.generateNarrativeFromRules(rules, ctx);
    return {
      ...sym,
      type: 'narrative',
      content: narrative,
      morphState: 'generated',
      features: this.computeNarrativeFeatures(narrative)
    };
  }

  private morphToConnectionist(sym: MessySymbol, ctx: MessyContext): MessySymbol {
    // MESSY: translate narrative into connectionist patterns
    const narrative = sym.content as any;
    const weights = this.narrativeToWeights(narrative);
    return {
      ...sym,
      type: 'connectionist',
      content: weights,
      morphState: 'simulated',
      features: this.computeConnectionistFeatures(weights)
    };
  }

  private morphToArchaeological(sym: MessySymbol, ctx: MessyContext): MessySymbol {
    // Historical: place connectionist patterns in archaeological time
    const weights = sym.content as Float32Array;
    const historicalLayer = this.weightsToHistoricalLayer(weights, ctx.currentEpoch);
    return {
      ...sym,
      type: 'archaeological',
      content: historicalLayer,
      morphState: 'evolved',
      epoch: ctx.currentEpoch - 1,
      features: this.computeArchaeologicalFeatures(historicalLayer)
    };
  }

  private morphToLinguistic(sym: MessySymbol, ctx: MessyContext): MessySymbol {
    // AUTOLING reverse: generate text from semantic structure
    const semantic = sym.content as any;
    const text = this.semanticToText(semantic);
    return {
      ...sym,
      type: 'linguistic',
      content: text,
      morphState: 'generated',
      features: this.computeLinguisticFeatures(text)
    };
  }

  private morphNarrativeToSemantic(sym: MessySymbol, ctx: MessyContext): MessySymbol {
    // Auto Novel reverse: extract semantic structure from narrative
    const narrative = sym.content as any;
    const semantic = this.narrativeToSemantic(narrative);
    return {
      ...sym,
      type: 'semantic',
      content: semantic,
      morphState: 'inferred',
      features: this.computeSemanticFeaturesFromNarrative(narrative)
    };
  }

  // Helper methods for morphing
  private tokenize(text: string): string[] {
    return text.toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(t => t.length > 1);
  }

  private buildCooccurrence(tokens: string[]): Map<string, number> {
    const cooc = new Map<string, number>();
    const window = 5;
    for (let i = 0; i < tokens.length; i++) {
      for (let j = Math.max(0, i - window); j < Math.min(tokens.length, i + window + 1); j++) {
        if (i !== j) {
          const pair = `${tokens[i]}::${tokens[j]}`;
          cooc.set(pair, (cooc.get(pair) || 0) + 1);
        }
      }
    }
    return cooc;
  }

  private inferField(tokens: string[]): string {
    const domains = new Map<string, string[]>();
    domains.set('game', ['game', 'engine', 'render', 'physics', 'player', 'level', 'sprite']);
    domains.set('code', ['function', 'class', 'import', 'export', 'return', 'const', 'let']);
    domains.set('narrative', ['story', 'hero', 'villain', 'quest', 'magic', 'journey']);
    domains.set('system', ['server', 'client', 'api', 'database', 'request', 'response']);

    let bestDomain = 'general';
    let bestScore = 0;
    for (const [domain, words] of domains) {
      const score = tokens.filter(t => words.includes(t)).length;
      if (score > bestScore) {
        bestScore = score;
        bestDomain = domain;
      }
    }
    return bestDomain;
  }

  private extractBehavioralRules(semantic: any): any[] {
    // Extract if-then patterns from co-occurrence
    const rules: any[] = [];
    for (const [pair, count] of semantic.cooccurrence) {
      if (count > 2) {
        const [a, b] = pair.split('::');
        rules.push({ condition: a, action: b, strength: count });
      }
    }
    return rules;
  }

  private generateNarrativeFromRules(rules: any[], ctx: MessyContext): any {
    // Propp-inspired: arrange rules into narrative sequence
    const sequence = rules
      .sort((a, b) => b.strength - a.strength)
      .slice(0, 8)
      .map((r, i) => ({
        step: i + 1,
        function: this.mapToProppFunction(r.condition, r.action),
        condition: r.condition,
        action: r.action,
        strength: r.strength
      }));
    return { sequence, morphology: 'linear', mythemes: this.extractMythemes(rules) };
  }

  private mapToProppFunction(condition: string, action: string): string {
    const map: Record<string, string> = {
      'depart': 'DEPARTURE', 'leave': 'DEPARTURE', 'go': 'DEPARTURE',
      'villain': 'VILLAINY', 'attack': 'VILLAINY', 'harm': 'VILLAINY',
      'help': 'DONOR_FUNCTION', 'give': 'DONOR_FUNCTION', 'gift': 'DONOR_FUNCTION',
      'fight': 'STRUGGLE', 'battle': 'STRUGGLE', 'defeat': 'VICTORY',
      'return': 'RETURN', 'home': 'RETURN', 'back': 'RETURN',
      'marry': 'WEDDING', 'love': 'WEDDING', 'union': 'WEDDING'
    };
    return map[condition] || map[action] || 'MEDIATION';
  }

  private extractMythemes(rules: any[]): { concept: string; value: number }[] {
    const mythemes = new Map<string, number>();
    for (const r of rules) {
      mythemes.set(r.condition, (mythemes.get(r.condition) || 0) + r.strength);
      mythemes.set(r.action, (mythemes.get(r.action) || 0) - r.strength * 0.5);
    }
    return Array.from(mythemes.entries()).map(([c, v]) => ({ concept: c, value: v }));
  }

  private narrativeToWeights(narrative: any): Float32Array {
    const weights = new Float32Array(this.featureDimension);
    for (let i = 0; i < this.featureDimension; i++) {
      weights[i] = Math.sin(i * 0.1 + narrative.sequence.length) * 0.5;
    }
    return weights;
  }

  private weightsToHistoricalLayer(weights: Float32Array, epoch: number): any {
    return {
      epoch,
      pattern: Array.from(weights).map(w => w > 0 ? '1' : '0').join(''),
      complexity: weights.filter(w => Math.abs(w) > 0.1).length / weights.length,
      depth: Math.abs(epoch)
    };
  }

  private semanticToText(semantic: any): string {
    return `Generated from semantic field "${semantic.field}" with ${semantic.tokens.length} tokens.`;
  }

  private narrativeToSemantic(narrative: any): any {
    return {
      tokens: narrative.sequence.map((s: any) => s.condition),
      cooccurrence: new Map(),
      field: 'narrative'
    };
  }

  // Feature computation methods
  private computeSemanticFeatures(tokens: string[], cooccurrence: Map<string, number>): boolean[] {
    const f = new Array(this.featureDimension).fill(false);
    f[0] = tokens.length > 100;
    f[1] = cooccurrence.size > 50;
    f[2] = new Set(tokens).size / tokens.length > 0.5; // lexical diversity
    return f;
  }

  private computeBehavioralFeatures(rules: any[]): boolean[] {
    const f = new Array(this.featureDimension).fill(false);
    f[3] = rules.length > 5;
    f[4] = rules.some((r: any) => r.strength > 10);
    return f;
  }

  private computeNarrativeFeatures(narrative: any): boolean[] {
    const f = new Array(this.featureDimension).fill(false);
    f[5] = narrative.sequence.length > 5;
    f[6] = narrative.morphology === 'linear';
    f[7] = narrative.mythemes.length > 3;
    return f;
  }

  private computeConnectionistFeatures(weights: Float32Array): boolean[] {
    const f = new Array(this.featureDimension).fill(false);
    f[8] = weights.some(w => Math.abs(w) > 0.8);
    f[9] = weights.filter(w => w > 0).length > weights.length / 2;
    return f;
  }

  private computeArchaeologicalFeatures(layer: any): boolean[] {
    const f = new Array(this.featureDimension).fill(false);
    f[10] = layer.complexity > 0.5;
    f[11] = layer.depth > 5;
    return f;
  }

  private computeLinguisticFeatures(text: string): boolean[] {
    const f = new Array(this.featureDimension).fill(false);
    f[12] = text.length > 500;
    f[13] = /\./.test(text);
    f[14] = /\?/.test(text);
    return f;
  }

  private computeSemanticFeaturesFromNarrative(narrative: any): boolean[] {
    const f = new Array(this.featureDimension).fill(false);
    f[15] = narrative.sequence.length > 3;
    return f;
  }

  // ═══════════════════════════════════════════════════════
  // PUBLIC API: The MESSY morphing interface
  // ═══════════════════════════════════════════════════════

  /**
   * Ingest a raw symbol into MESSY
   */
  ingest(id: string, content: any, type: MessySymbol['type'] = 'linguistic'): MessySymbol {
    const symbol: MessySymbol = {
      id,
      type,
      content,
      features: new Array(this.featureDimension).fill(false),
      morphState: 'raw',
      epoch: this.epochCounter,
      connections: new Map()
    };
    this.symbols.set(id, symbol);
    return symbol;
  }

  /**
   * Morph a symbol from one type to another
   * This is the core MESSY operation
   */
  morph(symbolId: string, targetType: MessySymbol['type'], context?: Partial<MessyContext>): MessySymbol {
    const symbol = this.symbols.get(symbolId);
    if (!symbol) throw new Error(`Symbol ${symbolId} not found`);

    const ctx: MessyContext = {
      neighbors: this.getNeighbors(symbolId),
      currentEpoch: this.epochCounter,
      ...context
    };

    // Find applicable morph rule
    const rule = this.morphRules.find(r =>
      r.fromType === symbol.type && r.toType === targetType
    );

    if (!rule) {
      throw new Error(`No morph rule from ${symbol.type} to ${targetType}`);
    }

    const morphed = rule.transform(symbol, ctx);
    this.symbols.set(morphed.id, morphed);

    // Update connections
    for (const neighbor of ctx.neighbors) {
      const strength = this.featureSimilarity(morphed.features, neighbor.features);
      morphed.connections.set(neighbor.id, strength);
      neighbor.connections.set(morphed.id, strength);
    }

    return morphed;
  }

  /**
   * Multi-step morph: chain transformations through MESSY
   */
  morphChain(symbolId: string, targetTypes: MessySymbol['type'][]): MessySymbol {
    let current = this.symbols.get(symbolId)!;
    for (const targetType of targetTypes) {
      current = this.morph(current.id, targetType);
    }
    return current;
  }

  /**
   * Who/What/Where/When/Why query on MESSY symbols
   * AUTOLING's core capability
   */
  query5W(symbolId: string): WhoWhatWhereWhenWhy {
    const symbol = this.symbols.get(symbolId);
    if (!symbol) {
      return { confidence: { who: 0, what: 0, where: 0, when: 0, why: 0 } };
    }

    // Extract 5W from symbol content and connections
    const content = typeof symbol.content === 'string' ? symbol.content : JSON.stringify(symbol.content);
    const neighbors = this.getNeighbors(symbolId);

    const who = this.extractAgent(content, neighbors);
    const what = this.extractAction(content, neighbors);
    const where = this.extractLocation(content, neighbors);
    const when = this.extractTime(content, neighbors);
    const why = this.extractCause(content, neighbors);

    return {
      who,
      what,
      where,
      when,
      why,
      confidence: {
        who: who ? 0.8 : 0.2,
        what: what ? 0.85 : 0.3,
        where: where ? 0.6 : 0.1,
        when: when ? 0.7 : 0.2,
        why: why ? 0.5 : 0.1
      }
    };
  }

  private extractAgent(content: string, neighbors: MessySymbol[]): string | undefined {
    const agents = ['player', 'user', 'hero', 'villain', 'system', 'engine', 'agent'];
    for (const a of agents) {
      if (content.includes(a)) return a;
    }
    for (const n of neighbors) {
      if (n.type === 'behavioral') return 'system';
    }
    return undefined;
  }

  private extractAction(content: string, neighbors: MessySymbol[]): string | undefined {
    const actions = ['render', 'update', 'process', 'generate', 'create', 'destroy', 'move'];
    for (const a of actions) {
      if (content.includes(a)) return a;
    }
    return undefined;
  }

  private extractLocation(content: string, neighbors: MessySymbol[]): string | undefined {
    const locations = ['server', 'client', 'browser', 'node', 'gpu', 'memory'];
    for (const l of locations) {
      if (content.includes(l)) return l;
    }
    return undefined;
  }

  private extractTime(content: string, neighbors: MessySymbol[]): string | undefined {
    const times = ['init', 'update', 'frame', 'tick', 'step', 'cycle'];
    for (const t of times) {
      if (content.includes(t)) return t;
    }
    return undefined;
  }

  private extractCause(content: string, neighbors: MessySymbol[]): string | undefined {
    const causes = ['because', 'since', 'due to', 'trigger', 'event', 'input'];
    for (const c of causes) {
      if (content.includes(c)) return c;
    }
    return undefined;
  }

  /**
   * Historical simulation: evolve symbols through epochs
   * Klein's Monte Carlo language change simulation
   */
  simulateEpochs(symbolId: string, epochs: number): MessySymbol[] {
    const history: MessySymbol[] = [];
    let current = this.symbols.get(symbolId);
    if (!current) return history;

    for (let e = 0; e < epochs; e++) {
      this.epochCounter++;
      // Mutate features with some probability
      const mutated = this.mutateSymbol(current);
      mutated.epoch = this.epochCounter;
      history.push(mutated);
      current = mutated;
    }

    return history;
  }

  private mutateSymbol(symbol: MessySymbol): MessySymbol {
    const mutated: MessySymbol = {
      ...symbol,
      id: `${symbol.id}_epoch_${this.epochCounter}`,
      features: [...symbol.features],
      connections: new Map(symbol.connections)
    };

    // Random bit flips (Monte Carlo mutation)
    for (let i = 0; i < this.featureDimension; i++) {
      if (Math.random() < 0.05) { // 5% mutation rate
        mutated.features[i] = !mutated.features[i];
      }
    }

    return mutated;
  }

  /**
   * Register a module (one of the 8 tools) with MESSY
   */
  registerModule(name: string, module: MessyModule) {
    this.modules.set(name, module);
    module.attachToMessy(this);
  }

  getModule(name: string): MessyModule | undefined {
    return this.modules.get(name);
  }

  // Internal helpers
  private getNeighbors(symbolId: string): MessySymbol[] {
    const symbol = this.symbols.get(symbolId);
    if (!symbol) return [];
    return Array.from(symbol.connections.keys())
      .map(id => this.symbols.get(id))
      .filter((s): s is MessySymbol => s !== undefined);
  }

  private featureSimilarity(a: boolean[], b: boolean[]): number {
    let matches = 0;
    for (let i = 0; i < Math.min(a.length, b.length); i++) {
      if (a[i] === b[i]) matches++;
    }
    return matches / Math.max(a.length, b.length);
  }

  getSymbol(id: string): MessySymbol | undefined {
    return this.symbols.get(id);
  }

  getAllSymbols(): MessySymbol[] {
    return Array.from(this.symbols.values());
  }

  getStats() {
    return {
      symbols: this.symbols.size,
      morphRules: this.morphRules.length,
      modules: this.modules.size,
      currentEpoch: this.epochCounter
    };
  }
}

// ═══════════════════════════════════════════════════════════
// MESSY MODULE INTERFACE — All 8 tools implement this
// ═══════════════════════════════════════════════════════════

interface MessyModule {
  name: string;
  attachToMessy(messy: MessySubstrate): void;
  process(symbolId: string): MessySymbol | Promise<MessySymbol>;
}

// ═══════════════════════════════════════════════════════════
// TOOL 1: DISEMINER (1968)
// ═══════════════════════════════════════════════════════════

class DiseMinerModule implements MessyModule {
  name = 'DISEMINER';
  private messy!: MessySubstrate;
  private vocabulary: Map<string, { contexts: Map<string, number>; features: boolean[] }> = new Map();

  attachToMessy(messy: MessySubstrate) {
    this.messy = messy;
  }

  process(symbolId: string): MessySymbol {
    const symbol = this.messy.getSymbol(symbolId);
    if (!symbol) throw new Error(`Symbol ${symbolId} not found`);

    // DISEMINER: build distributional vectors from text
    const text = typeof symbol.content === 'string' ? symbol.content : JSON.stringify(symbol.content);
    const tokens = text.toLowerCase().split(/\s+/).filter(t => t.length > 1);

    for (const token of tokens) {
      if (!this.vocabulary.has(token)) {
        this.vocabulary.set(token, {
          contexts: new Map(),
          features: new Array(256).fill(false)
        });
      }
      const entry = this.vocabulary.get(token)!;
      entry.contexts.set(symbolId, (entry.contexts.get(symbolId) || 0) + 1);
    }

    // Morph to semantic
    return this.messy.morph(symbolId, 'semantic');
  }

  infer(word: string): { synonyms: string[]; related: string[] } {
    const entry = this.vocabulary.get(word.toLowerCase());
    if (!entry) return { synonyms: [], related: [] };

    const synonyms: string[] = [];
    const related: string[] = [];

    for (const [otherWord, otherEntry] of this.vocabulary) {
      if (otherWord === word.toLowerCase()) continue;
      const overlap = this.computeOverlap(entry.contexts, otherEntry.contexts);
      if (overlap > 0.7) synonyms.push(otherWord);
      else if (overlap > 0.3) related.push(otherWord);
    }

    return { synonyms, related };
  }

  private computeOverlap(a: Map<string, number>, b: Map<string, number>): number {
    let intersection = 0;
    let union = new Set([...a.keys(), ...b.keys()]).size;
    for (const [key, count] of a) {
      if (b.has(key)) intersection += Math.min(count, b.get(key)!);
    }
    return union > 0 ? intersection / union : 0;
  }
}

// ═══════════════════════════════════════════════════════════
// TOOL 2: AUTOLING (1968)
// ═══════════════════════════════════════════════════════════

class AutolingModule implements MessyModule {
  name = 'AUTOLING';
  private messy!: MessySubstrate;
  private grammars: Map<string, { rules: any[]; purpose: string }> = new Map();

  attachToMessy(messy: MessySubstrate) {
    this.messy = messy;
    this.seedGrammars();
  }

  private seedGrammars() {
    this.grammars.set('code', {
      rules: [
        { pattern: 'class [NAME] { [BODY] }', semantic: 'class_definition' },
        { pattern: 'function [NAME]([ARGS]) { [BODY] }', semantic: 'function_definition' },
        { pattern: 'import [NAME] from [SOURCE]', semantic: 'import_statement' }
      ],
      purpose: 'generation_and_recognition'
    });
    this.grammars.set('narrative', {
      rules: [
        { pattern: 'The [HERO] [ACTION] the [VILLAIN]', semantic: 'struggle' },
        { pattern: 'A [DONOR] gives [ITEM] to [HERO]', semantic: 'donor_function' },
        { pattern: 'The [HERO] returns [HOME]', semantic: 'return' }
      ],
      purpose: 'generation_and_recognition'
    });
    this.grammars.set('query', {
      rules: [
        { pattern: 'Who [VERB] [OBJECT]?', semantic: 'who_query' },
        { pattern: 'What [VERB] [SUBJECT]?', semantic: 'what_query' },
        { pattern: 'Where [VERB] [SUBJECT]?', semantic: 'where_query' },
        { pattern: 'When [VERB] [SUBJECT]?', semantic: 'when_query' },
        { pattern: 'Why [VERB] [SUBJECT]?', semantic: 'why_query' }
      ],
      purpose: 'recognition'
    });
  }

  process(symbolId: string): MessySymbol {
    const symbol = this.messy.getSymbol(symbolId);
    if (!symbol) throw new Error(`Symbol ${symbolId} not found`);

    // AUTOLING: parse/generate using configured grammar
    const text = typeof symbol.content === 'string' ? symbol.content : '';
    const parsed = this.parseWithGrammar(text, 'code');

    // Morph to behavioral
    return this.messy.morph(symbolId, 'behavioral', { query: this.extractQuery(text) });
  }

  parseWithGrammar(text: string, grammarName: string): any {
    const grammar = this.grammars.get(grammarName);
    if (!grammar) return null;

    for (const rule of grammar.rules) {
      const regex = new RegExp(
        rule.pattern
          .replace(/\[NAME\]/g, '([A-Za-z_]+)')
          .replace(/\[BODY\]/g, '(.+)')
          .replace(/\[ARGS\]/g, '(.+)')
          .replace(/\[HERO\]/g, '([A-Za-z]+)')
          .replace(/\[VILLAIN\]/g, '([A-Za-z]+)')
          .replace(/\[ACTION\]/g, '([A-Za-z]+)')
          .replace(/\[DONOR\]/g, '([A-Za-z]+)')
          .replace(/\[ITEM\]/g, '([A-Za-z]+)')
          .replace(/\[HOME\]/g, '([A-Za-z]+)')
          .replace(/\[VERB\]/g, '([A-Za-z]+)')
          .replace(/\[OBJECT\]/g, '([A-Za-z]+)')
          .replace(/\[SUBJECT\]/g, '([A-Za-z]+)')
      );
      const match = text.match(regex);
      if (match) {
        return { semantic: rule.semantic, captures: match.slice(1) };
      }
    }
    return null;
  }

  generateWithGrammar(semantic: string, grammarName: string, bindings: Record<string, string>): string {
    const grammar = this.grammars.get(grammarName);
    if (!grammar) return '';

    const rule = grammar.rules.find(r => r.semantic === semantic);
    if (!rule) return '';

    let text = rule.pattern;
    for (const [key, value] of Object.entries(bindings)) {
      text = text.replace(new RegExp(`\[${key}\]`, 'g'), value);
    }
    return text;
  }

  private extractQuery(text: string): WhoWhatWhereWhenWhy | undefined {
    const queryGrammar = this.grammars.get('query');
    if (!queryGrammar) return undefined;

    for (const rule of queryGrammar.rules) {
      const regex = new RegExp(
        rule.pattern
          .replace(/\[VERB\]/g, '([A-Za-z]+)')
          .replace(/\[OBJECT\]/g, '([A-Za-z]+)')
          .replace(/\[SUBJECT\]/g, '([A-Za-z]+)')
      );
      const match = text.match(regex);
      if (match) {
        const type = rule.semantic.replace('_query', '');
        return {
          [type]: match[1],
          confidence: { who: 0, what: 0, where: 0, when: 0, why: 0, [type]: 0.9 }
        } as WhoWhatWhereWhenWhy;
      }
    }
    return undefined;
  }

  ask5W(symbolId: string): WhoWhatWhereWhenWhy {
    return this.messy.query5W(symbolId);
  }
}

// ═══════════════════════════════════════════════════════════
// TOOL 3: AUTO NOVEL WRITING (1973) — CURATED FOR CODE
// ═══════════════════════════════════════════════════════════

class AutoNovelModule implements MessyModule {
  name = 'AutoNovel';
  private messy!: MessySubstrate;

  attachToMessy(messy: MessySubstrate) {
    this.messy = messy;
  }

  process(symbolId: string): MessySymbol {
    const symbol = this.messy.getSymbol(symbolId);
    if (!symbol) throw new Error(`Symbol ${symbolId} not found`);

    // Auto Novel: generate narrative from behavioral rules
    // CURATED FOR CODE: instead of fiction, generate code stories
    return this.messy.morph(symbolId, 'narrative');
  }

  /**
   * CURATED CODE GENERATION: Write code as narrative
   * Each function is a "chapter", each class is a "character"
   */
  writeCodeAsNarrative(requirements: string): string {
    const chapters = this.decomposeIntoChapters(requirements);
    let code = `/**\n * Auto-Generated Code Narrative\n * Requirements: ${requirements}\n */\n\n`;

    for (const chapter of chapters) {
      code += `// Chapter ${chapter.number}: ${chapter.title}\n`;
      code += `${chapter.code}\n\n`;
    }

    return code;
  }

  private decomposeIntoChapters(requirements: string): { number: number; title: string; code: string }[] {
    // Propp-inspired decomposition
    return [
      { number: 1, title: 'Setup and Imports', code: this.generateSetup(requirements) },
      { number: 2, title: 'The Hero Class', code: this.generateHeroClass(requirements) },
      { number: 3, title: 'The Villain (Error Handling)', code: this.generateErrorHandling(requirements) },
      { number: 4, title: 'The Journey (Main Logic)', code: this.generateMainLogic(requirements) },
      { number: 5, title: 'The Return (Output)', code: this.generateOutput(requirements) }
    ];
  }

  private generateSetup(req: string): string {
    return `import { Engine } from './core';\nimport { Logger } from './utils';\n\nconst logger = new Logger();`;
  }

  private generateHeroClass(req: string): string {
    return `class Hero {\n  constructor() {\n    this.ready = true;\n  }\n  \n  act() {\n    // TODO: Implement hero action based on: ${req}\n  }\n}`;
  }

  private generateErrorHandling(req: string): string {
    return `class Villain extends Error {\n  constructor(message: string) {\n    super(message);\n    this.name = 'Villain';\n  }\n}`;
  }

  private generateMainLogic(req: string): string {
    return `async function journey() {\n  try {\n    const hero = new Hero();\n    await hero.act();\n  } catch (e) {\n    throw new Villain(e.message);\n  }\n}`;
  }

  private generateOutput(req: string): string {
    return `export { journey, Hero, Villain };`;
  }
}

// ═══════════════════════════════════════════════════════════
// TOOL 4: MESSY CORE (already defined above)
// The substrate itself is the 4th tool
// ═══════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════
// TOOL 5: PROPP/LÉVI-STRAUSS SIMULATION (1976-1977)
// ═══════════════════════════════════════════════════════════

class ProppLeviStraussModule implements MessyModule {
  name = 'ProppLeviStrauss';
  private messy!: MessySubstrate;

  // Propp's 31 functions
  private functions = [
    { id: 1, name: 'ABSENTATION', roles: ['hero'] },
    { id: 2, name: 'INTERDICTION', roles: ['hero', 'dispatcher'] },
    { id: 3, name: 'VIOLATION', roles: ['villain'] },
    { id: 4, name: 'RECONNAISSANCE', roles: ['villain'] },
    { id: 5, name: 'DELIVERY', roles: ['villain', 'victim'] },
    { id: 6, name: 'TRICKERY', roles: ['villain', 'victim'] },
    { id: 7, name: 'COMPLICITY', roles: ['villain', 'victim'] },
    { id: 8, name: 'VILLAINY', roles: ['villain', 'victim'] },
    { id: 9, name: 'MEDIATION', roles: ['hero', 'dispatcher'] },
    { id: 10, name: 'COUNTERACTION', roles: ['hero'] },
    { id: 11, name: 'DEPARTURE', roles: ['hero'] },
    { id: 12, name: 'DONOR_FUNCTION', roles: ['donor', 'hero'] },
    { id: 13, name: 'HERO_REACTION', roles: ['donor', 'hero'] },
    { id: 14, name: 'ACQUISITION', roles: ['hero'] },
    { id: 15, name: 'SPATIAL_TRANS', roles: ['hero'] },
    { id: 16, name: 'STRUGGLE', roles: ['hero', 'villain'] },
    { id: 17, name: 'BRANDING', roles: ['hero'] },
    { id: 18, name: 'VICTORY', roles: ['hero', 'villain'] },
    { id: 19, name: 'LIQUIDATION', roles: ['hero'] },
    { id: 20, name: 'RETURN', roles: ['hero'] },
    { id: 21, name: 'PURSUIT', roles: ['hero', 'villain'] },
    { id: 22, name: 'RESCUE', roles: ['hero'] },
    { id: 23, name: 'UNRECOGNIZED', roles: ['hero'] },
    { id: 24, name: 'UNFOUNDED_CLAIMS', roles: ['false_hero'] },
    { id: 25, name: 'DIFFICULT_TASK', roles: ['hero'] },
    { id: 26, name: 'SOLUTION', roles: ['hero'] },
    { id: 27, name: 'RECOGNITION', roles: ['hero'] },
    { id: 28, name: 'EXPOSURE', roles: ['false_hero'] },
    { id: 29, name: 'TRANSFIGURATION', roles: ['hero'] },
    { id: 30, name: 'PUNISHMENT', roles: ['villain'] },
    { id: 31, name: 'WEDDING', roles: ['hero', 'princess'] }
  ];

  attachToMessy(messy: MessySubstrate) {
    this.messy = messy;
  }

  process(symbolId: string): MessySymbol {
    return this.messy.getSymbol(symbolId)!;
  }

  generateFolktale(theme: string, length: number = 8): { functions: any[]; mythemes: any[] } {
    // Select functions relevant to theme
    const selected = this.selectFunctionsByTheme(theme, length);
    const mythemes = this.extractMythemes(selected);
    return { functions: selected, mythemes };
  }

  private selectFunctionsByTheme(theme: string, count: number): any[] {
    // Simple heuristic: match theme words to function names
    const themeWords = theme.toLowerCase().split(/\s+/);
    const scored = this.functions.map(fn => {
      const score = themeWords.filter(w => fn.name.toLowerCase().includes(w)).length +
                    fn.roles.filter(r => themeWords.includes(r)).length;
      return { fn, score };
    });
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, count).map(s => s.fn);
  }

  private extractMythemes(functions: any[]): { concept: string; value: number }[] {
    const mythemes = new Map<string, number>();
    for (const fn of functions) {
      for (const role of fn.roles) {
        mythemes.set(role, (mythemes.get(role) || 0) + 1);
      }
    }
    return Array.from(mythemes.entries()).map(([c, v]) => ({ concept: c, value: v }));
  }
}

// ═══════════════════════════════════════════════════════════
// TOOL 6: ANALOGY & MYSTICISM (1983)
// ═══════════════════════════════════════════════════════════

class AnalogyMysticismModule implements MessyModule {
  name = 'AnalogyMysticism';
  private messy!: MessySubstrate;

  attachToMessy(messy: MessySubstrate) {
    this.messy = messy;
  }

  process(symbolId: string): MessySymbol {
    return this.messy.getSymbol(symbolId)!;
  }

  /**
   * Klein's core: analogy operates on Boolean feature vectors
   * A : B :: C : D  means  (A ∧ ¬B) ≈ (C ∧ ¬D)
   */
  computeAnalogy(a: boolean[], b: boolean[], c: boolean[]): boolean[] {
    const d = new Array(a.length).fill(false);
    for (let i = 0; i < a.length; i++) {
      const aXorB = a[i] !== b[i];
      d[i] = c[i] !== aXorB;
    }
    return d;
  }

  findCrossDomainAnalogy(
    domainA: Map<string, boolean[]>,
    domainB: Map<string, boolean[]>
  ): AnalogyMapping | null {
    const sourceKeys = Array.from(domainA.keys());
    const targetKeys = Array.from(domainB.keys());
    const mapping = new Map<string, string>();
    const used = new Set<string>();

    for (const source of sourceKeys) {
      let bestTarget = '';
      let bestScore = -1;
      for (const target of targetKeys) {
        if (used.has(target)) continue;
        const score = this.similarity(domainA.get(source)!, domainB.get(target)!);
        if (score > bestScore) {
          bestScore = score;
          bestTarget = target;
        }
      }
      if (bestTarget) {
        mapping.set(source, bestTarget);
        used.add(bestTarget);
      }
    }

    return {
      sourceDomain: 'domainA',
      targetDomain: 'domainB',
      mapping,
      strength: mapping.size > 0 ? bestScore : 0,
      confidence: 0.8
    };
  }

  private similarity(a: boolean[], b: boolean[]): number {
    let matches = 0;
    for (let i = 0; i < Math.min(a.length, b.length); i++) {
      if (a[i] === b[i]) matches++;
    }
    return matches / Math.max(a.length, b.length);
  }
}

// ═══════════════════════════════════════════════════════════
// TOOL 7: HISTORICAL LANGUAGE CHANGE (1966, 1974)
// ═══════════════════════════════════════════════════════════

class HistoricalChangeModule implements MessyModule {
  name = 'HistoricalChange';
  private messy!: MessySubstrate;

  attachToMessy(messy: MessySubstrate) {
    this.messy = messy;
  }

  process(symbolId: string): MessySymbol {
    return this.messy.getSymbol(symbolId)!;
  }

  /**
   * Monte Carlo simulation of language/system change
   */
  simulateChange(
    initialSymbol: MessySymbol,
    generations: number,
    mutationRate: number = 0.1
  ): MessySymbol[] {
    return this.messy.simulateEpochs(initialSymbol.id, generations);
  }
}

// ═══════════════════════════════════════════════════════════
// TOOL 8: ANALOGICAL FOUNDATIONS OF CREATIVITY (1999-2002)
// ═══════════════════════════════════════════════════════════

class CreativityModule implements MessyModule {
  name = 'Creativity';
  private messy!: MessySubstrate;

  attachToMessy(messy: MessySubstrate) {
    this.messy = messy;
  }

  process(symbolId: string): MessySymbol {
    return this.messy.getSymbol(symbolId)!;
  }

  /**
   * The full creative synthesis: Upper Paleolithic to 2100CE
   * Generate novel structures by analogical blending
   */
  synthesizeCreativity(
    sourceDomain: Map<string, boolean[]>,
    targetDomain: Map<string, boolean[]>
  ): Map<string, boolean[]> {
    const analogyModule = this.messy.getModule('AnalogyMysticism') as AnalogyMysticismModule;
    if (!analogyModule) throw new Error('AnalogyMysticism module not registered');

    const analogy = analogyModule.findCrossDomainAnalogy(sourceDomain, targetDomain);
    if (!analogy) throw new Error('No analogy found between domains');

    // Creative blend: AND of common features, XOR of differing features
    const blend = new Map<string, boolean[]>();
    for (const [aKey, aVec] of sourceDomain) {
      const bKey = analogy.mapping.get(aKey);
      if (bKey) {
        const bVec = targetDomain.get(bKey)!;
        const blended = new Array(aVec.length).fill(false);
        for (let i = 0; i < aVec.length; i++) {
          blended[i] = aVec[i] && bVec[i] ? true : (aVec[i] !== bVec[i]);
        }
        blend.set(`${aKey}_x_${bKey}`, blended);
      }
    }

    return blend;
  }
}

// ═══════════════════════════════════════════════════════════
// UNIFIED KLEIN ENGINE — All 8 tools on MESSY
// ═══════════════════════════════════════════════════════════

class KleinEngine {
  messy: MessySubstrate;
  diseMiner: DiseMinerModule;
  autoling: AutolingModule;
  autoNovel: AutoNovelModule;
  proppLevi: ProppLeviStraussModule;
  analogy: AnalogyMysticismModule;
  historical: HistoricalChangeModule;
  creativity: CreativityModule;

  constructor() {
    this.messy = new MessySubstrate();

    // Create all 8 tools
    this.diseMiner = new DiseMinerModule();
    this.autoling = new AutolingModule();
    this.autoNovel = new AutoNovelModule();
    this.proppLevi = new ProppLeviStraussModule();
    this.analogy = new AnalogyMysticismModule();
    this.historical = new HistoricalChangeModule();
    this.creativity = new CreativityModule();

    // Register all tools with MESSY
    this.messy.registerModule('DISEMINER', this.diseMiner);
    this.messy.registerModule('AUTOLING', this.autoling);
    this.messy.registerModule('AutoNovel', this.autoNovel);
    this.messy.registerModule('ProppLeviStrauss', this.proppLevi);
    this.messy.registerModule('AnalogyMysticism', this.analogy);
    this.messy.registerModule('HistoricalChange', this.historical);
    this.messy.registerModule('Creativity', this.creativity);
  }

  /**
   * Full pipeline: ingest → DISEMINER → AUTOLING → AutoNovel → ... → output
   */
  async process(text: string, id: string = `input_${Date.now()}`): Promise<MessySymbol> {
    // D1: Ingest into MESSY
    const symbol = this.messy.ingest(id, text, 'linguistic');

    // D2: DISEMINER — distributional analysis
    await this.diseMiner.process(symbol.id);

    // D3: AUTOLING — parse structure, ask who/what/where/when/why
    await this.autoling.process(symbol.id);

    // D4: Auto Novel — generate narrative (or code, when curated)
    await this.autoNovel.process(symbol.id);

    // D5: Propp/Lévi-Strauss — structure the narrative
    // (Implicit in the morph chain)

    return this.messy.getSymbol(symbol.id)!;
  }

  /**
   * Ask the 5 W's about any ingested symbol
   */
  ask5W(symbolId: string): WhoWhatWhereWhenWhy {
    return this.autoling.ask5W(symbolId);
  }

  /**
   * Generate code as narrative (Auto Novel curated for code)
   */
  writeCode(requirements: string): string {
    return this.autoNovel.writeCodeAsNarrative(requirements);
  }

  /**
   * Generate a folktale (Propp + Lévi-Strauss)
   */
  tellStory(theme: string, length: number = 8): { functions: any[]; mythemes: any[] } {
    return this.proppLevi.generateFolktale(theme, length);
  }

  /**
   * Find analogies between domains
   */
  analogize(domainA: Map<string, boolean[]>, domainB: Map<string, boolean[]>): AnalogyMapping | null {
    return this.analogy.findCrossDomainAnalogy(domainA, domainB);
  }

  /**
   * Creative synthesis via analogy
   */
  create(source: Map<string, boolean[]>, target: Map<string, boolean[]>): Map<string, boolean[]> {
    return this.creativity.synthesizeCreativity(source, target);
  }

  /**
   * Simulate historical evolution
   */
  evolve(symbolId: string, generations: number): MessySymbol[] {
    return this.historical.simulateChange(this.messy.getSymbol(symbolId)!, generations);
  }

  getStats() {
    return {
      messy: this.messy.getStats(),
      modules: [
        this.diseMiner.name,
        this.autoling.name,
        this.autoNovel.name,
        this.proppLevi.name,
        this.analogy.name,
        this.historical.name,
        this.creativity.name
      ]
    };
  }
}

// ═══════════════════════════════════════════════════════════
// Exports
// ═══════════════════════════════════════════════════════════

export {
  MessySubstrate,
  MessySymbol,
  MessyMorphRule,
  MessyContext,
  MessyModule,
  WhoWhatWhereWhenWhy,
  DiseMinerModule,
  AutolingModule,
  AutoNovelModule,
  ProppLeviStraussModule,
  AnalogyMysticismModule,
  HistoricalChangeModule,
  CreativityModule,
  KleinEngine
};

export default KleinEngine;
