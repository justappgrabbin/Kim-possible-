/**
 * ============================================================
 * DISEMINER & NARRATIVE ENGINE
 * Sheldon Klein's Distributional-Semantics Inference Maker
 * Integrated with Meta-linguistic Systems and Analogy Engine
 *
 * Klein's contributions:
 *   - DISEMINER (1968): Distributional semantics inference
 *   - AUTOLING (1968): Meta-linguistic NLP system
 *   - Automatic Novel Writing (1973): Computer-generated fiction
 *   - Meta-symbolic Simulation (1976): Propp/Lévi-Strauss folktale modeling
 *   - Analogy & Mysticism (1983): Cultural structure via analogy
 *   - Analogical Foundations of Creativity (2002): Upper Paleolithic to 2100CE
 *
 * This module implements:
 *   1. Distributional semantic inference (word co-occurrence → meaning)
 *   2. Meta-linguistic grammar configuration (multiple grammars in one system)
 *   3. Narrative generation via Proppian functions + Lévi-Strauss structures
 *   4. Analogical reasoning (Boolean groups + feature vectors)
 *   5. Monte Carlo simulation of language change (historical dynamics)
 * ============================================================
 */

import { SemanticNode, AnalogyMapping } from './core-engine';

// ═══════════════════════════════════════════════════════════
// DISEMINER: Distributional-Semantics Inference Maker
// ═══════════════════════════════════════════════════════════

/**
 * Distributional hypothesis: "You shall know a word by the company it keeps"
 * (Firth, via Klein). Words that appear in similar contexts have similar meanings.
 */
interface DistributionalVector {
  word: string;
  // Context features: which contexts this word appears in
  contexts: Map<string, number>; // contextId -> frequency
  // Boolean feature vector (Klein's bi-directional inheritance)
  features: boolean[];
  // Semantic field position
  fieldPosition: number; // Which semantic field this word belongs to
}

interface SemanticField {
  id: string;
  label: string;
  // Words in this field
  words: Set<string>;
  // Centroid of the field (average distributional vector)
  centroid: Float32Array;
  // Relations to other fields (Klein: relations can be logical operators)
  relations: Map<string, string[]>; // relationType -> fieldIds
}

class DiseMiner {
  private vocabulary: Map<string, DistributionalVector> = new Map();
  private semanticFields: Map<string, SemanticField> = new Map();
  private contextWindow: number = 5; // Words to each side
  private featureDimension: number = 256;

  // Co-occurrence matrix (sparse)
  private cooccurrence: Map<string, Map<string, number>> = new Map();

  constructor() {
    this.seedSemanticFields();
  }

  private seedSemanticFields() {
    const fields = [
      { id: 'game_engine', label: 'Game Engine' },
      { id: 'graphics', label: 'Graphics & Rendering' },
      { id: 'physics', label: 'Physics Simulation' },
      { id: 'audio', label: 'Audio Systems' },
      { id: 'ai', label: 'Artificial Intelligence' },
      { id: 'narrative', label: 'Narrative & Story' },
      { id: 'input', label: 'Input & Control' },
      { id: 'network', label: 'Networking' },
      { id: 'diffusion', label: 'Diffusion Models' },
      { id: 'analogy', label: 'Analogical Reasoning' },
      { id: 'folktale', label: 'Folktale Structure' },
      { id: 'creativity', label: 'Creativity & Invention' },
    ];

    for (const f of fields) {
      this.semanticFields.set(f.id, {
        id: f.id,
        label: f.label,
        words: new Set(),
        centroid: new Float32Array(this.featureDimension),
        relations: new Map()
      });
    }

    // Establish field relations (Klein: logical operators between fields)
    this.addFieldRelation('game_engine', 'contains', 'graphics');
    this.addFieldRelation('game_engine', 'contains', 'physics');
    this.addFieldRelation('game_engine', 'contains', 'audio');
    this.addFieldRelation('game_engine', 'contains', 'ai');
    this.addFieldRelation('game_engine', 'contains', 'input');
    this.addFieldRelation('game_engine', 'contains', 'network');
    this.addFieldRelation('diffusion', 'generates', 'graphics');
    this.addFieldRelation('analogy', 'enables', 'creativity');
    this.addFieldRelation('folktale', 'structures', 'narrative');
    this.addFieldRelation('narrative', 'drives', 'game_engine');
  }

  private addFieldRelation(from: string, type: string, to: string) {
    const field = this.semanticFields.get(from);
    if (field) {
      const existing = field.relations.get(type) || [];
      existing.push(to);
      field.relations.set(type, existing);
    }
  }

  /**
   * Ingest a corpus and build distributional vectors
   */
  ingestCorpus(text: string, sourceId: string = 'default') {
    const tokens = this.tokenize(text);

    for (let i = 0; i < tokens.length; i++) {
      const word = tokens[i].toLowerCase();

      // Get context window
      const start = Math.max(0, i - this.contextWindow);
      const end = Math.min(tokens.length, i + this.contextWindow + 1);
      const context = tokens.slice(start, end).filter((_, idx) => idx + start !== i);

      // Update co-occurrence
      if (!this.cooccurrence.has(word)) {
        this.cooccurrence.set(word, new Map());
      }
      const wordCooc = this.cooccurrence.get(word)!;

      for (const ctxWord of context) {
        const ctx = ctxWord.toLowerCase();
        wordCooc.set(ctx, (wordCooc.get(ctx) || 0) + 1);
      }

      // Update or create distributional vector
      let vec = this.vocabulary.get(word);
      if (!vec) {
        vec = {
          word,
          contexts: new Map(),
          features: this.randomFeatures(),
          fieldPosition: -1 // Unassigned
        };
        this.vocabulary.set(word, vec);
      }

      vec.contexts.set(sourceId, (vec.contexts.get(sourceId) || 0) + 1);
    }

    // Recompute centroids and assign fields
    this.recomputeFields();
  }

  private tokenize(text: string): string[] {
    return text
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(t => t.length > 1);
  }

  private randomFeatures(): boolean[] {
    return Array.from({ length: this.featureDimension }, () => Math.random() > 0.5);
  }

  private recomputeFields() {
    // Assign words to fields based on co-occurrence patterns
    for (const [word, vec] of this.vocabulary) {
      // Find the field whose centroid is closest to this word's co-occurrence pattern
      let bestField: string | null = null;
      let bestScore = -1;

      for (const [fieldId, field] of this.semanticFields) {
        const score = this.computeFieldAffinity(word, field);
        if (score > bestScore) {
          bestScore = score;
          bestField = fieldId;
        }
      }

      if (bestField && bestScore > 0.1) {
        vec.fieldPosition = parseInt(bestField) || 0;
        const field = this.semanticFields.get(bestField);
        if (field) {
          field.words.add(word);
        }
      }
    }

    // Recompute centroids
    for (const field of this.semanticFields.values()) {
      const wordVectors = Array.from(field.words).map(w => this.vocabulary.get(w));
      if (wordVectors.length > 0 && wordVectors[0]) {
        const sum = new Float32Array(this.featureDimension);
        let count = 0;
        for (const wv of wordVectors) {
          if (wv) {
            for (let i = 0; i < this.featureDimension; i++) {
              sum[i] += wv.features[i] ? 1 : 0;
            }
            count++;
          }
        }
        for (let i = 0; i < this.featureDimension; i++) {
          field.centroid[i] = count > 0 ? sum[i] / count : 0;
        }
      }
    }
  }

  private computeFieldAffinity(word: string, field: SemanticField): number {
    const wordCooc = this.cooccurrence.get(word);
    if (!wordCooc) return 0;

    let score = 0;
    for (const fieldWord of field.words) {
      score += wordCooc.get(fieldWord) || 0;
    }
    return score / (field.words.size + 1);
  }

  /**
   * Infer meaning: given a word, what does it mean based on its distribution?
   */
  infer(word: string): { word: string; field: string; synonyms: string[]; related: string[] } {
    const vec = this.vocabulary.get(word.toLowerCase());
    if (!vec) return { word, field: 'unknown', synonyms: [], related: [] };

    const field = Array.from(this.semanticFields.values())
      .find(f => f.words.has(word.toLowerCase()));

    // Find synonyms (words with similar co-occurrence patterns)
    const synonyms: { word: string; similarity: number }[] = [];
    for (const [otherWord, otherVec] of this.vocabulary) {
      if (otherWord !== word.toLowerCase()) {
        const sim = this.cosineSimilarity(vec, otherVec);
        if (sim > 0.7) {
          synonyms.push({ word: otherWord, similarity: sim });
        }
      }
    }
    synonyms.sort((a, b) => b.similarity - a.similarity);

    // Find related words (co-occurring but not synonyms)
    const related: string[] = [];
    const wordCooc = this.cooccurrence.get(word.toLowerCase());
    if (wordCooc) {
      const sorted = Array.from(wordCooc.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10);
      for (const [w, freq] of sorted) {
        if (!synonyms.some(s => s.word === w)) {
          related.push(w);
        }
      }
    }

    return {
      word,
      field: field?.label || 'unknown',
      synonyms: synonyms.slice(0, 5).map(s => s.word),
      related: related.slice(0, 5)
    };
  }

  private cosineSimilarity(a: DistributionalVector, b: DistributionalVector): number {
    const aCooc = this.cooccurrence.get(a.word);
    const bCooc = this.cooccurrence.get(b.word);
    if (!aCooc || !bCooc) return 0;

    let dot = 0;
    let aNorm = 0;
    let bNorm = 0;

    for (const [word, freq] of aCooc) {
      const bFreq = bCooc.get(word) || 0;
      dot += freq * bFreq;
      aNorm += freq * freq;
    }
    for (const freq of bCooc.values()) {
      bNorm += freq * freq;
    }

    return dot / (Math.sqrt(aNorm) * Math.sqrt(bNorm) + 1e-10);
  }

  getVocabulary(): Map<string, DistributionalVector> {
    return this.vocabulary;
  }

  getSemanticFields(): Map<string, SemanticField> {
    return this.semanticFields;
  }
}

// ═══════════════════════════════════════════════════════════
// META-LINGUISTIC SYSTEM (AUTOLING-inspired)
 * Multiple grammars in one system
 * Semantic/syntactic production rules as data
 * Same rules for generation AND recognition
 * Bi-directional feature inheritance
// ═══════════════════════════════════════════════════════════

interface GrammarRule {
  id: string;
  // Semantic structure (relational calculus)
  semantic: {
    head: string;
    relations: { type: string; target: string }[];
  };
  // Syntactic realization
  syntactic: {
    pattern: string; // e.g., "[SUBJ] [VERB] [OBJ]"
    constraints: { slot: string; category: string }[];
  };
  // Boolean feature vector (Klein: all units have feature vectors)
  features: boolean[];
  // Logical operator type (Klein: relations can be logical operators)
  operator: 'and' | 'or' | 'not' | 'implies' | 'sequence';
}

interface Grammar {
  id: string;
  name: string;
  rules: GrammarRule[];
  // The grammar can be configured for different purposes
  purpose: 'generation' | 'recognition' | 'translation' | 'interface';
}

class MetaLinguisticSystem {
  private grammars: Map<string, Grammar> = new Map();
  private activeGrammar: string = 'default';

  constructor() {
    this.seedGrammars();
  }

  private seedGrammars() {
    // Grammar 1: Game Description Language
    const gameDescGrammar: Grammar = {
      id: 'game_desc',
      name: 'Game Description Language',
      purpose: 'generation',
      rules: [
        {
          id: 'gd_1',
          semantic: { head: 'game', relations: [{ type: 'has', target: 'engine' }] },
          syntactic: { pattern: 'A [game_type] game powered by [engine_name]', constraints: [] },
          features: this.randomFeatures(),
          operator: 'and'
        },
        {
          id: 'gd_2',
          semantic: { head: 'engine', relations: [{ type: 'uses', target: 'diffusion' }] },
          syntactic: { pattern: 'using [tech] for [purpose]', constraints: [] },
          features: this.randomFeatures(),
          operator: 'and'
        },
        {
          id: 'gd_3',
          semantic: { head: 'world', relations: [{ type: 'generated_by', target: 'diffusion' }] },
          syntactic: { pattern: 'The world is generated frame-by-frame', constraints: [] },
          features: this.randomFeatures(),
          operator: 'sequence'
        }
      ]
    };

    // Grammar 2: Narrative Structure (Proppian)
    const narrativeGrammar: Grammar = {
      id: 'narrative',
      name: 'Proppian Narrative Grammar',
      purpose: 'generation',
      rules: [
        {
          id: 'np_1',
          semantic: { head: 'villainy', relations: [{ type: 'causes', target: 'lack' }] },
          syntactic: { pattern: 'The [villain] [action] the [victim]', constraints: [] },
          features: this.randomFeatures(),
          operator: 'implies'
        },
        {
          id: 'np_2',
          semantic: { head: 'hero', relations: [{ type: 'departs', target: 'quest' }] },
          syntactic: { pattern: 'The hero leaves on a quest to [goal]', constraints: [] },
          features: this.randomFeatures(),
          operator: 'sequence'
        },
        {
          id: 'np_3',
          semantic: { head: 'donor', relations: [{ type: 'gives', target: 'magic_item' }] },
          syntactic: { pattern: 'A [donor] provides [magic_item]', constraints: [] },
          features: this.randomFeatures(),
          operator: 'and'
        },
        {
          id: 'np_4',
          semantic: { head: 'victory', relations: [{ type: 'resolves', target: 'villainy' }] },
          syntactic: { pattern: 'The hero [defeats] the [villain]', constraints: [] },
          features: this.randomFeatures(),
          operator: 'implies'
        }
      ]
    };

    // Grammar 3: Technical Documentation
    const docGrammar: Grammar = {
      id: 'tech_doc',
      name: 'Technical Documentation Grammar',
      purpose: 'generation',
      rules: [
        {
          id: 'td_1',
          semantic: { head: 'component', relations: [{ type: 'described_by', target: 'doc' }] },
          syntactic: { pattern: '## [component_name]\n\n[description]\n\n### Parameters\n[params]', constraints: [] },
          features: this.randomFeatures(),
          operator: 'and'
        }
      ]
    };

    this.grammars.set(gameDescGrammar.id, gameDescGrammar);
    this.grammars.set(narrativeGrammar.id, narrativeGrammar);
    this.grammars.set(docGrammar.id, docGrammar);
    this.activeGrammar = 'game_desc';
  }

  private randomFeatures(): boolean[] {
    return Array.from({ length: 128 }, () => Math.random() > 0.5);
  }

  setGrammar(id: string) {
    if (this.grammars.has(id)) {
      this.activeGrammar = id;
    }
  }

  generate(semanticInput: Record<string, any>): string {
    const grammar = this.grammars.get(this.activeGrammar);
    if (!grammar) return '';

    // Match semantic input to rules
    const matchedRules = grammar.rules.filter(rule => {
      return this.semanticMatch(rule.semantic, semanticInput);
    });

    if (matchedRules.length === 0) return '';

    // Apply operator logic (Klein: relations can be logical operators)
    const result = this.applyOperator(matchedRules, grammar.rules);
    return this.realizeSyntactic(result, semanticInput);
  }

  private semanticMatch(ruleSem: GrammarRule['semantic'], input: Record<string, any>): boolean {
    return input[ruleSem.head] !== undefined;
  }

  private applyOperator(rules: GrammarRule[], allRules: GrammarRule[]): GrammarRule[] {
    // Simplified: just return the matched rules in sequence
    // Full implementation would handle and/or/not/implies/sequence
    return rules;
  }

  private realizeSyntactic(rules: GrammarRule[], bindings: Record<string, any>): string {
    return rules.map(rule => {
      let text = rule.syntactic.pattern;
      // Simple slot filling
      for (const [key, value] of Object.entries(bindings)) {
        text = text.replace(new RegExp(`\[${key}\]`, 'g'), String(value));
      }
      // Clean up unfilled slots
      text = text.replace(/\[[^\]]+\]/g, '___');
      return text;
    }).join('\n');
  }

  /**
   * Recognize: parse text into semantic structure
   * (Klein: same rules for generation AND recognition)
   */
  recognize(text: string): Record<string, any> | null {
    const grammar = this.grammars.get(this.activeGrammar);
    if (!grammar) return null;

    for (const rule of grammar.rules) {
      const pattern = rule.syntactic.pattern
        .replace(/\[([^\]]+)\]/g, '(.+)') // Slots become capture groups
        .replace(/\\n/g, '\n');

      const regex = new RegExp(pattern);
      const match = text.match(regex);
      if (match) {
        return { [rule.semantic.head]: match[1] || true };
      }
    }
    return null;
  }

  getGrammars(): Grammar[] {
    return Array.from(this.grammars.values());
  }
}

// ═══════════════════════════════════════════════════════════
// NARRATIVE GENERATOR (Propp + Lévi-Strauss via Meta-symbolic Simulation)
// ═══════════════════════════════════════════════════════════

/**
 * Propp's 31 Functions (simplified to core narrative elements)
 * Lévi-Strauss: myth structures as binary oppositions resolved through mediation
 */
interface NarrativeFunction {
  id: number; // Propp function number
  name: string;
  // Lévi-Strauss: binary opposition structure
  opposition: { a: string; b: string };
  // Resolution (mediation)
  resolution: string;
  // Semantic roles involved
  roles: string[];
}

interface NarrativeSequence {
  functions: NarrativeFunction[];
  // The "morphology" — how functions combine
  morphology: 'linear' | 'circular' | 'branching' | 'networked';
  // Lévi-Strauss: mythemes (minimal units of myth)
  mythemes: { concept: string; value: number }[];
}

class NarrativeGenerator {
  private diseMiner: DiseMiner;
  private metaLinguistic: MetaLinguisticSystem;

  // Propp's functions (simplified)
  private proppFunctions: NarrativeFunction[] = [
    { id: 1, name: 'ABSENTATION', opposition: { a: 'home', b: 'away' }, resolution: 'departure', roles: ['hero'] },
    { id: 2, name: 'INTERDICTION', opposition: { a: 'allowed', b: 'forbidden' }, resolution: 'warning', roles: ['hero', 'dispatcher'] },
    { id: 3, name: 'VIOLATION', opposition: { a: 'order', b: 'chaos' }, resolution: 'transgression', roles: ['villain'] },
    { id: 4, name: 'RECONNAISSANCE', opposition: { a: 'known', b: 'unknown' }, resolution: 'discovery', roles: ['villain'] },
    { id: 5, name: 'DELIVERY', opposition: { a: 'ignorant', b: 'informed' }, resolution: 'information', roles: ['villain', 'victim'] },
    { id: 6, name: 'TRICKERY', opposition: { a: 'truth', b: 'deception' }, resolution: 'deception', roles: ['villain', 'victim'] },
    { id: 7, name: 'COMPLICITY', opposition: { a: 'innocent', b: 'guilty' }, resolution: 'cooperation', roles: ['villain', 'victim'] },
    { id: 8, name: 'VILLAINY', opposition: { a: 'whole', b: 'lacking' }, resolution: 'harm', roles: ['villain', 'victim'] },
    { id: 9, name: 'MEDIATION', opposition: { a: 'unaware', b: 'aware' }, resolution: 'call_to_action', roles: ['hero', 'dispatcher'] },
    { id: 10, name: 'COUNTERACTION', opposition: { a: 'passive', b: 'active' }, resolution: 'decision', roles: ['hero'] },
    { id: 11, name: 'DEPARTURE', opposition: { a: 'static', b: 'dynamic' }, resolution: 'journey', roles: ['hero'] },
    { id: 12, name: 'DONOR_FUNCTION', opposition: { a: 'unequipped', b: 'equipped' }, resolution: 'gift', roles: ['donor', 'hero'] },
    { id: 13, name: 'HERO_REACTION', opposition: { a: 'test', b: 'response' }, resolution: 'proof', roles: ['donor', 'hero'] },
    { id: 14, name: 'ACQUISITION', opposition: { a: 'without', b: 'with' }, resolution: 'possession', roles: ['hero'] },
    { id: 15, name: 'SPATIAL_TRANS', opposition: { a: 'here', b: 'there' }, resolution: 'movement', roles: ['hero'] },
    { id: 16, name: 'STRUGGLE', opposition: { a: 'contest', b: 'victory' }, resolution: 'combat', roles: ['hero', 'villain'] },
    { id: 17, name: 'BRANDING', opposition: { a: 'unmarked', b: 'marked' }, resolution: 'identification', roles: ['hero'] },
    { id: 18, name: 'VICTORY', opposition: { a: 'threat', b: 'safety' }, resolution: 'triumph', roles: ['hero', 'villain'] },
    { id: 19, name: 'LIQUIDATION', opposition: { a: 'problem', b: 'solution' }, resolution: 'resolution', roles: ['hero'] },
    { id: 20, name: 'RETURN', opposition: { a: 'away', b: 'home' }, resolution: 'journey_back', roles: ['hero'] },
    { id: 21, name: 'PURSUIT', opposition: { a: 'escape', b: 'capture' }, resolution: 'chase', roles: ['hero', 'villain'] },
    { id: 22, name: 'RESCUE', opposition: { a: 'danger', b: 'safety' }, resolution: 'salvation', roles: ['hero'] },
    { id: 23, name: 'UNRECOGNIZED', opposition: { a: 'known', b: 'unknown' }, resolution: 'disguise', roles: ['hero'] },
    { id: 24, name: 'UNFOUNDED_CLAIMS', opposition: { a: 'true', b: 'false' }, resolution: 'imposture', roles: ['false_hero'] },
    { id: 25, name: 'DIFFICULT_TASK', opposition: { a: 'impossible', b: 'possible' }, resolution: 'attempt', roles: ['hero'] },
    { id: 26, name: 'SOLUTION', opposition: { a: 'unsolved', b: 'solved' }, resolution: 'success', roles: ['hero'] },
    { id: 27, name: 'RECOGNITION', opposition: { a: 'hidden', b: 'revealed' }, resolution: 'identification', roles: ['hero'] },
    { id: 28, name: 'EXPOSURE', opposition: { a: 'deception', b: 'truth' }, resolution: 'revelation', roles: ['false_hero'] },
    { id: 29, name: 'TRANSFIGURATION', opposition: { a: 'old', b: 'new' }, resolution: 'change', roles: ['hero'] },
    { id: 30, name: 'PUNISHMENT', opposition: { a: 'guilt', b: 'penalty' }, resolution: 'justice', roles: ['villain'] },
    { id: 31, name: 'WEDDING', opposition: { a: 'alone', b: 'together' }, resolution: 'union', roles: ['hero', 'princess'] },
  ];

  constructor(diseMiner: DiseMiner, metaLinguistic: MetaLinguisticSystem) {
    this.diseMiner = diseMiner;
    this.metaLinguistic = metaLinguistic;
  }

  /**
   * Generate a narrative sequence using Propp's morphology
   * with Lévi-Straussian binary oppositions
   */
  generateNarrative(
    theme: string,
    length: number = 8,
    morphology: NarrativeSequence['morphology'] = 'linear'
  ): NarrativeSequence {
    // Select functions relevant to the theme
    const relevantFunctions = this.selectByTheme(theme, length);

    // Arrange according to morphology
    const arranged = this.arrangeFunctions(relevantFunctions, morphology);

    // Generate mythemes (Lévi-Strauss: minimal units of myth)
    const mythemes = this.generateMythemes(arranged, theme);

    return {
      functions: arranged,
      morphology,
      mythemes
    };
  }

  private selectByTheme(theme: string, count: number): NarrativeFunction[] {
    // Use DISEMINER to find semantically related functions
    const inference = this.diseMiner.infer(theme);
    const relatedWords = new Set([...inference.synonyms, ...inference.related]);

    // Score each function by relevance to theme
    const scored = this.proppFunctions.map(fn => {
      let score = 0;
      for (const role of fn.roles) {
        if (relatedWords.has(role.toLowerCase())) score += 2;
      }
      if (relatedWords.has(fn.opposition.a)) score += 1;
      if (relatedWords.has(fn.opposition.b)) score += 1;
      if (relatedWords.has(fn.resolution)) score += 1.5;
      return { fn, score };
    });

    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, count).map(s => s.fn);
  }

  private arrangeFunctions(
    functions: NarrativeFunction[],
    morphology: NarrativeSequence['morphology']
  ): NarrativeFunction[] {
    switch (morphology) {
      case 'linear':
        // Sort by Propp function number (canonical order)
        return [...functions].sort((a, b) => a.id - b.id);
      case 'circular':
        // Start and end with the same function
        return [...functions, functions[0]];
      case 'branching':
        // Shuffle with some branches
        return this.shuffleWithBranches(functions);
      case 'networked':
        // Random order with cross-references
        return this.shuffleWithCrossRefs(functions);
      default:
        return functions;
    }
  }

  private shuffleWithBranches(functions: NarrativeFunction[]): NarrativeFunction[] {
    const shuffled = [...functions];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }

  private shuffleWithCrossRefs(functions: NarrativeFunction[]): NarrativeFunction[] {
    return this.shuffleWithBranches(functions);
  }

  private generateMythemes(
    functions: NarrativeFunction[],
    theme: string
  ): { concept: string; value: number }[] {
    // Lévi-Strauss: mythemes are the minimal units of myth
    // They form a matrix of binary oppositions
    const mythemes = new Map<string, number>();

    for (const fn of functions) {
      mythemes.set(fn.opposition.a, (mythemes.get(fn.opposition.a) || 0) + 1);
      mythemes.set(fn.opposition.b, (mythemes.get(fn.opposition.b) || 0) - 1);
      mythemes.set(fn.resolution, (mythemes.get(fn.resolution) || 0) + 0.5);
    }

    // Add theme-specific mythemes
    const themeWords = theme.split(/\s+/);
    for (const word of themeWords) {
      mythemes.set(word.toLowerCase(), (mythemes.get(word.toLowerCase()) || 0) + 2);
    }

    return Array.from(mythemes.entries()).map(([concept, value]) => ({ concept, value }));
  }

  /**
   * Render narrative as text using the meta-linguistic grammar
   */
  renderNarrative(sequence: NarrativeSequence): string {
    this.metaLinguistic.setGrammar('narrative');

    const lines: string[] = [];
    lines.push(`# Narrative: ${sequence.morphology} structure`);
    lines.push('');

    for (const fn of sequence.functions) {
      const semanticInput = {
        [fn.name.toLowerCase()]: true,
        villain: 'the antagonist',
        hero: 'the protagonist',
        goal: fn.resolution,
        action: fn.opposition.b
      };
      const text = this.metaLinguistic.generate(semanticInput);
      lines.push(`## ${fn.name}`);
      lines.push(text);
      lines.push(`*Opposition: ${fn.opposition.a} ↔ ${fn.opposition.b} → ${fn.resolution}*`);
      lines.push('');
    }

    lines.push('---');
    lines.push('## Mythemes (Lévi-Strauss)');
    for (const mytheme of sequence.mythemes) {
      const bar = '█'.repeat(Math.abs(Math.round(mytheme.value * 2)));
      lines.push(`${mytheme.concept}: ${mytheme.value > 0 ? bar : ''}${mytheme.value < 0 ? bar : ''}`);
    }

    return lines.join('\n');
  }

  /**
   * Monte Carlo simulation of narrative evolution (Klein 1966, 1974)
   * Simulate how narratives change over "generations" of telling
   */
  simulateEvolution(
    initialSequence: NarrativeSequence,
    generations: number = 10,
    mutationRate: number = 0.1
  ): NarrativeSequence[] {
    const history: NarrativeSequence[] = [initialSequence];
    let current = initialSequence;

    for (let gen = 0; gen < generations; gen++) {
      const mutated = this.mutateSequence(current, mutationRate);
      history.push(mutated);
      current = mutated;
    }

    return history;
  }

  private mutateSequence(seq: NarrativeSequence, rate: number): NarrativeSequence {
    const mutatedFunctions = [...seq.functions];

    for (let i = 0; i < mutatedFunctions.length; i++) {
      if (Math.random() < rate) {
        // Mutate: swap with another function
        const swapIdx = Math.floor(Math.random() * this.proppFunctions.length);
        mutatedFunctions[i] = this.proppFunctions[swapIdx];
      }
    }

    // Recompute mythemes
    const mythemes = this.generateMythemes(mutatedFunctions, 'evolved');

    return {
      functions: mutatedFunctions,
      morphology: seq.morphology,
      mythemes
    };
  }
}

// ═══════════════════════════════════════════════════════════
// ANALOGY ENGINE (Klein 1983, 2002)
// Boolean groups + feature vectors for creative inference
// ═══════════════════════════════════════════════════════════

class AnalogyEngine {
  private featureDimension: number = 128;

  /**
   * Klein's insight: analogy operates on Boolean feature vectors
   * A : B :: C : D  means  (A ∧ ¬B) ≈ (C ∧ ¬D)  in feature space
   */
  computeAnalogy(
    a: boolean[],
    b: boolean[],
    c: boolean[]
  ): boolean[] {
    // A : B :: C : D
    // D = C ⊕ (A ⊕ B)  — XOR-based analogy (Klein-style Boolean group)
    const d = new Array(this.featureDimension).fill(false);
    for (let i = 0; i < this.featureDimension; i++) {
      const aXorB = a[i] !== b[i];
      d[i] = c[i] !== aXorB;
    }
    return d;
  }

  /**
   * Find the best analogy mapping between two domains
   */
  findAnalogy(
    sourceDomain: Map<string, boolean[]>,
    targetDomain: Map<string, boolean[]>
  ): AnalogyMapping | null {
    const sourceKeys = Array.from(sourceDomain.keys());
    const targetKeys = Array.from(targetDomain.keys());

    if (sourceKeys.length === 0 || targetKeys.length === 0) return null;

    // Greedy matching based on feature similarity
    const mapping = new Map<string, string>();
    const usedTargets = new Set<string>();

    for (const sourceKey of sourceKeys) {
      let bestTarget = '';
      let bestScore = -1;
      const sourceVec = sourceDomain.get(sourceKey)!;

      for (const targetKey of targetKeys) {
        if (usedTargets.has(targetKey)) continue;
        const targetVec = targetDomain.get(targetKey)!;
        const score = this.similarity(sourceVec, targetVec);
        if (score > bestScore) {
          bestScore = score;
          bestTarget = targetKey;
        }
      }

      if (bestTarget) {
        mapping.set(sourceKey, bestTarget);
        usedTargets.add(bestTarget);
      }
    }

    // Compute overall strength
    let totalScore = 0;
    for (const [s, t] of mapping) {
      totalScore += this.similarity(sourceDomain.get(s)!, targetDomain.get(t)!);
    }
    const strength = mapping.size > 0 ? totalScore / mapping.size : 0;

    return {
      sourceDomain: 'source',
      targetDomain: 'target',
      mapping,
      strength,
      confidence: strength * 0.9 // Slightly reduced confidence
    };
  }

  private similarity(a: boolean[], b: boolean[]): number {
    let matches = 0;
    for (let i = 0; i < Math.min(a.length, b.length); i++) {
      if (a[i] === b[i]) matches++;
    }
    return matches / Math.max(a.length, b.length);
  }

  /**
   * Generate a creative blend: combine two domains via analogy
   * (Klein: "The Analogical Foundations of Creativity")
   */
  creativeBlend(
    domainA: Map<string, boolean[]>,
    domainB: Map<string, boolean[]>,
    analogy: AnalogyMapping
  ): Map<string, boolean[]> {
    const blend = new Map<string, boolean[]>();

    for (const [aKey, aVec] of domainA) {
      const bKey = analogy.mapping.get(aKey);
      if (bKey) {
        const bVec = domainB.get(bKey)!;
        // Blend: AND of common features, XOR of differing features
        const blended = new Array(this.featureDimension).fill(false);
        for (let i = 0; i < this.featureDimension; i++) {
          blended[i] = aVec[i] && bVec[i] ? true : (aVec[i] !== bVec[i]);
        }
        blend.set(`${aKey}_x_${bKey}`, blended);
      } else {
        // Unmapped elements pass through
        blend.set(aKey, [...aVec]);
      }
    }

    return blend;
  }
}

// ═══════════════════════════════════════════════════════════
// UNIFIED KLEIN MODULE
// ═══════════════════════════════════════════════════════════

class KleinModule {
  diseMiner: DiseMiner;
  metaLinguistic: MetaLinguisticSystem;
  narrative: NarrativeGenerator;
  analogy: AnalogyEngine;

  constructor() {
    this.diseMiner = new DiseMiner();
    this.metaLinguistic = new MetaLinguisticSystem();
    this.narrative = new NarrativeGenerator(this.diseMiner, this.metaLinguistic);
    this.analogy = new AnalogyEngine();
  }

  /**
   * Ingest a corpus and build the full semantic infrastructure
   */
  ingest(corpus: string, sourceId: string = 'default') {
    this.diseMiner.ingestCorpus(corpus, sourceId);
  }

  /**
   * Generate a narrative about a given theme
   */
  narrate(theme: string, length: number = 8, morphology: 'linear' | 'circular' | 'branching' | 'networked' = 'linear'): string {
    const sequence = this.narrative.generateNarrative(theme, length, morphology);
    return this.narrative.renderNarrative(sequence);
  }

  /**
   * Find analogies between two semantic domains
   */
  analogize(domainA: Map<string, boolean[]>, domainB: Map<string, boolean[]>): AnalogyMapping | null {
    return this.analogy.findAnalogy(domainA, domainB);
  }

  /**
   * Generate a creative blend of two domains
   */
  blend(domainA: Map<string, boolean[]>, domainB: Map<string, boolean[]>, analogy: AnalogyMapping): Map<string, boolean[]> {
    return this.analogy.creativeBlend(domainA, domainB, analogy);
  }

  /**
   * Simulate narrative evolution over generations
   */
  evolve(theme: string, generations: number = 10): NarrativeSequence[] {
    const initial = this.narrative.generateNarrative(theme, 8, 'linear');
    return this.narrative.simulateEvolution(initial, generations, 0.15);
  }

  /**
   * Query the semantic infrastructure
   */
  query(word: string) {
    return this.diseMiner.infer(word);
  }

  getStats() {
    return {
      vocabularySize: this.diseMiner.getVocabulary().size,
      semanticFields: this.diseMiner.getSemanticFields().size,
      grammars: this.metaLinguistic.getGrammars().length,
      narrativeFunctions: 31 // Propp's functions
    };
  }
}

// ═══════════════════════════════════════════════════════════
// Exports
// ═══════════════════════════════════════════════════════════

export {
  DiseMiner,
  MetaLinguisticSystem,
  NarrativeGenerator,
  AnalogyEngine,
  KleinModule
};

export type {
  DistributionalVector,
  SemanticField,
  Grammar,
  GrammarRule,
  NarrativeFunction,
  NarrativeSequence
};

export default KleinModule;
