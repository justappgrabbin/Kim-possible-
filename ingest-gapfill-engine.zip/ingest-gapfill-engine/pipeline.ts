/**
 * ============================================================
 * INGEST-GAPFILL PIPELINE v2
 * All 8 Klein tools on MESSY morphing substrate + gameNgen
 *
 * MESSY is the connective tissue. Every tool passes through it.
 * The pipeline doesn't just call tools — it MORPHS between them.
 *
 * Dimensional Stack:
 *   D1 (Impulse)    → MESSY.ingest() → DISEMINER
 *   D2 (Polarity)   → MESSY.morph('linguistic'→'semantic') → AUTOLING
 *   D3 (Witness)    → MESSY.morph('semantic'→'behavioral') → MESSY core
 *   D4 (Context)    → MESSY.morph('behavioral'→'narrative') → Auto Novel
 *   D5 (Meaning)    → MESSY.morph('narrative'→'connectionist') → Analogy + Creativity
 *
 * The 5W Query Engine (AUTOLING):
 *   "Who wrote this?" → agent identification
 *   "What does it do?" → action extraction
 *   "Where does it run?" → spatial context
 *   "When does it execute?" → temporal context
 *   "Why does it exist?" → causal/motivational context
 * ============================================================
 */

import { IngestGapFillEngine, WorldModel, GapReport, GeneratedArtifact } from './core-engine';
import { GameNGenEngine, MockDiffusionBackend, DiffusionModelConfig } from './gamengen-adapter';
import { KleinEngine, WhoWhatWhereWhenWhy, MessySymbol } from './klein-full-toolkit';

interface PipelineConfig {
  maxFileSize: number;
  allowedExtensions: string[];
  recursive: boolean;
  diffusionConfig?: DiffusionModelConfig;
  useMockBackend: boolean;
  narrativeLength: number;
  narrativeMorphology: 'linear' | 'circular' | 'branching' | 'networked';
  autoFill: boolean;
  fillSeverity: ('critical' | 'warning' | 'info')[];
  outputDir: string;
  verbose: boolean;
  // MESSY-specific
  messyFeatureDimension: number;
  messyMutationRate: number;
  // Auto Novel curation
  autoNovelMode: 'fiction' | 'code' | 'technical_doc' | 'game_design';
}

const DEFAULT_CONFIG: PipelineConfig = {
  maxFileSize: 50 * 1024 * 1024,
  allowedExtensions: [
    'ts', 'js', 'tsx', 'jsx', 'py', 'html', 'css', 'json',
    'md', 'yaml', 'yml', 'xml', 'glsl', 'shader', 'wasm',
    'png', 'jpg', 'jpeg', 'gif', 'webp', 'mp3', 'wav', 'ogg',
    'gltf', 'obj', 'fbx'
  ],
  recursive: true,
  useMockBackend: true,
  narrativeLength: 8,
  narrativeMorphology: 'linear',
  autoFill: true,
  fillSeverity: ['critical', 'warning'],
  outputDir: './output',
  verbose: true,
  messyFeatureDimension: 256,
  messyMutationRate: 0.05,
  autoNovelMode: 'code'
};

class IngestGapFillPipeline {
  private engine: IngestGapFillEngine;
  private gamengen: GameNGenEngine | null = null;
  private klein: KleinEngine;
  private config: PipelineConfig;
  private log: string[] = [];

  constructor(config: Partial<PipelineConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.engine = new IngestGapFillEngine();
    this.klein = new KleinEngine();
  }

  async initialize() {
    this.log('╔══════════════════════════════════════════════════════════════╗');
    this.log('║     INGEST-GAPFILL PIPELINE v2 — MESSY Substrate             ║');
    this.log('╠══════════════════════════════════════════════════════════════╣');
    this.log('║  D1: Impulse    → DISEMINER  → distributional vectors        ║');
    this.log('║  D2: Polarity   → AUTOLING   → who/what/where/when/why       ║');
    this.log('║  D3: Witness    → MESSY      → meta-symbolic observation     ║');
    this.log('║  D4: Context    → Auto Novel → narrative/code generation     ║');
    this.log('║  D5: Meaning    → Analogy    → creative synthesis            ║');
    this.log('╚══════════════════════════════════════════════════════════════╝');
    this.log('');

    // Initialize gameNgen
    if (this.config.diffusionConfig || this.config.useMockBackend) {
      const diffConfig: DiffusionModelConfig = this.config.diffusionConfig || {
        modelPath: './models/gamengen',
        autoencoderPath: './models/vae',
        numInferenceSteps: 20,
        guidanceScale: 1.0,
        frameConditioning: 'concat',
        useTensorRT: false,
        useFlashAttention: false,
        outputResolution: [256, 256]
      };

      const backend = this.config.useMockBackend
        ? new MockDiffusionBackend(diffConfig)
        : null;

      if (backend) {
        this.gamengen = new GameNGenEngine(backend, this.engine);
        await this.gamengen.initialize();
        this.log('  gameNgen: Diffusion Engine — ready (mock)');
      }
    }

    this.log('  Klein: All 8 tools registered on MESSY');
    this.log('    ✓ DISEMINER (1968)');
    this.log('    ✓ AUTOLING (1968) — 5W query engine');
    this.log('    ✓ Auto Novel (1973) — curated for ' + this.config.autoNovelMode);
    this.log('    ✓ MESSY (1976) — morphing substrate');
    this.log('    ✓ Propp/Lévi-Strauss (1976-77)');
    this.log('    ✓ Analogy & Mysticism (1983)');
    this.log('    ✓ Historical Change (1966, 1974)');
    this.log('    ✓ Creativity (1999-2002)');
    this.log('');
    this.log('Pipeline initialized. Ready to ingest and morph.');
  }

  // ═══════════════════════════════════════════════════════
  // INGESTION — D1: Impulse → MESSY → DISEMINER
  // ═══════════════════════════════════════════════════════

  async ingestFile(filePath: string, content: string | Buffer) {
    this.log(`📥 Ingesting: ${filePath}`);
    const contentStr = typeof content === 'string' ? content : content.toString();

    // D1: Raw impulse into engine
    const signal = await this.engine.ingestFile(
      Buffer.from(contentStr),
      filePath.split('/').pop() || 'unknown',
      { path: filePath }
    );

    // D1→D2: Feed into MESSY → DISEMINER → AUTOLING
    const messySymbol = await this.klein.process(contentStr, `messy_${signal.id}`);

    this.log(`  → Signal ${signal.id} → MESSY ${messySymbol.id}`);
    this.log(`  → DISEMINER: ${this.klein.messy.getStats().symbols} symbols in network`);

    // AUTOLING: Ask the 5 W's
    const fiveW = this.klein.ask5W(messySymbol.id);
    this.log5W(fiveW);

    return { signal, messySymbol, fiveW };
  }

  private log5W(fiveW: WhoWhatWhereWhenWhy) {
    const entries = [];
    if (fiveW.who) entries.push(`Who: ${fiveW.who} (${(fiveW.confidence.who * 100).toFixed(0)}%)`);
    if (fiveW.what) entries.push(`What: ${fiveW.what} (${(fiveW.confidence.what * 100).toFixed(0)}%)`);
    if (fiveW.where) entries.push(`Where: ${fiveW.where} (${(fiveW.confidence.where * 100).toFixed(0)}%)`);
    if (fiveW.when) entries.push(`When: ${fiveW.when} (${(fiveW.confidence.when * 100).toFixed(0)}%)`);
    if (fiveW.why) entries.push(`Why: ${fiveW.why} (${(fiveW.confidence.why * 100).toFixed(0)}%)`);
    if (entries.length > 0) {
      this.log(`  → AUTOLING 5W: ${entries.join(' | ')}`);
    }
  }

  async ingestDirectory(dirPath: string, files: Record<string, string>) {
    this.log(`📂 Ingesting directory: ${dirPath}`);
    const results = [];
    for (const [path, content] of Object.entries(files)) {
      const ext = path.split('.').pop()?.toLowerCase() || '';
      if (!this.config.allowedExtensions.includes(ext)) {
        this.log(`  ⏭ Skipping (not allowed): ${path}`);
        continue;
      }
      if (content.length > this.config.maxFileSize) {
        this.log(`  ⏭ Skipping (too large): ${path}`);
        continue;
      }
      const result = await this.ingestFile(path, content);
      results.push(result);
    }
    this.log(`Directory complete: ${results.length} files ingested and morphed`);
    return results;
  }

  // ═══════════════════════════════════════════════════════
  // MESSY MORPHING — D2→D3→D4→D5
  // ═══════════════════════════════════════════════════════

  /**
   * Morph a symbol through the full dimensional chain
   */
  morphSymbol(symbolId: string): MessySymbol {
    this.log(`🔄 Morphing ${symbolId} through MESSY...`);

    // D2: linguistic → semantic (DISEMINER)
    const semantic = this.klein.messy.morph(symbolId, 'semantic');
    this.log(`  D2→D3: semantic — ${semantic.id}`);

    // D3: semantic → behavioral (AUTOLING)
    const behavioral = this.klein.messy.morph(semantic.id, 'behavioral');
    this.log(`  D3→D4: behavioral — ${behavioral.id}`);

    // D4: behavioral → narrative (Auto Novel)
    const narrative = this.klein.messy.morph(behavioral.id, 'narrative');
    this.log(`  D4→D5: narrative — ${narrative.id}`);

    // D5: narrative → connectionist (Analogy)
    const connectionist = this.klein.messy.morph(narrative.id, 'connectionist');
    this.log(`  D5: connectionist — ${connectionist.id}`);

    return connectionist;
  }

  /**
   * Full morph chain: linguistic → archaeological (through all epochs)
   */
  morphThroughTime(symbolId: string, epochs: number = 5): MessySymbol[] {
    this.log(`⏳ Morphing ${symbolId} through ${epochs} epochs...`);
    return this.klein.messy.simulateEpochs(symbolId, epochs);
  }

  // ═══════════════════════════════════════════════════════
  // SYNTHESIS & GAP FILLING
  // ═══════════════════════════════════════════════════════

  synthesize(): WorldModel {
    this.log('🔬 Synthesizing world model...');
    const world = this.engine.synthesize();
    this.log(`  Nodes: ${world.nodes.length}`);
    this.log(`  Gaps detected: ${world.gaps.length}`);
    this.log(`  Gaps filled: ${world.filled.length}`);
    this.log(`  Coverage: ${(world.emergentProperties.get('coverage') * 100).toFixed(1)}%`);
    return world;
  }

  fillAllGaps(): GeneratedArtifact[] {
    this.log('🔧 Filling all detected gaps...');
    const world = this.synthesize();
    const filled: GeneratedArtifact[] = [];

    for (const gap of world.gaps) {
      if (this.config.fillSeverity.includes(gap.severity)) {
        // Use analogy-driven gap filling when possible
        if (gap.triggeringAnalogy) {
          this.log(`  🎨 Analogy-driven fill: ${gap.gapType} (${gap.triggeringAnalogy.sourceDomain} → ${gap.triggeringAnalogy.targetDomain})`);
        }
        const artifacts = this.engine.rollout(
          world.nodes.find(n => n.id === gap.nodeId)?.label || 'unknown',
          1
        );
        filled.push(...artifacts);
        this.log(`  ✓ Filled ${gap.gapType} for ${gap.nodeId} (${gap.severity})`);
      }
    }

    this.log(`Total filled: ${filled.length}`);
    return filled;
  }

  // ═══════════════════════════════════════════════════════
  // AUTO NOVEL — CURATED FOR CODE
  // ═══════════════════════════════════════════════════════

  /**
   * Generate code as narrative (Auto Novel curated for code)
   * Each function = a chapter, each class = a character
   */
  writeCode(requirements: string): string {
    this.log(`📝 Auto Novel generating code: "${requirements}"`);
    const code = this.klein.writeCode(requirements);
    this.log(`  Generated ${code.split('\n').length} lines`);
    return code;
  }

  /**
   * Generate a folktale (Propp + Lévi-Strauss)
   */
  tellStory(theme: string, length: number = 8): string {
    this.log(`📖 Generating folktale: "${theme}"`);
    const tale = this.klein.tellStory(theme, length);
    const rendered = this.renderFolktale(tale);
    this.log(`  ${tale.functions.length} functions, ${tale.mythemes.length} mythemes`);
    return rendered;
  }

  private renderFolktale(tale: { functions: any[]; mythemes: any[] }): string {
    const lines = [
      '# Folktale Generated by Propp/Lévi-Strauss Module',
      '',
      '## Narrative Functions',
      ...tale.functions.map((f, i) => `${i + 1}. **${f.name}** — roles: ${f.roles.join(', ')}`),
      '',
      '## Mythemes (Lévi-Strauss)',
      ...tale.mythemes.map(m => `- ${m.concept}: ${m.value > 0 ? '+' : ''}${m.value}`),
      '',
      '## Binary Oppositions',
      ...tale.functions.map(f => `- ${f.name}: ${f.roles[0]} ↔ ${f.roles[1] || 'self'}`)
    ];
    return lines.join('\n');
  }

  // ═══════════════════════════════════════════════════════
  // ANALOGY & CREATIVITY
  // ═══════════════════════════════════════════════════════

  /**
   * Find analogies between two semantic domains
   */
  analogize(domainA: Map<string, boolean[]>, domainB: Map<string, boolean[]>): AnalogyMapping | null {
    this.log('🎨 Finding cross-domain analogy...');
    const analogy = this.klein.analogize(domainA, domainB);
    if (analogy) {
      this.log(`  Found analogy: ${analogy.sourceDomain} → ${analogy.targetDomain}`);
      this.log(`  Strength: ${analogy.strength.toFixed(2)}, Confidence: ${analogy.confidence.toFixed(2)}`);
      this.log(`  Mappings: ${Array.from(analogy.mapping.entries()).map(([k, v]) => `${k}→${v}`).join(', ')}`);
    }
    return analogy;
  }

  /**
   * Creative synthesis: blend two domains via analogy
   */
  create(source: Map<string, boolean[]>, target: Map<string, boolean[]>): Map<string, boolean[]> {
    this.log('✨ Creative synthesis via analogy...');
    const blend = this.klein.create(source, target);
    this.log(`  Generated ${blend.size} blended concepts`);
    return blend;
  }

  // ═══════════════════════════════════════════════════════
  // HISTORICAL SIMULATION
  // ═══════════════════════════════════════════════════════

  /**
   * Monte Carlo evolution of a symbol through epochs
   */
  evolve(symbolId: string, generations: number = 10): MessySymbol[] {
    this.log(`⏳ Monte Carlo evolution: ${generations} generations`);
    const history = this.klein.evolve(symbolId, generations);
    this.log(`  Evolved through ${history.length} epochs`);
    return history;
  }

  // ═══════════════════════════════════════════════════════
  // gameNgen INTEGRATION
  // ═══════════════════════════════════════════════════════

  async generateFrame(action: number): Promise<any> {
    if (!this.gamengen) throw new Error('gameNgen not initialized');
    const frame = await this.gamengen.generateFrame(action);
    this.log(`🎮 Generated frame ${frame.frameIndex} (action: ${action})`);
    return frame;
  }

  async dreamSequence(theme: string, length: number = 16): Promise<any[]> {
    if (!this.gamengen) throw new Error('gameNgen not initialized');
    const nodes = this.engine.query(theme);
    const seedNode = nodes[0];
    this.log(`🌙 Dreaming: "${theme}" (${length} frames)`);
    const frames = await this.gamengen.dreamSequence(seedNode, length);
    this.log(`  ${frames.length} dream frames generated`);
    return frames;
  }

  // ═══════════════════════════════════════════════════════
  // QUERY & EXPORT
  // ═══════════════════════════════════════════════════════

  query(pattern: string) {
    return this.engine.query(pattern);
  }

  ask5W(symbolId: string): WhoWhatWhereWhenWhy {
    return this.klein.ask5W(symbolId);
  }

  getStats() {
    const engineStats = this.engine.getStats();
    const kleinStats = this.klein.getStats();
    return {
      ...engineStats,
      messy: kleinStats.messy,
      modules: kleinStats.modules,
      gamengen: this.gamengen ? 'initialized' : 'not initialized',
      autoNovelMode: this.config.autoNovelMode,
      logEntries: this.log.length
    };
  }

  exportWorldModel(): string {
    return this.engine.exportWorldModel();
  }

  getLogs(): string[] {
    return this.log;
  }

  private log(message: string) {
    const entry = `[${new Date().toISOString()}] ${message}`;
    this.log.push(entry);
    if (this.config.verbose) {
      console.log(entry);
    }
  }
}

// ═══════════════════════════════════════════════════════════
// DEMO
// ═══════════════════════════════════════════════════════════

async function demo() {
  const pipeline = new IngestGapFillPipeline({
    useMockBackend: true,
    autoFill: true,
    autoNovelMode: 'code',
    verbose: true
  });

  await pipeline.initialize();

  // Ingest example files
  const results = await pipeline.ingestDirectory('demo', {
    'src/engine.ts': `
      import { Renderer } from './renderer';
      import { Physics } from './physics';
      export class GameEngine {
        private renderer: Renderer;
        private physics: Physics;
        constructor() {
          this.renderer = new Renderer();
          this.physics = new Physics();
        }
        update(dt: number) {
          this.physics.step(dt);
          this.renderer.render();
        }
      }
    `,
    'src/renderer.ts': `
      export class Renderer {
        render() {
          // TODO: implement rendering with WebGL
        }
      }
    `,
    'src/physics.ts': `
      export class Physics {
        step(dt: number) {
          // TODO: implement physics with Cannon.js
        }
      }
    `,
    'src/audio.ts': `
      export class AudioSystem {
        play(sound: string) {
          // TODO: implement audio with Web Audio API
        }
      }
    `,
    'package.json': JSON.stringify({
      name: 'demo-game',
      version: '1.0.0',
      dependencies: {
        'three': '^0.160.0',
        'cannon-es': '^0.20.0'
      }
    }),
    'README.md': '# Demo Game

A simple game engine demo using Three.js and Cannon.js.'
  });

  // Morph the first symbol through all dimensions
  if (results.length > 0) {
    const morphed = pipeline.morphSymbol(results[0].messySymbol.id);
    console.log(`\n🔄 Morphed symbol: ${morphed.id} → ${morphed.type}`);
  }

  // Synthesize world model
  const world = pipeline.synthesize();

  // Fill gaps
  const fills = pipeline.fillAllGaps();

  // Auto Novel: write code as narrative
  const code = pipeline.writeCode('A game engine with rendering, physics, and audio systems');
  console.log('\n=== AUTO NOVEL (CODE) ===\n');
  console.log(code);

  // Propp/Lévi-Strauss: generate folktale
  const story = pipeline.tellStory('game engine creation', 8);
  console.log('\n=== FOLKTALE ===\n');
  console.log(story);

  // Analogy: find cross-domain mapping
  const domainA = new Map<string, boolean[]>([
    ['renderer', [true, false, true, false]],
    ['physics', [false, true, true, false]],
    ['audio', [true, true, false, false]]
  ]);
  const domainB = new Map<string, boolean[]>([
    ['visual_cortex', [true, false, true, false]],
    ['motor_system', [false, true, true, false]],
    ['auditory_cortex', [true, true, false, false]]
  ]);
  const analogy = pipeline.analogize(domainA, domainB);

  // Creative synthesis
  if (analogy) {
    const blend = pipeline.create(domainA, domainB);
    console.log(`\n=== CREATIVE BLEND ===\n`);
    for (const [key, vec] of blend) {
      console.log(`${key}: [${vec.map(v => v ? '1' : '0').join('')}]`);
    }
  }

  // Historical evolution
  if (results.length > 0) {
    const evolution = pipeline.evolve(results[0].messySymbol.id, 5);
    console.log(`\n=== EVOLUTION (${evolution.length} epochs) ===`);
    for (const epoch of evolution) {
      console.log(`  Epoch ${epoch.epoch}: ${epoch.type} → ${epoch.morphState}`);
    }
  }

  // Dream sequence
  const frames = await pipeline.dreamSequence('exploration', 8);
  console.log(`\n🌙 Generated ${frames.length} dream frames`);

  // Stats
  console.log('\n=== STATS ===');
  console.log(JSON.stringify(pipeline.getStats(), null, 2));

  return { world, fills, code, story, frames, stats: pipeline.getStats() };
}

if (typeof window === 'undefined') {
  demo().catch(console.error);
}

export { IngestGapFillPipeline, PipelineConfig, DEFAULT_CONFIG, demo };
export default IngestGapFillPipeline;
