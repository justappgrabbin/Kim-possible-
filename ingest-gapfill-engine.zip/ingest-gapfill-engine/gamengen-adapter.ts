/**
 * ============================================================
 * gameNgen ADAPTER v2 — Real Integration
 *
 * Connects to the Python gameNgen server via WebSocket or HTTP.
 * Falls back to MockDiffusionBackend if server is unavailable.
 *
 * Architecture:
 *   TypeScript Engine ←→ WebSocket/HTTP ←→ Python FastAPI Server
 *   (D1-D5, MESSY)       (base64 PNG)      (PyTorch + diffusers)
 *
 * To use real diffusion:
 *   1. Download checkpoints: huggingface-cli download arnaudstiegler/sd-model-gameNgen-60ksteps
 *   2. Start Python server: python gamengen_server.py --model <path>
 *   3. Connect TypeScript: new GameNGenEngine(new PythonDiffusionBackend("ws://localhost:8000/ws"))
 * ============================================================
 */

import { SemanticNode, IngestedSignal, IngestGapFillEngine } from './core-engine';

// ═══════════════════════════════════════════════════════════
// Frame Representation
// ═══════════════════════════════════════════════════════════

interface GameNGenFrame {
  latent: Float32Array;
  action: number;
  previousFrames: string[];
  timestamp: number;
  frameIndex: number;
  semanticOverlay: SemanticNode | null;
  // Real addition: actual PNG bytes from Python server
  pngBytes?: Uint8Array;
  metadata?: {
    generation_time_ms: number;
    device: string;
    action_name: string;
  };
}

interface FrameBuffer {
  frames: GameNGenFrame[];
  maxSize: number;
  contextWindow: number;
}

// ═══════════════════════════════════════════════════════════
// Abstract Backend Interface
// ═══════════════════════════════════════════════════════════

interface DiffusionModelConfig {
  modelPath: string;
  autoencoderPath: string;
  numInferenceSteps: number;
  guidanceScale: number;
  frameConditioning: 'concat' | 'cross-attn';
  useTensorRT: boolean;
  useFlashAttention: boolean;
  outputResolution: [number, number];
}

abstract class DiffusionModelBackend {
  protected config: DiffusionModelConfig;
  protected isLoaded: boolean = false;

  constructor(config: DiffusionModelConfig) {
    this.config = config;
  }

  abstract load(): Promise<void>;
  abstract generateFrame(
    previousLatents: Float32Array[],
    action: number,
    seed?: number
  ): Promise<{ latent: Float32Array; pngBytes?: Uint8Array; metadata?: any }>;
  abstract encodeImage(pixels: Uint8Array): Promise<Float32Array>;
  abstract decodeLatent(latent: Float32Array): Promise<Uint8Array>;
  abstract dispose(): Promise<void>;
}

// ═══════════════════════════════════════════════════════════
// PYTHON SERVER BACKEND (Real — connects to FastAPI/WebSocket)
// ═══════════════════════════════════════════════════════════

interface PythonServerConfig {
  baseUrl: string;      // e.g., "http://localhost:8000"
  wsUrl?: string;       // e.g., "ws://localhost:8000/ws"
  timeout: number;      // ms
  retries: number;
}

class PythonDiffusionBackend extends DiffusionModelBackend {
  private serverConfig: PythonServerConfig;
  private ws: WebSocket | null = null;
  private frameQueue: Map<number, (result: any) => void> = new Map();
  private frameCounter: number = 0;

  constructor(
    config: DiffusionModelConfig,
    serverConfig: PythonServerConfig
  ) {
    super(config);
    this.serverConfig = serverConfig;
  }

  async load(): Promise<void> {
    // Check if server is healthy
    try {
      const response = await fetch(`${this.serverConfig.baseUrl}/health`);
      const health = await response.json();
      if (!health.model_loaded) {
        throw new Error('Python server model not loaded');
      }
      this.isLoaded = true;
      console.log('[PythonBackend] Connected to gameNgen server');
    } catch (e) {
      throw new Error(`Cannot connect to Python server: ${e}`);
    }

    // Connect WebSocket for streaming
    if (this.serverConfig.wsUrl) {
      this.connectWebSocket();
    }
  }

  private connectWebSocket() {
    this.ws = new WebSocket(this.serverConfig.wsUrl!);

    this.ws.onopen = () => {
      console.log('[PythonBackend] WebSocket connected');
    };

    this.ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'frame') {
        // Resolve pending frame request
        const pending = this.frameQueue.get(data.metadata.seed || 0);
        if (pending) {
          pending(data);
          this.frameQueue.delete(data.metadata.seed || 0);
        }
      }
    };

    this.ws.onerror = (err) => {
      console.error('[PythonBackend] WebSocket error:', err);
    };
  }

  async generateFrame(
    previousLatents: Float32Array[],
    action: number,
    seed?: number
  ): Promise<{ latent: Float32Array; pngBytes?: Uint8Array; metadata?: any }> {
    const s = seed ?? this.frameCounter++;

    // Encode previous frame as base64 if available
    let previousB64: string | undefined;
    if (previousLatents.length > 0) {
      // In real implementation, we'd decode the latent to PNG first
      // For now, we assume the server handles latent conditioning
      previousB64 = undefined;
    }

    // Use WebSocket if available, otherwise HTTP
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      return this.generateViaWebSocket(action, previousB64, s);
    } else {
      return this.generateViaHTTP(action, previousB64, s);
    }
  }

  private generateViaWebSocket(
    action: number,
    previousB64: string | undefined,
    seed: number
  ): Promise<{ latent: Float32Array; pngBytes?: Uint8Array; metadata?: any }> {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.frameQueue.delete(seed);
        reject(new Error('WebSocket frame generation timeout'));
      }, this.serverConfig.timeout);

      this.frameQueue.set(seed, (data) => {
        clearTimeout(timeout);
        const pngBytes = previousB64
          ? Uint8Array.from(atob(data.frame_b64), c => c.charCodeAt(0))
          : undefined;
        resolve({
          latent: new Float32Array(4 * 32 * 32), // Placeholder — server returns PNG
          pngBytes,
          metadata: data.metadata,
        });
      });

      this.ws!.send(JSON.stringify({
        action,
        previous_frame: previousB64,
        seed,
      }));
    });
  }

  private async generateViaHTTP(
    action: number,
    previousB64: string | undefined,
    seed: number
  ): Promise<{ latent: Float32Array; pngBytes?: Uint8Array; metadata?: any }> {
    const response = await fetch(`${this.serverConfig.baseUrl}/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action,
        previous_frame_b64: previousB64,
        seed,
        num_steps: this.config.numInferenceSteps,
      }),
    });

    const data = await response.json();
    const pngBytes = Uint8Array.from(atob(data.frame_b64), c => c.charCodeAt(0));

    return {
      latent: new Float32Array(4 * 32 * 32),
      pngBytes,
      metadata: data.metadata,
    };
  }

  async encodeImage(pixels: Uint8Array): Promise<Float32Array> {
    // Send to Python server for VAE encoding
    const response = await fetch(`${this.serverConfig.baseUrl}/encode`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/octet-stream' },
      body: pixels,
    });
    const data = await response.json();
    return new Float32Array(data.latent);
  }

  async decodeLatent(latent: Float32Array): Promise<Uint8Array> {
    // Send to Python server for VAE decoding
    const response = await fetch(`${this.serverConfig.baseUrl}/decode`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ latent: Array.from(latent) }),
    });
    const data = await response.json();
    return Uint8Array.from(atob(data.png_b64), c => c.charCodeAt(0));
  }

  async dispose(): Promise<void> {
    if (this.ws) {
      this.ws.close();
    }
    this.isLoaded = false;
  }
}

// ═══════════════════════════════════════════════════════════
// MOCK BACKEND (for testing without Python server)
// ═══════════════════════════════════════════════════════════

class MockDiffusionBackend extends DiffusionModelBackend {
  constructor(config: DiffusionModelConfig) {
    super(config);
  }

  async load(): Promise<void> {
    console.log('[MockDiffusion] No real diffusion model loaded');
    console.log('[MockDiffusion] To use real gameNgen:');
    console.log('  1. pip install torch diffusers transformers fastapi uvicorn');
    console.log('  2. python gamengen_server.py --model arnaudstiegler/sd-model-gameNgen-60ksteps');
    console.log('  3. Use PythonDiffusionBackend instead of MockDiffusionBackend');
    this.isLoaded = true;
  }

  async generateFrame(
    previousLatents: Float32Array[],
    action: number,
    seed?: number
  ): Promise<{ latent: Float32Array; pngBytes?: Uint8Array; metadata?: any }> {
    const size = 4 * 64 * 64;
    const latent = new Float32Array(size);
    const s = seed ?? Math.random() * 10000;
    for (let i = 0; i < size; i++) {
      latent[i] = Math.sin(i * 0.01 + action + s) * 0.5;
    }

    return {
      latent,
      metadata: {
        action: ['NOOP','MOVE_FORWARD','MOVE_BACKWARD','TURN_LEFT','TURN_RIGHT','ATTACK','USE','JUMP'][action] || 'UNKNOWN',
        generation_time_ms: 50,
        device: 'mock',
        note: 'This is a MOCK. No real diffusion model is running.'
      }
    };
  }

  async encodeImage(pixels: Uint8Array): Promise<Float32Array> {
    const size = 4 * 64 * 64;
    const latent = new Float32Array(size);
    for (let i = 0; i < size && i < pixels.length; i++) {
      latent[i] = pixels[i] / 255.0;
    }
    return latent;
  }

  async decodeLatent(latent: Float32Array): Promise<Uint8Array> {
    const pixels = new Uint8Array(latent.length);
    for (let i = 0; i < latent.length; i++) {
      pixels[i] = Math.min(255, Math.max(0, (latent[i] + 1) * 127.5));
    }
    return pixels;
  }

  async dispose(): Promise<void> {
    this.isLoaded = false;
  }
}

// ═══════════════════════════════════════════════════════════
// ONNX BACKEND (stub — for future in-browser inference)
// ═══════════════════════════════════════════════════════════

class ONNXDiffusionBackend extends DiffusionModelBackend {
  private session: any;

  constructor(config: DiffusionModelConfig) {
    super(config);
  }

  async load(): Promise<void> {
    // Requires onnxruntime-web or onnxruntime-node
    // const ort = await import('onnxruntime-web');
    // this.session = await ort.InferenceSession.create(this.config.modelPath);
    console.log('[ONNXBackend] Stub — requires ONNX Runtime + converted model weights');
    console.log('[ONNXBackend] To use:');
    console.log('  1. Convert PyTorch model to ONNX: torch.onnx.export()');
    console.log('  2. Install: npm install onnxruntime-web');
    console.log('  3. Load: await InferenceSession.create("model.onnx")');
    this.isLoaded = true;
  }

  async generateFrame(previousLatents: Float32Array[], action: number, seed?: number): Promise<any> {
    throw new Error('ONNX backend requires converted model weights');
  }

  async encodeImage(pixels: Uint8Array): Promise<Float32Array> {
    throw new Error('ONNX backend requires converted model weights');
  }

  async decodeLatent(latent: Float32Array): Promise<Uint8Array> {
    throw new Error('ONNX backend requires converted model weights');
  }

  async dispose(): Promise<void> {
    this.isLoaded = false;
  }
}

// ═══════════════════════════════════════════════════════════
// GameNGen Engine (unchanged core logic)
// ═══════════════════════════════════════════════════════════

class GameNGenEngine {
  private backend: DiffusionModelBackend;
  private frameBuffer: FrameBuffer;
  private engine: IngestGapFillEngine;

  private actionSpace: Map<number, string> = new Map([
    [0, 'NOOP'], [1, 'MOVE_FORWARD'], [2, 'MOVE_BACKWARD'],
    [3, 'TURN_LEFT'], [4, 'TURN_RIGHT'], [5, 'ATTACK'],
    [6, 'USE'], [7, 'JUMP'],
  ]);

  private semanticActionMap: Map<string, number> = new Map();

  constructor(backend: DiffusionModelBackend, engine: IngestGapFillEngine) {
    this.backend = backend;
    this.engine = engine;
    this.frameBuffer = { frames: [], maxSize: 1000, contextWindow: 4 };
  }

  async initialize() {
    await this.backend.load();
    this.buildSemanticActionMap();
  }

  private buildSemanticActionMap() {
    this.semanticActionMap.set('move', 1);
    this.semanticActionMap.set('go', 1);
    this.semanticActionMap.set('advance', 1);
    this.semanticActionMap.set('retreat', 2);
    this.semanticActionMap.set('back', 2);
    this.semanticActionMap.set('left', 3);
    this.semanticActionMap.set('turn_left', 3);
    this.semanticActionMap.set('right', 4);
    this.semanticActionMap.set('turn_right', 4);
    this.semanticActionMap.set('attack', 5);
    this.semanticActionMap.set('shoot', 5);
    this.semanticActionMap.set('fire', 5);
    this.semanticActionMap.set('use', 6);
    this.semanticActionMap.set('interact', 6);
    this.semanticActionMap.set('jump', 7);
    this.semanticActionMap.set('leap', 7);
  }

  async generateFrame(action: number, seed?: number): Promise<GameNGenFrame> {
    const previousLatents = this.frameBuffer.frames
      .slice(-this.frameBuffer.contextWindow)
      .map(f => f.latent);

    const result = await this.backend.generateFrame(previousLatents, action, seed);

    const frame: GameNGenFrame = {
      latent: result.latent,
      action,
      previousFrames: previousLatents.map((_, i) =>
        this.frameBuffer.frames[this.frameBuffer.frames.length - previousLatents.length + i]?.timestamp.toString() || ''
      ),
      timestamp: Date.now(),
      frameIndex: this.frameBuffer.frames.length,
      semanticOverlay: null,
      pngBytes: result.pngBytes,
      metadata: result.metadata,
    };

    this.frameBuffer.frames.push(frame);
    if (this.frameBuffer.frames.length > this.frameBuffer.maxSize) {
      this.frameBuffer.frames.shift();
    }

    return frame;
  }

  async autoregressiveRollout(
    actions: number[],
    onFrame?: (frame: GameNGenFrame, index: number) => void
  ): Promise<GameNGenFrame[]> {
    const rollout: GameNGenFrame[] = [];
    for (let i = 0; i < actions.length; i++) {
      const frame = await this.generateFrame(actions[i]);
      rollout.push(frame);
      if (onFrame) onFrame(frame, i);
    }
    return rollout;
  }

  async generateFromSemantic(node: SemanticNode): Promise<GameNGenFrame> {
    const action = this.semanticToAction(node);
    const frame = await this.generateFrame(action);
    frame.semanticOverlay = node;
    await this.ingestGeneratedFrame(frame, node);
    return frame;
  }

  private semanticToAction(node: SemanticNode): number {
    for (const [concept, action] of this.semanticActionMap) {
      if (node.label.toLowerCase().includes(concept)) return action;
    }
    for (const analogy of node.analogies) {
      for (const [source, target] of analogy.mapping) {
        if (source === node.id) {
          for (const [concept, action] of this.semanticActionMap) {
            if (target.toLowerCase().includes(concept)) return action;
          }
        }
      }
    }
    return 0;
  }

  private async ingestGeneratedFrame(frame: GameNGenFrame, node: SemanticNode) {
    const decoded = frame.pngBytes || await this.backend.decodeLatent(frame.latent);
    const signal: IngestedSignal = {
      id: `frame_${frame.timestamp}`,
      raw: decoded,
      mimeType: 'image/png',
      filename: `frame_${frame.frameIndex}.png`,
      size: decoded.length,
      timestamp: frame.timestamp,
      source: 'stream',
      metadata: {
        action: frame.action,
        actionName: this.actionSpace.get(frame.action),
        semanticNodeId: node.id,
        frameIndex: frame.frameIndex,
        generator: 'gameNGen',
        generationTimeMs: frame.metadata?.generation_time_ms,
      }
    };
    await this.engine.ingestFile(Buffer.from(decoded), signal.filename, signal.metadata);
  }

  async fillVisualGap(description: string, surroundingFrames: GameNGenFrame[] = []): Promise<GameNGenFrame> {
    const originalBuffer = [...this.frameBuffer.frames];
    this.frameBuffer.frames = [...surroundingFrames];
    const action = this.descriptionToAction(description);
    const frame = await this.generateFrame(action);
    this.frameBuffer.frames = originalBuffer;
    this.frameBuffer.frames.push(frame);
    return frame;
  }

  private descriptionToAction(description: string): number {
    const lower = description.toLowerCase();
    for (const [concept, action] of this.semanticActionMap) {
      if (lower.includes(concept)) return action;
    }
    return 0;
  }

  async dreamSequence(seedNode: SemanticNode | undefined, length: number = 16): Promise<GameNGenFrame[]> {
    const actions = this.sampleActionsFromNode(seedNode, length);
    return this.autoregressiveRollout(actions);
  }

  private sampleActionsFromNode(node: SemanticNode | undefined, count: number): number[] {
    const actions: number[] = [];
    const domainBias = new Map<string, number[]>();
    domainBias.set('graphics', [1, 3, 4]);
    domainBias.set('physics', [1, 2, 7]);
    domainBias.set('ui', [0, 6]);
    domainBias.set('network', [0, 1]);
    domainBias.set('ai', [0, 5, 6]);
    domainBias.set('audio', [0, 6]);

    const biases = node?.analogies.flatMap(a =>
      Array.from(a.mapping.keys()).flatMap(k => domainBias.get(k) || [0])
    ) || [];

    const effectiveBias = biases.length > 0 ? biases : [0, 1, 3, 4];
    for (let i = 0; i < count; i++) {
      actions.push(effectiveBias[Math.floor(Math.random() * effectiveBias.length)]);
    }
    return actions;
  }

  getFrameBuffer(): FrameBuffer {
    return { ...this.frameBuffer };
  }

  clearFrameBuffer() {
    this.frameBuffer.frames = [];
  }

  setContextWindow(size: number) {
    this.frameBuffer.contextWindow = size;
  }

  exportRollout(frames: GameNGenFrame[]): string {
    return JSON.stringify({
      frames: frames.map(f => ({
        action: f.action,
        actionName: this.actionSpace.get(f.action),
        timestamp: f.timestamp,
        frameIndex: f.frameIndex,
        semanticNodeId: f.semanticOverlay?.id,
        hasPng: !!f.pngBytes,
        latentShape: f.latent.length,
        metadata: f.metadata,
      })),
      metadata: {
        totalFrames: frames.length,
        duration: frames[frames.length - 1]?.timestamp - frames[0]?.timestamp,
        averageFPS: frames.length / ((frames[frames.length - 1]?.timestamp - frames[0]?.timestamp) / 1000 || 1),
      }
    }, null, 2);
  }
}

// ═══════════════════════════════════════════════════════════
// Exports
// ═══════════════════════════════════════════════════════════

export {
  GameNGenEngine,
  DiffusionModelBackend,
  DiffusionModelConfig,
  PythonDiffusionBackend,
  PythonServerConfig,
  MockDiffusionBackend,
  ONNXDiffusionBackend,
  GameNGenFrame,
  FrameBuffer,
};

export type { GameNGenFrame as Frame, FrameBuffer as Buffer };
