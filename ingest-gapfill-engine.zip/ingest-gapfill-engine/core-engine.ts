/**
 * ============================================================
 * INGEST & GAP-FILL ENGINE
 * Combining gameNgen (generative world-modeling) + Sheldon Klein
 * (meta-linguistic semantic inference, DISEMINER, analogy-based gap-filling)
 *
 * Dimensional Stack:
 *   D1 = Impulse (file ingestion, raw signal)
 *   D2 = Polarity (classification: what is this / what is it NOT)
 *   D3 = Witness/Observer-Node (the hinge — pattern recognition, analogy engine)
 *   D4 = Context (relational embedding, gap detection)
 *   D5 = Meaning (generative synthesis, gap filling, world-model output)
 *
 * Birth Sequence: HTML → Python → JSON → JS → CSS
 * Punctuation = Cosmic Geometry
 * Emergent Interference = 99% deterministic + 1% emergent surprise
 * ============================================================
 */

// ═══════════════════════════════════════════════════════════
// D1: IMPULSE — Raw Signal Ingestion
// ═══════════════════════════════════════════════════════════

interface IngestedSignal {
  id: string;
  raw: ArrayBuffer | string;
  mimeType: string;
  filename: string;
  size: number;
  timestamp: number;
  source: 'file' | 'url' | 'api' | 'stream' | 'git' | 'huggingface';
  metadata: Record<string, any>;
  // D1 is pure impulse — no interpretation yet
}

class ImpulseIngestor {
  private signalQueue: IngestedSignal[] = [];
  private observers: ((signal: IngestedSignal) => void)[] = [];

  async ingest(source: IngestedSignal['source'], payload: any, metadata: Record<string, any> = {}): Promise<IngestedSignal> {
    const signal: IngestedSignal = {
      id: `sig_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      raw: payload,
      mimeType: metadata.mimeType || this.inferMimeType(payload, metadata.filename),
      filename: metadata.filename || 'unknown',
      size: this.computeSize(payload),
      timestamp: Date.now(),
      source,
      metadata
    };
    this.signalQueue.push(signal);
    this.observers.forEach(cb => cb(signal));
    return signal;
  }

  private inferMimeType(payload: any, filename?: string): string {
    if (filename) {
      const ext = filename.split('.').pop()?.toLowerCase();
      const map: Record<string, string> = {
        ts: 'text/typescript', js: 'text/javascript', py: 'text/python',
        html: 'text/html', css: 'text/css', json: 'application/json',
        png: 'image/png', jpg: 'image/jpeg', mp3: 'audio/mpeg',
        mp4: 'video/mp4', gltf: 'model/gltf+json', obj: 'model/obj',
        md: 'text/markdown', yaml: 'text/yaml', xml: 'text/xml',
        wasm: 'application/wasm', shader: 'text/glsl'
      };
      if (ext && map[ext]) return map[ext];
    }
    if (typeof payload === 'string') return 'text/plain';
    if (payload instanceof ArrayBuffer) return 'application/octet-stream';
    return 'unknown';
  }

  private computeSize(payload: any): number {
    if (typeof payload === 'string') return payload.length;
    if (payload instanceof ArrayBuffer) return payload.byteLength;
    return 0;
  }

  onIngest(callback: (signal: IngestedSignal) => void) {
    this.observers.push(callback);
  }
}

// ═══════════════════════════════════════════════════════════
// D2: POLARITY — Classification Engine (What IS / What IS NOT)
// ═══════════════════════════════════════════════════════════

interface PolarityVector {
  signalId: string;
  // Binary dimensions — Klein's Boolean feature vectors
  isCode: boolean;
  isAsset: boolean;
  isConfig: boolean;
  isDocumentation: boolean;
  isExecutable: boolean;
  isData: boolean;
  // Language polarity
  language: string | null; // 'typescript', 'python', 'glsl', 'markdown', etc.
  // Structural polarity
  hasImports: boolean;
  hasExports: boolean;
  hasTypes: boolean;
  hasTests: boolean;
  hasComments: boolean;
  // Semantic polarity (what it does vs what it doesn't)
  functionalDomain: string[]; // ['graphics', 'audio', 'physics', 'ui', 'network', 'ai']
  // Confidence
  confidence: number; // 0-1
}

class PolarityClassifier {
  private featureExtractors: Map<string, (content: string) => Partial<PolarityVector>>;

  constructor() {
    this.featureExtractors = new Map();
    this.registerDefaultExtractors();
  }

  private registerDefaultExtractors() {
    // TypeScript/JavaScript detector
    this.featureExtractors.set('typescript', (content) => ({
      isCode: true,
      language: 'typescript',
      hasImports: /import\s+/.test(content),
      hasExports: /export\s+/.test(content),
      hasTypes: /interface|type\s+|:\s+(string|number|boolean|any)/.test(content),
      hasTests: /describe|it\(|test\(/.test(content),
      functionalDomain: this.inferDomain(content)
    }));

    // Python detector
    this.featureExtractors.set('python', (content) => ({
      isCode: true,
      language: 'python',
      hasImports: /import\s+|from\s+/.test(content),
      hasExports: /def\s+|class\s+/.test(content),
      hasTypes: /:\s+(str|int|float|bool|List|Dict|Optional)/.test(content),
      hasTests: /def test_|import unittest|import pytest/.test(content),
      functionalDomain: this.inferDomain(content)
    }));

    // HTML detector
    this.featureExtractors.set('html', (content) => ({
      isCode: true,
      language: 'html',
      hasImports: /<script/.test(content) || /<link/.test(content),
      hasExports: false,
      hasTypes: false,
      hasTests: false,
      functionalDomain: ['ui', 'structure']
    }));

    // CSS detector
    this.featureExtractors.set('css', (content) => ({
      isCode: true,
      language: 'css',
      hasImports: /@import/.test(content),
      hasExports: false,
      hasTypes: false,
      hasTests: false,
      functionalDomain: ['ui', 'visual', 'space']
    }));

    // JSON detector
    this.featureExtractors.set('json', (content) => ({
      isConfig: true,
      language: 'json',
      hasImports: false,
      hasExports: false,
      hasTypes: false,
      hasTests: false,
      functionalDomain: ['configuration', 'data']
    }));

    // Markdown detector
    this.featureExtractors.set('markdown', (content) => ({
      isDocumentation: true,
      language: 'markdown',
      hasImports: false,
      hasExports: false,
      hasTypes: false,
      hasTests: false,
      functionalDomain: ['documentation', 'knowledge']
    }));

    // Image detector
    this.featureExtractors.set('image', (content) => ({
      isAsset: true,
      language: null,
      hasImports: false,
      hasExports: false,
      hasTypes: false,
      hasTests: false,
      functionalDomain: ['visual', 'texture', 'sprite']
    }));

    // Audio detector
    this.featureExtractors.set('audio', (content) => ({
      isAsset: true,
      language: null,
      hasImports: false,
      hasExports: false,
      hasTypes: false,
      hasTests: false,
      functionalDomain: ['audio', 'sound', 'music']
    }));

    // 3D Model detector
    this.featureExtractors.set('model', (content) => ({
      isAsset: true,
      language: null,
      hasImports: false,
      hasExports: false,
      hasTypes: false,
      hasTests: false,
      functionalDomain: ['3d', 'mesh', 'geometry']
    }));
  }

  private inferDomain(content: string): string[] {
    const domains: string[] = [];
    const patterns: Record<string, RegExp> = {
      graphics: /canvas|webgl|gl|shader|texture|sprite|render|draw|pixel|vertex/,
      audio: /audio|sound|music|oscillator|waveform|frequency/,
      physics: /physics|collision|rigidbody|gravity|velocity|force/,
      ui: /dom|element|component|button|input|modal|overlay|css/,
      network: /fetch|websocket|http|api|request|socket|server/,
      ai: /neural|network|model|inference|tensor|embedding|diffusion|llm/
    };
    for (const [domain, pattern] of Object.entries(patterns)) {
      if (pattern.test(content.toLowerCase())) domains.push(domain);
    }
    return domains;
  }

  classify(signal: IngestedSignal): PolarityVector {
    const content = typeof signal.raw === 'string' ? signal.raw : '';
    const mimeBase = signal.mimeType.split('/')[0];
    const ext = signal.filename.split('.').pop()?.toLowerCase() || '';

    let extractor: ((content: string) => Partial<PolarityVector>) | undefined;

    // Map mime/extension to extractor
    const langMap: Record<string, string> = {
      ts: 'typescript', js: 'typescript', tsx: 'typescript', jsx: 'typescript',
      py: 'python', html: 'html', css: 'css',
      json: 'json', md: 'markdown', yaml: 'json', yml: 'json',
      png: 'image', jpg: 'image', jpeg: 'image', gif: 'image', webp: 'image',
      mp3: 'audio', wav: 'audio', ogg: 'audio',
      gltf: 'model', obj: 'model', fbx: 'model'
    };

    extractor = this.featureExtractors.get(langMap[ext] || mimeBase);

    const extracted = extractor ? extractor(content) : {
      isCode: false, isAsset: false, isConfig: false,
      isDocumentation: false, isExecutable: false, isData: false,
      language: null, hasImports: false, hasExports: false,
      hasTypes: false, hasTests: false, hasComments: false,
      functionalDomain: [], confidence: 0.5
    };

    return {
      signalId: signal.id,
      isCode: extracted.isCode ?? false,
      isAsset: extracted.isAsset ?? false,
      isConfig: extracted.isConfig ?? false,
      isDocumentation: extracted.isDocumentation ?? false,
      isExecutable: extracted.isExecutable ?? false,
      isData: extracted.isData ?? false,
      language: extracted.language ?? null,
      hasImports: extracted.hasImports ?? false,
      hasExports: extracted.hasExports ?? false,
      hasTypes: extracted.hasTypes ?? false,
      hasTests: extracted.hasTests ?? false,
      hasComments: /\/\/|\/\*|#|<!--/.test(content),
      functionalDomain: extracted.functionalDomain ?? [],
      confidence: 0.85
    };
  }
}

// ═══════════════════════════════════════════════════════════
// D3: WITNESS / OBSERVER-NODE — The Hinge (Pattern Recognition + Analogy)
// ═══════════════════════════════════════════════════════════

// Klein's key insight: analogy is the foundation of creativity
// Boolean feature vectors enable bi-directional inheritance
// Relations can be logical operators

interface SemanticNode {
  id: string;
  // Klein-style: objects are atoms or classes, or contain relational structures
  type: 'atom' | 'class' | 'relation' | 'script' | 'operator';
  features: boolean[]; // Boolean feature vector
  label: string;
  // Relations to other nodes
  relations: Map<string, string[]>; // relationType -> nodeIds
  // Analogical mappings (this is the creative engine)
  analogies: AnalogyMapping[];
  // Depth in the semantic network
  depth: number;
}

interface AnalogyMapping {
  sourceDomain: string; // e.g., "game engine"
  targetDomain: string; // e.g., "biological system"
  mapping: Map<string, string>; // sourceNode -> targetNode
  strength: number; // 0-1, how strong the analogy
  confidence: number;
}

class WitnessEngine {
  private semanticNetwork: Map<string, SemanticNode> = new Map();
  private analogyGraph: AnalogyMapping[] = [];
  private featureDimension: number = 128; // Boolean vector size

  constructor() {
    this.seedBaseOntology();
  }

  private seedBaseOntology() {
    // Seed the network with fundamental game development concepts
    // These are Klein-style "atoms" with Boolean feature vectors
    const concepts = [
      { id: 'engine', label: 'Game Engine', type: 'class' as const, features: this.randomFeatures() },
      { id: 'renderer', label: 'Renderer', type: 'class' as const, features: this.randomFeatures() },
      { id: 'physics', label: 'Physics System', type: 'class' as const, features: this.randomFeatures() },
      { id: 'audio', label: 'Audio System', type: 'class' as const, features: this.randomFeatures() },
      { id: 'input', label: 'Input Handler', type: 'class' as const, features: this.randomFeatures() },
      { id: 'ai', label: 'AI System', type: 'class' as const, features: this.randomFeatures() },
      { id: 'asset', label: 'Asset Manager', type: 'class' as const, features: this.randomFeatures() },
      { id: 'network', label: 'Network Layer', type: 'class' as const, features: this.randomFeatures() },
      { id: 'ui', label: 'UI System', type: 'class' as const, features: this.randomFeatures() },
      { id: 'scene', label: 'Scene Graph', type: 'class' as const, features: this.randomFeatures() },
      // gameNgen specific
      { id: 'diffusion', label: 'Diffusion Model', type: 'class' as const, features: this.randomFeatures() },
      { id: 'framegen', label: 'Frame Generator', type: 'class' as const, features: this.randomFeatures() },
      { id: 'autoregressive', label: 'Autoregressive Rollout', type: 'class' as const, features: this.randomFeatures() },
      // Klein/DISEMINER specific
      { id: 'diseMiner', label: 'DISEMINER', type: 'class' as const, features: this.randomFeatures() },
      { id: 'analogy', label: 'Analogy Engine', type: 'operator' as const, features: this.randomFeatures() },
      { id: 'metalinguistic', label: 'Meta-linguistic System', type: 'class' as const, features: this.randomFeatures() },
      { id: 'narrative', label: 'Narrative Generator', type: 'class' as const, features: this.randomFeatures() },
    ];

    for (const c of concepts) {
      this.semanticNetwork.set(c.id, {
        id: c.id,
        type: c.type,
        features: c.features,
        label: c.label,
        relations: new Map(),
        analogies: [],
        depth: 0
      });
    }

    // Establish base relations (Klein: relations can be logical operators)
    this.addRelation('engine', 'contains', 'renderer');
    this.addRelation('engine', 'contains', 'physics');
    this.addRelation('engine', 'contains', 'audio');
    this.addRelation('engine', 'contains', 'input');
    this.addRelation('engine', 'contains', 'ai');
    this.addRelation('engine', 'contains', 'asset');
    this.addRelation('engine', 'contains', 'network');
    this.addRelation('engine', 'contains', 'ui');
    this.addRelation('engine', 'contains', 'scene');
    this.addRelation('diffusion', 'generates', 'framegen');
    this.addRelation('framegen', 'uses', 'autoregressive');
    this.addRelation('diseMiner', 'uses', 'analogy');
    this.addRelation('diseMiner', 'uses', 'metalinguistic');
    this.addRelation('narrative', 'powered_by', 'diseMiner');

    // Seed analogies (Klein's analogical foundations of creativity)
    this.addAnalogy({
      sourceDomain: 'game engine',
      targetDomain: 'biological system',
      mapping: new Map([
        ['renderer', 'visual cortex'],
        ['physics', 'motor system'],
        ['audio', 'auditory cortex'],
        ['input', 'sensory nerves'],
        ['ai', 'prefrontal cortex'],
        ['network', 'synaptic connections'],
        ['scene', 'hippocampus (spatial memory)']
      ]),
      strength: 0.78,
      confidence: 0.82
    });

    this.addAnalogy({
      sourceDomain: 'diffusion model',
      targetDomain: 'dream generation',
      mapping: new Map([
        ['diffusion', 'REM sleep'],
        ['framegen', 'visual imagery'],
        ['autoregressive', 'narrative continuity'],
        ['action_conditioning', 'intention/memory']
      ]),
      strength: 0.85,
      confidence: 0.75
    });

    this.addAnalogy({
      sourceDomain: 'DISEMINER',
      targetDomain: 'folk tale structure',
      mapping: new Map([
        ['diseMiner', 'Proppian functions'],
        ['analogy', 'morphological equivalence'],
        ['metalinguistic', 'universal grammar'],
        ['narrative', 'myth generation']
      ]),
      strength: 0.91,
      confidence: 0.88
    });
  }

  private randomFeatures(): boolean[] {
    return Array.from({ length: this.featureDimension }, () => Math.random() > 0.5);
  }

  private addRelation(fromId: string, relationType: string, toId: string) {
    const from = this.semanticNetwork.get(fromId);
    if (from) {
      const existing = from.relations.get(relationType) || [];
      existing.push(toId);
      from.relations.set(relationType, existing);
    }
  }

  private addAnalogy(analogy: AnalogyMapping) {
    this.analogyGraph.push(analogy);
    // Apply analogy to nodes
    for (const [sourceId, targetId] of analogy.mapping) {
      const sourceNode = this.semanticNetwork.get(sourceId);
      if (sourceNode) {
        sourceNode.analogies.push(analogy);
      }
    }
  }

  // The core witness function: observe a polarity vector and place it in semantic space
  observe(polarity: PolarityVector, signal: IngestedSignal): SemanticNode {
    // Generate a feature vector from the polarity
    const features = this.polarityToFeatures(polarity);

    const node: SemanticNode = {
      id: `node_${signal.id}`,
      type: polarity.isCode ? 'class' : polarity.isAsset ? 'atom' : 'relation',
      features,
      label: signal.filename,
      relations: new Map(),
      analogies: [],
      depth: 1
    };

    // Find the nearest neighbors in semantic space (Klein-style analogy)
    const neighbors = this.findNearestNeighbors(node, 5);

    // Establish relations based on functional domain overlap
    for (const neighbor of neighbors) {
      const overlap = this.computeDomainOverlap(polarity.functionalDomain, neighbor);
      if (overlap > 0.5) {
        this.addRelation(node.id, 'related_to', neighbor.id);
        this.addRelation(neighbor.id, 'has_neighbor', node.id);
      }
    }

    this.semanticNetwork.set(node.id, node);
    return node;
  }

  private polarityToFeatures(polarity: PolarityVector): boolean[] {
    // Convert polarity into a Boolean feature vector (Klein-style)
    const features = new Array(this.featureDimension).fill(false);
    // Encode binary properties into the first 16 features
    features[0] = polarity.isCode;
    features[1] = polarity.isAsset;
    features[2] = polarity.isConfig;
    features[3] = polarity.isDocumentation;
    features[4] = polarity.isExecutable;
    features[5] = polarity.isData;
    features[6] = polarity.hasImports;
    features[7] = polarity.hasExports;
    features[8] = polarity.hasTypes;
    features[9] = polarity.hasTests;
    features[10] = polarity.hasComments;
    // Encode functional domain (bits 16-32)
    const domains = ['graphics', 'audio', 'physics', 'ui', 'network', 'ai'];
    for (let i = 0; i < domains.length; i++) {
      features[16 + i] = polarity.functionalDomain.includes(domains[i]);
    }
    // Hash the language into remaining bits
    if (polarity.language) {
      const hash = this.simpleHash(polarity.language);
      for (let i = 0; i < 32; i++) {
        features[32 + i] = (hash & (1 << i)) !== 0;
      }
    }
    return features;
  }

  private simpleHash(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash);
  }

  private findNearestNeighbors(node: SemanticNode, k: number): SemanticNode[] {
    const allNodes = Array.from(this.semanticNetwork.values());
    const scored = allNodes.map(n => ({
      node: n,
      similarity: this.hammingSimilarity(node.features, n.features)
    }));
    scored.sort((a, b) => b.similarity - a.similarity);
    return scored.slice(0, k).map(s => s.node);
  }

  private hammingSimilarity(a: boolean[], b: boolean[]): number {
    let matches = 0;
    for (let i = 0; i < Math.min(a.length, b.length); i++) {
      if (a[i] === b[i]) matches++;
    }
    return matches / Math.max(a.length, b.length);
  }

  private computeDomainOverlap(domains: string[], node: SemanticNode): number {
    // Infer domains from node's label and analogies
    const nodeDomains = new Set<string>();
    node.analogies.forEach(a => {
      a.mapping.forEach((_, source) => {
        if (source.includes('graphics') || source.includes('render')) nodeDomains.add('graphics');
        if (source.includes('audio') || source.includes('sound')) nodeDomains.add('audio');
        if (source.includes('physics')) nodeDomains.add('physics');
        if (source.includes('ui') || source.includes('interface')) nodeDomains.add('ui');
        if (source.includes('network') || source.includes('socket')) nodeDomains.add('network');
        if (source.includes('ai') || source.includes('neural')) nodeDomains.add('ai');
      });
    });

    const overlap = domains.filter(d => nodeDomains.has(d)).length;
    return overlap / Math.max(domains.length, nodeDomains.size, 1);
  }

  // Klein's key: analogy-driven inference
  inferByAnalogy(nodeId: string, targetDomain: string): AnalogyMapping | null {
    const node = this.semanticNetwork.get(nodeId);
    if (!node) return null;

    // Find analogies that map from this node's domain to the target domain
    const relevant = this.analogyGraph.filter(a =>
      a.mapping.has(nodeId) && a.targetDomain === targetDomain
    );

    if (relevant.length === 0) return null;
    return relevant.reduce((best, current) =>
      current.strength > best.strength ? current : best
    );
  }

  getNetwork(): Map<string, SemanticNode> {
    return this.semanticNetwork;
  }

  getAnalogies(): AnalogyMapping[] {
    return this.analogyGraph;
  }
}

// ═══════════════════════════════════════════════════════════
// D4: CONTEXT — Relational Embedding & Gap Detection
// ═══════════════════════════════════════════════════════════

interface GapReport {
  nodeId: string;
  gapType: 'missing_dependency' | 'missing_type' | 'missing_test' | 'missing_doc' |
           'missing_config' | 'missing_asset' | 'missing_implementation' | 'semantic_incoherence';
  severity: 'critical' | 'warning' | 'info';
  description: string;
  suggestedFill: string; // What should be generated
  confidence: number;
  // Contextual relations that reveal the gap
  relatedNodes: string[];
  // The analogy that suggested this gap (if any)
  triggeringAnalogy?: AnalogyMapping;
}

interface ContextField {
  nodeId: string;
  // Relational calculus (Klein: semantic structures as relational calculus)
  incomingRelations: Map<string, string[]>; // relationType -> fromNodeIds
  outgoingRelations: Map<string, string[]>; // relationType -> toNodeIds
  // Embedding in the semantic network
  depth: number;
  // Coherence score
  coherence: number; // 0-1, how well this node fits its context
}

class ContextEngine {
  private witness: WitnessEngine;
  private contextFields: Map<string, ContextField> = new Map();

  // gameNgen-inspired: what frames are needed for continuity
  private frameBuffer: SemanticNode[] = [];
  private maxFrameBuffer: number = 8;

  constructor(witness: WitnessEngine) {
    this.witness = witness;
  }

  buildContext(nodeId: string): ContextField {
    const network = this.witness.getNetwork();
    const node = network.get(nodeId);
    if (!node) throw new Error(`Node ${nodeId} not found`);

    const incoming = new Map<string, string[]>();
    const outgoing = new Map<string, string[]>();

    // Scan all nodes for relations involving this node
    for (const [id, n] of network) {
      for (const [relType, targets] of n.relations) {
        if (targets.includes(nodeId)) {
          const existing = incoming.get(relType) || [];
          existing.push(id);
          incoming.set(relType, existing);
        }
      }
      if (id === nodeId) {
        for (const [relType, targets] of n.relations) {
          outgoing.set(relType, [...targets]);
        }
      }
    }

    // Compute coherence: how well connected is this node?
    const totalPossible = network.size - 1;
    const actualConnections = Array.from(incoming.values()).flat().length +
                              Array.from(outgoing.values()).flat().length;
    const coherence = totalPossible > 0 ? actualConnections / Math.sqrt(totalPossible) : 1;

    const field: ContextField = {
      nodeId,
      incomingRelations: incoming,
      outgoingRelations: outgoing,
      depth: node.depth,
      coherence: Math.min(coherence, 1)
    };

    this.contextFields.set(nodeId, field);
    this.updateFrameBuffer(node);
    return field;
  }

  private updateFrameBuffer(node: SemanticNode) {
    this.frameBuffer.push(node);
    if (this.frameBuffer.length > this.maxFrameBuffer) {
      this.frameBuffer.shift();
    }
  }

  // The core gap detection: what is missing from this context?
  detectGaps(nodeId: string): GapReport[] {
    const network = this.witness.getNetwork();
    const node = network.get(nodeId);
    const context = this.contextFields.get(nodeId);
    if (!node || !context) return [];

    const gaps: GapReport[] = [];

    // 1. Missing dependencies (if code has imports but no corresponding files)
    if (node.type === 'class' && !context.incomingRelations.has('implemented_by')) {
      const hasImports = node.features[6]; // hasImports encoded in feature vector
      if (hasImports) {
        gaps.push({
          nodeId,
          gapType: 'missing_dependency',
          severity: 'critical',
          description: `Node ${node.label} has imports but no resolved dependencies in the network`,
          suggestedFill: 'Generate or locate missing import modules',
          confidence: 0.9,
          relatedNodes: Array.from(context.outgoingRelations.get('related_to') || [])
        });
      }
    }

    // 2. Missing tests (if code but no test relation)
    const hasTests = node.features[9];
    if (node.type === 'class' && !hasTests) {
      gaps.push({
        nodeId,
        gapType: 'missing_test',
        severity: 'warning',
        description: `Node ${node.label} lacks test coverage`,
        suggestedFill: 'Generate test suite based on functional domain and exports',
        confidence: 0.75,
        relatedNodes: Array.from(context.outgoingRelations.get('related_to') || [])
      });
    }

    // 3. Missing documentation (if code but no doc relation)
    const hasComments = node.features[10];
    if (node.type === 'class' && !hasComments) {
      gaps.push({
        nodeId,
        gapType: 'missing_doc',
        severity: 'info',
        description: `Node ${node.label} lacks documentation`,
        suggestedFill: 'Generate README/API docs from code analysis',
        confidence: 0.8,
        relatedNodes: Array.from(context.outgoingRelations.get('related_to') || [])
      });
    }

    // 4. Semantic incoherence (low coherence score)
    if (context.coherence < 0.3) {
      gaps.push({
        nodeId,
        gapType: 'semantic_incoherence',
        severity: 'warning',
        description: `Node ${node.label} is poorly connected to the semantic network`,
        suggestedFill: 'Find or create bridging nodes to integrate this component',
        confidence: 0.7,
        relatedNodes: Array.from(context.outgoingRelations.get('related_to') || [])
      });
    }

    // 5. Analogy-driven gaps (Klein's creative inference)
    // If this node has an analogy to a well-structured domain, what's missing?
    for (const analogy of node.analogies) {
      const mappedTarget = analogy.mapping.get(nodeId);
      if (mappedTarget) {
        // Check if the target domain's expected relations exist
        const targetNode = network.get(mappedTarget);
        if (targetNode) {
          for (const [relType, targets] of targetNode.relations) {
            const hasEquivalent = Array.from(node.relations.keys()).some(
              k => k.includes(relType) || relType.includes(k)
            );
            if (!hasEquivalent) {
              gaps.push({
                nodeId,
                gapType: 'missing_implementation',
                severity: 'warning',
                description: `Analogy to ${analogy.targetDomain} suggests missing ${relType} relation`,
                suggestedFill: `Implement ${relType} capability based on ${mappedTarget} pattern`,
                confidence: analogy.strength * analogy.confidence,
                relatedNodes: [mappedTarget],
                triggeringAnalogy: analogy
              });
            }
          }
        }
      }
    }

    // 6. gameNgen-inspired: frame continuity gaps
    // If this is part of a sequence, are there missing frames?
    if (this.frameBuffer.length >= 2) {
      const lastFrame = this.frameBuffer[this.frameBuffer.length - 2];
      const continuity = this.hammingSimilarity(node.features, lastFrame.features);
      if (continuity < 0.3 && continuity > 0) {
        // Sudden jump — possible missing intermediate
        gaps.push({
          nodeId,
          gapType: 'missing_implementation',
          severity: 'info',
          description: `Semantic discontinuity detected between ${lastFrame.label} and ${node.label}`,
          suggestedFill: 'Generate intermediate abstraction layer or adapter',
          confidence: 0.6,
          relatedNodes: [lastFrame.id]
        });
      }
    }

    return gaps;
  }

  private hammingSimilarity(a: boolean[], b: boolean[]): number {
    let matches = 0;
    for (let i = 0; i < Math.min(a.length, b.length); i++) {
      if (a[i] === b[i]) matches++;
    }
    return matches / Math.max(a.length, b.length);
  }

  getFrameBuffer(): SemanticNode[] {
    return [...this.frameBuffer];
  }
}

// ═══════════════════════════════════════════════════════════
// D5: MEANING — Generative Synthesis & Gap Filling
// ═══════════════════════════════════════════════════════════

interface GeneratedArtifact {
  id: string;
  // What gap this fills
  fillsGap: GapReport;
  // The generated content
  content: string;
  // Metadata about generation
  generator: 'template' | 'analogy' | 'diffusion' | 'llm' | 'hybrid';
  // Quality metrics
  coherence: number;
  novelty: number; // How new is this vs existing network
  // gameNgen: this is a "frame" in the autoregressive rollout
  isFrame: boolean;
  frameIndex?: number;
}

interface WorldModel {
  // The complete generated understanding of the ingested system
  nodes: SemanticNode[];
  gaps: GapReport[];
  filled: GeneratedArtifact[];
  // The "game" that emerges from this world model
  // gameNgen: the diffusion model IS the game
  emergentProperties: Map<string, any>;
}

class MeaningSynthesizer {
  private witness: WitnessEngine;
  private context: ContextEngine;
  private generationLog: GeneratedArtifact[] = [];

  // Template library for gap filling (Klein: script-like world knowledge rules)
  private templates: Map<string, (gap: GapReport, context: ContextField) => string>;

  constructor(witness: WitnessEngine, context: ContextEngine) {
    this.witness = witness;
    this.context = context;
    this.templates = new Map();
    this.registerTemplates();
  }

  private registerTemplates() {
    // Missing dependency template
    this.templates.set('missing_dependency', (gap, ctx) => {
      const node = this.witness.getNetwork().get(gap.nodeId);
      const imports = this.extractImports(node?.label || '');
      return `// AUTO-GENERATED: Dependency Resolution for ${node?.label}
// Detected missing imports: ${imports.join(', ')}
// Generated by Ingest-GapFill Engine (D5 Meaning Synthesis)

${imports.map(imp => `import { ${imp} } from './${imp.toLowerCase()}';`).join('\n')}

// TODO: Implement actual module logic based on functional domain: ${node?.relations.get('related_to')?.join(', ')}
`;
    });

    // Missing test template
    this.templates.set('missing_test', (gap, ctx) => {
      const node = this.witness.getNetwork().get(gap.nodeId);
      return `// AUTO-GENERATED: Test Suite for ${node?.label}
// Generated by Ingest-GapFill Engine (D5 Meaning Synthesis)

describe('${node?.label}', () => {
  it('should initialize correctly', () => {
    const instance = new ${node?.label?.split('.')[0]?.replace(/\.[^.]+$/, '') || 'Component'}();
    expect(instance).toBeDefined();
  });

  it('should handle core functionality', () => {
    // TODO: Implement domain-specific test based on: ${node?.relations.get('related_to')?.join(', ')}
  });
});
`;
    });

    // Missing doc template
    this.templates.set('missing_doc', (gap, ctx) => {
      const node = this.witness.getNetwork().get(gap.nodeId);
      return `# ${node?.label}

## Overview
Auto-generated documentation for ${node?.label}.

## Functional Domain
${node?.relations.get('related_to')?.join(', ') || 'General purpose'}

## Dependencies
${Array.from(ctx.incomingRelations.keys()).join(', ') || 'None detected'}

## Usage
\`\`\`typescript
// TODO: Add usage example based on exports analysis
\`\`\`

---
*Generated by Ingest-GapFill Engine*
`;
    });

    // Missing implementation (analogy-driven)
    this.templates.set('missing_implementation', (gap, ctx) => {
      const analogy = gap.triggeringAnalogy;
      if (analogy) {
        return `// AUTO-GENERATED: Analogy-Driven Implementation
// Source Domain: ${analogy.sourceDomain}
// Target Domain: ${analogy.targetDomain}
// Mapping: ${Array.from(analogy.mapping.entries()).map(([k,v]) => `${k}→${v}`).join(', ')}
// Strength: ${analogy.strength}, Confidence: ${analogy.confidence}

// This implementation was generated by analogical inference from ${analogy.sourceDomain}
// to ${analogy.targetDomain}. The pattern from the source domain was mapped to
// fill the detected gap in the target domain.

// TODO: Review and refine this analogy-based implementation
class ${gap.nodeId.split('_').pop() || 'GeneratedComponent'} {
  // Analogical structure derived from ${analogy.sourceDomain}
  // Core pattern: ${Array.from(analogy.mapping.keys())[0] || 'unknown'}
}
`;
      }
      return `// AUTO-GENERATED: Implementation Stub
// Gap detected: ${gap.description}
// TODO: Implement based on context relations
`;
    });

    // Semantic incoherence template
    this.templates.set('semantic_incoherence', (gap, ctx) => {
      return `// AUTO-GENERATED: Bridge/Adapter
// This component bridges semantic gaps detected in the network
// Related nodes: ${gap.relatedNodes.join(', ')}

// Bridge pattern to connect disconnected components
export class SemanticBridge {
  constructor() {
    // Initializes connections between: ${gap.relatedNodes.join(' ↔ ')}
  }

  async reconcile() {
    // TODO: Implement reconciliation logic
  }
}
`;
    });
  }

  private extractImports(filename: string): string[] {
    // Simple heuristic: extract capitalized words as potential imports
    const matches = filename.match(/[A-Z][a-zA-Z]+/g) || [];
    return matches.filter(m => m.length > 2);
  }

  synthesize(gap: GapReport): GeneratedArtifact {
    const ctx = this.context.buildContext(gap.nodeId);
    const template = this.templates.get(gap.gapType);

    let content: string;
    let generator: GeneratedArtifact['generator'];

    if (template && gap.confidence > 0.5) {
      content = template(gap, ctx);
      generator = gap.triggeringAnalogy ? 'analogy' : 'template';
    } else {
      // Fallback: generate a generic stub
      content = `// AUTO-GENERATED: Generic Stub for ${gap.gapType}
// Description: ${gap.description}
// Confidence: ${gap.confidence}
// TODO: Manual implementation required
`;
      generator = 'template';
    }

    const artifact: GeneratedArtifact = {
      id: `gen_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      fillsGap: gap,
      content,
      generator,
      coherence: ctx.coherence,
      novelty: 1 - ctx.coherence, // Lower coherence = higher novelty needed
      isFrame: true,
      frameIndex: this.generationLog.length
    };

    this.generationLog.push(artifact);
    return artifact;
  }

  // gameNgen-style autoregressive generation: each frame conditions the next
  autoregressiveRollout(seedNodeId: string, steps: number): GeneratedArtifact[] {
    const rollout: GeneratedArtifact[] = [];
    let currentNodeId = seedNodeId;

    for (let i = 0; i < steps; i++) {
      // Build context for current node
      this.context.buildContext(currentNodeId);
      // Detect gaps
      const gaps = this.context.detectGaps(currentNodeId);
      // Filter to most critical
      const criticalGaps = gaps.filter(g => g.severity === 'critical');
      const targetGap = criticalGaps[0] || gaps[0];

      if (!targetGap) break;

      // Synthesize fill
      const artifact = this.synthesize(targetGap);
      artifact.frameIndex = i;
      rollout.push(artifact);

      // The generated artifact becomes the next seed (autoregressive)
      // In a full implementation, we'd parse the generated content and create a new node
      currentNodeId = targetGap.nodeId; // Simplified: continue from same node
    }

    return rollout;
  }

  // Build the complete world model from all ingested signals
  buildWorldModel(): WorldModel {
    const network = this.witness.getNetwork();
    const allNodes = Array.from(network.values());
    const allGaps: GapReport[] = [];
    const allFilled: GeneratedArtifact[] = [];

    for (const node of allNodes) {
      if (node.depth === 0) continue; // Skip base ontology
      this.context.buildContext(node.id);
      const gaps = this.context.detectGaps(node.id);
      allGaps.push(...gaps);

      for (const gap of gaps) {
        const artifact = this.synthesize(gap);
        allFilled.push(artifact);
      }
    }

    // Compute emergent properties
    const emergent = new Map<string, any>();
    emergent.set('totalNodes', allNodes.length);
    emergent.set('totalGaps', allGaps.length);
    emergent.set('totalFilled', allFilled.length);
    emergent.set('coverage', allGaps.length > 0 ? allFilled.length / allGaps.length : 1);
    emergent.set('analogiesUsed', allFilled.filter(a => a.generator === 'analogy').length);
    emergent.set('autoregressiveFrames', allFilled.filter(a => a.isFrame).length);

    return {
      nodes: allNodes,
      gaps: allGaps,
      filled: allFilled,
      emergentProperties: emergent
    };
  }

  getGenerationLog(): GeneratedArtifact[] {
    return this.generationLog;
  }
}

// ═══════════════════════════════════════════════════════════
// UNIVERSAL ENGINE ORCHESTRATOR
// ═══════════════════════════════════════════════════════════

export class IngestGapFillEngine {
  private impulse: ImpulseIngestor;
  private polarity: PolarityClassifier;
  private witness: WitnessEngine;
  private context: ContextEngine;
  private meaning: MeaningSynthesizer;

  // State
  private ingestedSignals: IngestedSignal[] = [];
  private worldModel: WorldModel | null = null;

  constructor() {
    this.impulse = new ImpulseIngestor();
    this.polarity = new PolarityClassifier();
    this.witness = new WitnessEngine();
    this.context = new ContextEngine(this.witness);
    this.meaning = new MeaningSynthesizer(this.witness, this.context);

    // Wire the pipeline: D1 → D2 → D3 → D4 → D5
    this.impulse.onIngest((signal) => this.processSignal(signal));
  }

  private async processSignal(signal: IngestedSignal) {
    // D1 → D2: Classify
    const polarity = this.polarity.classify(signal);

    // D2 → D3: Observe and place in semantic network
    const node = this.witness.observe(polarity, signal);

    // D3 → D4: Build context and detect gaps
    this.context.buildContext(node.id);
    const gaps = this.context.detectGaps(node.id);

    // D4 → D5: Synthesize fills for critical gaps
    for (const gap of gaps.filter(g => g.severity === 'critical')) {
      this.meaning.synthesize(gap);
    }

    this.ingestedSignals.push(signal);
  }

  // Public API
  async ingestFile(file: File | Buffer, filename: string, metadata: Record<string, any> = {}) {
    const content = file instanceof Buffer ? file.toString() : await file.text();
    return this.impulse.ingest('file', content, { filename, ...metadata });
  }

  async ingestURL(url: string, metadata: Record<string, any> = {}) {
    // In a real implementation, fetch the URL content
    return this.impulse.ingest('url', url, { filename: url.split('/').pop() || 'unknown', ...metadata });
  }

  async ingestGit(repoUrl: string, metadata: Record<string, any> = {}) {
    return this.impulse.ingest('git', repoUrl, { filename: repoUrl.split('/').pop() || 'unknown', ...metadata });
  }

  async ingestAPI(endpoint: string, data: any, metadata: Record<string, any> = {}) {
    return this.impulse.ingest('api', JSON.stringify(data), { filename: endpoint, ...metadata });
  }

  // Build the complete world model
  synthesize(): WorldModel {
    this.worldModel = this.meaning.buildWorldModel();
    return this.worldModel;
  }

  // gameNgen-style: generate an autoregressive rollout
  rollout(seedFilename: string, steps: number = 10): GeneratedArtifact[] {
    const signal = this.ingestedSignals.find(s => s.filename === seedFilename);
    if (!signal) throw new Error(`Seed file ${seedFilename} not found`);
    const node = this.witness.getNetwork().get(`node_${signal.id}`);
    if (!node) throw new Error(`Node for ${seedFilename} not found`);
    return this.meaning.autoregressiveRollout(node.id, steps);
  }

  // Query the semantic network
  query(pattern: string): SemanticNode[] {
    const network = this.witness.getNetwork();
    const results: SemanticNode[] = [];
    for (const node of network.values()) {
      if (node.label.toLowerCase().includes(pattern.toLowerCase()) ||
          node.type.toLowerCase().includes(pattern.toLowerCase())) {
        results.push(node);
      }
    }
    return results;
  }

  // Get analogies for a node
  getAnalogies(nodeId: string): AnalogyMapping[] {
    const node = this.witness.getNetwork().get(nodeId);
    return node?.analogies || [];
  }

  // Export the world model
  exportWorldModel(): string {
    if (!this.worldModel) this.synthesize();
    return JSON.stringify(this.worldModel, (key, value) => {
      if (value instanceof Map) {
        return Object.fromEntries(value);
      }
      return value;
    }, 2);
  }

  getStats() {
    return {
      ingested: this.ingestedSignals.length,
      nodes: this.witness.getNetwork().size,
      analogies: this.witness.getAnalogies().length,
      generated: this.meaning.getGenerationLog().length,
      worldModel: this.worldModel ? {
        gaps: this.worldModel.gaps.length,
        filled: this.worldModel.filled.length,
        coverage: this.worldModel.emergentProperties.get('coverage')
      } : null
    };
  }
}

// Export types
export type {
  IngestedSignal,
  PolarityVector,
  SemanticNode,
  AnalogyMapping,
  GapReport,
  ContextField,
  GeneratedArtifact,
  WorldModel
};

// Default export
export default IngestGapFillEngine;
