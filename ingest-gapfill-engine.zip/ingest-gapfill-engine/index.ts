/**
 * ============================================================
 * INGEST & GAP-FILL ENGINE v2
 * Main Entry Point
 *
 * All 8 Klein tools on MESSY morphing substrate + gameNgen
 *
 * Sheldon Klein's complete toolkit:
 *   1. DISEMINER (1968) — Distributional-Semantics Inference
 *   2. AUTOLING (1968) — Meta-linguistic System (5W query engine)
 *   3. Auto Novel (1973) — Computer-Generated Fiction (curated for code)
 *   4. MESSY (1976) — Meta-Symbolic Simulation (morphing substrate)
 *   5. Propp/Lévi-Strauss (1976-77) — Folktale Structure Simulation
 *   6. Analogy & Mysticism (1983) — Cultural Structure via Analogy
 *   7. Historical Change (1966, 1974) — Monte Carlo Language Evolution
 *   8. Creativity (1999-2002) — Analogical Foundations of Creativity
 *
 * gameNgen: Diffusion-based real-time world generation
 * ============================================================
 */

// Core engine (D1-D5)
export { IngestGapFillEngine } from './core-engine';

// gameNgen adapter
export { GameNGenEngine, MockDiffusionBackend, ONNXDiffusionBackend } from './gamengen-adapter';

// Full Klein toolkit (all 8 tools on MESSY)
export {
  KleinEngine,
  MessySubstrate,
  MessySymbol,
  MessyMorphRule,
  MessyContext,
  MessyModule,
  WhoWhatWhereWhenWhy,
  DiseMinerModule,
  AutolingModule,
  AutoNovelModule,
  ProppLeviStraussModule,
  AnalogyMysticismModule,
  HistoricalChangeModule,
  CreativityModule
} from './klein-full-toolkit';

// Pipeline
export { IngestGapFillPipeline, demo } from './pipeline';

// Types from core engine
export type {
  IngestedSignal,
  PolarityVector,
  SemanticNode,
  AnalogyMapping,
  GapReport,
  ContextField,
  GeneratedArtifact,
  WorldModel
} from './core-engine';

// Types from gameNgen
export type {
  GameNGenFrame,
  FrameBuffer,
  DiffusionModelConfig
} from './gamengen-adapter';

// Types from Klein toolkit
export type {
  DistributionalVector,
  SemanticField,
  Grammar,
  GrammarRule,
  NarrativeFunction,
  NarrativeSequence
} from './klein-diseMiner';

// Types from pipeline
export type { PipelineConfig } from './pipeline';
