#!/usr/bin/env python3
"""
gameNgen Python Server — Real Diffusion Inference Bridge
=========================================================

This server loads the actual gameNgen checkpoints from Hugging Face
and serves frame generation via FastAPI/WebSocket.

Requirements:
  pip install torch diffusers transformers accelerate fastapi uvicorn
  pip install websockets pillow numpy

Usage:
  python gamengen_server.py --model arnaudstiegler/sd-model-gameNgen-60ksteps

The TypeScript engine connects to this server and sends:
  - previous_frame: base64 PNG or latent tensor
  - action: integer (0-7) or text description
  - num_steps: denoising steps (default 20)

The server returns:
  - generated_frame: base64 PNG
  - latent: the latent representation (for next frame conditioning)
  - metadata: generation params, timing, etc.
"""

import os
import sys
import base64
import io
import time
import argparse
from typing import Optional, List, Tuple
from dataclasses import dataclass

import numpy as np
from PIL import Image

# PyTorch / diffusers
try:
    import torch
    from torch import nn
    from diffusers import (
        StableDiffusionPipeline,
        DDPMScheduler,
        AutoencoderKL,
        UNet2DConditionModel,
    )
    from transformers import CLIPTextModel, CLIPTokenizer
    HAS_DIFFUSERS = True
except ImportError:
    HAS_DIFFUSERS = False
    print("WARNING: diffusers not installed. Running in mock mode.")

# FastAPI
try:
    from fastapi import FastAPI, WebSocket, HTTPException
    from fastapi.responses import JSONResponse
    import uvicorn
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False
    print("WARNING: fastapi not installed. CLI mode only.")


# ═══════════════════════════════════════════════════════════
# ACTION SPACE (from gameNgen paper / VizDoom)
# ═══════════════════════════════════════════════════════════

ACTION_MAP = {
    0: "NOOP",
    1: "MOVE_FORWARD",
    2: "MOVE_BACKWARD",
    3: "TURN_LEFT",
    4: "TURN_RIGHT",
    5: "ATTACK",
    6: "USE",
    7: "JUMP",
}

ACTION_DESCRIPTIONS = {
    "NOOP": "the agent stands still",
    "MOVE_FORWARD": "the agent moves forward",
    "MOVE_BACKWARD": "the agent moves backward",
    "TURN_LEFT": "the agent turns left",
    "TURN_RIGHT": "the agent turns right",
    "ATTACK": "the agent attacks",
    "USE": "the agent uses an object",
    "JUMP": "the agent jumps",
}


# ═══════════════════════════════════════════════════════════
# gameNgen Model Wrapper
# ═══════════════════════════════════════════════════════════

@dataclass
class GenerationConfig:
    num_inference_steps: int = 20
    guidance_scale: float = 1.0  # gameNgen uses 1.0 (no CFG) for speed
    frame_conditioning: str = "concat"  # concat previous frame latent
    output_resolution: Tuple[int, int] = (256, 256)
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    dtype: torch.dtype = torch.float16


class GameNGenModel:
    """Loads and runs the gameNgen diffusion model."""

    def __init__(self, model_path: str, config: Optional[GenerationConfig] = None):
        self.model_path = model_path
        self.config = config or GenerationConfig()
        self.device = self.config.device

        if not HAS_DIFFUSERS:
            raise RuntimeError("diffusers not installed. Cannot load real model.")

        print(f"Loading gameNgen model from: {model_path}")
        print(f"Device: {self.device}, Dtype: {self.config.dtype}")

        # Load components
        self._load_pipeline()

        # Frame buffer for autoregressive generation
        self.frame_buffer: List[torch.Tensor] = []
        self.max_buffer_size = 8

        print("Model loaded successfully.")

    def _load_pipeline(self):
        """Load the fine-tuned Stable Diffusion pipeline."""
        # Load the full pipeline (this downloads ~2GB if not cached)
        self.pipe = StableDiffusionPipeline.from_pretrained(
            self.model_path,
            torch_dtype=self.config.dtype,
            safety_checker=None,  # gameNgen doesn't need safety checker
        )
        self.pipe = self.pipe.to(self.device)

        # Extract components for manual control
        self.vae = self.pipe.vae
        self.unet = self.pipe.unet
        self.text_encoder = self.pipe.text_encoder
        self.tokenizer = self.pipe.tokenizer
        self.scheduler = self.pipe.scheduler

        # gameNgen-specific: the UNet was fine-tuned to accept
        # concatenated latents (previous frame + noise)
        # Check if UNet has 8 input channels (4 + 4)
        in_channels = self.unet.config.in_channels
        print(f"UNet input channels: {in_channels}")
        if in_channels != 8:
            print(f"WARNING: Expected 8 channels for frame conditioning, got {in_channels}")
            print("The model may not have been fine-tuned with frame concatenation.")

    def encode_action(self, action: int) -> torch.Tensor:
        """Convert action index to text embedding."""
        action_name = ACTION_MAP.get(action, "NOOP")
        description = ACTION_DESCRIPTIONS[action_name]
        prompt = f"DOOM game frame, {description}, first person shooter"

        # Tokenize and encode
        text_inputs = self.tokenizer(
            prompt,
            padding="max_length",
            max_length=self.tokenizer.model_max_length,
            truncation=True,
            return_tensors="pt",
        )
        text_input_ids = text_inputs.input_ids.to(self.device)

        with torch.no_grad():
            text_embeddings = self.text_encoder(text_input_ids)[0]

        return text_embeddings

    def encode_frame(self, image: Image.Image) -> torch.Tensor:
        """Encode image to latent space via VAE."""
        # Resize to model resolution
        image = image.resize(self.config.output_resolution)

        # Convert to tensor [0, 1]
        image_np = np.array(image).astype(np.float32) / 255.0
        image_tensor = torch.from_numpy(image_np).permute(2, 0, 1).unsqueeze(0)
        image_tensor = image_tensor.to(self.device, dtype=self.config.dtype)

        # VAE encode
        with torch.no_grad():
            latent = self.vae.encode(image_tensor).latent_dist.sample()
            latent = latent * 0.18215  # SD scaling factor

        return latent

    def decode_latent(self, latent: torch.Tensor) -> Image.Image:
        """Decode latent to RGB image via VAE."""
        latent = latent / 0.18215

        with torch.no_grad():
            image = self.vae.decode(latent).sample

        # Convert to PIL
        image = (image / 2 + 0.5).clamp(0, 1)
        image = image.cpu().permute(0, 2, 3, 1).numpy()[0]
        image = (image * 255).astype(np.uint8)
        return Image.fromarray(image)

    def generate_frame(
        self,
        action: int,
        previous_frame: Optional[Image.Image] = None,
        seed: Optional[int] = None,
    ) -> Tuple[Image.Image, torch.Tensor, dict]:
        """
        Generate a single frame conditioned on previous frame + action.

        Args:
            action: Action index (0-7)
            previous_frame: Previous frame as PIL Image (or None for first frame)
            seed: Random seed for reproducibility

        Returns:
            (generated_image, latent, metadata)
        """
        start_time = time.time()

        # Set seed
        if seed is not None:
            torch.manual_seed(seed)
            np.random.seed(seed)

        # Encode action
        text_embeddings = self.encode_action(action)

        # Prepare latent input
        if previous_frame is not None:
            prev_latent = self.encode_frame(previous_frame)
        else:
            # Initialize with random noise if no previous frame
            prev_latent = torch.randn(
                1, 4, self.config.output_resolution[0] // 8, self.config.output_resolution[1] // 8,
                device=self.device, dtype=self.config.dtype
            )

        # Generate noise latent
        noise_latent = torch.randn(
            1, 4, self.config.output_resolution[0] // 8, self.config.output_resolution[1] // 8,
            device=self.device, dtype=self.config.dtype
        )

        # Concatenate previous frame latent + noise (gameNgen conditioning)
        # This is the key: the model sees history
        latent = torch.cat([prev_latent, noise_latent], dim=1)

        # Denoising loop
        self.scheduler.set_timesteps(self.config.num_inference_steps)
        timesteps = self.scheduler.timesteps

        for i, t in enumerate(timesteps):
            # Predict noise
            with torch.no_grad():
                noise_pred = self.unet(
                    latent,
                    t,
                    encoder_hidden_states=text_embeddings,
                ).sample

            # Scheduler step
            latent = self.scheduler.step(noise_pred, t, latent).prev_sample

        # Decode the generated latent (first 4 channels)
        generated_latent = latent[:, :4, :, :]
        image = self.decode_latent(generated_latent)

        # Update frame buffer
        self.frame_buffer.append(generated_latent)
        if len(self.frame_buffer) > self.max_buffer_size:
            self.frame_buffer.pop(0)

        elapsed = time.time() - start_time
        metadata = {
            "action": ACTION_MAP.get(action, "UNKNOWN"),
            "action_index": action,
            "num_steps": self.config.num_inference_steps,
            "guidance_scale": self.config.guidance_scale,
            "generation_time_ms": elapsed * 1000,
            "device": self.device,
            "seed": seed,
        }

        return image, generated_latent, metadata

    def autoregressive_rollout(
        self,
        actions: List[int],
        initial_frame: Optional[Image.Image] = None,
        on_frame: Optional[callable] = None,
    ) -> List[Tuple[Image.Image, dict]]:
        """
        Generate a sequence of frames autoregressively.
        Each frame conditions the next.
        """
        frames = []
        current_frame = initial_frame

        for i, action in enumerate(actions):
            image, latent, metadata = self.generate_frame(action, current_frame)
            frames.append((image, metadata))

            if on_frame:
                on_frame(image, metadata, i)

            current_frame = image

        return frames


# ═══════════════════════════════════════════════════════════
# Mock Model (for testing without diffusers)
# ═══════════════════════════════════════════════════════════

class MockGameNGenModel:
    """Mock implementation for testing without PyTorch."""

    def __init__(self, model_path: str, config: Optional[GenerationConfig] = None):
        self.model_path = model_path
        self.config = config or GenerationConfig()
        self.frame_buffer = []
        print(f"[MockGameNGen] Initialized (no PyTorch)")

    def generate_frame(self, action: int, previous_frame=None, seed=None):
        """Generate a deterministic noise pattern."""
        np.random.seed(seed or action * 42)
        arr = np.random.randint(0, 255, (256, 256, 3), dtype=np.uint8)
        image = Image.fromarray(arr)

        metadata = {
            "action": ACTION_MAP.get(action, "UNKNOWN"),
            "action_index": action,
            "num_steps": self.config.num_inference_steps,
            "generation_time_ms": 50.0,
            "device": "mock",
            "seed": seed,
        }

        return image, torch.zeros(1, 4, 32, 32) if HAS_DIFFUSERS else None, metadata

    def autoregressive_rollout(self, actions, initial_frame=None, on_frame=None):
        frames = []
        current = initial_frame
        for i, action in enumerate(actions):
            img, latent, meta = self.generate_frame(action, current, seed=i * 100)
            frames.append((img, meta))
            if on_frame:
                on_frame(img, meta, i)
            current = img
        return frames


# ═══════════════════════════════════════════════════════════
# FastAPI Server
# ═══════════════════════════════════════════════════════════

app = FastAPI(title="gameNgen Server", version="1.0.0")
model: Optional[GameNGenModel] = None


@app.on_event("startup")
async def startup():
    global model
    # Load model on startup
    model_path = os.environ.get("GAMENGEN_MODEL", "arnaudstiegler/sd-model-gameNgen-60ksteps")
    if HAS_DIFFUSERS:
        try:
            model = GameNGenModel(model_path)
        except Exception as e:
            print(f"Failed to load model: {e}")
            print("Falling back to mock mode.")
            model = MockGameNGenModel(model_path)
    else:
        model = MockGameNGenModel(model_path)


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "model_loaded": model is not None,
        "has_diffusers": HAS_DIFFUSERS,
        "has_fastapi": HAS_FASTAPI,
    }


@app.post("/generate")
async def generate_frame_endpoint(
    action: int,
    previous_frame_b64: Optional[str] = None,
    seed: Optional[int] = None,
    num_steps: Optional[int] = 20,
):
    """Generate a single frame."""
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    # Decode previous frame if provided
    previous_frame = None
    if previous_frame_b64:
        img_bytes = base64.b64decode(previous_frame_b64)
        previous_frame = Image.open(io.BytesIO(img_bytes))

    # Generate
    image, latent, metadata = model.generate_frame(
        action=action,
        previous_frame=previous_frame,
        seed=seed,
    )

    # Encode output
    buf = io.BytesIO()
    image.save(buf, format="PNG")
    frame_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

    return JSONResponse({
        "frame_b64": frame_b64,
        "metadata": metadata,
    })


@app.post("/rollout")
async def rollout_endpoint(
    actions: List[int],
    initial_frame_b64: Optional[str] = None,
    seed: Optional[int] = None,
):
    """Generate an autoregressive rollout."""
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    initial_frame = None
    if initial_frame_b64:
        img_bytes = base64.b64decode(initial_frame_b64)
        initial_frame = Image.open(io.BytesIO(img_bytes))

    frames = []

    def on_frame(img, meta, idx):
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        frames.append({
            "frame_b64": base64.b64encode(buf.getvalue()).decode("utf-8"),
            "metadata": meta,
            "index": idx,
        })

    model.autoregressive_rollout(actions, initial_frame, on_frame)

    return JSONResponse({
        "frames": frames,
        "total": len(frames),
    })


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket for real-time frame streaming."""
    await websocket.accept()
    await websocket.send_json({"type": "connected", "model": model is not None})

    try:
        while True:
            data = await websocket.receive_json()
            action = data.get("action", 0)
            previous_b64 = data.get("previous_frame")
            seed = data.get("seed")

            previous_frame = None
            if previous_b64:
                img_bytes = base64.b64decode(previous_b64)
                previous_frame = Image.open(io.BytesIO(img_bytes))

            image, latent, metadata = model.generate_frame(action, previous_frame, seed)

            buf = io.BytesIO()
            image.save(buf, format="PNG")
            frame_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

            await websocket.send_json({
                "type": "frame",
                "frame_b64": frame_b64,
                "metadata": metadata,
            })
    except Exception as e:
        await websocket.send_json({"type": "error", "message": str(e)})
    finally:
        await websocket.close()


# ═══════════════════════════════════════════════════════════
# CLI Mode
# ═══════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="gameNgen Python Server")
    parser.add_argument("--model", default="arnaudstiegler/sd-model-gameNgen-60ksteps", help="Model path or HF repo")
    parser.add_argument("--host", default="0.0.0.0", help="Server host")
    parser.add_argument("--port", type=int, default=8000, help="Server port")
    parser.add_argument("--device", default="cuda", help="Device (cuda/cpu)")
    parser.add_argument("--mock", action="store_true", help="Force mock mode")
    parser.add_argument("--action", type=int, default=1, help="Action for CLI test")
    parser.add_argument("--steps", type=int, default=20, help="Denoising steps")
    parser.add_argument("--seed", type=int, default=None, help="Random seed")
    parser.add_argument("--cli", action="store_true", help="Run CLI test instead of server")
    args = parser.parse_args()

    config = GenerationConfig(
        num_inference_steps=args.steps,
        device="cpu" if args.mock else args.device,
    )

    if args.mock or not HAS_DIFFUSERS:
        model = MockGameNGenModel(args.model, config)
    else:
        model = GameNGenModel(args.model, config)

    if args.cli:
        # CLI test mode
        print(f"\nGenerating frame with action={args.action}, steps={args.steps}")
        image, latent, metadata = model.generate_frame(args.action, seed=args.seed)
        print(f"Generated in {metadata['generation_time_ms']:.1f}ms")
        print(f"Action: {metadata['action']}")

        # Save
        output_path = f"frame_action{args.action}_seed{args.seed or 'random'}.png"
        image.save(output_path)
        print(f"Saved to: {output_path}")

        # Autoregressive test
        print(f"\nGenerating 5-frame autoregressive rollout...")
        actions = [1, 3, 1, 4, 1]  # forward, left, forward, right, forward
        frames = model.autoregressive_rollout(actions, initial_frame=image)
        for i, (img, meta) in enumerate(frames):
            img.save(f"rollout_frame_{i}.png")
        print(f"Saved {len(frames)} rollout frames")
    else:
        # Server mode
        if not HAS_FASTAPI:
            print("ERROR: fastapi not installed. Cannot start server.")
            print("Install: pip install fastapi uvicorn")
            sys.exit(1)

        # Set model as global for FastAPI
        globals()["model"] = model
        uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
