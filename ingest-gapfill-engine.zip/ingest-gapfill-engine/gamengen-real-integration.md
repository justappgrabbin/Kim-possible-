# gameNgen Real Integration Architecture

## What We Actually Need

The current `gamengen-adapter.ts` has a `MockDiffusionBackend` that generates sine-wave noise. To make this REAL, we need:

### 1. Model Weights (from Hugging Face)

```
arnaudstiegler/sd-model-gameNgen-60ksteps
├── unet/diffusion_pytorch_model.bin      # ~1.7GB — the UNet
├── vae/diffusion_pytorch_model.bin       # ~300MB — the VAE  
├── text_encoder/model.safetensors        # ~500MB — CLIP text encoder
├── scheduler/scheduler_config.json       # DDPM config
├── model_index.json                      # Pipeline config
```

### 2. Python Bridge (RECOMMENDED)

TypeScript/Node cannot efficiently run 2GB+ PyTorch models. The practical architecture:

```
┌─────────────────────────────────────────────────────────────┐
│  TypeScript Engine (D1-D5, MESSY, Klein tools)              │
│  - Ingestion, classification, semantic network               │
│  - Gap detection, analogy, narrative generation              │
└────────────────────┬────────────────────────────────────────┘
                     │ WebSocket / HTTP POST
                     ▼
┌─────────────────────────────────────────────────────────────┐
│  Python gameNgen Server (FastAPI)                           │
│  - PyTorch + diffusers + transformers                       │
│  - Loads actual checkpoints from Hugging Face               │
│  - Runs UNet denoising loop (20 steps, ~50ms/frame)         │
│  - Returns generated frame as PNG bytes                   │
└─────────────────────────────────────────────────────────────┘
```

### 3. The Actual Inference Loop (Python)

```python
from diffusers import StableDiffusionPipeline, DDPMScheduler
from transformers import CLIPTextModel, CLIPTokenizer
import torch

# Load fine-tuned model
pipe = StableDiffusionPipeline.from_pretrained(
    "arnaudstiegler/sd-model-gameNgen-60ksteps",
    torch_dtype=torch.float16,
).to("cuda")

# gameNgen-specific: frame conditioning
# Previous frames are concatenated as additional latent channels
# Action is embedded via text encoder

def generate_frame(previous_latents, action_embedding, num_steps=20):
    # 1. Prepare latents: concat previous frames + noise
    # 2. Encode action: "MOVE_FORWARD" → CLIP embedding
    # 3. Denoising loop (20 steps):
    #    for t in scheduler.timesteps:
    #        noise_pred = unet(latent, t, encoder_hidden_states).sample
    #        latent = scheduler.step(noise_pred, t, latent).prev_sample
    # 4. Decode: VAE latent → RGB image
    # 5. Return PIL Image or PNG bytes
    pass
```

### 4. Frame Conditioning (The Key Trick)

From the gameNgen paper:
> "The model is conditioned on the previous frame and the action taken by the agent. The previous frame is encoded by the VAE and concatenated with the noise latent. The action is encoded as text and fed through the text encoder."

Implementation:
```python
# Previous frame → VAE encode → latent
prev_latent = vae.encode(prev_frame).latent_dist.sample()
prev_latent = prev_latent * 0.18215  # SD scaling factor

# Concat with noise (4 channels + 4 channels = 8 channels)
# The UNet was fine-tuned to accept 8-channel input
latent = torch.cat([prev_latent, noise], dim=1)

# Action → text → CLIP embedding
action_text = ACTION_MAP[action]  # e.g., "MOVE_FORWARD"
action_embedding = text_encoder(tokenizer(action_text))
```

### 5. Autoregressive Rollout

```python
frames = [initial_frame]  # From dataset or seed
for action in action_sequence:
    prev_latent = vae.encode(frames[-1])
    new_frame = generate_frame(prev_latent, action)
    frames.append(new_frame)
    # Each new frame conditions the next
```

### 6. Performance Targets

| Metric | Paper | Our Target |
|--------|-------|------------|
| Resolution | 256x256 | 256x256 |
| FPS | 20 | 10-20 (with TensorRT) |
| Denoising steps | 20 | 20-50 |
| Frame buffer | 4 frames | 4-8 frames |
| Guidance scale | 1.0 (no CFG) | 1.0-3.0 |

### 7. Integration Points with MESSY/Klein

```typescript
// TypeScript side sends semantic context to Python
const semanticContext = {
  action: 'explore',           // From MESSY behavioral analysis
  environment: 'dungeon',     // From semantic field detection
  mood: 'tense',              // From narrative analysis
  previousFrames: [frame1, frame2, frame3]
};

// Python side receives this and generates the frame
// The diffusion model IS the game — no separate renderer
```

## Current Status

| Component | Status |
|-----------|--------|
| TypeScript engine (D1-D5) | ✅ Complete (semantic network, gap detection, analogy) |
| MESSY substrate | ✅ Complete (morphing between all 6 symbol types) |
| Klein 8 tools | ✅ Complete (all wired through MESSY) |
| Mock diffusion backend | ✅ Complete (deterministic noise for testing) |
| ONNX backend stub | ⚠️ Stub (needs ONNX Runtime + model weights) |
| Python bridge | ❌ Not implemented (needs FastAPI + diffusers) |
| Real model weights | ❌ Not downloaded (needs Hugging Face auth + 2GB+ download) |
| Frame conditioning | ❌ Not implemented (needs VAE concat logic) |
| Autoregressive rollout | ⚠️ Mock only (real version needs Python bridge) |

## Next Steps to Make It Real

1. **Download checkpoints**: `huggingface-cli download arnaudstiegler/sd-model-gameNgen-60ksteps`
2. **Build Python server**: FastAPI + diffusers + PyTorch CUDA
3. **Implement frame conditioning**: VAE encode + latent concat + action embed
4. **Wire WebSocket**: TypeScript engine ↔ Python server
5. **Optimize**: TensorRT, FlashAttention, fp16 quantization
