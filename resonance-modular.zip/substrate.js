// ═══════════════════════════════════════════════════════════
// SUBSTRATE — Pure Visual Mesh
// No app logic. No event handling. Just field, breath, color.
// ═══════════════════════════════════════════════════════════

class Substrate {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) {
      this.canvas = document.createElement('canvas');
      this.canvas.id = canvasId;
      document.body.insertBefore(this.canvas, document.body.firstChild);
    }
    this.ctx = this.canvas.getContext('2d');
    this.gridW = 0; this.gridH = 0;
    this.spins = new Float32Array(0);
    this.nextSpins = new Float32Array(0);
    this.frame = 0;
    this.params = {
      temperature: 2.5,
      coupling: 1.0,
      field: 0.0,
      hue: 270,        // Purple base
      sat: 40,
      light: 8,
      accentHue: 320,  // Pink accent
      breathSpeed: 0.04
    };
    this.resize();
    window.addEventListener('resize', () => this.resize());
    this.initGrid();
    this.animate();
  }

  resize() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    this.canvas.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;z-index:0;pointer-events:none;';
    this.gridW = Math.ceil(window.innerWidth / 8);
    this.gridH = Math.ceil(window.innerHeight / 8);
    this.initGrid();
  }

  initGrid() {
    const size = this.gridW * this.gridH;
    this.spins = new Float32Array(size);
    this.nextSpins = new Float32Array(size);
    for (let i = 0; i < size; i++) {
      const x = i % this.gridW;
      const y = Math.floor(i / this.gridW);
      this.spins[i] = Math.sin(x * 0.05) * Math.cos(y * 0.05) + (Math.random() - 0.5) * 0.3;
    }
  }

  // External API: other systems perturb the field
  perturb(x, y, strength, radius = 50) {
    const gx = Math.floor((x / window.innerWidth) * this.gridW);
    const gy = Math.floor((y / window.innerHeight) * this.gridH);
    const r = Math.floor((radius / window.innerWidth) * this.gridW);
    for (let dy = -r; dy <= r; dy++) {
      for (let dx = -r; dx <= r; dx++) {
        const cx = (gx + dx + this.gridW) % this.gridW;
        const cy = (gy + dy + this.gridH) % this.gridH;
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist > r) continue;
        const idx = cy * this.gridW + cx;
        const falloff = 1 - (dist / r);
        this.spins[idx] += strength * falloff;
        this.spins[idx] = Math.max(-1, Math.min(1, this.spins[idx]));
      }
    }
  }

  setParams(newParams) {
    Object.assign(this.params, newParams);
  }

  step() {
    const { gridW: w, gridH: h, params: p } = this;
    const J = p.coupling, T = p.temperature, H = p.field;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = y * w + x;
        const s = this.spins[i];
        let neighborSum = 0;
        neighborSum += this.spins[((y - 1 + h) % h) * w + x];
        neighborSum += this.spins[((y + 1) % h) * w + x];
        neighborSum += this.spins[y * w + ((x - 1 + w) % w)];
        neighborSum += this.spins[y * w + ((x + 1) % w)];
        const energy = -J * s * neighborSum - H * s;
        const target = neighborSum / 4;
        const noise = (Math.random() - 0.5) * T * 0.1;
        this.nextSpins[i] = s * 0.7 + (target + noise + H * 0.1) * 0.3;
        this.nextSpins[i] = Math.max(-1, Math.min(1, this.nextSpins[i]));
      }
    }
    const tmp = this.spins; this.spins = this.nextSpins; this.nextSpins = tmp;
  }

  render() {
    const { ctx, canvas: c, gridW: gw, gridH: gh, params: p } = this;
    const cellW = c.width / gw, cellH = c.height / gh;
    ctx.fillStyle = '#0a0614';
    ctx.fillRect(0, 0, c.width, c.height);
    for (let y = 0; y < gh; y++) {
      for (let x = 0; x < gw; x++) {
        const i = y * gw + x;
        const spin = this.spins[i];
        const intensity = (spin + 1) / 2;
        const hue = p.hue + intensity * 30 + Math.sin(this.frame * p.breathSpeed) * 10;
        const sat = p.sat + intensity * 20;
        const light = p.light + intensity * 12;
        const alpha = 0.3 + intensity * 0.4;
        ctx.fillStyle = `hsla(${hue}, ${sat}%, ${light}%, ${alpha})`;
        ctx.fillRect(x * cellW, y * cellH, cellW + 1, cellH + 1);
      }
    }
    // Glow spots on high-energy regions
    for (let y = 2; y < gh - 2; y += 3) {
      for (let x = 2; x < gw - 2; x += 3) {
        const i = y * gw + x;
        const spin = Math.abs(this.spins[i]);
        if (spin > 0.7) {
          const px = (x / gw) * c.width, py = (y / gh) * c.height;
          const radius = 30 + spin * 50;
          const grad = ctx.createRadialGradient(px, py, 0, px, py, radius);
          grad.addColorStop(0, `hsla(${p.accentHue}, 80%, 60%, ${spin * 0.15})`);
          grad.addColorStop(1, 'transparent');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(px, py, radius, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
    this.frame++;
  }

  animate() {
    this.step();
    this.render();
    requestAnimationFrame(() => this.animate());
  }
}

// Export for mesh use
window.Substrate = Substrate;