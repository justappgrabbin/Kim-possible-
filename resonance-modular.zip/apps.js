// ═══════════════════════════════════════════════════════════
// APPS v2 — Modular Application Layer with Synthesis
// ═══════════════════════════════════════════════════════════

class AppRegistry {
  constructor() { this.apps = new Map(); }
  register(id, config) { this.apps.set(id, { ...config, id, active: false }); }
  get(id) { return this.apps.get(id); }
  all() { return Array.from(this.apps.values()); }
}

class TerminalApp {
  constructor() { this.history = []; this.historyIndex = -1; }
  api() { return { execute: (cmd) => this.execute(cmd) }; }

  execute(input) {
    if (!input?.trim()) return;
    this.history.push(input);
    this.historyIndex = this.history.length;
    const parts = input.trim().split(/\s+/);
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);
    const rest = args.join(' ');

    const autoling = this.mesh?.api('autoling');

    const commands = {
      help: () => `AUTOLING Terminal — Commands:
  help                    Show this message
  clear                   Clear terminal
  py <code>               Transform Python to JavaScript
  transform <ext> <code>  Transform any file type to JS
  grammar <gate>          Expand Klein grammar for gate
  generate <type> <gate>  Generate content (photo/video/story/game)
  code <type> <desc>      Synthesize code (component/function/shader/animation/canvas/full)
  image <gate> <subject>  Generate image prompt
  clip <gate> <duration>  Generate clip storyboard
  mesh                    List mesh modules
  status                  Show mesh status
  whoami                  System identity
  time                    Current time`,

      clear: () => 'CLEAR',

      py: () => {
        const code = rest.replace(/^py\s+/, '');
        return autoling ? autoling.transform('py', code) : 'Autoling offline';
      },

      transform: () => {
        const ext = args[0];
        const code = args.slice(1).join(' ');
        return autoling ? autoling.transform(ext, code) : 'Autoling offline';
      },

      grammar: () => {
        const gate = parseInt(args[0]) || 61;
        return autoling ? autoling.generate(gate) : 'Autoling offline';
      },

      generate: () => {
        const type = args[0] || 'photo';
        const gate = parseInt(args[1]) || 61;
        return autoling ? autoling.generateContent(type, { gate }) : 'Autoling offline';
      },

      code: () => {
        const type = args[0] || 'component';
        const desc = args.slice(1).join(' ') || 'generated component';
        const gate = this.mesh?.coordinate?.gate || 61;
        if (!autoling) return 'Autoling offline';
        const result = autoling.generateCode({ type, description: desc, gate });
        return result;
      },

      image: () => {
        const gate = parseInt(args[0]) || 61;
        const subject = args.slice(1).join(' ') || 'abstract figure';
        if (!autoling) return 'Autoling offline';
        const result = autoling.generateImage({ gate, subject, style: 'photorealistic' });
        return JSON.stringify(result, null, 2);
      },

      clip: () => {
        const gate = parseInt(args[0]) || 61;
        const duration = parseInt(args[1]) || 5;
        if (!autoling) return 'Autoling offline';
        const result = autoling.generateClip({ gate, duration, style: 'cinematic' });
        return JSON.stringify(result, null, 2);
      },

      mesh: () => {
        const modules = this.mesh ? Array.from(this.mesh.modules.keys()) : [];
        return `Mesh modules: ${modules.join(', ')}`;
      },

      status: () => this.mesh ? `Phase: ${this.mesh.phase} | Coordinate: ${JSON.stringify(this.mesh.coordinate)} | Modules: ${this.mesh.modules.size}` : 'No mesh',

      whoami: () => 'RESONANCE — Modular Autopoietic System with AUTOLING Synthesis',

      time: () => new Date().toISOString()
    };

    const handler = commands[cmd];
    return handler ? handler() : `Unknown: ${cmd}. Type 'help' for commands.`;
  }

  onRegister(mesh) {
    this.mesh = mesh;
    mesh.on('terminal:input', (packet) => {
      const result = this.execute(packet.data.input);
      mesh.emit('terminal:output', { result, input: packet.data.input });
    });
  }

  render() {
    return `<div style="display:flex;flex-direction:column;height:100%;gap:8px;">
      <div id="term-output" style="flex:1;overflow-y:auto;background:#0a0614;padding:10px;border-radius:6px;font-family:monospace;font-size:12px;line-height:1.6;color:#e8e8e8;">
        <div style="color:#c084fc">RESONANCE Terminal — AUTOLING v2</div>
        <div style="color:#6b5b8a">code · image · clip · grammar · transform</div>
        <div style="color:#6b5b8a">Type 'help' for commands</div>
      </div>
      <div style="display:flex;gap:6px;">
        <span style="color:#a855f7;font-family:monospace;font-size:12px;">❯</span>
        <input type="text" id="term-input" style="flex:1;background:transparent;border:none;color:#f5c518;font-family:monospace;font-size:12px;outline:none;" placeholder="Enter command..." />
      </div>
    </div>`;
  }
}

class AgentApp {
  api() { return { respond: (input) => this.respond(input) }; }

  respond(input) {
    if (!input?.trim()) return;
    const lower = input.toLowerCase().trim();
    const autoling = this.mesh?.api('autoling');
    const gate = this.mesh?.coordinate?.gate || 61;

    // Code generation requests
    if (lower.includes('code') || lower.includes('component') || lower.includes('function') || lower.includes('shader') || lower.includes('animation')) {
      const type = lower.includes('shader') ? 'shader' : lower.includes('animation') ? 'animation' : lower.includes('function') ? 'function' : lower.includes('canvas') ? 'canvas' : 'component';
      const desc = input.replace(/code|component|function|shader|animation|canvas|generate|create|write|make/gi, '').trim() || 'generated';
      if (autoling) {
        const result = autoling.generateCode({ type, description: desc, gate });
        return `Generated ${type} (Gate ${gate}):

\`\`\`
${result}
\`\`\``;
      }
    }

    // Image generation requests
    if (lower.includes('image') || lower.includes('photo') || lower.includes('picture') || lower.includes('generate image')) {
      const subject = input.replace(/image|photo|picture|generate|create|make|of|a|an/gi, '').trim() || 'abstract figure';
      if (autoling) {
        const result = autoling.generateImage({ gate, subject, style: 'photorealistic' });
        return `Image Prompt (Gate ${gate}):

${result.prompt}

Negative: ${result.negative}

Technical: ${JSON.stringify(result.technical, null, 2)}`;
      }
    }

    // Clip/Video generation requests
    if (lower.includes('video') || lower.includes('clip') || lower.includes('short') || lower.includes('film') || lower.includes('movie')) {
      const duration = parseInt(lower.match(/\d+/)?.[0]) || 5;
      if (autoling) {
        const result = autoling.generateClip({ gate, duration, style: 'cinematic' });
        return `Clip Storyboard: "${result.title}"

Logline: ${result.logline}

Storyboard:
${result.storyboard.map(s => `  ${s.time}: ${s.description} [${s.transition}]`).join('
')}

Camera: ${JSON.stringify(result.cameraWork, null, 2)}

Audio: ${JSON.stringify(result.audioDirection, null, 2)}`;
      }
    }

    // Content generation (story, game)
    if (lower.includes('story') || lower.includes('game') || lower.includes('narrative')) {
      const type = lower.includes('game') ? 'game' : 'story';
      if (autoling) {
        const result = autoling.generateContent(type, { gate });
        return `Generated ${type} (Gate ${gate}):

${result}`;
      }
    }

    // Grammar expansion
    if (lower.includes('grammar') || lower.includes('sentence') || lower.includes('language')) {
      if (autoling) {
        const sentence = autoling.generate(gate);
        return `Gate ${gate} Grammar Expansion:

${sentence}`;
      }
    }

    // File transformation
    if (lower.includes('transform') || lower.includes('convert') || lower.includes('python') || lower.includes('json') || lower.includes('markdown')) {
      return 'Drop any file on the desktop to auto-transform it. AUTOLING handles: .py → .js, .json → .js, .md → .html, .css → .js, .html → .js';
    }

    // Status
    if (lower.includes('status') || lower.includes('mesh') || lower.includes('system')) {
      const modules = this.mesh ? Array.from(this.mesh.modules.keys()) : [];
      return `Mesh Status:
• Modules: ${modules.join(' · ')}
• Phase: ${this.mesh?.phase || 'unknown'}
• Coordinate: ${JSON.stringify(this.mesh?.coordinate)}
• AUTOLING: ${autoling ? 'online' : 'offline'}`;
    }

    return `I am AUTOLING — the Novel Writer, Code Synthesizer, Image Director, and Clip Architect.

I can:
• **Write code**: "code a shader for gate 36" or "generate a React component for data visualization"
• **Generate images**: "image of a crystalline figure" or "photo of entropy event"
• **Direct clips**: "5 second clip of crisis rupture" or "video storyboard for gate 61"
• **Expand grammar**: "sentence for gate 24" or "Klein expansion"
• **Transform files**: Drop Python, JSON, Markdown, CSS, HTML files anywhere
• **Generate stories/games**: "story for gate 35" or "game mechanic for gate 36"

What would you like to create?`;
  }

  onRegister(mesh) {
    this.mesh = mesh;
    mesh.on('agent:input', (packet) => {
      const response = this.respond(packet.data.input);
      mesh.emit('agent:output', { response, input: packet.data.input });
    });
  }

  render() {
    return `<div style="display:flex;flex-direction:column;height:100%;gap:8px;">
      <div id="agent-chat" style="flex:1;overflow-y:auto;background:#0a0614;padding:10px;border-radius:6px;font-size:12px;line-height:1.6;">
        <div style="color:#a855f7;margin-bottom:8px;"><strong>AUTOLING Agent:</strong> Novel Writer · Code Synthesizer · Image Director · Clip Architect</div>
        <div style="color:#6b5b8a;margin-bottom:8px;">Ask me to write code, generate images, direct clips, or expand grammar.</div>
      </div>
      <div style="display:flex;gap:8px;">
        <input type="text" id="agent-input" style="flex:1;" placeholder="Create something..." />
        <button class="btn btn-primary" onclick="mesh.emit('agent:input', {input: document.getElementById('agent-input').value}); document.getElementById('agent-input').value=''">Create</button>
      </div>
    </div>`;
  }
}

class LatticeApp {
  onRegister(mesh) {
    this.mesh = mesh;
    mesh.on('coordinate:changed', (packet) => {
      const { gate, base } = packet.data;
      const substrate = mesh.get('substrate');
      if (substrate) {
        substrate.setParams({
          hue: 240 + (base * 15),
          accentHue: 300 + (gate % 20),
          temperature: 1.5 + (gate % 8) * 0.3
        });
      }
    });
  }
  render() {
    return `<div style="display:flex;flex-direction:column;height:100%;gap:8px;">
      <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px;">
        ${['MOVEMENT','EVOLUTION','BEING','DESIGN','SPACE'].map((c,i) =>
          `<button onclick="mesh.setCoordinate(${i+1},1,1,1,${i+1})" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:var(--text-primary);border-radius:8px;padding:8px;cursor:pointer;font-size:10px;">${c}</button>`
        ).join('')}
      </div>
      <div id="lattice-info" style="flex:1;background:#0a0614;padding:12px;border-radius:8px;font-size:11px;color:#6b5b8a;font-family:monospace;">
        Coordinate: <span id="coord-display">1.1:1;1,1</span>
      </div>
    </div>`;
  }
}

class FileApp {
  constructor() { this.files = new Map(); }
  api() { return { save: (n, c) => this.save(n, c), load: (n) => this.load(n), list: () => this.list() }; }
  save(name, content) {
    this.files.set(name, content);
    try { localStorage.setItem(`file_${name}`, content); } catch(e) {}
    if (this.mesh) this.mesh.emit('file:saved', { name, size: content.length });
    return true;
  }
  load(name) {
    if (this.files.has(name)) return this.files.get(name);
    try { return localStorage.getItem(`file_${name}`); } catch(e) { return null; }
  }
  list() { return Array.from(this.files.keys()); }
  onRegister(mesh) {
    this.mesh = mesh;
    mesh.on('file:upload', (packet) => {
      const { file } = packet.data;
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target.result;
        const ext = file.name.split('.').pop().toLowerCase();
        this.save(file.name, content);
        mesh.emit('file:uploaded', { name: file.name, content, ext, size: file.size });
      };
      reader.readAsText(file);
    });
  }
  render() {
    return `<div style="display:flex;flex-direction:column;height:100%;gap:8px;">
      <div style="display:flex;gap:8px;">
        <button class="btn" onclick="document.getElementById('file-upload').click()">Upload</button>
        <input type="file" id="file-upload" style="display:none" onchange="const f=this.files[0]; if(f) mesh.emit('file:upload', {file: f})" />
      </div>
      <div id="file-list" style="flex:1;overflow-y:auto;background:#0a0614;padding:10px;border-radius:6px;font-size:12px;">No files</div>
    </div>`;
  }
}

window.AppRegistry = AppRegistry;
window.TerminalApp = TerminalApp;
window.AgentApp = AgentApp;
window.LatticeApp = LatticeApp;
window.FileApp = FileApp;