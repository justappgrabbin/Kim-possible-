// ═══════════════════════════════════════════════════════════
// MESH — Autopoietic Backbone
// Single source of truth. All modules register here.
// ═══════════════════════════════════════════════════════════

class Mesh {
  constructor() {
    this.modules = new Map();        // name -> { instance, api, deps }
    this.state = new Map();          // canonical state
    this.eventLog = [];              // chronological
    this.listeners = new Map();      // event -> [callbacks]
    this.coordinate = { gate: 1, line: 1, color: 1, tone: 1, base: 1 };
    this.phase = 'dormant';
    this.vitality = 15;
    this.cycle = 0;
    this.started = Date.now();
    this.autosaveTimer = null;
    this.startAutosave();
  }

  // ─── Module Lifecycle ───
  register(name, module, deps = []) {
    this.modules.set(name, { instance: module, deps, api: module.api || {} });
    if (module.onRegister) module.onRegister(this);
    console.log(`[MESH] ${name} registered`);
    return this;
  }

  get(name) {
    return this.modules.get(name)?.instance;
  }

  api(name) {
    return this.modules.get(name)?.api || {};
  }

  // ─── State ───
  set(key, value) {
    const old = this.state.get(key);
    this.state.set(key, value);
    this.emit('state:changed', { key, old, new: value, timestamp: Date.now() });
  }

  get(key) {
    return this.state.get(key);
  }

  // ─── Coordinates ───
  setCoordinate(gate, line, color, tone, base) {
    this.coordinate = { gate, line, color, tone, base };
    this.emit('coordinate:changed', { ...this.coordinate });
  }

  // ─── Events ───
  on(event, callback) {
    if (!this.listeners.has(event)) this.listeners.set(event, []);
    this.listeners.get(event).push(callback);
  }

  off(event, callback) {
    if (!this.listeners.has(event)) return;
    const arr = this.listeners.get(event);
    const idx = arr.indexOf(callback);
    if (idx > -1) arr.splice(idx, 1);
  }

  emit(event, data) {
    const packet = { event, data, timestamp: Date.now(), coordinate: { ...this.coordinate } };
    this.eventLog.push(packet);
    if (this.eventLog.length > 10000) this.eventLog.shift();
    (this.listeners.get(event) || []).forEach(cb => {
      try { cb(packet); } catch(e) { console.error(`[MESH] ${event} handler error:`, e); }
    });
    // Also emit to substrate if visual
    if (event.startsWith('app:') || event.startsWith('file:') || event.startsWith('lattice:')) {
      const substrate = this.get('substrate');
      if (substrate && data.x !== undefined && data.y !== undefined) {
        substrate.perturb(data.x || window.innerWidth/2, data.y || window.innerHeight/2, 0.3);
      }
    }
  }

  // ─── Autosave ───
  startAutosave() {
    this.autosaveTimer = setInterval(() => this.save(), 30000);
  }

  save() {
    const snapshot = {
      state: Object.fromEntries(this.state),
      coordinate: this.coordinate,
      phase: this.phase,
      vitality: this.vitality,
      cycle: this.cycle,
      eventLog: this.eventLog.slice(-500),
      timestamp: Date.now()
    };
    try {
      localStorage.setItem('mesh_snapshot', JSON.stringify(snapshot));
    } catch(e) {}
    this.emit('mesh:saved', snapshot);
  }

  load() {
    try {
      const raw = localStorage.getItem('mesh_snapshot');
      if (!raw) return false;
      const snap = JSON.parse(raw);
      if (snap.state) Object.entries(snap.state).forEach(([k,v]) => this.state.set(k, v));
      if (snap.coordinate) this.coordinate = snap.coordinate;
      if (snap.phase) this.phase = snap.phase;
      if (snap.vitality) this.vitality = snap.vitality;
      this.emit('mesh:loaded', snap);
      return true;
    } catch(e) { return false; }
  }

  // ─── Lifecycle ───
  tick() {
    this.cycle++;
    const idle = Date.now() - (this.get('lastActivity') || this.started);
    const newPhase = idle > 120000 ? 'dormant' : idle < 30000 ? 'active' : 'observant';
    if (newPhase !== this.phase) {
      const old = this.phase;
      this.phase = newPhase;
      this.emit('phase:changed', { from: old, to: newPhase });
    }
    this.emit('mesh:tick', { cycle: this.cycle, phase: this.phase });
  }

  start() {
    setInterval(() => this.tick(), 5000);
    this.emit('mesh:started', { timestamp: Date.now() });
  }
}

window.Mesh = Mesh;