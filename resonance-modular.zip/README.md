# RESONANCE — Modular Mesh System

## Architecture

### Three Layers, Clean Separation

| Layer | File | Responsibility | Isolation |
|-------|------|---------------|-----------|
| **L1 Substrate** | `substrate.js` | Pure visual mesh. Purple, breathing, Ising-model spin grid. | No app logic. No events. Only `perturb()` API. |
| **L2 Mesh** | `mesh.js` | Autopoietic backbone. Module registry, state, events, coordinates, autosave. | All communication goes through here. |
| **L3 AUTOLING** | `autoling.js` | Generative engine. Klein grammar trees, file transformers, content generators. | Plugs into mesh, responds to events. |
| **L3 Apps** | `apps.js` | Modular applications. Terminal, Agent, Lattice, File Manager. | Each is self-contained, registers with mesh. |
| **Shell** | `shell.html` | Entry point. Loads modules, wires them, provides window manager + dock. | Thin bootstrap layer. |

## How It Works

### 1. The Substrate Is Pure

```javascript
const substrate = new Substrate('canvas-id');
// Only external API:
substrate.perturb(x, y, strength, radius);  // Visual ripple
substrate.setParams({ hue, temperature, coupling });  // Mood shift
```

The substrate knows nothing about gates, files, or apps. It just breathes purple and responds to perturbations.

### 2. The Mesh Is the Only Communication Channel

```javascript
const mesh = new Mesh();

// Register modules
mesh.register('substrate', substrate);
mesh.register('autoling', autoling);
mesh.register('terminal', terminalApp);

// Emit events
mesh.emit('file:uploaded', { name: 'script.py', ext: 'py' });

// Listen to events
mesh.on('file:uploaded', (packet) => {
  // packet = { event, data, timestamp, coordinate }
});
```

### 3. AUTOLING Handles Transformation

**File Transformers:**
- `.py` → `.js` (Python to JavaScript)
- `.json` → `.js` (JSON module)
- `.md` → `.html` (Markdown to HTML)
- `.css` → `.js` (CSS to style object)
- `.html` → `.js` (HTML component)

**Content Generators:**
- `photo` — DALL-E/Stable Diffusion prompts
- `video` — Temporal animation prompts
- `story` — Narrative openers
- `game` — Game mechanic descriptions

**Klein Grammar:**
- Recursive phrase-structure expansion
- Gate-specific grammars (61, 36, 35, 24)
- Real syntactic categories: S → NP → VP → PP

### 4. Apps Are Modular

Each app has:
```javascript
class MyApp {
  api() { return { /* public API */ }; }
  onRegister(mesh) { /* wire into mesh events */ }
  render() { return '<div>HTML string</div>'; }
}
```

## Coordinate System

All events carry a canonical coordinate:
```
Gate.Line:Color;Tone,Base
34.5:4;3,2
```

This unifies:
- Human Design (Gate/Line)
- 5D Lattice (Base → Center)
- Cognitive Spine (Gate → Channel)
- Substrate (Base → hue/temperature)

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Ctrl/Cmd + T` | Open Terminal |
| `Ctrl/Cmd + A` | Open Agent |
| `Ctrl/Cmd + L` | Open Lattice |
| `Ctrl/Cmd + O` | Open Files |
| `Ctrl/Cmd + H` | Toggle App Grid |
| `Escape` | Close Grid |

## To Use

1. Open `shell.html` in any browser
2. No build step. No dependencies. Pure vanilla JS.
3. Drop files anywhere to auto-transform via AUTOLING
4. Ask the Agent to generate content
5. Use Terminal to run commands and transform code

## Extending

Add a new app:
```javascript
class MyApp {
  render() { return '<div>My app</div>'; }
  onRegister(mesh) {
    mesh.on('myapp:command', (p) => { ... });
  }
}
mesh.register('myapp', new MyApp());
```

Add to the grid in `shell.html`:
```javascript
const appRegistry = [
  { id: 'myapp', icon: '★', label: 'My App' },
  // ...
];
```
